/*
 * Copyright 2024 NXP
 *
 * NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
 * used strictly in accordance with the applicable license terms. By expressly accepting such terms
 * or by downloading, installing, activating and/or otherwise using the software, you are agreeing
 * that you have read, and that you agree to comply with and are bound by, such license terms. If
 * you do not agree to be bound by the applicable license terms, then you may not retain, install,
 * activate or otherwise use the software.
 */

/**
 * @file
 * @brief Communication related components for the SwupCanHostif example.
 * @addtogroup PHSCA_UCICANFD
 * @{
 */
 

/*************************************************************************/
/* Includes                                                              */
/*************************************************************************/

/* SDK */
#include <phscaApi_Pwr.h>
#include <phscaApi_Status.h>
#include <phscaApi_Swup.h>
#include <phscaUci.h>

/* Custom */
#include <phscaCasFlexCan.h>
#include <phscaCasHal.h>
#include <phscaCasTools.h>

/* Application */
#include <phscaUciCanFd.h>


/*************************************************************************/
/* Preprocessor Definitions                                              */
/*************************************************************************/

/** @brief Uses extended (29-bit) or standard (11-bit) CAN IDs. */
#define PHSCA_UCICANFD_CAN_EXTENDED_ID_ENABLED      ((bool)true)
    
/** @brief Enable CAN-FD. */
#define PHSCA_UCICANFD_CAN_FD_ENABLED               ((bool)true)


/** @brief CRC-16 polynomial to use for host communication. */
#define PHSCA_UCICANFD_CRC_XMODEM_POLYNOMIAL        ((uint32_t)0x1021)


/** @brief UCI buffer size to receive commands including the UCI header. */
#define PHSCA_UCICANFD_UCI_CMD_BUFFER_SIZE          ((uint32_t)8192u)

/** @brief UCI buffer size to transmit responses including the UCI header. */
#define PHSCA_UCICANFD_UCI_RSP_BUFFER_SIZE          ((uint32_t)2048u)

/** 
 * @brief Maximum packet size of a UCI message. 
 * For CAN-FD: Set to 64
 * For Classic CAN: Set to 8
 */
#define PHSCA_UCICANFD_UCI_MAX_PACKETSIZE           ((uint8_t)64u)       


/** @brief: Number of TX and RX message buffers. */
#define PHSCA_UCICANFD_NUM_MB                       ((uint8_t)1u)

/** 
 * @brief: Maximum payload length of TX and RX message buffers.
 * For CAN-FD: Set to 64
 * For Classic CAN: Set to 8
 */#define PHSCA_UCICANFD_MAX_PAYLOAD_LENGTH_MB     ((uint8_t)64u)      

      
/*************************************************************************/
/* Private Type Definitions                                              */
/*************************************************************************/
      

/*************************************************************************/
/* Private Function Prototypes                                           */
/*************************************************************************/

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to register callbacks upon message reception. */
static void phscaUciCanFd_PhyCom_RegisterCallbacks(
    pphscaCom_ReceiveMsgCb_t const receiveCallback, pphscaCom_ReceiveMsgErrorCb_t const receiveErrorCallback);

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to registers callbacks upon message transmission. */
static void phscaUciCanFd_PhyCom_RegisterTransmissionDoneCallback(
    pphscaCom_TransmitMsgCb_t const transmissionDoneCallback);

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to start the physical (CAN) communication. */
static phscaApi_Status_t phscaUciCanFd_PhyCom_Start(void);

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to stop the physical (CAN) communication. */
static void phscaUciCanFd_PhyCom_Stop(void);

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to transmit a (CAN) message. */
static phscaApi_Status_t phscaUciCanFd_PhyCom_TransmitMessage(uint16_t const size, uint8_t const* const message);

/**
 * @brief Callback called on a successful command message reception. This function saves the received UCI frame.
 * Interface to @ref skphscaUciCanFd_UciConfig.
 * @param[in] groupId The Group Identifier (GID) indicates the categorization of the command message.
 * @param[in] opCodeId The Opcode Identifier (OID) indicates the identification of the command message.
 * @param[in] payloadSize The size of the received payload in bytes.
 * @param[in] payload The received payload.
 */
void phscaUciCanFd_Uci_CommandCallback(
    uint8_t const groupId, uint8_t const opCodeId, uint32_t const payloadSize, uint8_t const *const payload);

/** @brief Callback called on finished message transmission. */
static void phscaUciCanFd_Uci_TxFinishedCallback(void);

/** @brief Callback after every CAN frame transmission. */
static void phscaUciCanFd_Can_TxCallback(const uint8_t txMbIndex, const phscaFlexcan_TransferStatus_t status);

/** @brief Callback after every CAN frame reception. */
static void phscaUciCanFd_Can_RxCallback(const uint8_t rxMbIndex, const phscaFlexcan_TransferStatus_t status);


/*************************************************************************/
/* Private Variables                                                     */
/*************************************************************************/

/*--- Function pointers ---*/
/** @brief Callback to UCI module to indicate that a transmission is done. */
static pphscaCom_TransmitMsgCb_t spphscaUciCanFd_TransmissionDoneCallback = NULL;


/*--- UCI related variables ---*/
/** @brief Protected UCI command buffer. Used for receiving a UCI command from host. */
static uint8_t sphscaUciCanFd_UciCommandBuffer[PHSCA_UCICANFD_UCI_CMD_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;

/** @brief Protected UCI response buffer. Used for sending a UCI response to host including header. */
static uint8_t sphscaUciCanFd_UciResponseBuffer[PHSCA_UCICANFD_UCI_RSP_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;

/** @brief Protected UCI notification buffer. Used for sending one or more notifications to host. */
static uint8_t sphscaUciCanFd_UciNotificationBuffer[PHSCA_UCICANFD_UCI_NTF_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;

/** @brief Open UCI command payload buffer. */
static uint8_t sphscaUciCanFd_UciOpenCommandBuffer[PHSCA_UCICANFD_UCI_CMD_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;

/** @brief Open UCI response buffer. Used for buffering a UCI response before sending. */
static uint8_t sphscaUciCanFd_UciOpenResponseBuffer[PHSCA_UCICANFD_UCI_RSP_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;


/** @brief Length of a reeived UCI command. */
static uint32_t sphscaUciCanFd_UciOpenCommandPayloadLength = 0u;


/** @brief This flag indicates if UCI is initialized. */
static volatile bool sphscaUciCanFd_UciIsInit = false;

/** @brief Gid of the received frame. It is updated from @ref phscaUciCanFd_CommandCallback. */
static volatile uint8_t sphscaUciCanFd_UciGid;

/** @brief Oid of the received frame. It is updated from @ref phscaUciCanFd_CommandCallback. */
static volatile uint8_t sphscaUciCanFd_UciOid;

/** @brief Indication of newly received frame. It is updated from @ref phscaUciCanFd_CommandCallback. */
static volatile bool sphscaUciCanFd_UciNewCommand = false;


/*--- CAN related variables ---*/

/** @brief: CAN clock configurations */
static phscaApi_ClkClockSourceSwitchCtrl_t const skphscaUciCanFd_ClkSrcCtrlCan = 
{
    .canFreq        = PHSCAAPI_CLK_CAN_80M,
    .clkDiv         = PHSCAAPI_CLK_DIV1,
    .clkPin         = PHSCAAPI_CLK_XTAL,
    .clkPinFreq     = PHSCAAPI_CLK_FREQ55M2,
    .clkSrcConfig   = 
    {
        .clkPinEnable   = 1u, 
        .gpPllEnable    = 1u
    },
//    .cLoad          = 0u,                     ???
    .cpuClkSrc      = PHSCAAPI_CLK_GPPLL,
//    .sysTickSel     = PHSCAAPI_CLK_SYSTICK_FRODIV128,
//    .xtalBias       = PHSCAAPI_CLK_XTAL_BIAS_OFF    
};

/** @brief: Default clock configuration */
static phscaApi_ClkClockSourceSwitchCtrl_t const skphscaUciCanFd_ClkSrcCtrlDefault = 
{
    .canFreq        = PHSCAAPI_CLK_CAN_OFF,
    .clkDiv         = PHSCAAPI_CLK_DIV1,
    .clkPin         = PHSCAAPI_CLK_XTAL,
    .clkPinFreq     = PHSCAAPI_CLK_FREQ55M2,
    .clkSrcConfig   = 
    {
        .clkPinEnable   = 0u, 
        .gpPllEnable    = 0u
    },
//    .cLoad          = 0u,                     ???
    .cpuClkSrc      = PHSCAAPI_CLK_FRO,
//    .sysTickSel     = PHSCAAPI_CLK_SYSTICK_FRODIV128,
//    .xtalBias       = PHSCAAPI_CLK_XTAL_BIAS_OFF    
};

/** 
 * @brief: CAN TX message buffer.
 * Only one (of a maximum of PHSCACASFLEXCAN_TX_MESSAGE_BUFFER_COUNT = 7) message buffers is initialized.
 * Because CAN-FD is used, a maxmimum of 64 bytes are transmitted.
 * Payload is padded with PHCSACASFLEXCAN_PADDING_BYTE_VALUE for payload lengths that are not aligned with DLC.
 */
static phscaCasFlexCan_TxMbDescriptor sphscaUciCanFd_TxMbDescriptors[PHSCA_UCICANFD_NUM_MB] = 
{
    [0u] =
    {
        .id                 = PHSCA_UCICANFD_CAN_TX_ID,
        .isExtendedId       = PHSCA_UCICANFD_CAN_EXTENDED_ID_ENABLED,
        .isFd               = PHSCA_UCICANFD_CAN_FD_ENABLED,
        .isMbEnabled        = true,
        .mbIndex            = 0u,
        .txPayload          = {0x00u},
        .txPayloadLength    = PHSCA_UCICANFD_MAX_PAYLOAD_LENGTH_MB,
    }
};

/**
 * @brief: CAN RX message buffer designated for UCI communication
 * Only one (of a maximum of PHSCACASFLEXCAN_TX_MESSAGE_BUFFER_COUNT = 7) message buffers is initialized.
 * Because CAN-FD is used, a maxmimum of 64 bytes are transmitted.
 */
static phscaCasFlexCan_RxMbDescriptor sphscaUciCanFd_RxMbDescriptors[PHSCA_UCICANFD_NUM_MB] = 
{
    [0u] =
    {
        .isExtendedId       = PHSCA_UCICANFD_CAN_EXTENDED_ID_ENABLED,
        .isFd               = PHSCA_UCICANFD_CAN_FD_ENABLED,
        .isMbEnabled        = true,
        .mbIndex            = 7u,
        /* This message buffer shall receive message ID's 0x000 -> 0x0FF */
        .rxId               = PHSCA_UCICANFD_CAN_RX_ID,
        .rxIdFilterMask     = PHSCA_UCICANFD_CAN_RX_ID,
    }
};


/*--- Configuration structs ---*/
/** @brief Physical communication access configuration. */
static const phscaCom_Access_t skphscaUciCanFd_PhyComAccess = 
{
    .registerCallbacks      = phscaUciCanFd_PhyCom_RegisterCallbacks,
    .registerTransmitCallback = phscaUciCanFd_PhyCom_RegisterTransmissionDoneCallback,
    .start                  = phscaUciCanFd_PhyCom_Start,
    .stop                   = phscaUciCanFd_PhyCom_Stop,
    .transmitMsg            = phscaUciCanFd_PhyCom_TransmitMessage,
};

/** @brief CRC configuration parameters. */
static const phscaCrc_ConfigParams_t  __attribute__((unused)) skphscaUciCanFd_CrcConfig = 
{
    .resultReflect          = 0u,
    .inputReflect           = 0u,
    .initRem                = 0u,
    .poly                   = PHSCA_UCICANFD_CRC_XMODEM_POLYNOMIAL,
    .finalXor               = 0u
};


/** @brief UCI configuration data. */
static const phscaUci_Config_t skphscaUciCanFd_UciConfig = 
{
    .comAccessStruct        = &skphscaUciCanFd_PhyComAccess,
    .commandBuffer          = &sphscaUciCanFd_UciCommandBuffer[0u],
    .commandBufferSize      = (uint16_t)sizeof(sphscaUciCanFd_UciCommandBuffer),
    .commandCb              = phscaUciCanFd_Uci_CommandCallback,
    .crcConfig              = NULL,
    .maxPacketSize          = (uint16_t)PHSCA_UCICANFD_UCI_MAX_PACKETSIZE,
    .notificationBuffer     = &sphscaUciCanFd_UciNotificationBuffer[0u],
    .notificationBufferSize = (uint16_t)sizeof(sphscaUciCanFd_UciNotificationBuffer),
    .pbfConfig              = PHSCA_UCI_CONFIG_PBF_ON,
    .responseBuffer         = &sphscaUciCanFd_UciResponseBuffer[0u],
    .responseBufferSize     = (uint16_t)sizeof(sphscaUciCanFd_UciResponseBuffer),
    .txFinishedCb           = phscaUciCanFd_Uci_TxFinishedCallback,
};


/*************************************************************************/
/* Private Functions                                                     */
/*************************************************************************/

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to register callbacks upon message reception. */
static void phscaUciCanFd_PhyCom_RegisterCallbacks(pphscaCom_ReceiveMsgCb_t const receiveCallback, 
                                                   pphscaCom_ReceiveMsgErrorCb_t const receiveErrorCallback)
{
    (void)receiveCallback;
    (void)receiveErrorCallback;
}

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to registers callbacks upon message transmission. */
static void phscaUciCanFd_PhyCom_RegisterTransmissionDoneCallback(pphscaCom_TransmitMsgCb_t const transmissionDoneCallback)
{
    spphscaUciCanFd_TransmissionDoneCallback = transmissionDoneCallback;
}

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to start the physical (CAN) communication. */
static phscaApi_Status_t phscaUciCanFd_PhyCom_Start(void)
{
    __NOP();
    return PHSCA_API_SUCCESS;
}

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to stop the physical (CAN) communication. */
static void phscaUciCanFd_PhyCom_Stop(void)
{
    __NOP();
}

/** @brief Interface to @ref skphscaUciCanFd_PhyComAccess to transmit a (CAN) message. */
static phscaApi_Status_t phscaUciCanFd_PhyCom_TransmitMessage(uint16_t const size, uint8_t const* const message)
{
    phscaApi_Status_t retVal = PHSCA_API_SUCCESS;

    __builtin_memcpy(&sphscaUciCanFd_TxMbDescriptors[0u].txPayload, message, size);
    sphscaUciCanFd_TxMbDescriptors[0u].txPayloadLength = size;
    retVal = phscaCasFlexCan_TransmitInterrupt(&sphscaUciCanFd_TxMbDescriptors[0u]);

    return retVal;
}

/** @brief Wrapper to send UCI responses. This should only occur from the phscaUciCanFd module.
 *
 * @param[in] groupId Group ID.
 * @param[in] opCodeId OPcode ID.
 * @param[in] payloadSize Payload length.
 */
static void phscaUciCanFd_Response(uint8_t const groupId, uint8_t const opCodeId, uint32_t const payloadSize)
{
    phscaApi_Status_t retVal = PHSCA_API_STATUS_INVALID;
    
    retVal = phscaUci_Response(groupId, opCodeId, payloadSize, &sphscaUciCanFd_UciOpenResponseBuffer[0u]);
    if (PHSCA_API_SUCCESS != retVal)
    {
        while(1);
    }
}

/**
 * @brief Wrapper to send UCI notification.
 *
 * @param[in] groupId Group ID.
 * @param[in] opCodeId OPcode ID.
 * @param[in] payloadSize Payload length.
 */
static void phscaUciCanFd_Notify(uint8_t const groupId, uint8_t const opCodeId, uint32_t const payloadSize)
{
    phscaApi_Status_t retVal = PHSCA_API_STATUS_INVALID;
    
    retVal = phscaUci_Notify(groupId, opCodeId, payloadSize, &gphscaUciCanFd_UciOpenNotificationBuffer[0u]);
    if (PHSCA_API_SUCCESS != retVal)
    {
        while(1);
    }
}

/** 
 * @brief Callback function called on a successful control message reception. 
 * @details Basic validity checks are performed. If the UCI command is valid, @ref sphscaUciCanFd_UciNewCommand is set 
 * to true, signalling the @ref phscaUciCanFd_Handler to further process the command.
 */
// add static?
void phscaUciCanFd_Uci_CommandCallback(uint8_t const groupId, uint8_t const opCodeId, 
                                       uint32_t const payloadSize, const uint8_t *const payload)
{
    /* Check if UCI packet has valid syntax */
    if (((uint8_t *)NULL == payload) && (0u < payloadSize))
    {
        sphscaUciCanFd_UciOpenResponseBuffer[0u] = (uint8_t)PHSCA_UCI_MSG_STATUS_SYNTAX_ERROR;
        phscaUciCanFd_Response(groupId, opCodeId, PHSCA_UCICANFD_SIZE_PAYLOAD_ONLY_STATUS);
    }
    
    /* Check if payload size is valid */
    else if (payloadSize > PHSCA_UCICANFD_UCI_CMD_BUFFER_SIZE)
    {
        sphscaUciCanFd_UciOpenResponseBuffer[0u] = (uint8_t)PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
        phscaUciCanFd_Response(groupId, opCodeId, PHSCA_UCICANFD_SIZE_PAYLOAD_ONLY_STATUS);
    }
    
    /* Check if another UCI command is still being processed */
    else if (true == sphscaUciCanFd_UciNewCommand)
    {
        sphscaUciCanFd_UciOpenResponseBuffer[0u] = (uint8_t)PHSCA_UCI_MSG_STATUS_REJECTED;
        phscaUciCanFd_Response(groupId, opCodeId, PHSCA_UCICANFD_SIZE_PAYLOAD_ONLY_STATUS);
    }
    else
    {    
        /* Save received data to process in task level. */
        sphscaUciCanFd_UciGid = groupId;
        sphscaUciCanFd_UciOid = opCodeId;

        /* Save the command payload. */
        sphscaUciCanFd_UciOpenCommandPayloadLength = payloadSize;
        sphscaUciCanFd_UciNewCommand = true;
    }
}

/** @brief Handles generic UCI commands that are not directed towards further modules. */
static phscaUci_Msg_Status_t phscaUciCanFd_GenericUciInputHandler(uint8_t const opCodeId)
{
    phscaUci_Msg_Status_t statusCode = PHSCA_UCI_MSG_STATUS_UNKNOWN_OID;
    
    switch ((phscaUciCanFd_UciOidGeneric_t)opCodeId)
    {
        case (uint8_t)PHSCA_UCICANFD_OID_GENERIC_DEBUG_LEDON:
        {
            phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_0);
            statusCode = PHSCA_UCI_MSG_STATUS_OK;
            break;
        }
        
        case (uint8_t)PHSCA_UCICANFD_OID_GENERIC_DEBUG_LEDOFF:
        {
            phscaCasHal_LedOff(PHSCA_CAS_HAL_LED_0);
            statusCode = PHSCA_UCI_MSG_STATUS_OK;
            break;
        }
        
        case (uint8_t)PHSCA_UCICANFD_OID_RESET_DEVICE:
        {
            phscaApi_PwrPlatformReset(PHSCAAPI_SW_PWR_ON_RST_SET);
            phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
            while(1);
        }
        
        case (uint8_t)PHSCA_UCICANFD_OID_GENERIC_BOOTUP:
        {
            /* Should never be called from host side */
            statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            break;
        }     
    }
    
    return statusCode;
}

/** @brief Callback called on finished message transmission. */
static void phscaUciCanFd_Uci_TxFinishedCallback(void)
{
    __NOP();
}

/** @brief Callback after every CAN frame transmission. */
static void phscaUciCanFd_Can_TxCallback(const uint8_t txMbIndex, const phscaFlexcan_TransferStatus_t status)
{
    (void)txMbIndex;
    (void)status;
    spphscaUciCanFd_TransmissionDoneCallback(PHSCA_API_SUCCESS);
}

/** @brief Callback after every CAN frame reception. */
static void phscaUciCanFd_Can_RxCallback(const uint8_t rxMbIndex, const phscaFlexcan_TransferStatus_t status)
{
    (void)status;

    static bool     ongoing_frag_transmission = false;
    static uint8_t  gid;
    static uint8_t  oid;
    static uint16_t len;
    
    phscaApi_Status_t               retVal  = PHSCA_API_ERR_FAIL;
    phscaCasFlexCan_RxMbDescriptor  *mBuff  = &sphscaUciCanFd_RxMbDescriptors[rxMbIndex - PHSCACASFLEXCAN_MESSAGE_BUFFER_OFFSET];

    /*--- Extract PBF, GID, OID and payload length ---*/
    uint8_t  pbf        = (uint8_t)(((uint8_t)mBuff->rxPayload[0u] & (uint8_t)(0x10u)) >> 4);
    uint8_t  curr_gid   = (uint8_t)((uint8_t)mBuff->rxPayload[0u] & (uint8_t)(0x0Fu));
    uint8_t  curr_oid   = (uint8_t)((uint8_t)mBuff->rxPayload[1u] & (uint8_t)(0x3Fu));
    uint16_t curr_len   = (uint16_t)((uint16_t)mBuff->rxPayload[2u] << (uint16_t)8u) | (uint16_t)mBuff->rxPayload[3u];
    
    
    /*--- Process incomming message ---*/
    bool completed_transmission     = false;
    
    /* New complete (non-fragmented) transmission */
    if ((false == ongoing_frag_transmission) && ((uint8_t)0u == (uint8_t)pbf))
    {
        (void)__builtin_memcpy(&sphscaUciCanFd_UciOpenCommandBuffer[0u], &mBuff->rxPayload[4u], curr_len);
        gid     = curr_gid;
        oid     = curr_oid;
        len     = curr_len;
        ongoing_frag_transmission   = false;
        completed_transmission      = true;
    }
    
    /* New fragmented transmission */
    else if ((false == ongoing_frag_transmission) && ((uint8_t)1u == (uint8_t)pbf))
    {
        (void)__builtin_memcpy(&sphscaUciCanFd_UciOpenCommandBuffer[0u], &mBuff->rxPayload[4u], curr_len);
        gid     = curr_gid;
        oid     = curr_oid;
        len     = curr_len;
        ongoing_frag_transmission   = true;
        completed_transmission      = false;
    }
    
    /* Existing fragmented transmission - still ongoing */
    else if ((true == ongoing_frag_transmission) && ((uint8_t)1u == (uint8_t)pbf))
    {
        if ((gid != curr_gid) || (oid != curr_oid))
        {        
            phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
            while(1u);
        }
        (void)__builtin_memcpy(&sphscaUciCanFd_UciOpenCommandBuffer[len], &mBuff->rxPayload[4u], curr_len);
        len     = len + curr_len;
        ongoing_frag_transmission   = true;
        completed_transmission      = false;
    }
    
    /* Existing fragmented transmission - ending*/
    else if ((true == ongoing_frag_transmission) && ((uint8_t)0u == (uint8_t)pbf))
    {
        if ((gid != curr_gid) || (oid != curr_oid))
        {        
            phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
            while(1u);
        }
        (void)__builtin_memcpy(&sphscaUciCanFd_UciOpenCommandBuffer[len], &mBuff->rxPayload[4u], curr_len);
        len     = len + curr_len;
        ongoing_frag_transmission   = false;
        completed_transmission      = true;
    }
    
    /* Error catch - program should never reach this point */
    else
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    
    /* Restart reception for this message buffer */
    retVal = phscaCasFlexCan_ReceiveInterrupt(&sphscaUciCanFd_RxMbDescriptors[rxMbIndex - PHSCACASFLEXCAN_MESSAGE_BUFFER_OFFSET]);
    if(retVal != PHSCA_API_SUCCESS)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    /* Call the UCI command callback. */
    if (true == completed_transmission)
    {
        phscaUciCanFd_Uci_CommandCallback(gid, oid, (uint32_t)len, &sphscaUciCanFd_UciOpenCommandBuffer[0u]);
    }
}

/*************************************************************************/
/* Public Type Definitions                                               */
/*************************************************************************/


/*************************************************************************/
/* Public Variables                                                      */
/*************************************************************************/

/** @brief Open UCI notification buffer. Used for buffering a UCI notification before sending. */
uint8_t gphscaUciCanFd_UciOpenNotificationBuffer[PHSCA_UCICANFD_UCI_NTF_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;

/** @brief GID of the current notification. */
uint8_t gphscaUciCanFd_UciNotificationGid;

/** @brief OID of the current notification. */
uint8_t gphscaUciCanFd_UciNotificationOid;

/** @brief Length of the current notification. */
uint32_t gphscaUciCanFd_UciNotificationLength = 0u;

/** @brief Indication of newly set notification frame. It is updated from @ref phscaUciCanFd_CommandCallback. */
bool gphscaUciCanFd_UciNewNotification = false;


/*************************************************************************/
/* Public Functions                                                      */
/*************************************************************************/

/** 
 * @brief Load SBE and activate CAN Clock 
 * @pre This function requires SWUP to be active
 */
void phscaUciCanFd_ActivateCanHw(void)
{
    phscaApi_Status_t retVal = PHSCA_API_STATUS_INVALID;
    
    /* Load SBE, such that phscaApis are available */
    retVal = phscaApi_Swup_LoadSBE();
    if (PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while (1u);
    }
        
    /* Activate XTAL */
    retVal = phscaApi_ClkSwitchClockSource(&skphscaUciCanFd_ClkSrcCtrlCan);
    if (PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while (1u);
    }

    phscaCasHal_LedOff(PHSCA_CAS_HAL_LED_0);
}

/** 
 * @brief Deactivate CAN Clock and unload SBE
 * @pre This function requires SWUP to be active
 */
void phscaUciCanFd_DeactivateCanHw(void)
{
    phscaApi_Status_t retVal = PHSCA_API_STATUS_INVALID;
    
    phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_0);

    retVal = phscaApi_ClkSwitchClockSource(&skphscaUciCanFd_ClkSrcCtrlDefault);
    if (PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while (1u);
    }  
            
    retVal = phscaApi_Swup_UnLoadSBE();
    if (PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }   
}

/**
 * @brief Initialize CAN-FD interface and UCI. 
 * @pre DMA needs to be initialized.
 */
void phscaUciCanFd_Init(void)
{
    phscaApi_Status_t retVal = PHSCA_API_STATUS_INVALID;
    
    /* Initialize FlexCAN */
    retVal = phscaCasFlexCan_Init(PHSCA_UCICANFD_CAN_FD_ENABLED);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }

    /* Configure CAN TX callback */
    retVal = phscaCasFlexCan_SetTxCallback(phscaUciCanFd_Can_TxCallback);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    /* Configure CAN RX callback */
    retVal = phscaCasFlexCan_SetRxCallback(phscaUciCanFd_Can_RxCallback);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    /* Configure CAN TX message buffer */
    retVal = phscaCasFlexCan_ConfigureTxMessageBuffers(sphscaUciCanFd_TxMbDescriptors);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    /* Configure CAN RX message buffer */
    retVal = phscaCasFlexCan_ConfigureRxMessageBuffers(sphscaUciCanFd_RxMbDescriptors);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    /* Set CAN RX message buffers to allow interrupts */
    retVal = phscaCasFlexCan_ReceiveInterrupt(&sphscaUciCanFd_RxMbDescriptors[0u]);
    if (PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while (1u);
    }
    
    /* Initialize UCI */   
    retVal = phscaUci_Init(&skphscaUciCanFd_UciConfig);
    if (PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while (1u);
    }
    sphscaUciCanFd_UciIsInit = true;
}


/** 
 * @brief Indication function for UCI events. 
 * @details The handler function is to be called periodically. It processes all UCI inputs and refers the input to the
 * correct UciInputHandler. This function is build generically to include further GIDs for multiple UciInputHandlers.
 * In this example, only a generic GID and a custom GID are relevant.
 */
void phscaUciCanFd_Handler(void)
{
    phscaUci_Msg_Status_t statusCode = PHSCA_UCI_MSG_STATUS_FAILED;

    /* Check for new (valid) UCI command */
    if (true == sphscaUciCanFd_UciNewCommand)
    {
        /* Save current state of volatile variables */      //necessary?
        const uint8_t gid = sphscaUciCanFd_UciGid;
        const uint8_t oid = sphscaUciCanFd_UciOid;
        
        statusCode = (uint8_t)PHSCA_UCI_MSG_STATUS_UNKNOWN_GID;
        
        /* Process GID codes */
        switch ((phscaUciCanFd_UciGidCodes_t)gid)
        {
            case (uint8_t)PHSCA_UCICANFD_GID_GENERIC:
            {
                statusCode = phscaUciCanFd_GenericUciInputHandler(oid);
                break;
            }
            
            case (uint8_t)PHSCA_UCICANFD_GID_CUSTOM:
            {
                statusCode = (uint8_t)PHSCA_UCI_MSG_STATUS_UNKNOWN_OID;
                
                switch((phscaUciCanFd_UciOidCustom_t)oid)
                {
                    case(PHSCA_UCICANFD_OID_CUSTOM_ACTIVATE_SWUP):
                    {
                        phscaApi_Swup_Activate(0u);
                    }
                }
            }
        }
                   
        /* Reset flag, as new command has been processed */
        sphscaUciCanFd_UciNewCommand = false;
        
        /* Send response */
        sphscaUciCanFd_UciOpenResponseBuffer[PHSCA_UCICANFD_RESPONSE_STATUS_OFFSET] = (uint8_t)statusCode;
        phscaUciCanFd_Response(gid, oid, PHSCA_UCICANFD_SIZE_PAYLOAD_ONLY_STATUS);
    }
    
    /* Check for outgoing notification */
    if (true == gphscaUciCanFd_UciNewNotification)
    {
        phscaUciCanFd_Notify(gphscaUciCanFd_UciNotificationGid, 
                             gphscaUciCanFd_UciNotificationOid,
                             gphscaUciCanFd_UciNotificationLength);
        
        gphscaUciCanFd_UciNewNotification = false;
    }
}


/**@}*/
