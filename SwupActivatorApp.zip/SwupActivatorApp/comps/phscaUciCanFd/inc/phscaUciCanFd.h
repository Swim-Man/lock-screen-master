/*
 * Copyright 2024 NXP
 *
 * NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
 * used strictly in accordance with the applicable license terms. By expressly accepting such terms
 * or by downloading, installing, activating and/or otherwise using the software, you are agreeing
 * that you have read, and that you agree to comply with and are bound by, such license terms. If
 * you do not agree to be bound by the applicable license terms, then you may not retain, install,
 * activate or otherwise use the software.
 */

/**
 * @file
 * @brief Communication related components for the SwupCanHostif example.
 * @addtogroup phscaUciCanFd
 * @{
 */
 

#ifndef PHSCAUCICANFD_H
#define PHSCAUCICANFD_H

/*************************************************************************/
/* Includes                                                              */
/*************************************************************************/

/* SDK */
#include <phscaApi_Status.h>
#include <phscaUci.h>

/* Custom */
#include <phscaCasFlexCan.h>
#include <phscaCasTools.h>


/*************************************************************************/
/* Preprocessor Definitions                                              */
/*************************************************************************/

/*--- CAN IDs ---*/
/** @brief CAN ID to be used for all CAN messages transmitted by this device. */
#define PHSCA_UCICANFD_CAN_TX_ID                    (0x011u)

/** @brief CAN ID to be received by this device. */
#define PHSCA_UCICANFD_CAN_RX_ID                    (0x001u)


/*--- Sizes ---*/
/** @brief UCI buffer size to transmit notifications including the UCI header. */
#define PHSCA_UCICANFD_UCI_NTF_BUFFER_SIZE          ((uint32_t)8349u)

/** @brief Size of the payload consisting of solely one status code. */
#define PHSCA_UCICANFD_SIZE_PAYLOAD_ONLY_STATUS     ((uint8_t)1u)


/*--- Offsets ---*/
/** @brief Offset in response buffer for response status codes. */
#define PHSCA_UCICANFD_RESPONSE_STATUS_OFFSET       ((uint8_t)0u)


/*************************************************************************/
/* Private Type Definitions                                              */
/*************************************************************************/


/*************************************************************************/
/* Private Variables                                                     */
/*************************************************************************/

    
/*************************************************************************/
/* Private Functions                                                     */
/*************************************************************************/


/*************************************************************************/
/* Public Type Definitions                                               */
/*************************************************************************/

/** @brief Command Groupd Identifiers (GIDs). */
typedef enum __PACKED
{
    /** @brief UCI Generic Group. */
    PHSCA_UCICANFD_GID_GENERIC  = (uint8_t)0x00u,
    
    /** @brief Custom commands */
    PHSCA_UCICANFD_GID_CUSTOM   = (uint8_t)0x0Eu,
    
} phscaUciCanFd_UciGidCodes_t;

/** @brief Command Opcode Identifiers (OIDs) for GID_GENERIC. */
typedef enum __PACKED
{
    /** @brief Turn Led0 on (for debugging purposes). */
    PHSCA_UCICANFD_OID_GENERIC_DEBUG_LEDON          = (uint8_t)0x00,
    
    /** @brief Turn Led0 off (for debugging purposes). */
    PHSCA_UCICANFD_OID_GENERIC_DEBUG_LEDOFF         = (uint8_t)0x01,
        
    /** @brief Boot up notification. */
    PHSCA_UCICANFD_OID_GENERIC_BOOTUP               = (uint8_t)0x0A,
            
    /** @brief Reset device. */
    PHSCA_UCICANFD_OID_RESET_DEVICE                 = (uint8_t)0x0E,
        
} phscaUciCanFd_UciOidGeneric_t;

/** @brief Command Opcode Identifiers (OIDs) for GID_CUSTOM. */
typedef enum __PACKED
{
    /** @brief Activate SWUP. */
    PHSCA_UCICANFD_OID_CUSTOM_ACTIVATE_SWUP         = (uint8_t)0x12,
        
} phscaUciCanFd_UciOidCustom_t;

/*************************************************************************/
/* Public Variables                                                      */
/*************************************************************************/

/** @brief Open UCI notification buffer. Used for buffering a UCI notification before sending. */
extern uint8_t gphscaUciCanFd_UciOpenNotificationBuffer[PHSCA_UCICANFD_UCI_NTF_BUFFER_SIZE] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN;

/** @brief Length of the current notification. */
extern uint32_t gphscaUciCanFd_UciNotificationLength;

/** @brief GID of the current notification. */
extern uint8_t gphscaUciCanFd_UciNotificationGid;

/** @brief OID of the current notification. */
extern uint8_t gphscaUciCanFd_UciNotificationOid;

/** @brief Indication of newly set notification frame. It is updated from @ref phscaUciCanFd_CommandCallback. */
extern bool gphscaUciCanFd_UciNewNotification;

/*************************************************************************/
/* Public Functions                                                      */
/*************************************************************************/

/** @brief Load SBE and activate CAN Clock */
void phscaUciCanFd_ActivateCanHw(void);

/** @brief Deactivate CAN Clock and unload SBE*/
void phscaUciCanFd_DeactivateCanHw(void);

/**
 * @brief Initialize CAN-FD interface and UCI. 
 * @pre DMA needs to be initialized.
 */
void phscaUciCanFd_Init(void);

/** @brief Indication function for UCI events. */
void phscaUciCanFd_Handler(void);


/**@}*/
#endif /* PHSCAUCICANFD_H */
