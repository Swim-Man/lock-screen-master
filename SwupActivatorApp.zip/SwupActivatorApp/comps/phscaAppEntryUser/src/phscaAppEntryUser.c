/*
 *  Copyright 2022-2024 NXP
 *
 *  NXP Confidential and Proprietary. This software is owned or controlled
 *  by NXP and may only be used strictly in accordance with the applicable
 *  license terms.  By expressly accepting such terms or by downloading,
 *  installing, activating and/or otherwise using the software, you are
 *  agreeing that you have read, and that you agree to comply with and are
 *  bound by, such license terms.  If you do not agree to be bound by the
 *  applicable license terms, then you may not retain, install, activate
 *  or otherwise use the software.
 */

/**
 * @file
 * @brief This file provides demonstration for application information page configurations needed for boot process.
 */

#include <phscaAppEntryUser.h>
#include <phscaAppEntryUser_Memory.h>
#include <phscaAppEntryUser_MemoryCheck.h>

/* User application main(). */
extern __NO_RETURN int main(void);

/** @brief The fast boot flag. */
static bool sphscaAppEntryUser_FastBoot = false;

/** @brief Get the fast boot flag. */
bool phscaAppEntryUser_GetFastBootFlag(void)
{
	return sphscaAppEntryUser_FastBoot;
}

/** @brief Clear the fast boot flag. */
void phscaAppEntryUser_ClearFastBootFlag(void)
{
	sphscaAppEntryUser_FastBoot = false;
}

/**
 * @brief Entry-point for fast-boot.
 * This point is reached when the user application is booted after a wake-up from DPD in fast-boot mode.
 */
__NO_RETURN static void phscaAppEntryUser_AppFastBoot(void)
{
	sphscaAppEntryUser_FastBoot = true;
	/* re-initialize system after fast boot */
	SystemInit();
	/* Call the user application main(). */
	main();
	/* Wait for a debugger */
	while (true)
	{
		if (0u != (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk))
		{
			__BKPT(0);
		}

		__WFE();
	}
}


/**
 * @brief Image header for this application.
 */
PHSCAAPPENTRYUSER_IMAGE_HEADER_APP_INFO_ATTRIBUTE phscaApi_ImageHeader_t const gkphscaAppEntryUser_AppImageHeader =
{
	/*
	 * Integrity check data (hash and CRC are to be filled in by post-build step)
	 *
	 * Integrity checks are not (yet) enabled.
	 */
	.integrity =
	{
		.hash     = {0u},
		.reserved = {0u},
		.crc      = 0x00000000u,
		.size     = (uint32_t) &gkphscaAppEntryUser_AppSize[0u] - sizeof(gkphscaAppEntryUser_AppImageHeader.integrity)
	},

	/* Type specific header (application image) */
	.specific =
	{
		.app =
		{
			/* Marker tag for valid applications */
			.type = PHSCAAPI_TAG_NS_APP,

			/* Version information (we currently report 0.0.0 with component ID 0) */
			.version   =
			{
				.major = 1u,
				.minor = 0u,
				.patch = 0u,
				.id	   = 0xA001u
			},
            
			/*
			 * Reference to the application's exception vector table
			 *
			 * The vector table (indirectly) defines the initial stack pointer and entry point for the
			 * standard boot flow.
			 */
			.vtorPtr = (uint32_t const* const)&__VECTOR_TABLE[0],

			/*
			 * Stack limit used for the standard boot flow.
			 */
			.mspStdLim = (uint32_t) &gkphscaAppEntryUser_AppStdMspStart[0u],

			/*
			 * Application entry point and stack setup for the fast (wake-up) boot flow (NOTE: currently not used)
			 */
			.fastAppEntry = phscaAppEntryUser_AppFastBoot,
			.mspFast      = (uint32_t) &gkphscaAppEntryUser_AppFastMspEnd[0u],
			.mspFastLim   = (uint32_t) &gkphscaAppEntryUser_AppFastMspStart[0u]
		}
	}
};

/**
 * @brief Primary application info structure.
 * @Note: In case user application is updated using SWUP package updater, then the application information is added by SWUP.
 * The @ref phscaApi_AppInfo_t defines the location of the application (and the software updater's
 * host interface - if any - within flash).
 */
PHSCAAPPENTRYUSER_APP_INFO_ATTRIBUTE phscaApi_AppInfo_t const gkphscaAppEntryUser_AppInfo =
{
	/* Marker tag for the application info structure */
	.tag    = (uint32_t) PHSCAAPI_TAG_NS_APP_INFO,
	.bundle =
	{
		.sectors =
		{
			.sectors =
			{
				/* Sectors shall be defined as they occur in memory (page offset is always raising) */
				/* Sectors shall not overlap */

				/* Fundamental sector: A sector for the AppInfo pages - full access allowed by application and SWUP, only for development purpose */
				/* Note: In security perspective it should not be writable by application in production use case */
				{
					.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_PAGE_OFFSET,
					.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_SIZE,
					.attributes  = phscaApi_Sectors_Attribute_Any
				},
				/* Fundamental sector: A sector for the SWUP hostIF backup - full access allowed by application and SWUP, only for development purpose */
				/* Note: In security perspective it should not be writable by application in production use case */
				{
					.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_PAGE_OFFSET,
					.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_SIZE,
					.attributes  = phscaApi_Sectors_Attribute_Any
				},
				/* An application code sector - full access allowed by application */
				{
					.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_PAGE_OFFSET,
					.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_SIZE,
					.attributes  = phscaApi_Sectors_Attribute_Any
				},
				/* An application data sector - full access allowed by application */
				{
					.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET,
					.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_SIZE,
					.attributes  = phscaApi_Sectors_Attribute_Any
				},
				/* A user key store sector - access should be allowed only for application */
				{
					.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_KEYSTORE_PAGE_OFFSET,
					.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_KEYSTORE_SIZE,
					.attributes  = phscaApi_Sectors_Attribute_Api
				},
				/* Fundamental sector: sector for the HIF - full access allowed by application and SWUP, only for development purpose */
				/* Note: In security perspective it should not be writable by application in production use case */
				{
					.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_PAGE_OFFSET,
					.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_SIZE,
					.attributes  = phscaApi_Sectors_Attribute_Any
				},
				/* Not used entries - 0 will be treated as phscaApi_Sectors_Attribute_None */
				{0}
			}
		},

		.components =
		{
			.components =
			{
			/* An application code component */
			{
				.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_PAGE_OFFSET,
				.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_SIZE,
				/* Combined (attributes phscaApi_Components_Attribute_Code | phscaApi_Components_Attribute_Const) would enforce integrity check */
				.attributes  = phscaApi_Components_Attribute_Code,
				.version =
				{
					.major = 0u,
					.minor = 0u,
					.patch = 0u,
					.id    = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_ID
				}
			},
			/* An application lib component */
			{
				.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_LIB_PAGE_OFFSET,
				.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_LIB_SIZE,
				.attributes  = phscaApi_Components_Attribute_Code,
				.version =
				{
					.major = 0u,
					.minor = 0u,
					.patch = 0u,
					.id    = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_LIB_ID
				}
			},
			/* An application constants component */
			{
				.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_PAGE_OFFSET,
				.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_SIZE,
				.attributes  = phscaApi_Components_Attribute_Data,
				.version =
				{
					.major = 0u,
					.minor = 0u,
					.patch = 0u,
					.id    = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_CONSTS_ID
				}
			},
			/* A Host Interface (HIF) component */
			{
				.page_offset = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_PAGE_OFFSET,
				.size        = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_SIZE,
				.attributes  = phscaApi_Components_Attribute_Code,
				.version =
				{
					.major = 0u,
					.minor = 0u,
					.patch = 0u,
					.id    = PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_ID
				}
			},
			{0}
			}
		},
		.application_boot_entries = {
			.boot_entries = { PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_ID, 0, 0, 0 }
		},
		.hostif_boot_entries = {
			.boot_entries = { PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_ID, 0, 0, 0 }
		}
	},

	/*! @note Reserved and explicitly initialized to 0 */
	.reserved = {0u}
};
