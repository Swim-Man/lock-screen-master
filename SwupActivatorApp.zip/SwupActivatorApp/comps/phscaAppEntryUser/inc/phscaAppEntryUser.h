/*
 *  Copyright 2021-2024 NXP
 *
 *  NXP Confidential and Proprietary. This software is owned or controlled
 *  by NXP and may only be used strictly in accordance with the applicable
 *  license terms.  By expressly accepting such terms or by downloading,
 *  installing, activating and/or otherwise using the software, you are
 *  agreeing that you have read, and that you agree to comply with and are
 *  bound by, such license terms.  If you do not agree to be bound by the
 *  applicable license terms, then you may not retain, install, activate
 *  or otherwise use the software.
 */

/**
 * @file
 * @brief This file provides normal domain demonstration of application information page of application to needed for boot process.
 */

#ifndef PHSCAAPPENTRYUSER_H
#define PHSCAAPPENTRYUSER_H

#include "RTE_Components.h"
#include CMSIS_device_header
#include <stdbool.h>

#include <phscaApi_Tag.h>
#include <phscaApi_AppInfo.h>
#include <phscaApi_Image.h>
#include <phscaApi_Types.h>
#include <phscaApi_Bundle.h>

#ifndef PHSCAAPPENTRYUSER_APP_INFO_ATTRIBUTE
/** @brief Generic section attribute definition to be used for application info structure. */
#define PHSCAAPPENTRYUSER_APP_INFO_ATTRIBUTE __attribute__((__section__(".APP_INFO"), __used__))
#endif

#ifndef PHSCAAPPENTRYUSER_IMAGE_HEADER_APP_INFO_ATTRIBUTE
/** @brief Generic section attribute definition to be used for application info image header structure. */
#define PHSCAAPPENTRYUSER_IMAGE_HEADER_APP_INFO_ATTRIBUTE __attribute__((__section__(".IMAGE_HEADER_APP_INFO"),__used__))
#endif

/** @brief Custom Component IDs */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_ID                      0xFAF0u
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_LIB_ID                           0xFAF1u
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_CONSTS_ID                        0xFAF2u

/** @brief Custom Host Interface (HIF) Component ID */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_ID                        0xFAFBu

/** @brief Entry type in the vector table. */
typedef void (*Vector_Table_Entry_t)(void);

/** @brief Vector table holding function pointers to vector handlers */
extern const Vector_Table_Entry_t __VECTOR_TABLE[];

/** @brief Generic application info structure constant. */
extern phscaApi_AppInfo_t const gkphscaAppEntryUser_AppInfo;

/** @brief Generic application info image header structure constant for primary or secondary. */
extern phscaApi_ImageHeader_t const gkphscaAppEntryUser_AppImageHeader;

/** @brief Application size in bytes */
extern uint8_t gkphscaAppEntryUser_AppSize[]          __asm__ ("Load$$LR$$LR_APP$$Length");

/**
 * @brief End (highest) address of the main stack (linker provided symbol).
 * It's used as stack base address, as ARM-M33 architecture prefers downward growing stack */
extern uint8_t gkphscaAppEntryUser_AppStdMspEnd[]     __asm__ ("Image$$ARM_LIB_STACK$$ZI$$Limit");

/**
 * @brief Start (lowest) address of the main stack (linker provided symbol).
 * It's used as limit address, as ARM-M33 architecture prefers downward growing stack. */
extern uint8_t gkphscaAppEntryUser_AppStdMspStart[]   __asm__ ("Image$$ARM_LIB_STACK$$ZI$$Base");

/**
 * @brief End (highest) address of the main stack for fast boot flow (linker provided symbol).
 * It's used as stack base address, as ARM-M33 architecture prefers downward growing stack */

extern uint8_t gkphscaAppEntryUser_AppFastMspEnd[]    __asm__ ("Image$$FAST_STACK$$ZI$$Limit");
/**
 * @brief Start (lowest) address of the main stack for fast boot flow(linker provided symbol).
 * It's used as limit address, as ARM-M33 architecture prefers downward growing stack. */
extern uint8_t gkphscaAppEntryUser_AppFastMspStart[]  __asm__ ("Image$$FAST_STACK$$ZI$$Base");

/** @brief Get fastboot flag. */
bool phscaAppEntryUser_GetFastBootFlag(void);

/** @brief Clear fastboot flag. */
void phscaAppEntryUser_ClearFastBootFlag(void);
	
#endif /* PHSCAAPPENTRYUSER_H */

/* EOF */
