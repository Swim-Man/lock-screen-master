/*
 *  Copyright 2021-2024 NXP
 *
 *  NXP Confidential and Proprietary. This software is owned or controlled
 *  by NXP and may only be used strictly in accordance with the applicable
 *  license terms.  By expressly accepting such terms or by downloading,
 *  installing, activating and/or otherwise using the software, you are
 *  agreeing that you have read, and that you agree to comply with and are
 *  bound by, such license terms.  If you do not agree to be bound by the
 *  applicable license terms, then you may not retain, install, activate
 *  or otherwise use the software.
 */

/**
 * @file
 * @brief This file provides normal domain memory address and component definitions.
 */

#ifndef PHSCAAPPENTRYUSER_MEMORY_H
#define PHSCAAPPENTRYUSER_MEMORY_H

#if (defined PHSCA_LINKER_SCOPE) && (PHSCA_LINKER_SCOPE != 0)
    #define PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(x) (x)
#else
    #include <stdint.h>
    #define PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(x) (UINT32_C(x))
#endif

/** 
 * User component memory address definitions
 */

/** @brief Start address of the user domain Flash memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_ADDRESS                    PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(0x00400000)

/** @brief Size of a Flash page (in bytes). */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGE_SIZE                  PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(0x1000)

/** @brief Available pages in the user Flash memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES                      PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(192)

/** @brief Size of the the user Flash memory in bytes*/
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_SIZE                       (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGE_SIZE * PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES)

/**
 * @brief Draft of user domain Flash Memory Map for SwupActivatorApp in SWUP CAN Hostif example
 *
 * =================================================  |---> Page offset: 0
 * ||                APPINFO (1 page)             ||
 * =================================================  |---> Page offset: 1
 * ||         SWUP SWD HOSTIF BKP (1 page)        ||
 * =================================================  |---> Page offset: 2
 * ||                                             ||
 * ||            USER MEMORY (172 pages)          ||
 * ||                                             ||
 * ||                                             ||
 * =================================================  |---> Page offset: 174
 * ||    Reserved for APP CONFIG PAGE (1 page)    ||
 * =================================================  |---> Page offset: 175
 * ||  Reserved for SWUP USER KEY STORE (1 page)  ||
 * =================================================  |---> Page offset: 176
 * ||          SWUP CAN HOSTIF A (8 pages)        ||
 * =================================================  |---> Page offset: 184
 * ||          SWUP CAN HOSTIF B (8 pages)        ||
 * =================================================  |---> Page offset: PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES = 192
 * 
 * Fundamental sectors and page offsets :  SHALL NOT BE CHANGED BY USER
 */

/** @brief The size in pages of AppInfo sector */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_SIZE                    PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(1)

/** @brief The size in pages of the SWUP Host Interface backup sector */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_SIZE             PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(1)

/** @brief The size in pages of the Host Interface (HIF) sector */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_SIZE                      PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(16)

/** @brief AppInfo occupies 1st user domain Flash page  */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_PAGE_OFFSET             PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(0)

/** @brief SWUP Host Interface backup occupies 2nd user domain Flash page */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_PAGE_OFFSET      (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_PAGE_OFFSET + PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_SIZE)

/** @brief Host Interface (HIF) occupies last 3 user domain Flash pages */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_PAGE_OFFSET               0xB7   // (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_SIZE)

/** @brief The size in pages of user user domain Flash memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_MEMORY_SIZE                 (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_INFO_SIZE - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_SIZE\
                                                      - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_HOSTIF_SIZE)
/** @brief The page offset of user user domain Flash memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_MEMORY_PAGE_OFFSET          (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_PAGE_OFFSET + PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_SWUP_HOSTIF_BKP_SIZE)

/** 
 * @brief Application specific sectors defined by user
 * The order, size and page offsets of sectors listed below can be changed, 
 * but still, occupied memory needs to fit between pages ( 2 ; (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - 3) )
 *
 * Draft of application code and data user domain Flash Memory Map
 *
 * ||             ||                    ...                      ||
 * ================================================================  |---> Page offset: 2
 * ||             ||                  APP CODE                   ||
 * ||             ||  (max PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - 16 pages)  ||
 * ||     USER    =================================================  |---> Page offset: (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - 4) - 10
 * ||    MEMORY   ||                  APP DATA                   ||
 * ||             ||                  10 pages                   ||
 * ||             =================================================  |---> Page offset: (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - 4)
 * ||             ||            USER KEYSTORE (1 page)           ||
 * ================================================================  |---> Page offset: (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_FLASH_PAGES - 3)
 * ||             ||                    ...                      ||
 *
 * APP CODE - memory for application itself, its libriaries, consts, etc.
 * APP DATA - memory used by application to write/read data in runtime
 * USER KEYSTORE - memory used by application for key storage
 */

/** @brief The size in pages of application data (User domain Flash memory modified by application) */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_SIZE                    PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(10)

/** @brief The size in pages of User Keystore sector */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_KEYSTORE_SIZE               PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(1)

/** @brief The size in pages of application code,  The application code span rest of user memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_SIZE                    (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_MEMORY_SIZE - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_SIZE - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_KEYSTORE_SIZE)

/** @brief Application code starts at beggining of user user domain Flash memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_PAGE_OFFSET             PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_MEMORY_PAGE_OFFSET

/** @brief Application data starts after application code */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET             (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_PAGE_OFFSET + PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_SIZE)

/** @brief User Keystore occupies 1 page after application data */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_USER_KEYSTORE_PAGE_OFFSET        (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET + PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_SIZE)

/**
 * @brief Application specific components defined by user
 * This part allows to combine multiple components inside application Code sector (f.e. main application, libs, consts...)
 * This example contains main application, lib and consts components. That enables individual versions of separate parts of code.
 *
 * Draft of application code components user domain Flash Memory Map
 *
 * ||             ||                    ...                      ||
 * ================================================================  |---> Page offset: 2
 * ||             ||                  MAIN APP                   ||
 * ||             ||    (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_SIZE - 20 - 10)   ||
 * ||             =================================================  |---> Page offset: PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET - 10 - 20
 * ||  APP_CODE   ||              APP LIB (20 pages)             ||
 * ||             =================================================  |---> Page offset: PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET - 10
 * ||             ||            APP CONSTS (10 pages)            ||
 * ================================================================  |---> Page offset: PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET
 * ||             ||                    ...                      ||
*/

/** @brief The size in pages of application lib */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_LIB_SIZE                     PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(20)

/** @brief The size in pages of application consts */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_SIZE                  PHSCAAPPENTRYUSER_DEFINE_AS_UNSIGNED(10)

/** @brief The size in pages of main application,  The main application span rest of application code memory */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_SIZE                    (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_SIZE - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_LIB_SIZE - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_SIZE)

/** @brief Main application starts at application code start */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_MAIN_APP_PAGE_OFFSET             PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CODE_PAGE_OFFSET

/** @brief application consts is located at the end of APP_CODE */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_PAGE_OFFSET           (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_DATA_PAGE_OFFSET - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_SIZE)

/** @brief application lib starts located before APP CONSTS */
#define PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_LIB_PAGE_OFFSET              (PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_CONSTS_PAGE_OFFSET - PHSCAAPPENTRYUSER_COMPONENT_USER_DOMAIN_APP_LIB_SIZE)

#endif /* PHSCAAPPENTRYUSER_MEMORY_H */

/* EOF */
