# NCJ29D6 SwupActivatorApp example
The SwupActivatorApp is an example onic user application. Its main purpose is to activate the SWUP using the phscaApi_Swup_Activate() API. It implements a CAN-FD interface, such that messages over a CAN can be exchanged.
Please refer to the user guide of the SwupCanHostif example for more information.