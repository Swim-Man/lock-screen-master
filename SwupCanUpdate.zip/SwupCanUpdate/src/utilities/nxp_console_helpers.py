#    Copyright 2022 - 2024 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import builtins
import logging
import sys
from enum import Enum, IntEnum
from logging.handlers import RotatingFileHandler
from pathlib import Path
from re import compile, sub
from typing import List, Literal, Type, TypeVar

import colorlog

import __main__

######################################################################################
### disable console printing in application ### -> set 'False' to disable printing ###
CONSOLE_PRINTING = True
######################################################################################


class StrColor:
    """
    A class that defines ANSI escape codes for text color formatting.
    """

    BLACK = "\033[90m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[37m"
    DEFAULT = "\033[99m"
    RESET = "\033[0m"


class StrFormat:
    """
    A class that defines ANSI escape codes for text formatting.
    """

    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"
    ITALIC = "\033[3m"
    STRIKETHROUGH = "\033[9m"
    INVERTED = "\033[7m"
    RESET = "\033[0m"


def print(string: str, color: StrColor = "", format1: StrFormat = "", format2: StrFormat = "") -> None:
    """
    Prints the given string with optional color and formatting.

    Args:
        string (str): The string to be printed.
        color (StrColor, optional): The color of the printed string. Defaults to "".
        format1 (StrFormat, optional): The first formatting option. Defaults to "".
        format2 (StrFormat, optional): The second formatting option. Defaults to "".

    Returns:
        None
    """
    if CONSOLE_PRINTING:
        builtins.print(f"{color}{format1}{format2}{string}{StrColor.RESET}")


######################################################################################


def print_hex(byte_stream: List[int]) -> None:
    """
    Prints the given byte stream as hexadecimal values.

    Args:
        byte_stream (List[int]): The byte stream to be printed.

    Returns:
        None
    """
    print(as_hex(byte_stream))


def as_hex(input_value: int | List[int] | List[List[int]], uppercase: bool = True, prepend_bytes: int = 0) -> str:
    """
    Converts the input value(s) to a hexadecimal string representation.
    Args:
        input (int | List[int] | List[List[int]]): The value(s) to be converted to hexadecimal.
        uppercase (bool, optional): Specifies whether the hexadecimal letters should be uppercase. Defaults to True.
        prepend_bytes (int, optional): The number of leading zeros to prepend to the hexadecimal string. Defaults to 0.
    Returns:
        str: The hexadecimal string representation of the input value(s) with specified formatting.
    Raises:
        ValueError: If the input value is unexpected.
    """
    hex_format = "X" if uppercase else "x"

    def format_hex(number: int) -> str:
        hex_length = max(2, prepend_bytes * 2) + 2  # Ensure at least one byte representation
        if number < 0:
            return f"-0x{abs(number):0{hex_length-2}{hex_format}}"
        else:
            return f"0x{number:0{hex_length-2}{hex_format}}"

    if isinstance(input_value, int):
        return format_hex(input_value)
    elif isinstance(input_value, list):
        if input_value and isinstance(input_value[0], list):
            nested_lists = ["[" + ", ".join(format_hex(item) for item in sublist) + "]" for sublist in input_value]
            return "[ " + ",\n".join(nested_lists) + " ]"
        else:
            return "[" + ", ".join(format_hex(item) for item in input_value) + "]"
    else:
        raise ValueError("Unexpected input type")


class EnumInputStatus(IntEnum):
    INPUT_STATUS_OK = 0x00
    INPUT_STATUS_INVALID_ARGUMENT = 0x01
    INPUT_STATUS_NO_ARGUMENT = 0x02
    INPUT_STATUS_INVALID_PREFIX = 0x03
    INPUT_STATUS_UNDEF = 0xFF


def get_command_line_hex_input(
    sys: sys, index: int = 0, endianness: Literal["big", "little"] = "big", accept_prefix_0x_for_larger_than_one_byte: bool = False
):
    """
    Get hex input from command-line arguments and convert it into a list of integers.

    Args:
        sys (sys): The sys module.
        index (int, optional): The index of the command-line argument to retrieve. Defaults to 0.
        endianness (Literal["big", "little"], optional): The endianness of the hex values. Defaults to "big".
        accept_prefix_0x_for_larger_than_one_byte (bool, optional): Whether to accept the prefix '0x' for values larger than one byte. Defaults to False.

    Returns:
        Tuple[EnumInputStatus, Optional[List[int]]]: A tuple containing the input status and the list of hex values.
    """

    # Using input from command-line argument | one argument
    if len(sys.argv) >= 2 and index <= (len(sys.argv) - 2):
        hex_input = str(sys.argv[index + 1])

        hex_input = sub(r"[\"'\[\]]", "", hex_input)  # Remove unwanted characters
        hex_input_list = hex_input.split(",") if "," in hex_input else hex_input.split()
        hex_input_list = [item.strip() for item in hex_input_list if item]  # Remove whitespace and empty items

        if not hex_input_list:
            return EnumInputStatus.INPUT_STATUS_NO_ARGUMENT, None

        hex_list = []
        for value in hex_input_list:
            try:
                int_value = int(value, base=16)
            except ValueError:
                if hex_list:
                    return EnumInputStatus.INPUT_STATUS_INVALID_ARGUMENT, hex_list
                else:
                    return EnumInputStatus.INPUT_STATUS_INVALID_ARGUMENT, None
            if int_value > 0xFF:
                chosen_endianness = endianness
                while chosen_endianness not in ("little", "big"):
                    chosen_endianness = input("Please choose the endian ('little' or 'big') for all inputs above 0xFF: ")
                try:
                    hex_list.extend(to_hex_list(value, byteorder=chosen_endianness, accept_prefix_0x=accept_prefix_0x_for_larger_than_one_byte))
                except ValueError:
                    if hex_list:
                        return EnumInputStatus.INPUT_STATUS_INVALID_PREFIX, hex_list
                    else:
                        return EnumInputStatus.INPUT_STATUS_INVALID_PREFIX, None
            else:
                hex_list.append(int_value)
        return EnumInputStatus.INPUT_STATUS_OK, hex_list

    else:
        return EnumInputStatus.INPUT_STATUS_NO_ARGUMENT, None


def query_hex_input(byteorder: Literal["big", "little"] = "big", accept_prefix_0x_for_larger_than_one_byte: bool = False) -> List[int]:
    """
    Prompts the user to input a hexadecimal message and interprets it as a list of integers.

    Args:
        byteorder (Literal["big", "little"], optional): The byteorder of the input values above 0xFF. Defaults to "big".
        accept_prefix_0x_for_larger_than_one_byte (bool, optional): Whether to accept the prefix '0x' for values larger than one byte. Defaults to False.

    Returns:
        List[int]: The list of integers representing the hexadecimal message.

    Raises:
        ValueError: If the input is not a valid hexadecimal value.

    """
    while True:
        hex_input = input("Please input hex message to interpret: ")
        hex_input = sub(r"[\"'\[\]]", "", hex_input)  # Remove unwanted characters

        hex_input_list = hex_input.split(",") if "," in hex_input else hex_input.split()
        hex_input_list = [item.strip() for item in hex_input_list if item]  # Remove whitespace and empty items

        if not hex_input_list:
            print("Error: No input", StrColor.RED)
            continue

        hex_list = []
        for value in hex_input_list:
            try:
                int_value = int(value, base=16)
            except ValueError:
                print("Error: Argument needs to be in hex", StrColor.RED)
                break
            if int_value > 0xFF:
                chosen_byteorder = byteorder
                while chosen_byteorder not in ("little", "big"):
                    chosen_byteorder = input("Please choose the byteorder ('little' or 'big') for all inputs above 0xFF: ")
                try:
                    hex_list.extend(to_hex_list(input=value, byteorder=chosen_byteorder, accept_prefix_0x=accept_prefix_0x_for_larger_than_one_byte))
                except ValueError:
                    print("Error: Input larger than 0xFF contains prefix 0x [not allowed]", StrColor.RED)
                    break
            else:
                hex_list.append(int_value)
        else:
            break

    return hex_list


# helper class for formatting different type of data
class ToStringFormatter(object):
    """
    A utility class for formatting objects as strings.

    Args:
        indent_level (int): The indentation level for formatting nested objects.

    Attributes:
        types (dict): A dictionary mapping object types to formatting callbacks.
        tab_char (str): The character used for indentation.
        space (str): The string used for indentation.
        indent (int): The current indentation level.

    Methods:
        set_formatter(obj, callback): Sets a formatting callback for a specific object type.
        __call__(value, **args): Formats the given value as a string.
        format_object(value): Formats an object as a string.
        format_dict(value): Formats a dictionary as a string.
        format_list(value): Formats a list as a string.
        format_tuple(value): Formats a tuple as a string.
        format_int(value): Formats an integer as a string.
        format_str(value): Formats a string as a string.
    """

    def __init__(self, indent_level=0):
        self.types = {}
        self.tab_char = "\t"
        self.space = "    "
        self.indent = indent_level
        self.set_formatter(object, self.__class__.format_object)
        self.set_formatter(dict, self.__class__.format_dict)
        self.set_formatter(list, self.__class__.format_list)
        self.set_formatter(tuple, self.__class__.format_tuple)
        self.set_formatter(int, self.__class__.format_int)
        self.set_formatter(str, self.__class__.format_str)

    def set_formatter(self, obj, callback):
        """
        Sets a formatting callback for a specific object type.

        Args:
            obj (type): The object type.
            callback (function): The formatting callback function.
        """
        self.types[obj] = callback

    def __call__(self, value, **args):
        """
        Formats the given value as a string.

        Args:
            value: The value to be formatted.
            **args: Additional arguments to customize the formatting.

        Returns:
            str: The formatted string representation of the value.
        """
        for key in args:
            setattr(self, key, args[key])
        formatter = self.types[type(value) if type(value) in self.types else object]
        return formatter(self, value)

    def format_object(self, value):
        """
        Formats an object as a string.

        Args:
            value: The object to be formatted.

        Returns:
            str: The formatted string representation of the object.
        """
        if isinstance(value, Enum) or isinstance(value, IntEnum):
            return value.name
        else:
            return str(value)

    def format_dict(self, value: dict):
        """
        Formats a dictionary as a string.

        Args:
            value (dict): The dictionary to be formatted.

        Returns:
            str: The formatted string representation of the dictionary.
        """
        items = [
            "\n"
            + self.space * (self.indent + 3)
            + (self.types[type(key) if type(key) in self.types else object])(self, key)
            + ": "
            + (self.types[type(value[key]) if type(value[key]) in self.types else object])(self, value[key])
            for key in value
        ]
        return ",".join(items)

    def format_list(self, value: list):
        """
        Formats a list as a string.

        Args:
            value (list): The list to be formatted.

        Returns:
            str: The formatted string representation of the list.
        """
        if all(isinstance(item, str) for item in value):
            # If all items are strings, check if any contain newline characters
            if any("\n" in item for item in value):
                # Use newline to join if any strings contain newline characters
                return "\n".join([self.types[type(item) if type(item) in self.types else object](self, item) for item in value])
            else:
                # Otherwise, join strings in a list format
                return "[" + ", ".join([self.types[type(item) if type(item) in self.types else object](self, item) for item in value]) + "]"
        else:
            # For lists not entirely made of strings, use standard list formatting
            items = [self.types[type(item) if type(item) in self.types else object](self, item) for item in value]
            return "[" + ", ".join(items) + "]"

    def format_tuple(self, value: tuple):
        """
        Formats a tuple as a string.

        Args:
            value (tuple): The tuple to be formatted.

        Returns:
            str: The formatted string representation of the tuple.
        """
        items = [(self.types[type(item) if type(item) in self.types else object])(self, item) for item in value]
        return str(items).replace("[", "(").replace("]", ")")

    def format_int(self, value: int):
        """
        Formats an integer as a string, using specialized handling for values greater than 0xFF by utilizing the to_hex_list function.
        For values less than or equal to 0xFF, formats using hexadecimal notation.
        Args:
            value (int): The integer to be formatted.
        Returns:
            str: The formatted string representation of the integer.
        """
        if value > 0xFF:
            # Use to_hex_list for integers greater than 0xFF
            hex_list = to_hex_list(value, byteorder="little")
            number = as_hex(hex_list) + "(" + str(value) + ")"
        else:
            # Use as_hex for values 0xFF and below
            number = as_hex(value)
        return number

    def format_str(self, value: str):
        """
        Formats a string as a string.

        Args:
            value (str): The string to be formatted.

        Returns:
            str: The formatted string representation of the string.
        """
        return f"{value}"


def class_to_str(self, include_title: bool | str = True, indent_level: int = 0) -> str:  # TODO: compact view / wrap logging on line
    """
    Convert the class instance to a string representation.

    Args:
        include_title (bool | str, optional): Determines whether to include the class name as a title.
            Defaults to True.
        indent_level (int, optional): The level of indentation for the string representation.
            Defaults to 0.

    Returns:
        str: The string representation of the class instance.

    Example:
        class Example:
            def __str__(self):
                return class_to_str(self)
    """
    to_str_formatter = ToStringFormatter(indent_level=indent_level)
    space = "    "
    msg = ""

    if include_title:
        msg = f"\n{space * indent_level + space}{self.__class__.__name__}:"
    elif isinstance(include_title, str):
        msg = "\n" + str(include_title)

    members = [attr for attr in self.__dict__ if not callable(getattr(self, attr)) and not attr.startswith("__") and not attr.startswith("_abc")]
    for item in members:
        if not include_title:
            msg += f"\n{space * indent_level + space}{item}: {to_str_formatter(getattr(self, item))}"
        else:
            msg += f"\n{space * indent_level + space * 2}{item}: {to_str_formatter(getattr(self, item))}"

    msg = msg.replace("'", "")
    return msg


def to_hex_list(
    input: int | str, byteorder: Literal["big", "little"] = "little", signed: bool = False, accept_prefix_0x: bool = True, forced_list_len: int = None
) -> List[int]:
    """
    Converts a hexadecimal input (either integer or string) into a list of integers representing the hexadecimal values.
    Negative values will be handled by calculating two's complement.

    Args:
        input (int | str): The (hexadecimal) input to be converted.
        byteorder (Literal["big", "little"], optional): The desired byteorder of the resulting list. Defaults to "little".
        signed (bool, optional): If set to true two's complement is used for negative numbers.
        accept_prefix_0x (bool, optional): Whether to accept the prefix "0x" in the input. Defaults to True.
        forced_list_len (int, optional): The desired length of the resulting list. If specified, the list will be padded or truncated accordingly. Defaults to None.
    Returns:
        List[int]: List of integers representing the hexadecimal values of each byte.
    Raises:
        ValueError: if input is not an integer or a hexadecimal string.
        ValueError: if byteorder is neither 'little' nor 'big'."
        ValueError: if the resulting list length is greater than forced length specified in forced_list_len.
    """
    if not isinstance(input, (int, str)):
        raise ValueError("Input must be an integer or a hexadecimal string.")
    if byteorder not in ("big", "little"):
        raise ValueError("byteorder must be either 'little' or 'big'.")
    if isinstance(input, str):
        if not accept_prefix_0x and input.startswith("0x"):
            raise ValueError("Hexadecimal string input with '0x' prefix not accepted.")
        input_int = int(input, base=16)
    else:
        input_int = input
    num_bytes = (input_int.bit_length() + 7) // 8
    if forced_list_len:
        if num_bytes > forced_list_len:
            raise ValueError(f"Resulting list length greater than forced length of {forced_list_len}.")
        num_bytes = forced_list_len

    hex_list = list(input_int.to_bytes(length=num_bytes, byteorder=byteorder, signed=signed))
    return hex_list

# generic type for IntEnum
T = TypeVar("T", bound=IntEnum)


def query_int_enum(var_name: str, int_enum_cls: Type[T]) -> T:
    """
    Prompts the user to select an integer value from an IntEnum.

    Args:
        var_name (str): The name of the variable.
        int_enum (IntEnum): The IntEnum containing the possible values.

    Returns:
        IntEnum value: The selected value from the IntEnum.
    """
    print(f"\nList of {var_name}:", StrFormat.UNDERLINE)
    for member in int_enum_cls:
        print(f"\t{member.value}: {member.name}")

    while True:
        raw_input = input("Please specify your input.\nChoose from the list above: ")
        print("")

        try:
            result_int = int(raw_input)
            var = int_enum_cls(result_int)
            return var
        except ValueError:
            matching_members = [member for member in int_enum_cls if raw_input.lower() in member.name.lower()]
            if len(matching_members) == 1:
                print(matching_members[0].name)
                return matching_members[0]
            elif len(matching_members) > 1:
                print(f"More than one possible choice: {[member.name for member in matching_members]}")
            else:
                pass


def snake_case(s):
    """
    Convert a string to snake case.

    Args:
        s (str): The input string.

    Returns:
        str: The snake case version of the input string.
    """
    return "_".join(sub("([A-Z][a-z]+)", r" \1", sub("([A-Z]+)", r" \1", s.replace("-", " "))).split()).lower()


#####################################################################################################
### LOGGING ###
# Please 'import logging' in application as well

# Custom Logger class
class CustomLogger(logging.Logger):
    OK = 15
    W_INFO = 25

    def __init__(self, name, level=logging.NOTSET):
        super().__init__(name, level)
        logging.addLevelName(self.OK, "OK")
        logging.addLevelName(self.W_INFO, "W_INFO")

    def ok(self, message, *args, **kws):
        if self.isEnabledFor(self.OK):
            self._log(self.OK, message, args, **kws)

    def w_info(self, message, *args, **kws):
        if self.isEnabledFor(self.W_INFO):
            self._log(self.W_INFO, message, args, **kws)

    def newline(self, level=None):
        if level is None:
            level = self.getEffectiveLevel()
        for handler in self.handlers:
            if handler.level <= level:
                try:
                    handler.stream.write("\n")
                    handler.flush()
                except AttributeError:
                    pass

# Register the custom logger class
logging.setLoggerClass(CustomLogger)

# Extend logging module with custom levels
logging.OK = 15
logging.addLevelName(logging.OK, "OK")

logging.W_INFO = 25
logging.addLevelName(logging.W_INFO, "W_INFO")


# Define a custom formatter
class NoColorFormatter(logging.Formatter):
    # Regular expression to match ANSI escape codes
    ansi_escape = compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

    def format(self, record: logging.LogRecord):
        original = super().format(record)
        # Remove ANSI escape codes from the message
        return self.ansi_escape.sub("", original)


def create_logger(log_path: str, log_filename: str, backup_count: int, level_log=logging.DEBUG, level_console=logging.INFO) -> CustomLogger:
    """
    Create a logger with a file handler and a console handler.

    Args:
        log_path (str): The path to the directory where the log file will be stored.
        log_filename (str): The name of the log file.
        backup_count (int): The number of backup log files to keep.
        level_log (int, optional): The logging level for the file handler. Defaults to logging.DEBUG.
        level_console (int, optional): The logging level for the console handler. Defaults to logging.INFO.

    Returns:
        logging.Logger: The created logger object.

    Example:
        logger = create_logger("logs", "example.log", 5, logging.DEBUG, logging.INFO)

    Create a logger with a file handler and a console handler.

    Logging levels:
        DEBUG: Detailed information, typically of interest only when diagnosing problems.
        OK: [green] Confirmation that things are working as expected.
        INFO: Confirmation that things are working as expected.
        W_INFO: [purple] Additional information which with extra visibility due to color
        WARNING: [yellow] An indication that something unexpected happened, or indicative of some problem in the near future. The software is still working as expected.
        ERROR: [red] Due to a more serious problem, the software has not been able to perform some function.
        CRITICAL: [red] A serious error, indicating that the program itself may be unable to continue running.
    """

    Path(log_path).mkdir(parents=True, exist_ok=True)
    filename = Path(log_filename)

    logger = logging.getLogger(Path(__main__.__file__).stem)

    # console handler
    console_stream_handler = logging.StreamHandler()
    console_formatter = colorlog.ColoredFormatter(
        "%(log_color)s%(levelname)-8s%(reset)s %(message_log_color)s%(message)s",
        datefmt=None,
        reset=True,
        log_colors={
            "DEBUG": "cyan",
            "OK": "green",
            "INFO": "green",
            "W_INFO": "purple",
            "WARNING": "yellow",
            "ERROR": "red",
            "CRITICAL": "red,bg_white",
        },
        secondary_log_colors={"message": {"OK": "green", "W_INFO": "purple", "WARNING": "yellow", "ERROR": "red", "CRITICAL": "red"}},
        style="%",
    )
    console_stream_handler.setFormatter(console_formatter)
    console_stream_handler.set_name("StreamHandler")

    # rollover
    if filename.exists() and filename.read_text() != "":
        should_roll_over = True
    else:
        should_roll_over = False
    log_file_handler = RotatingFileHandler(filename, mode="w", backupCount=backup_count, delay=True)
    if should_roll_over:  # log already exists, roll over!
        log_file_handler.doRollover()

    # log file handler
    log_file_formatter = NoColorFormatter(
        "%(levelname)-8s %(message)s",
        style="%",
    )
    log_file_handler.setFormatter(log_file_formatter)
    log_file_handler.set_name("RotatingFileHandler")

    logger.setLevel(level_log)
    log_file_handler.setLevel(level_log)
    console_stream_handler.setLevel(level_console)

    logger.addHandler(log_file_handler)
    logger.addHandler(console_stream_handler)

    return logger


def create_logger_interpreter(log_path: str, log_filename: str, backup_count: int, level_log=logging.DEBUG, level_console=logging.DEBUG):
    """
    Create a logger with file and console handlers.

    Args:
        log_path (str): The path to the log directory.
        log_filename (str): The name of the log file.
        backup_count (int): The number of backup log files to keep.
        level_log (int, optional): The log level for the file handler. Defaults to logging.DEBUG.
        level_console (int, optional): The log level for the console handler. Defaults to logging.DEBUG.

    Returns:
        logging.Logger: The created logger object.

    Example:
        logger = create_logger_interpreter("logs", "interpreter.log", 5, logging.DEBUG, logging.DEBUG)

    Logging levels:
        DEBUG: Cyan
        OK: Green
        INFO: White
        WARNING: Yellow
        ERROR: Red
        CRITICAL: Purple
    """
    logger = create_logger(log_path, log_filename, backup_count, level_log, level_console)

    ################################
    console_formatter = colorlog.ColoredFormatter(
        "%(message_log_color)s%(message)s",
        datefmt=None,
        reset=True,
        log_colors={"DEBUG": "cyan", "OK": "green", "INFO": "white", "WARNING": "yellow", "ERROR": "red", "CRITICAL": "purple"},
        secondary_log_colors={
            "message": {"DEBUG": "cyan", "OK": "green", "INFO": "white", "WARNING": "yellow", "ERROR": "red", "CRITICAL": "purple"}
        },
        style="%",
    )

    # log file handler
    log_file_formatter = NoColorFormatter(
        "%(message)s",
        style="%",
    )

    # update formatters
    for handler in logger.handlers:
        match handler.get_name():
            case "RotatingFileHandler":
                handler.setFormatter(log_file_formatter)
            case "StreamHandler":
                handler.setFormatter(console_formatter)
            case _:
                pass

    return logger
