#    Copyright 2022 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

from __future__ import annotations

import sys
from abc import ABC, abstractmethod
from copy import deepcopy
from dataclasses import dataclass
from enum import IntEnum
from math import ceil, floor, log10
from typing import Dict, List

from more_itertools import chunked

from drivers.nxp_uci import EnumUciGid, EnumUciStatus, EnumUciMessageType, UciMessage
from drivers.nxp_uwb_helpers import BB_TICKS_TO_SEC_CONVERSION_FACTOR

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

from utilities.nxp_console_helpers import class_to_str
from utilities.nxp_decorators import frozen


class EnumTestwareOid(IntEnum):
    TESTWARE_OID_RESET_DEVICE = 0x00
    TESTWARE_OID_BOOT_STATUS = 0x01
    TESTWARE_OID_GET_FW_VERSION = 0x02
    TESTWARE_OID_RX_CONFIG = 0x04
    TESTWARE_OID_TX_CONFIG = 0x05
    TESTWARE_OID_START_BASEBAND = 0x06
    TESTWARE_OID_STOP_BASEBAND = 0x07
    TESTWARE_OID_GET_BASEBAND_RESULTS = 0x08
    TESTWARE_OID_POWER_MGMT_CONFIG = 0x09
    TESTWARE_OID_ACTIVATE_SWUP = 0x12
    TESTWARE_OID_GENERIC_BASEBAND_CONFIG = 0x0A
    TESTWARE_OID_CLOCK_MGMT_CONFIG = 0x0B
    TESTWARE_OID_PIN_TOGGLE_CONFIG = 0x0C
    TESTWARE_OID_GPADC_OPERATION = 0x0D
    TESTWARE_OID_BASEBAND_STATUS = 0x0E
    TESTWARE_OID_GET_RADIO_CONFIG_VERSION = 0x12
    TESTWARE_OID_SET_BITFIELD = 0x13
    TESTWARE_OID_GET_BITFIELD = 0x14
    TESTWARE_OID_ECHO_REV_PAYLOAD = 0x15
    TESTWARE_OID_RX_RADIO_CONFIG = 0x18
    TESTWARE_OID_TX_RADIO_CONFIG = 0x19
    TESTWARE_OID_RANGING_PAYLOAD_CONFIG = 0x20
    TESTWARE_OID_RANGING_APPLICATION_CONFIG = 0x21
    TESTWARE_OID_RANGING_SEQUENCE_CONFIG = 0x22
    TESTWARE_OID_START_RANGING = 0x23
    TESTWARE_OID_GET_RANGING_PAYLOAD = 0x24
    TESTWARE_OID_RADAR_APPLICATION_CONFIG = 0x30
    TESTWARE_OID_START_RADAR = 0x31
    TESTWARE_OID_CONFIG_CAN = 0x3E
    TESTWARE_OID_CONFIG_UCI = 0x3F


@frozen
class CirData:
    class EnumAntennaIndex(IntEnum):
        RX1 = 0x01
        RX2 = 0x02

    def __init__(
        self,
        antenna_index: EnumAntennaIndex,
        agc_gain_db: int,
        cir_index: int,
        cir_offset: int,
        num_taps: int,
        timestamp: int,
        cir_taps: List[complex],
        cir_taps_bytes: List[int],
    ):
        self.antenna_index = antenna_index
        self.agc_gain = agc_gain_db
        self.cir_index = cir_index
        self.cir_offset = cir_offset
        self.num_taps = num_taps
        self.timestamp = timestamp
        self.cir_taps = cir_taps
        self.cir_taps_bytes = cir_taps_bytes

    def __str__(self) -> str:
        return class_to_str(self)


# GENERIC_BASEBAND_CONFIG
@frozen
class BasebandConfiguration:
    class ConfigurationSelect(IntEnum):
        RX_RADIO_CONFIGURATION = 0x00
        RX_DIGITAL_FRONTEND_CONFIGURATION = 0x01
        RX_PAYLOAD_CONFIGURATION = 0x02
        RX_RANGING_CONTROL_CONFIGURATION = 0x03
        RX_ANTENNA_CONFIGURATION = 0x04

        TX_RADIO_CONFIGURATION = 0x10
        TX_POWER_CONFIGURATION = 0x11
        TX_PAYLOAD_CONFIGURATION = 0x12
        TX_DDFS_CONFIGURATION = 0x13
        TX_RANGING_CONTROL_CONFIGURATION = 0x14

        SYNC_CODE_CONFIGURATION = 0x20
        STS_CONFIGURATION = 0x21
        COMMAND_CONFIGURATION = 0x22
        SFD_CONFIGURATION = 0x23

        RX_RADAR_CIR_CONFIGURATION = 0x30
        RX_RADAR_CONTROL_CONFIGURATION = 0x31
        TX_RADAR_CONTROL_CONFIGURATION = 0x32
        RX_RADAR_CALIBRATION_DATA = 0x33
        RADAR_NOISE_SUPPRESSION_CONFIGURATION = 0x34

        PERFORM_AGC_CALIBRATION = 0xFC
        PLL_RECALIBRATION = 0xFD
        CALLBACK_CONFIGURATION = 0xFE

    # Template class for configurations
    class Configuration(ABC):
        @abstractmethod
        def _get_select(self):
            pass

        @abstractmethod
        def _get_index(self):
            pass

        @abstractmethod
        def _get_data(self):
            pass

        @abstractmethod
        def _get_results(cls, payload: List[int]):
            pass

    # RX_RADIO_CONFIGURATION
    @frozen
    class RxRadioConfiguration(Configuration):
        def __init__(self, config_index: int = 0, radio_config_source: int = 0):
            self.config_index = config_index
            self.radio_config_source = radio_config_source
            self._rfu = [0x00, 0x00, 0x00]

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_RADIO_CONFIGURATION

        def _get_index(self):
            return self.config_index & 0xFF

        def _get_data(self):
            bytes = []
            bytes.append(self.radio_config_source & 0xFF)
            bytes += self._rfu
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.RxRadioConfiguration(radio_config_source=payload[0])

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # RX_DIGITAL_FRONTEND_CONFIGURATION
    @frozen
    class RxDigitalFrontendConfiguration(Configuration):
        class EnumNbicBandwidth(IntEnum):
            LINEAR_BANDWIDTH_12_MHZ = 0x00
            LINEAR_BANDWIDTH_27_MHZ = 0x01
            LINEAR_BANDWIDTH_54_MHZ = 0x02
            LINEAR_BANDWIDTH_108_MHZ = 0x03
            LINEAR_BANDWIDTH_160_MHZ = 0x04
            LINEAR_BANDWIDTH_320_MHZ = 0x05
            MIN_PHASE_BANDWIDTH_0_6_MHZ = 0x00
            MIN_PHASE_BANDWIDTH_1_2_MHZ = 0x01
            MIN_PHASE_BANDWIDTH_3_MHZ = 0x02

        class EnumNbicFilter(IntEnum):
            LINEAR = 0x00
            MIN_PHASE = 0x01

        class EnumNbicMode(IntEnum):
            MANUAL_MODE = 0x00
            MANUAL_MODE_JAMMER_DETECTION = 0x01
            AUTOMATIC_MODE_JAMMER_DETECTION = 0x02
            TRACKING_MODE_JAMMER_DETECTION = 0x03

        class EnumRXEnable(IntEnum):
            DISABLE = 0x00
            RX1_ENABLE = 0x01
            RX2_ENABLE = 0x02
            RX1_RX2_ENABLE = 0x03

        @staticmethod
        def _center_frequency_to_bytes(freq: float):
            # convert scale of -500 to 500(minus 1 step) to the scale of an 16 bit signed integer
            freq *= 65.536
            freq = int(round(freq))
            # truncate if larger than 15 bit can carry
            freq = freq if freq < 2**15 else 2**15 - 1
            freq = freq if freq >= -(2**15) else -(2**15)
            bytes = list(freq.to_bytes(length=2, byteorder="little", signed=True))
            return bytes

        def __init__(
            self,
            config_index: int = 0,
            nbic_bandwidth_rx1: EnumNbicBandwidth = EnumNbicBandwidth.LINEAR_BANDWIDTH_12_MHZ,
            nbic_filter_rx1: EnumNbicFilter = EnumNbicFilter.LINEAR,
            nbic_mode_rx1: EnumNbicMode = EnumNbicMode.MANUAL_MODE,
            center_freq_rx1_mhz: float = 0,
            nbic_bandwidth_rx2: EnumNbicBandwidth = EnumNbicBandwidth.LINEAR_BANDWIDTH_12_MHZ,
            nbic_filter_rx2: EnumNbicFilter = EnumNbicFilter.LINEAR,
            nbic_mode_rx2: EnumNbicMode = EnumNbicMode.MANUAL_MODE,
            center_freq_rx2_mhz: float = 0,
            nbic_control: EnumRXEnable = EnumRXEnable.DISABLE,
            cs_filter_control: EnumRXEnable = EnumRXEnable.DISABLE,
            iq_comp_control: EnumRXEnable = EnumRXEnable.DISABLE,
            dc_estimation_filter: EnumRXEnable = EnumRXEnable.DISABLE,
        ):
            self.config_index = config_index
            self.nbic_bandwidth_rx1 = nbic_bandwidth_rx1
            self.nbic_filter_rx1 = nbic_filter_rx1
            self.nbic_mode_rx1 = nbic_mode_rx1
            self.center_freq_rx1_mhz = center_freq_rx1_mhz
            self.nbic_bandwidth_rx2 = nbic_bandwidth_rx2
            self.nbic_filter_rx2 = nbic_filter_rx2
            self.nbic_mode_rx2 = nbic_mode_rx2
            self.center_freq_rx2_mhz = center_freq_rx2_mhz
            self.nbic_control = nbic_control
            self.cs_filter_control = cs_filter_control
            self.iq_comp_control = iq_comp_control
            self.dc_estimation_filter = dc_estimation_filter

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_DIGITAL_FRONTEND_CONFIGURATION

        def _get_index(self):
            return self.config_index & 0xFF

        def _get_data(self):
            bytes = []
            bytes.append((self.nbic_bandwidth_rx1 & 0x0F) | ((self.nbic_filter_rx1 & 0x0F) << 4))
            bytes.append(self.nbic_mode_rx1 & 0xFF)
            bytes += self._center_frequency_to_bytes(self.center_freq_rx1_mhz)
            bytes.append((self.nbic_bandwidth_rx2 & 0x0F) | ((self.nbic_filter_rx2 & 0x0F) << 4))
            bytes.append(self.nbic_mode_rx2 & 0xFF)
            bytes += self._center_frequency_to_bytes(self.center_freq_rx2_mhz)
            bytes.append(self.nbic_control & 0xFF)
            bytes.append(self.cs_filter_control & 0xFF)
            bytes.append(self.iq_comp_control & 0xFF)
            bytes.append(self.dc_estimation_filter & 0xFF)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            nbic_filter_rx1 = BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicFilter(payload[0] >> 4)
            if nbic_filter_rx1 is BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicFilter.MIN_PHASE:
                nbic_bandwidth_rx1 = [
                    name
                    for name, member in BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicBandwidth.__members__.items()
                    if member == (payload[0] & 0x0F) and member.name != name
                ]
                nbic_bandwidth_rx1 = getattr(BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicBandwidth, nbic_bandwidth_rx1[0])
            else:
                nbic_bandwidth_rx1 = BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicBandwidth(payload[0] & 0x0F)

            nbic_filter_rx2 = BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicFilter(payload[4] >> 4)
            if nbic_filter_rx2 is BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicFilter.MIN_PHASE:
                nbic_bandwidth_rx2 = [
                    name
                    for name, member in BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicBandwidth.__members__.items()
                    if member == (payload[4] & 0x0F) and member.name != name
                ]
                nbic_bandwidth_rx2 = getattr(BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicBandwidth, nbic_bandwidth_rx2[0])
            else:
                nbic_bandwidth_rx2 = BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicBandwidth(payload[4] & 0x0F)

            return BasebandConfiguration.RxDigitalFrontendConfiguration(
                nbic_bandwidth_rx1=nbic_bandwidth_rx1,
                nbic_filter_rx1=nbic_filter_rx1,
                nbic_mode_rx1=BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicMode(payload[1]),
                center_freq_rx1_mhz=(((int.from_bytes(bytes=payload[2 : (3 + 1)], byteorder="little", signed=True)) / (2**15)) * 500),
                nbic_bandwidth_rx2=nbic_bandwidth_rx2,
                nbic_filter_rx2=nbic_filter_rx2,
                nbic_mode_rx2=BasebandConfiguration.RxDigitalFrontendConfiguration.EnumNbicMode(payload[5]),
                center_freq_rx2_mhz=(((int.from_bytes(bytes=payload[6 : (7 + 1)], byteorder="little", signed=True)) / (2**15)) * 500),
                nbic_control=BasebandConfiguration.RxDigitalFrontendConfiguration.EnumRXEnable(payload[8]),
                cs_filter_control=BasebandConfiguration.RxDigitalFrontendConfiguration.EnumRXEnable(payload[9]),
                iq_comp_control=BasebandConfiguration.RxDigitalFrontendConfiguration.EnumRXEnable(payload[10]),
                dc_estimation_filter=BasebandConfiguration.RxDigitalFrontendConfiguration.EnumRXEnable(payload[11]),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.center_freq_rx1_mhz = str(round(self.center_freq_rx1_mhz, 2)) + " MHz"
            _self.center_freq_rx2_mhz = str(round(self.center_freq_rx2_mhz, 2)) + " MHz"
            return class_to_str(_self, include_title=True, indent_level=1)

    # RX_PAYLOAD_CONFIGURATION
    @frozen
    class RxPayloadConfiguration(Configuration):
        class EnumCRCType(IntEnum):
            CRC32 = 0x00
            CRC16 = 0x01

        class EnumPayloadLength(IntEnum):
            AUTO_DECODING = 0xFFFF

        def __init__(self, crc_enable: bool = False, crc_type: EnumCRCType = EnumCRCType.CRC32, payload_length: int | EnumPayloadLength = 0xFFFF):
            self.crc_enable = crc_enable
            self.crc_type = crc_type
            self.payload_length = payload_length

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_PAYLOAD_CONFIGURATION

        def _get_index(self):
            return 0x00

        def _get_data(self):
            bytes = []
            bytes.append(int(self.crc_enable))
            bytes.append(self.crc_type & 0xFF)
            bytes.append(self.payload_length & 0x00FF)
            bytes.append((self.payload_length & 0xFF00) >> 8)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.RxPayloadConfiguration(
                crc_enable=bool(payload[0]),
                crc_type=BasebandConfiguration.RxPayloadConfiguration.EnumCRCType(payload[1]),
                payload_length=int.from_bytes(bytes=payload[2 : (3 + 1)], byteorder="little", signed=False),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)

            if self.payload_length == 0xFFFF:
                payload_length_description = (
                    "Auto decoding: The payload length will be automatically decoded by the receiver based on the length field within the PHR."
                )
            elif self.payload_length < 127:
                payload_length_description = "BPRF frames"
            elif 127 <= self.payload_length < 4095:
                payload_length_description = "HPRF frames"
            else:
                payload_length_description = "not defined"

            _self.payload_length = f"{self.payload_length} bytes ({payload_length_description})"
            return class_to_str(_self, include_title=True, indent_level=1)

    # RX_RANGING_CONTROL_CONFIGURATION
    @frozen
    class RxRangingControlConfiguration(Configuration):
        class EnumIndex(IntEnum):
            INDEX_0 = 0x00
            INDEX_1 = 0x01
            INDEX_2 = 0x02
            INDEX_3 = 0x03
            FETCH_FROM_RADIO_CONFIGURATION = 0xFF

        class EnumRXEnable(IntEnum):
            DISABLE = 0x00
            RX1_ENABLE = 0x01
            RX2_ENABLE = 0x02
            RX1_RX2_ENABLE = 0x03
            RX1_RX2_ENABLE_DUAL_TIMESTAMPS = 0x83

        @staticmethod
        def preamble_on_time_int_to_us(p_int: int):
            return round(p_int * (128 / 124.8))

        @staticmethod
        def preamble_on_time_us_to_int(p_us: int):
            return round(p_us / (128 / 124.8))

        def __init__(
            self,
            config_index: int = 0x00,
            rx_radio_config_index: EnumIndex = EnumIndex.INDEX_0,
            sync_code_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            rx_dfe_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            rx_antenna_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            preamble_on_time_us: int = 0x00,
            auto_rx_mask: int = 0x0000,
            sts_enable: bool = False,
            phr_enable: bool = False,
            psdu_enable: bool = False,
            toa_enable: bool = False,
            pdoa_enable: bool = False,
            rx_enable: EnumRXEnable = EnumRXEnable.RX1_ENABLE,
            rx_sync_disable: bool = False,
            sfd_configuration_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
        ):
            self.config_index = config_index
            self.rx_radio_config_index = rx_radio_config_index
            self.sync_code_config_index = sync_code_config_index
            self.rx_dfe_config_index = rx_dfe_config_index
            self.rx_antenna_config_index = rx_antenna_config_index
            self.preamble_on_time_us = preamble_on_time_us
            self.auto_rx_mask = auto_rx_mask
            self.sts_enable = sts_enable
            self.phr_enable = phr_enable
            self.psdu_enable = psdu_enable
            self.toa_enable = toa_enable
            self.pdoa_enable = pdoa_enable
            self.rx_enable = rx_enable
            self.rx_sync_disable = rx_sync_disable
            self.sfd_configuration_index = sfd_configuration_index

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_RANGING_CONTROL_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.rx_radio_config_index & 0xFF)
            bytes.append(self.sync_code_config_index & 0xFF)
            bytes.append(self.rx_dfe_config_index & 0xFF)
            bytes.append(self.rx_antenna_config_index & 0xFF)
            bytes.append(self.preamble_on_time_us_to_int(self.preamble_on_time_us) & 0x00FF)
            bytes.append((self.preamble_on_time_us_to_int(self.preamble_on_time_us) & 0xFF00) >> 8)
            bytes.append(self.auto_rx_mask & 0x00FF)
            bytes.append((self.auto_rx_mask & 0xFF00) >> 8)
            bytes.append(int(self.sts_enable))
            bytes.append(int(self.phr_enable))
            bytes.append(int(self.psdu_enable))
            bytes.append(int(self.toa_enable))
            bytes.append(int(self.pdoa_enable))
            bytes.append(self.rx_enable & 0xFF)
            bytes.append(int(self.rx_sync_disable))
            bytes.append(self.sfd_configuration_index & 0xFF)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.RxRangingControlConfiguration(
                rx_radio_config_index=BasebandConfiguration.RxRangingControlConfiguration.EnumIndex(payload[0]),
                sync_code_config_index=BasebandConfiguration.RxRangingControlConfiguration.EnumIndex(payload[1]),
                rx_dfe_config_index=BasebandConfiguration.RxRangingControlConfiguration.EnumIndex(payload[2]),
                rx_antenna_config_index=BasebandConfiguration.RxRangingControlConfiguration.EnumIndex(payload[3]),
                preamble_on_time_us=cls.preamble_on_time_int_to_us(int.from_bytes(bytes=payload[4 : (5 + 1)], byteorder="little", signed=False)),
                auto_rx_mask=int.from_bytes(bytes=payload[6 : (7 + 1)], byteorder="little", signed=False),
                sts_enable=bool(payload[8]),
                phr_enable=bool(payload[9]),
                psdu_enable=bool(payload[10]),
                toa_enable=bool(payload[11]),
                pdoa_enable=bool(payload[12]),
                rx_enable=BasebandConfiguration.RxRangingControlConfiguration.EnumRXEnable(payload[13]),
                rx_sync_disable=bool(payload[14]),
                sfd_configuration_index=BasebandConfiguration.RxRangingControlConfiguration.EnumIndex(payload[15]),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.preamble_on_time_us = str(self.preamble_on_time_us) + " us"
            return class_to_str(_self, include_title=True, indent_level=1)

    # RX_ANTENNA_CONFIGURATION
    @frozen
    class RxAntennaConfiguration(Configuration):
        class EnumMode(IntEnum):
            ONE_HOT_ENCODING_OF_ANTENNA_SWITCH = 0x00
            BINARY_CONTROL_OF_ANTENNA_SWITCH_ZERO_BASED = 0x01
            BINARY_CONTROL_OF_ANTENNA_SWITCH_ONE_BASED = 0x02

        def __init__(
            self,
            ant_cnt: int = 0,  # 0 equals 1 connected antenna, 1 equals 2 connected antennas, ...
            ant_sel_shr_set: int = 0,
            ant_sel_sts_set: int = 0,
            ant_sel_iter_enbl: bool = False,
            ant_sel_pyld_set: int = 0,
            ant_sel_mode_set: EnumMode = EnumMode.ONE_HOT_ENCODING_OF_ANTENNA_SWITCH,
        ):
            self.ant_cnt = ant_cnt
            self.ant_sel_shr_set = ant_sel_shr_set
            self.ant_sel_sts_set = ant_sel_sts_set
            self.ant_sel_iter_enbl = ant_sel_iter_enbl
            self.ant_sel_pyld_set = ant_sel_pyld_set
            self.ant_sel_mode_set = ant_sel_mode_set
            self._rfu = [0x00, 0x00]

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_ANTENNA_CONFIGURATION

        def _get_index(self):
            return 0x00

        def _get_data(self):
            bytes = []
            bytes.append(self.ant_cnt & 0xFF)
            bytes.append(self.ant_sel_shr_set & 0xFF)
            bytes.append(self.ant_sel_sts_set & 0xFF)
            bytes.append(int(self.ant_sel_iter_enbl))
            bytes.append(self.ant_sel_pyld_set & 0xFF)
            bytes.append(self.ant_sel_mode_set & 0xFF)
            bytes += self._rfu
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.RxAntennaConfiguration(
                ant_cnt=payload[0],
                ant_sel_shr_set=payload[1],
                ant_sel_sts_set=payload[2],
                ant_sel_iter_enbl=bool(payload[3]),
                ant_sel_pyld_set=payload[4],
                ant_sel_mode_set=BasebandConfiguration.RxAntennaConfiguration.EnumMode(payload[5]),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.ant_cnt = f"{['0x{:02x}'.format(self.ant_cnt)]} ({self.ant_cnt}): Number of connected antennas is {self.ant_cnt + 1}"
            _self.ant_sel_shr_set = (
                f"{['0x{:02x}'.format(self.ant_sel_shr_set)]} ({self.ant_sel_shr_set}): SHR reception on antenna {self.ant_sel_shr_set + 1}"
            )
            _self.ant_sel_sts_set = (
                f"{['0x{:02x}'.format(self.ant_sel_sts_set)]} ({self.ant_sel_sts_set}): STS reception on antenna {self.ant_sel_sts_set + 1}"
            )
            _self.ant_sel_iter_enbl = f"{['0x{:02x}'.format(self.ant_sel_iter_enbl)]} ({self.ant_sel_iter_enbl}): Antenna selection is iterated through the STS segments: {'enabled' if self.ant_sel_iter_enbl is True else 'disabled'}"
            _self.ant_sel_pyld_set = (
                f"{['0x{:02x}'.format(self.ant_sel_pyld_set)]} ({self.ant_sel_pyld_set}): PHR+PSDU reception on antenna {self.ant_sel_pyld_set + 1}"
            )
            return class_to_str(_self, include_title=True, indent_level=1)

    # TX_RADIO_CONFIGURATION
    @frozen
    class TxRadioConfiguration(Configuration):
        def __init__(self, config_index: int = 0, radio_config_source: int = 0):
            self.config_index = config_index
            self.radio_config_source = radio_config_source
            self._rfu = [0x00, 0x00, 0x00]

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.TX_RADIO_CONFIGURATION

        def _get_index(self):
            return self.config_index & 0xFF

        def _get_data(self):
            bytes = []
            bytes.append(self.radio_config_source & 0xFF)
            bytes += self._rfu
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.TxRadioConfiguration(radio_config_source=payload[0])

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # TX_POWER_CONFIGURATION
    @frozen
    class TxPowerConfiguration(Configuration):
        @staticmethod
        def _dbm_to_byte(dbm: float):
            dbm *= 6
            dbm = int(round(dbm))
            # truncate if larger than 7 bit can carry
            dbm = dbm if dbm < 2**7 else 2**7 - 1
            dbm = dbm if dbm >= -(2**7) else -(2**7)
            byte = list(dbm.to_bytes(length=1, byteorder="little", signed=True))[0]
            return byte

        @staticmethod
        def _byte_to_dbm(byte):
            dbm = int.from_bytes(bytes=[byte], byteorder="little", signed=True)
            dbm *= 1 / 6
            dbm = ceil(dbm * 100) / 100
            return dbm

        def __init__(self, config_index: int = 0, tx_power_nominal_dbm: float = 0, tx_power_offset_dbm: float = 0, tx_power_boost_dbm: float = 0):
            self.config_index = config_index
            self.tx_power_nominal_dbm = tx_power_nominal_dbm
            self.tx_power_offset_dbm = tx_power_offset_dbm
            self.tx_power_boost_dbm = tx_power_boost_dbm
            self._rfu = 0x00

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.TX_POWER_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self._dbm_to_byte(self.tx_power_nominal_dbm))
            bytes.append(self._dbm_to_byte(self.tx_power_offset_dbm))
            bytes.append(self._dbm_to_byte(self.tx_power_boost_dbm))
            bytes.append(self._rfu)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.TxPowerConfiguration(
                tx_power_nominal_dbm=BasebandConfiguration.TxPowerConfiguration._byte_to_dbm(payload[0]),
                tx_power_offset_dbm=BasebandConfiguration.TxPowerConfiguration._byte_to_dbm(payload[1]),
                tx_power_boost_dbm=BasebandConfiguration.TxPowerConfiguration._byte_to_dbm(payload[2]),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.tx_power_nominal_dbm = str(self.tx_power_nominal_dbm) + " dBm"
            _self.tx_power_offset_dbm = str(self.tx_power_offset_dbm) + " dBm"
            _self.tx_power_boost_dbm = str(self.tx_power_boost_dbm) + " dBm"
            return class_to_str(_self, include_title=True, indent_level=1)

    # TX_PAYLOAD_CONFIGURATION
    @frozen
    class TxPayloadConfiguration(Configuration):
        class EnumCRCType(IntEnum):
            CRC32 = 0x00
            CRC16 = 0x01

        def __init__(
            self, crc_enable: bool = False, crc_type: EnumCRCType = EnumCRCType.CRC32, payload_length: int = 0, payload_data: List[int] = [0x00, 0x00]
        ):
            self.crc_enable = crc_enable
            self.crc_type = crc_type
            self.payload_length = payload_length
            self.payload_data = payload_data

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.TX_PAYLOAD_CONFIGURATION

        def _get_index(self):
            return 0x00

        def _get_data(self):
            bytes = []
            bytes.append(int(self.crc_enable))
            bytes.append(self.crc_type & 0xFF)
            bytes.append(self.payload_length & 0x00FF)
            bytes.append((self.payload_length & 0xFF00) >> 8)
            for i in range(len(self.payload_data)):
                bytes.append(self.payload_data[i] & 0xFF)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.TxPayloadConfiguration(
                crc_enable=bool(payload[0]),
                crc_type=BasebandConfiguration.TxPayloadConfiguration.EnumCRCType(payload[1]),
                payload_length=int.from_bytes(bytes=payload[2 : (3 + 1)], byteorder="little", signed=False),
                payload_data=payload[4:],
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            if self.payload_length < 127:
                payload_length_description = "BPRF frames"
            elif 127 <= self.payload_length < 4095:
                payload_length_description = "HPRF frames"
            else:
                payload_length_description = "not defined"

            _self.payload_length = f"{self.payload_length} bytes ({payload_length_description})"
            return class_to_str(_self, include_title=True, indent_level=1)

    # TX_DDFS_CONFIGURATION
    @frozen
    class TxDdfsConfiguration(Configuration):
        class EnumDdfsCtrl(IntEnum):
            DDFSEN_ENBL = 0
            DDFSCNTEN_ENBL = 1
            DDFSPOSTFRMEN_ENBL = 2
            DDFSCNT_SET = 3
            DDFSGAPCNT_SET = 4

        class EnumDdfsTone(IntEnum):
            FREQUENCY = 0
            PHASE_OFFSET = 1
            DITHER_SELECT = 2

        @staticmethod
        def _ns_to_int(time: float):
            # the steps between each index are 8.0128ns
            # the first index starts at 0ns
            result = int(round(time / 8.0128))
            return result

        @staticmethod
        def _int_to_ns(integer: int):
            # the steps between each index are 8.0128ns
            result = integer * 8.0128
            # round
            result = round(result, 4)
            return result

        @staticmethod
        def _khz_to_int(freq: int):
            # frequencies are represented by steps of 975 KHz
            result = int(round(freq / 975))
            return result

        @staticmethod
        def _int_to_khz(integer: int):
            return integer * 975

        @staticmethod
        def _deg_to_int(deg: float):
            # degrees are represented by steps of 360/2048
            result = int(round(deg * 2048 / 360))
            return result

        @staticmethod
        def _int_to_deg(integer: int):
            result = (integer * 360) / 2**11
            return result

        class DdfsControl:
            def __init__(
                self,
                FETCH_FROM_RADIO_CONFIG: bool = False,
                ddfs_enable: bool = False,
                ddfs_cnt_enable: bool = False,
                ddfs_post_frame_enable: bool = False,
                ddfs_cnt_set_ns: float = 0.0,
                ddfs_gap_set_ns: float = 0.0,
            ):
                self.FETCH_FROM_RADIO_CONFIG = FETCH_FROM_RADIO_CONFIG
                self.ddfs_enable = ddfs_enable
                self.ddfs_cnt_enable = ddfs_cnt_enable
                self.ddfs_post_frame_enable = ddfs_post_frame_enable
                self.ddfs_cnt_set_ns = ddfs_cnt_set_ns
                self.ddfs_gap_set_ns = ddfs_gap_set_ns

            def __str__(self) -> str:
                return class_to_str(self, include_title=False, indent_level=1)

            def _get_int(self) -> int:
                if self.FETCH_FROM_RADIO_CONFIG:
                    return 0xFFFFFFFF
                else:
                    return (
                        int(self.ddfs_enable)
                        | (int(self.ddfs_cnt_enable) & 1 << 1)
                        | (int(self.ddfs_post_frame_enable) & 1 << 2)
                        | ((BasebandConfiguration.TxDdfsConfiguration._ns_to_int(self.ddfs_cnt_set_ns) & 0xFFF) << 3)
                        | ((BasebandConfiguration.TxDdfsConfiguration._ns_to_int(self.ddfs_gap_set_ns) & 0xFF) << 15)
                    )

        class DdfsTone0:
            def __init__(self, FETCH_FROM_RADIO_CONFIG: bool = False, tone_0_increment_khz: int = 0, tone_0_offset_degree: float = 0.0):
                self.FETCH_FROM_RADIO_CONFIG = FETCH_FROM_RADIO_CONFIG
                self.tone_0_increment_khz = tone_0_increment_khz
                self.tone_0_offset_degree = tone_0_offset_degree

            def __str__(self) -> str:
                return class_to_str(self, include_title=False, indent_level=1)

            def _get_int(self) -> int:
                if self.FETCH_FROM_RADIO_CONFIG:
                    return 0xFFFFFFFF
                else:
                    return (BasebandConfiguration.TxDdfsConfiguration._khz_to_int(self.tone_0_increment_khz) & 0x7FF) | (
                        (BasebandConfiguration.TxDdfsConfiguration._deg_to_int(self.tone_0_offset_degree) & 0x7FF) << 11
                    )

        class DdfsTone1:
            class EnumDitherSelect(IntEnum):
                NO_DITHER = 0x00
                DITHER_1BIT = 0x01
                DITHER_2BIT = 0x02
                MAX_DITHER = 0x03

            def __init__(
                self,
                FETCH_FROM_RADIO_CONFIG: bool = False,
                tone_1_increment_khz: int = 0,
                tone_1_offset_degree: float = 0.0,
                dither_select: EnumDitherSelect = EnumDitherSelect.NO_DITHER,
            ):
                self.FETCH_FROM_RADIO_CONFIG = FETCH_FROM_RADIO_CONFIG
                self.tone_1_increment_khz = tone_1_increment_khz
                self.tone_1_offset_degree = tone_1_offset_degree
                self.dither_select = dither_select

            def __str__(self) -> str:
                return class_to_str(self, include_title=False, indent_level=1)

            def _get_int(self) -> int:
                if self.FETCH_FROM_RADIO_CONFIG:
                    return 0xFFFFFFFF
                else:
                    return (
                        (BasebandConfiguration.TxDdfsConfiguration._khz_to_int(self.tone_1_increment_khz) & 0x7FF)
                        | ((BasebandConfiguration.TxDdfsConfiguration._deg_to_int(self.tone_1_offset_degree) & 0x7FF) << 11)
                        | (self.dither_select << 22)
                    )

        def __init__(self, ddfs_control: DdfsControl = DdfsControl(), ddfs_tone_0: DdfsTone0 = DdfsTone0(), ddfs_tone_1: DdfsTone1 = DdfsTone1()):
            self.ddfs_control = ddfs_control
            self.ddfs_tone_0 = ddfs_tone_0
            self.ddfs_tone_1 = ddfs_tone_1

        def _get_index(self):
            return 0x00

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.TX_DDFS_CONFIGURATION

        def _get_data(self):
            bytes = []

            if isinstance(self.ddfs_control, int):
                bytes.append(self.ddfs_control & 0x000000FF)
                bytes.append((self.ddfs_control & 0x0000FF00) >> 8)
                bytes.append((self.ddfs_control & 0x00FF0000) >> 16)
                bytes.append((self.ddfs_control & 0xFF000000) >> 24)
            else:
                ddfs_control_int = self.ddfs_control._get_int()
                bytes.append(ddfs_control_int & 0x000000FF)
                bytes.append((ddfs_control_int & 0x0000FF00) >> 8)
                bytes.append((ddfs_control_int & 0x00FF0000) >> 16)
                bytes.append((ddfs_control_int & 0xFF000000) >> 24)

            if isinstance(self.ddfs_tone_0, int):
                bytes.append(self.ddfs_tone_0 & 0x000000FF)
                bytes.append((self.ddfs_tone_0 & 0x0000FF00) >> 8)
                bytes.append((self.ddfs_tone_0 & 0x00FF0000) >> 16)
                bytes.append((self.ddfs_tone_0 & 0xFF000000) >> 24)
            else:
                ddfs_tone_0_int = self.ddfs_tone_0._get_int()
                bytes.append(ddfs_tone_0_int & 0x000000FF)
                bytes.append((ddfs_tone_0_int & 0x0000FF00) >> 8)
                bytes.append((ddfs_tone_0_int & 0x00FF0000) >> 16)
                bytes.append((ddfs_tone_0_int & 0xFF000000) >> 24)

            if isinstance(self.ddfs_tone_1, int):
                bytes.append(self.ddfs_tone_1 & 0x000000FF)
                bytes.append((self.ddfs_tone_1 & 0x0000FF00) >> 8)
                bytes.append((self.ddfs_tone_1 & 0x00FF0000) >> 16)
                bytes.append((self.ddfs_tone_1 & 0xFF000000) >> 24)
            else:
                ddfs_tone_1_int = self.ddfs_tone_1._get_int()
                bytes.append(ddfs_tone_1_int & 0x000000FF)
                bytes.append((ddfs_tone_1_int & 0x0000FF00) >> 8)
                bytes.append((ddfs_tone_1_int & 0x00FF0000) >> 16)
                bytes.append((ddfs_tone_1_int & 0xFF000000) >> 24)

            return bytes

        @classmethod
        def _get_results(cls, payload: List[int]):
            FFRC_ddfs_enable = int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False) == 0xFFFFFFFF
            FFRC_ddfs_tone_0 = int.from_bytes(bytes=payload[4 : (7 + 1)], byteorder="little", signed=False) == 0xFFFFFFFF
            FFRC_ddfs_tone_1 = int.from_bytes(bytes=payload[8 : (11 + 1)], byteorder="little", signed=False) == 0xFFFFFFFF

            ddfs_control_bits = int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False)
            ddfs_tone_0_bits = int.from_bytes(bytes=payload[4 : (7 + 1)], byteorder="little", signed=False)
            ddfs_tone_1_bits = int.from_bytes(bytes=payload[8 : (11 + 1)], byteorder="little", signed=False)

            ddfs_cnt_set_ns = None if FFRC_ddfs_enable else cls._int_to_ns((ddfs_control_bits >> 3) & 0xFFF)
            ddfs_gap_set_ns = None if FFRC_ddfs_enable else cls._int_to_ns((ddfs_control_bits >> 15) & 0xFF)

            tone_0_increment_khz = None if FFRC_ddfs_tone_0 else cls._int_to_khz((ddfs_tone_0_bits) & 0x7FF)
            tone_0_offset_degree = None if FFRC_ddfs_tone_0 else cls._int_to_deg((ddfs_tone_0_bits >> 11) & 0x7FF)

            tone_1_increment_khz = None if FFRC_ddfs_tone_1 else cls._int_to_khz((ddfs_tone_1_bits) & 0x7FF)
            tone_1_offset_degree = None if FFRC_ddfs_tone_1 else cls._int_to_deg((ddfs_tone_1_bits >> 11) & 0x7FF)

            dither_select = None if FFRC_ddfs_tone_1 else cls.DdfsTone1.EnumDitherSelect((ddfs_tone_1_bits >> 22) & 0x03)

            return BasebandConfiguration.TxDdfsConfiguration(
                ddfs_control=cls.DdfsControl(
                    FETCH_FROM_RADIO_CONFIG=FFRC_ddfs_enable,
                    ddfs_enable=None if FFRC_ddfs_enable else bool(ddfs_control_bits & 0x01),
                    ddfs_cnt_enable=None if FFRC_ddfs_enable else bool(ddfs_control_bits & 0x02),
                    ddfs_post_frame_enable=None if FFRC_ddfs_enable else bool(ddfs_control_bits & 0x04),
                    ddfs_cnt_set_ns=ddfs_cnt_set_ns,
                    ddfs_gap_set_ns=ddfs_gap_set_ns,
                ),
                ddfs_tone_0=cls.DdfsTone0(
                    FETCH_FROM_RADIO_CONFIG=FFRC_ddfs_tone_0, tone_0_increment_khz=tone_0_increment_khz, tone_0_offset_degree=tone_0_offset_degree
                ),
                ddfs_tone_1=cls.DdfsTone1(
                    FETCH_FROM_RADIO_CONFIG=FFRC_ddfs_tone_1,
                    tone_1_increment_khz=tone_1_increment_khz,
                    tone_1_offset_degree=tone_1_offset_degree,
                    dither_select=dither_select,
                ),
            )

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # TX_RANGING_CONTROL_CONFIGURATION
    @frozen
    class TxRangingControlConfiguration(Configuration):
        # FETCH_FROM_RADIO_CONFIG = 0xFF

        class EnumTXEnable(IntEnum):
            DISABLE = 0x00
            TX1_ENABLE = 0x01
            TX2_ENABLE = 0x02

        class EnumTODEnable(IntEnum):
            DISABLE = 0x00
            TOD_ENABLE_SHR_TX1 = 0x01
            TOD_ENABLE_SHR_TX2 = 0x02

        class EnumIndex(IntEnum):
            INDEX_0 = 0x00
            INDEX_1 = 0x01
            INDEX_2 = 0x02
            INDEX_3 = 0x03
            FETCH_FROM_RADIO_CONFIGURATION = 0xFF

        def __init__(
            self,
            config_index: int = 0x00,
            tx_radio_config_index: EnumIndex = EnumIndex.INDEX_0,
            sync_code_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            tx_power_config_index: EnumIndex = EnumIndex.INDEX_0,
            sts_enable: bool = False,
            phr_enable: bool = False,
            psdu_enable: bool = False,
            ddfs_enable: bool = False,
            ranging_enable: bool = False,
            tx_enable: EnumTXEnable = EnumTXEnable.TX1_ENABLE,
            time_of_departure_enable: EnumTODEnable = EnumTODEnable.DISABLE,
            sfd_configuration_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
        ):
            self.config_index = config_index
            self.tx_radio_config_index = tx_radio_config_index
            self.sync_code_config_index = sync_code_config_index
            self.tx_power_config_index = tx_power_config_index
            self.sts_enable = sts_enable
            self.phr_enable = phr_enable
            self.psdu_enable = psdu_enable
            self.ddfs_enable = ddfs_enable
            self.ranging_enable = ranging_enable
            self.tx_enable = tx_enable
            self.time_of_departure_enable = time_of_departure_enable
            self.sfd_configuration_index = sfd_configuration_index
            self._rfu = [0x00]

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.TX_RANGING_CONTROL_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.tx_radio_config_index & 0xFF)
            bytes.append(self.sync_code_config_index & 0xFF)
            bytes.append(self.tx_power_config_index & 0xFF)
            bytes.append(int(self.sts_enable))
            bytes.append(int(self.phr_enable))
            bytes.append(int(self.psdu_enable))
            bytes.append(int(self.ddfs_enable))
            bytes.append(int(self.ranging_enable))
            bytes.append(self.tx_enable & 0xFF)
            bytes.append(self.time_of_departure_enable & 0xFF)
            bytes.append(self.sfd_configuration_index & 0xFF)
            bytes += self._rfu
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.TxRangingControlConfiguration(
                tx_radio_config_index=BasebandConfiguration.TxRangingControlConfiguration.EnumIndex(payload[0]),
                sync_code_config_index=BasebandConfiguration.TxRangingControlConfiguration.EnumIndex(payload[1]),
                tx_power_config_index=payload[2],
                sts_enable=bool(payload[3]),
                phr_enable=bool(payload[4]),
                psdu_enable=bool(payload[5]),
                ddfs_enable=bool(payload[6]),
                ranging_enable=bool(payload[7]),
                tx_enable=BasebandConfiguration.TxRangingControlConfiguration.EnumTXEnable(payload[8]),
                time_of_departure_enable=BasebandConfiguration.TxRangingControlConfiguration.EnumTODEnable(payload[9]),
                sfd_configuration_index=BasebandConfiguration.TxRangingControlConfiguration.EnumIndex(payload[10]),
            )

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # SYNC_CODE_CONFIGURATION
    @frozen
    class SyncCodeConfiguration(Configuration):
        def __init__(self, config_index: int = 0, sync_code_setting: int = 0x00):
            self.config_index = config_index
            self.sync_code_setting = sync_code_setting
            self._rfu = [0x00, 0x00, 0x00]

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.SYNC_CODE_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.sync_code_setting & 0xFF)
            bytes += self._rfu
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.SyncCodeConfiguration(sync_code_setting=payload[0])

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # STS_CONFIGURATION
    @frozen
    class StsConfiguration(Configuration):
        class EnumStsLocation(IntEnum):
            STS1_ENABLE = 0x00
            STS2_ENABLE = 0x01
            FETCH_FROM_RADIO_CONFIG = 0xFF

        class EnumStsLengthControl(IntEnum):
            LENGTH_16_SYMBOLS = 0x00
            LENGTH_32_SYMBOLS = 0x01
            LENGTH_64_SYMBOLS = 0x02
            LENGTH_128_SYMBOLS = 0x03
            LENGTH_256_SYMBOLS = 0x04
            FETCH_FROM_RADIO_CONFIG = 0xFF

        class EnumStsSegmentControl(IntEnum):
            NUMBER_OF_SEGMENTS_1 = 0x00
            NUMBER_OF_SEGMENTS_2 = 0x01
            NUMBER_OF_SEGMENTS_3 = 0x02
            NUMBER_OF_SEGMENTS_4 = 0x03
            FETCH_FROM_RADIO_CONFIG = 0xFF

        class EnumCirPerSegmentControl(IntEnum):
            CIR_PER_SEGMENT = 0x00
            COMBINED_CIR_ALL_SEGMENTS = 0x01
            FETCH_FROM_RADIO_CONFIG = 0xFF

        def __init__(
            self,
            sts_location: EnumStsLocation = EnumStsLocation.FETCH_FROM_RADIO_CONFIG,
            sts_length_control: EnumStsLengthControl = EnumStsLengthControl.FETCH_FROM_RADIO_CONFIG,
            sts_segment_control: EnumStsSegmentControl = EnumStsSegmentControl.FETCH_FROM_RADIO_CONFIG,
            cir_per_segment_control: EnumCirPerSegmentControl = EnumCirPerSegmentControl.FETCH_FROM_RADIO_CONFIG,
            hrp_sts_key: List[int] = [0x14, 0x14, 0x86, 0x74, 0xD1, 0xD3, 0x36, 0xAA, 0xF8, 0x60, 0x50, 0xA8, 0x14, 0xEB, 0x22, 0x0F],
            hrp_sts_vupper96: List[int] = [0x36, 0x2E, 0xEB, 0x34, 0xC4, 0x4F, 0xA8, 0xFB, 0xD3, 0x7E, 0xC3, 0xCA],
            hrp_sts_vcounter: int = 0x1F9A3DE4,
            sts_offset_1: int = 0x00000001,
            sts_offset_2: int = 0x00000001,
            sts_offset_3: int = 0x00000001,
            sts_offset_4: int = 0x00000001,
        ):
            self.sts_location = sts_location
            self.sts_length_control = sts_length_control
            self.sts_segment_control = sts_segment_control
            self.cir_per_segment_control = cir_per_segment_control
            self._rfu = [0x00, 0x00, 0x00, 0x00]
            self.hrp_sts_key = hrp_sts_key
            self.hrp_sts_vupper96 = hrp_sts_vupper96
            self.hrp_sts_vcounter = hrp_sts_vcounter
            self.sts_offset_1 = sts_offset_1
            self.sts_offset_2 = sts_offset_2
            self.sts_offset_3 = sts_offset_3
            self.sts_offset_4 = sts_offset_4

        def _get_index(self):
            return 0x00

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.STS_CONFIGURATION

        def _get_data(self):
            bytes = []
            bytes.append(self.sts_location & 0xFF)
            bytes.append(self.sts_length_control & 0xFF)
            bytes.append(self.sts_segment_control & 0xFF)
            bytes.append(self.cir_per_segment_control & 0xFF)
            bytes += self._rfu

            input_size = len(self.hrp_sts_key)
            for i in range(16):
                if i < input_size:
                    # make sure that each input that is appended is byte sized
                    bytes.append(self.hrp_sts_key[i] & 0xFF)
                else:
                    # pad the input with zeroes if it is too short
                    bytes.append(0x00)

            # repeat the same for hrp_sts_vupper96
            input_size = len(self.hrp_sts_vupper96)
            for i in range(12):
                if i < input_size:
                    bytes.append(self.hrp_sts_vupper96[i] & 0xFF)
                else:
                    bytes.append(0x00)
            # hrp_sts_vcounter shall be transmitted as big endian
            bytes.append((self.hrp_sts_vcounter & 0xFF000000) >> 24)
            bytes.append((self.hrp_sts_vcounter & 0x00FF0000) >> 16)
            bytes.append((self.hrp_sts_vcounter & 0x0000FF00) >> 8)
            bytes.append(self.hrp_sts_vcounter & 0x000000FF)

            bytes.append(self.sts_offset_1 & 0x000000FF)
            bytes.append((self.sts_offset_1 & 0x0000FF00) >> 8)
            bytes.append((self.sts_offset_1 & 0x00FF0000) >> 16)
            bytes.append((self.sts_offset_1 & 0xFF000000) >> 24)
            bytes.append(self.sts_offset_2 & 0x000000FF)
            bytes.append((self.sts_offset_2 & 0x0000FF00) >> 8)
            bytes.append((self.sts_offset_2 & 0x00FF0000) >> 16)
            bytes.append((self.sts_offset_2 & 0xFF000000) >> 24)
            bytes.append(self.sts_offset_3 & 0x000000FF)
            bytes.append((self.sts_offset_3 & 0x0000FF00) >> 8)
            bytes.append((self.sts_offset_3 & 0x00FF0000) >> 16)
            bytes.append((self.sts_offset_3 & 0xFF000000) >> 24)
            bytes.append(self.sts_offset_4 & 0x000000FF)
            bytes.append((self.sts_offset_4 & 0x0000FF00) >> 8)
            bytes.append((self.sts_offset_4 & 0x00FF0000) >> 16)
            bytes.append((self.sts_offset_4 & 0xFF000000) >> 24)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.StsConfiguration(
                sts_location=BasebandConfiguration.StsConfiguration.EnumStsLocation(payload[0]),
                sts_length_control=BasebandConfiguration.StsConfiguration.EnumStsLengthControl(payload[1]),
                sts_segment_control=BasebandConfiguration.StsConfiguration.EnumStsSegmentControl(payload[2]),
                cir_per_segment_control=BasebandConfiguration.StsConfiguration.EnumCirPerSegmentControl(payload[3]),
                hrp_sts_key=payload[8 : (23 + 1)],
                hrp_sts_vupper96=payload[24 : (35 + 1)],
                hrp_sts_vcounter=payload[36 : (39 + 1)],
                sts_offset_1=int.from_bytes(bytes=payload[40 : (43 + 1)], byteorder="little", signed=False),
                sts_offset_2=int.from_bytes(bytes=payload[44 : (47 + 1)], byteorder="little", signed=False),
                sts_offset_3=int.from_bytes(bytes=payload[48 : (51 + 1)], byteorder="little", signed=False),
                sts_offset_4=int.from_bytes(bytes=payload[52 : (55 + 1)], byteorder="little", signed=False),
            )

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # COMMAND_CONFIGURATION
    @frozen
    class CommandConfiguration(Configuration):
        class EnumIndex(IntEnum):
            INDEX_0 = 0x00
            INDEX_1 = 0x01
            INDEX_2 = 0x02
            INDEX_3 = 0x03
            NOT_USED_FOR_THIS_OPERATION = 0xFF

        class EnumCommandType(IntEnum):
            RX_FRAME_MODE = 0x00
            TX_FRAME_MODE = 0x01
            TRX_FRAME_MODE = 0x02
            TX_FRAME_MODE_RX_RADAR_MODE = 0x03
            RX_RADAR_MODE = 0x04
            TX_RADAR_MODE = 0x05
            TRX_RADAR_MODE = 0x06
            TRX_RADAR_FULL_CALIBRATION_MODE = 0x07
            TRX_RADAR_FAST_CALIBRATION_MODE = 0x08
            RADAR_NOISE_SUPPRESSION_CALIBRATION_MODE = 0x09
            DSP_TOOLBOX_MODE = 0x0B
            EMPTY_SLOT = 0x0C

        @staticmethod
        def _ns_to_int(time: float):
            # the steps between each index are 8.0128ns
            result = int(round(time / 8.0128))
            # check for results smaller than zero
            result = 0 if result < 0 else result
            return result

        @staticmethod
        def _int_to_ns(integer):
            # the steps between each index are 8.0128ns
            result = integer * 8.0128
            # check for results smaller than zero
            result = 0 if integer < 0 else result
            # round up
            result = ceil(result)
            return result

        def __init__(
            self,
            config_index: int = 0,
            command_type: EnumCommandType = EnumCommandType.RX_FRAME_MODE,
            rx_control_index: EnumIndex = EnumIndex.INDEX_0,
            tx_control_index: EnumIndex = EnumIndex.INDEX_0,
            toolbox_control_index: EnumIndex = EnumIndex.NOT_USED_FOR_THIS_OPERATION,
            frequency_control_index: EnumIndex = EnumIndex.NOT_USED_FOR_THIS_OPERATION,  # RFU. Any input value here is overwritten by Testware onic application with 0xFF
            command_repeat_count: int = 0x01,
            repeat_interval_ns: float = 500000,
            sequence_interval_ns: float = 500000,
        ):
            self.config_index = config_index
            self.command_type = command_type
            self.rx_control_index = rx_control_index
            self.tx_control_index = tx_control_index
            self.toolbox_control_index = toolbox_control_index
            self.frequency_control_index = frequency_control_index
            self.command_repeat_count = command_repeat_count
            self.repeat_interval_ns = repeat_interval_ns
            self.sequence_interval_ns = sequence_interval_ns

        def _get_index(self):
            return self.config_index

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.COMMAND_CONFIGURATION

        def _get_data(self):
            bytes = []
            bytes.append(self.command_type & 0x000000FF)
            bytes.append((self.command_type & 0x0000FF00) >> 8)
            bytes.append((self.command_type & 0x00FF0000) >> 16)
            bytes.append((self.command_type & 0xFF000000) >> 24)
            bytes.append(self.rx_control_index & 0xFF)
            bytes.append(self.tx_control_index & 0xFF)
            bytes.append(self.toolbox_control_index & 0xFF)
            bytes.append(self.frequency_control_index & 0xFF)
            bytes.append(self.command_repeat_count & 0x000000FF)
            bytes.append((self.command_repeat_count & 0x0000FF00) >> 8)
            bytes.append((self.command_repeat_count & 0x00FF0000) >> 16)
            bytes.append((self.command_repeat_count & 0xFF000000) >> 24)
            repeat_interval_bytes = self._ns_to_int(self.repeat_interval_ns)
            bytes.append(repeat_interval_bytes & 0x000000FF)
            bytes.append((repeat_interval_bytes & 0x0000FF00) >> 8)
            bytes.append((repeat_interval_bytes & 0x00FF0000) >> 16)
            bytes.append((repeat_interval_bytes & 0xFF000000) >> 24)
            sequence_interval_bytes = self._ns_to_int(self.sequence_interval_ns)
            bytes.append(sequence_interval_bytes & 0x000000FF)
            bytes.append((sequence_interval_bytes & 0x0000FF00) >> 8)
            bytes.append((sequence_interval_bytes & 0x00FF0000) >> 16)
            bytes.append((sequence_interval_bytes & 0xFF000000) >> 24)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.CommandConfiguration(
                command_type=BasebandConfiguration.CommandConfiguration.EnumCommandType(payload[0]),
                rx_control_index=BasebandConfiguration.CommandConfiguration.EnumIndex(payload[4]),
                tx_control_index=BasebandConfiguration.CommandConfiguration.EnumIndex(payload[5]),
                toolbox_control_index=BasebandConfiguration.CommandConfiguration.EnumIndex(payload[6]),
                frequency_control_index=BasebandConfiguration.CommandConfiguration.EnumIndex(payload[7]),
                command_repeat_count=int.from_bytes(bytes=payload[8 : (11 + 1)], byteorder="little", signed=False),
                repeat_interval_ns=BasebandConfiguration.CommandConfiguration._int_to_ns(
                    int.from_bytes(bytes=payload[12 : (15 + 1)], byteorder="little", signed=False)
                ),
                sequence_interval_ns=BasebandConfiguration.CommandConfiguration._int_to_ns(
                    int.from_bytes(bytes=payload[16 : (19 + 1)], byteorder="little", signed=False)
                ),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.command_repeat_count = (
                self.command_repeat_count if self.command_repeat_count != 0 else "0x00000000: Endless execution of the selected command operation"
            )
            _self.repeat_interval_ns = str(self.repeat_interval_ns) + " ns"
            _self.sequence_interval_ns = str(self.sequence_interval_ns) + " ns"
            return class_to_str(_self, include_title=True, indent_level=1)

    # SFD_CONFIGURATION
    @frozen
    class SfdConfiguration(Configuration):
        def __init__(self, config_index: int = 0x00, sfd_id: int = 0x00):
            self.config_index = config_index
            self.sfd_id = sfd_id
            self._rfu = [0x00, 0x00, 0x00]

        def _get_index(self):
            return self.config_index

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.SFD_CONFIGURATION

        def _get_data(self):
            bytes = []
            bytes.append(self.sfd_id & 0xFF)
            bytes += self._rfu
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.SfdConfiguration(sfd_id=payload[0])

        def __str__(self) -> str:
            _self = deepcopy(self)

            match self.sfd_id:
                case 0x00:
                    _self.sfd_id = "0x00 (SFD ID 0: [0, +1, 0, -1, +1, 0, 0, -1] Supported for BPRF frames)"
                case 0x01:
                    _self.sfd_id = "0x01 (SFD ID 1: [-1, -1, +1, -1] Supported for HPRF frames)"
                case 0x02:
                    _self.sfd_id = "0x02 (SFD ID 2: [-1, -1, -1, +1, -1, -1, +1, -1] Supported for BPRF and HPRF frames)"
                case 0x03:
                    _self.sfd_id = "0x03 (SFD ID 3: [-1, -1, -1, -1, -1, +1, +1, -1, -1, +1, -1, +1, -1, -1, +1, -1] Supported for HPRF frames)"
                case _:
                    _self.sfd_id = f"{self.sfd_id} (INVALID PARAMETER)"

            return class_to_str(_self, include_title=True, indent_level=1)

    # RX_RADAR_CIR_CONFIGURATION
    @frozen
    class RxRadarCirConfiguration(Configuration):
        class EnumBufferSize(IntEnum):
            BUFFER_32KB = 0x00
            BUFFER_64KB = 0x01
            BUFFER_96KB = 0x02
            BUFFER_128KB = 0x03

        @frozen
        class LprfRadarMode:
            def __init__(
                self,
                enable_radar_mode: bool = False,
                enable_lprf_radar_long_range_mode_control_RX1: bool = False,
                enable_lprf_radar_long_range_mode_control_RX2: bool = False,
            ):
                self.enable_radar_mode = enable_radar_mode
                self.enable_lprf_radar_long_range_mode_control_RX1 = enable_lprf_radar_long_range_mode_control_RX1
                self.enable_lprf_radar_long_range_mode_control_RX2 = enable_lprf_radar_long_range_mode_control_RX2

            def __str__(self):
                return class_to_str(self, include_title=True, indent_level=2)

        @frozen
        class RadarDataAcquisitionMode:
            class EnumAnalogCoupling(IntEnum):
                AC = 0x00
                DC = 0x01

            class EnumRadarDataSelect(IntEnum):
                CORRELATED_DATA = 0x00
                RAW_BINNING_DATA = 0x01

            def __init__(
                self,
                analog_coupling: EnumAnalogCoupling = EnumAnalogCoupling.DC,
                radar_data_selection: EnumRadarDataSelect = EnumRadarDataSelect.CORRELATED_DATA,
                disable_agc_control_radar_fast_calibration: bool = False,
                wired_synch_control_enable: bool = False,
            ):
                self.analog_coupling = analog_coupling
                self.radar_data_selection = radar_data_selection
                self.disable_agc_control_radar_fast_calibration = disable_agc_control_radar_fast_calibration
                self.rfu = 0
                self.wired_synch_control_enable = wired_synch_control_enable

            def __str__(self):
                return class_to_str(self, include_title=True, indent_level=2)

        def __init__(
            self,
            config_index: int = 0,
            cir_taps: int = 0x0040,
            rx_sync_symbol_cnt: int = 0x0000,
            cir_offset: int = 0x0000,
            rx_sensitivity_boost_offset_rx1: int = 0x00,
            rx_sensitivity_boost_offset_rx2: int = 0x00,
            cir_notification_threshold: int = 0x00000000,
            timestamp_logging_enbl: bool = False,
            cir_buffer_size: EnumBufferSize = EnumBufferSize.BUFFER_32KB,
            data_acq_mode: RadarDataAcquisitionMode = RadarDataAcquisitionMode(),
            lprf_radar_mode: LprfRadarMode = LprfRadarMode(),
        ):
            self.config_index = config_index
            self.cir_taps = cir_taps
            self.rx_sync_symbol_cnt = rx_sync_symbol_cnt
            self.cir_offset = cir_offset
            self.rx_sensitivity_boost_offset_rx1 = rx_sensitivity_boost_offset_rx1
            self.rx_sensitivity_boost_offset_rx2 = rx_sensitivity_boost_offset_rx2
            self.cir_notification_threshold = cir_notification_threshold
            self.timestamp_logging_enbl = timestamp_logging_enbl
            self.cir_buffer_size = cir_buffer_size
            self.data_acq_mode = data_acq_mode
            self.lprf_radar_mode = lprf_radar_mode

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_RADAR_CIR_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.cir_taps & 0x00FF)
            bytes.append((self.cir_taps & 0xFF00) >> 8)
            self.rx_sync_symbol_cnt = int(self.rx_sync_symbol_cnt / 8)
            bytes.append(self.rx_sync_symbol_cnt & 0x00FF)
            bytes.append((self.rx_sync_symbol_cnt & 0xFF00) >> 8)
            bytes.append(self.cir_offset & 0x00FF)
            bytes.append((self.cir_offset & 0xFF00) >> 8)
            bytes.append(self.rx_sensitivity_boost_offset_rx1)
            bytes.append(self.rx_sensitivity_boost_offset_rx2)
            bytes.append(self.cir_notification_threshold & 0x000000FF)
            bytes.append((self.cir_notification_threshold & 0x0000FF00) >> 8)
            bytes.append((self.cir_notification_threshold & 0x00FF0000) >> 16)
            bytes.append((self.cir_notification_threshold & 0xFF000000) >> 24)
            bytes.append(int(self.timestamp_logging_enbl) & 0xFF)
            bytes.append(self.cir_buffer_size)
            bytes.append(
                (self.data_acq_mode.analog_coupling & 0x01)
                | ((self.data_acq_mode.radar_data_selection & 0x01) << 1)
                | ((self.data_acq_mode.disable_agc_control_radar_fast_calibration & 0x01) << 2)
                | ((self.data_acq_mode.rfu & 0x01) << 3)
                | ((self.data_acq_mode.wired_synch_control_enable & 0x01) << 4)
            )
            bytes.append(
                (self.lprf_radar_mode.enable_radar_mode << 0)
                | (self.lprf_radar_mode.enable_lprf_radar_long_range_mode_control_RX1 << 1)
                | (self.lprf_radar_mode.enable_lprf_radar_long_range_mode_control_RX2 << 2)
            )
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.RxRadarCirConfiguration(
                cir_taps=int.from_bytes(bytes=payload[0 : (1 + 1)], byteorder="little", signed=False),
                rx_sync_symbol_cnt=int.from_bytes(bytes=payload[2 : (3 + 1)], byteorder="little", signed=False),
                cir_offset=int.from_bytes(bytes=payload[4 : (5 + 1)], byteorder="little", signed=False),
                rx_sensitivity_boost_offset_rx1=payload[6],
                rx_sensitivity_boost_offset_rx2=payload[7],
                cir_notification_threshold=int.from_bytes(bytes=payload[8 : (11 + 1)], byteorder="little", signed=False),
                timestamp_logging_enbl=bool(payload[12]),
                cir_buffer_size=BasebandConfiguration.RxRadarCirConfiguration.EnumBufferSize(payload[13]),
                data_acq_mode=BasebandConfiguration.RxRadarCirConfiguration.RadarDataAcquisitionMode(
                    analog_coupling=BasebandConfiguration.RxRadarCirConfiguration.RadarDataAcquisitionMode.EnumAnalogCoupling(payload[14] & 1 << 0),
                    radar_data_selection=BasebandConfiguration.RxRadarCirConfiguration.RadarDataAcquisitionMode.EnumRadarDataSelect(
                        (payload[14] & 1 << 1) >> 1
                    ),
                    disable_agc_control_radar_fast_calibration=bool((payload[14] & 1 << 2)),
                    rfu=bool((payload[14] & 1 << 3)),
                    wired_synch_control_enable=bool((payload[14] & 1 << 4))
                ),
                lprf_radar_mode=BasebandConfiguration.RxRadarCirConfiguration.LprfRadarMode(
                    enable_radar_mode=bool(payload[15] & 1 << 0),
                    enable_lprf_radar_long_range_mode_control_RX1=bool(payload[15] & 1 << 1),
                    enable_lprf_radar_long_range_mode_control_RX2=bool(payload[15] & 1 << 2),
                ),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.rx_sync_symbol_cnt = (
                f"{'0x{:04x}'.format(self.rx_sync_symbol_cnt)}: Count: {self.rx_sync_symbol_cnt * 8}"
                if self.rx_sync_symbol_cnt != 0
                else f"{'0x{:04x}'.format(self.rx_sync_symbol_cnt)} (default: 256)"
            )
            _self.cir_notification_threshold = (
                self.cir_notification_threshold
                if self.cir_notification_threshold != 0
                else f"{'0x{:02x}'.format(self.cir_notification_threshold)} (disabled)"
            )
            return class_to_str(_self, include_title=True, indent_level=1)

    # RX_RADAR_CONTROL_CONFIGURATION
    @frozen
    class RxRadarControlConfiguration(Configuration):
        class EnumIndex(IntEnum):
            INDEX_0 = 0x00
            INDEX_1 = 0x01
            INDEX_2 = 0x02
            INDEX_3 = 0x03
            FETCH_FROM_RADIO_CONFIGURATION = 0xFF

        class EnumRXEnable(IntEnum):
            DISABLE = 0x00
            RX1_ENABLE = 0x01
            RX2_ENABLE = 0x02
            RX1_RX2_ENABLE = 0x03

        class EnumSensitivityBoostEnable(IntEnum):
            DISABLE = 0x00
            RX1_ENABLE = 0x01
            RX2_ENABLE = 0x02
            RX1_RX2_ENABLE = 0x03

        def __init__(
            self,
            config_index: int = 0x00,
            rx_radio_config_index: int = 0x00,
            sync_code_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            rx_digital_frontend_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            rx_radar_cir_config_index: EnumIndex = EnumIndex.INDEX_0,
            rx_radar_calibration_select: int = 0x00,
            rns_configuration_index: EnumIndex = EnumIndex.INDEX_0,
            rx_enable: EnumRXEnable = EnumRXEnable.RX1_ENABLE,
            sensitivity_boost_enable: EnumSensitivityBoostEnable = EnumSensitivityBoostEnable.DISABLE,
        ):
            self.config_index = config_index
            self.rx_radio_config_index = rx_radio_config_index
            self.sync_code_config_index = sync_code_config_index
            self.rx_digital_frontend_config_index = rx_digital_frontend_config_index
            self.rx_radar_cir_config_index = rx_radar_cir_config_index
            self.rx_radar_calibration_select = rx_radar_calibration_select
            self.rns_configuration_index = rns_configuration_index
            self.rx_enable = rx_enable
            self.sensitivity_boost_enable = sensitivity_boost_enable

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_RADAR_CONTROL_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.rx_radio_config_index & 0xFF)
            bytes.append(self.sync_code_config_index & 0xFF)
            bytes.append(self.rx_digital_frontend_config_index & 0xFF)
            bytes.append(self.rx_radar_cir_config_index & 0xFF)
            bytes.append(self.rx_radar_calibration_select & 0xFF)
            bytes.append(self.rns_configuration_index & 0xFF)
            bytes.append(self.rx_enable & 0xFF)
            bytes.append(self.sensitivity_boost_enable & 0xFF)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.RxRadarControlConfiguration(
                rx_radio_config_index=BasebandConfiguration.RxRadarControlConfiguration.EnumIndex(payload[0]),
                sync_code_config_index=BasebandConfiguration.RxRadarControlConfiguration.EnumIndex(payload[1]),
                rx_digital_frontend_config_index=BasebandConfiguration.RxRadarControlConfiguration.EnumIndex(payload[2]),
                rx_radar_cir_config_index=BasebandConfiguration.RxRadarControlConfiguration.EnumIndex(payload[3]),
                rx_radar_calibration_select=payload[4],
                rns_configuration_index=BasebandConfiguration.RxRadarControlConfiguration.EnumIndex(payload[5]),
                rx_enable=BasebandConfiguration.RxRadarControlConfiguration.EnumRXEnable(payload[6]),
                sensitivity_boost_enable=BasebandConfiguration.RxRadarControlConfiguration.EnumSensitivityBoostEnable(payload[7]),
            )

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # TX_RADAR_CONTROL_CONFIGURATION
    @frozen
    class TxRadarControlConfiguration(Configuration):
        class EnumIndex(IntEnum):
            INDEX_0 = 0x00
            INDEX_1 = 0x01
            INDEX_2 = 0x02
            INDEX_3 = 0x03
            FETCH_FROM_RADIO_CONFIGURATION = 0xFF

        class EnumTXEnable(IntEnum):
            DISABLE = 0x00
            TX1_ENABLE = 0x01
            TX2_ENABLE = 0x02

        def __init__(
            self,
            config_index: int = 0x00,
            tx_radio_config_index: EnumIndex = EnumIndex.INDEX_0,
            sync_code_config_index: EnumIndex = EnumIndex.FETCH_FROM_RADIO_CONFIGURATION,
            tx_power_config_index: EnumIndex = EnumIndex.INDEX_0,
            tx_enable: EnumTXEnable = EnumTXEnable.TX1_ENABLE,
            tx_sync_symbol_cnt: int = 0x0000,
            sfd_enbl: bool = False,
        ):
            self.config_index = config_index
            self.tx_radio_config_index = tx_radio_config_index
            self.sync_code_config_index = sync_code_config_index
            self.tx_power_config_index = tx_power_config_index
            self.tx_enable = tx_enable
            self.tx_sync_symbol_cnt = tx_sync_symbol_cnt
            self.sfd_enbl = sfd_enbl

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.TX_RADAR_CONTROL_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.tx_radio_config_index & 0xFF)
            bytes.append(self.sync_code_config_index & 0xFF)
            bytes.append(self.tx_power_config_index & 0xFF)
            bytes.append(self.tx_enable & 0xFF)
            self.tx_sync_symbol_cnt = int(self.tx_sync_symbol_cnt / 8)
            bytes.append(self.tx_sync_symbol_cnt & 0x00FF)
            bytes.append((self.tx_sync_symbol_cnt & 0xFF00) >> 8)
            bytes.append(int(self.sfd_enbl) & 0x00FF)
            bytes.append((int(self.sfd_enbl)& 0xFF00) >> 8)
            return bytes

        @classmethod
        def _get_results(cls, payload):
            return BasebandConfiguration.TxRadarControlConfiguration(
                tx_radio_config_index=BasebandConfiguration.TxRadarControlConfiguration.EnumIndex(payload[0]),
                sync_code_config_index=BasebandConfiguration.TxRadarControlConfiguration.EnumIndex(payload[1]),
                tx_power_config_index=BasebandConfiguration.TxRadarControlConfiguration.EnumIndex(payload[2]),
                tx_enable=BasebandConfiguration.TxRadarControlConfiguration.EnumTXEnable(payload[3]),
                tx_sync_symbol_cnt=int.from_bytes(bytes=payload[4:6], byteorder="little", signed=False),
                sfd_enbl=bool(int.from_bytes(bytes=payload[6:8], byteorder="little", signed=False)),
            )

        def __str__(self) -> str:
            _self = deepcopy(self)
            _self.tx_sync_symbol_cnt = (
                f"{'0x{:04x}'.format(self.tx_sync_symbol_cnt)}: Count: {self.tx_sync_symbol_cnt * 8}"
                if self.tx_sync_symbol_cnt != 0
                else f"{'0x{:04x}'.format(self.tx_sync_symbol_cnt)} (default: 256)"
            )
            return class_to_str(_self, include_title=True, indent_level=1)

    # RX_RADAR_CALIBRATION_DATA
    @frozen
    class RxRadarCalibrationData(Configuration):
        # Attenuation RX1or2 in dB = (Attenuation RX1or2 stage #1 in dB + (2 * Attenuation RX1or2 stage #2 in dB/2) + (2 * Attenuation RX1or2 stage #3 in dB/2)
        def __init__(
            self,
            config_index: int = 0x00,
            rx1_attenuation_stage_1: int = 0,
            rx1_attenuation_stage_2: int = 0,
            rx1_attenuation_stage_3: int = 0,
            rx1_radar_calibration_data: List[int] = [0x00] * 44,
            rx2_attenuation_stage_1: int = 0,
            rx2_attenuation_stage_2: int = 0,
            rx2_attenuation_stage_3: int = 0,
            rx2_radar_calibration_data: List[int] = [0x00] * 44,
        ):
            self.config_index = config_index
            self.rx1_attenuation_stage_1 = rx1_attenuation_stage_1
            self.rx1_attenuation_stage_2 = rx1_attenuation_stage_2
            self.rx1_attenuation_stage_3 = rx1_attenuation_stage_3
            self.rx1_radar_calibration_data = rx1_radar_calibration_data
            self.rx2_attenuation_stage_1 = rx2_attenuation_stage_1
            self.rx2_attenuation_stage_2 = rx2_attenuation_stage_2
            self.rx2_attenuation_stage_3 = rx2_attenuation_stage_3
            self.rx2_radar_calibration_data = rx2_radar_calibration_data

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RX_RADAR_CALIBRATION_DATA

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            rx_attenuation: int = 0
            rx_attenuation = (
                (self.rx1_attenuation_stage_1 & 0x1F) | ((self.rx1_attenuation_stage_2 & 0x0F) << 5) | ((self.rx1_attenuation_stage_3 & 0x0F) << 9)
            )
            bytes += rx_attenuation.to_bytes(length=4, byteorder="little", signed=False)
            bytes += self.rx1_radar_calibration_data
            rx_attenuation = (
                (self.rx2_attenuation_stage_1 & 0x1F) | ((self.rx2_attenuation_stage_2 & 0x0F) << 5) | ((self.rx2_attenuation_stage_3 & 0x0F) << 9)
            )
            bytes += rx_attenuation.to_bytes(length=4, byteorder="little", signed=False)
            bytes += self.rx2_radar_calibration_data
            return bytes

        @classmethod
        def _get_results(cls, payload: List[int]):
            rx1_attenuation = int.from_bytes(bytes=payload[0:4], byteorder="little", signed=False)
            rx2_attenuation = int.from_bytes(bytes=payload[48:53], byteorder="little", signed=False)

            results = BasebandConfiguration.RxRadarCalibrationData(
                rx1_attenuation_stage_1=rx1_attenuation & 0x1F,
                rx1_attenuation_stage_2=(rx1_attenuation >> 5) & 0x0F,
                rx1_attenuation_stage_3=(rx1_attenuation >> 9) & 0x0F,
                rx1_radar_calibration_data=payload[4 : (47 + 1)],
                rx2_attenuation_stage_1=rx2_attenuation & 0x1F,
                rx2_attenuation_stage_2=(rx2_attenuation >> 5) & 0x0F,
                rx2_attenuation_stage_3=(rx2_attenuation >> 9) & 0x0F,
                rx2_radar_calibration_data=payload[52 : (95 + 1)],
            )
            return results

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # RNS_CONFIGURATION
    @frozen
    class RadarNoiseSuppressionConfiguration(Configuration):
        @frozen
        class RadarNoiseSuppression:
            @frozen
            class RadarNoiseSuppressionControl:
                class EnumRnsDriftMode(IntEnum):
                    DC_REMOVAL = 0x00
                    DC_FREEZE = 0x01

                def __init__(
                    self,
                    noise_suppression_enable: bool = False,
                    drift_suppression_enable: bool = False,
                    drift_suppression_mode: EnumRnsDriftMode = EnumRnsDriftMode.DC_REMOVAL,
                ):
                    self.noise_suppression_enable = noise_suppression_enable
                    self.drift_suppression_enable = drift_suppression_enable
                    self.drift_suppression_mode = drift_suppression_mode

                def __str__(self):
                    return class_to_str(self, include_title=False, indent_level=3)

            def __init__(
                self,
                rns_control: RadarNoiseSuppressionControl,
                self_interference_tap: int = 0x0000,
                noise_suppression_index_mask: int = 0x00000000,
                dc_coefficient: int = 0x0000,
                rns_calibration_slot_index: int = 0x00,
                thr_scale: int = 0x00,
            ):
                self.self_interference_tap = self_interference_tap
                self.rns_control = rns_control
                self.noise_suppression_index_mask = noise_suppression_index_mask
                self.dc_coefficient = dc_coefficient
                self.rns_calibration_slot_index = rns_calibration_slot_index
                self.thr_scale = thr_scale

            def __str__(self):
                return class_to_str(self, include_title=False, indent_level=2)

        def __init__(
            self,
            config_index: int = 0x00,
            radar_noise_suppression_cfg_rx1: RadarNoiseSuppression = RadarNoiseSuppression(
                rns_control=RadarNoiseSuppression.RadarNoiseSuppressionControl()
            ),
            radar_noise_suppression_cfg_rx2: RadarNoiseSuppression = RadarNoiseSuppression(
                rns_control=RadarNoiseSuppression.RadarNoiseSuppressionControl()
            ),
        ):
            self.config_index = config_index
            self.radar_noise_suppression_cfg_rx1 = radar_noise_suppression_cfg_rx1
            self.radar_noise_suppression_cfg_rx2 = radar_noise_suppression_cfg_rx2

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.RADAR_NOISE_SUPPRESSION_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []

            bytes += list(self.radar_noise_suppression_cfg_rx1.self_interference_tap.to_bytes(length=2, byteorder="little", signed=False))
            rns_control: int = 0
            rns_control = (
                (int(self.radar_noise_suppression_cfg_rx1.rns_control.noise_suppression_enable) << 0)
                | (int(self.radar_noise_suppression_cfg_rx1.rns_control.drift_suppression_enable) << 1)
                | (int(self.radar_noise_suppression_cfg_rx1.rns_control.drift_suppression_mode) << 2)
            )
            bytes += list(rns_control.to_bytes(length=2, byteorder="little", signed=False))
            bytes += list(self.radar_noise_suppression_cfg_rx1.noise_suppression_index_mask.to_bytes(length=4, byteorder="little", signed=False))
            bytes += list(self.radar_noise_suppression_cfg_rx1.dc_coefficient.to_bytes(length=2, byteorder="little", signed=False))
            bytes += self.radar_noise_suppression_cfg_rx1.rns_calibration_slot_index.to_bytes(length=1, byteorder="little", signed=False)
            bytes += self.radar_noise_suppression_cfg_rx1.thr_scale.to_bytes(length=1, byteorder="little", signed=True)
            bytes += [0x00, 0x00, 0x00, 0x00]  # RFU

            bytes += list(self.radar_noise_suppression_cfg_rx2.self_interference_tap.to_bytes(length=2, byteorder="little", signed=False))
            rns_control = 0
            rns_control = (
                (int(self.radar_noise_suppression_cfg_rx2.rns_control.noise_suppression_enable) << 0)
                | (int(self.radar_noise_suppression_cfg_rx2.rns_control.drift_suppression_enable) << 1)
                | (int(self.radar_noise_suppression_cfg_rx2.rns_control.drift_suppression_mode) << 2)
            )
            bytes += list(rns_control.to_bytes(length=2, byteorder="little", signed=False))
            bytes += list(self.radar_noise_suppression_cfg_rx2.noise_suppression_index_mask.to_bytes(length=4, byteorder="little", signed=False))
            bytes += list(self.radar_noise_suppression_cfg_rx2.dc_coefficient.to_bytes(length=2, byteorder="little", signed=False))
            bytes += self.radar_noise_suppression_cfg_rx2.rns_calibration_slot_index.to_bytes(length=1, byteorder="little", signed=False)
            bytes += self.radar_noise_suppression_cfg_rx2.thr_scale.to_bytes(length=1, byteorder="little", signed=True)
            bytes += [0x00, 0x00, 0x00, 0x00]  # RFU

            return bytes

        @classmethod
        def _get_results(cls, payload: List[int]):
            noise_suppr_cfgs = []

            for index in range(2):
                cfg = BasebandConfiguration.RadarNoiseSuppressionConfiguration.RadarNoiseSuppression(
                    self_interference_tap=int.from_bytes(bytes=payload[(index * 16) + 0 : (index * 16) + 2], byteorder="little", signed=False),
                    rns_control=BasebandConfiguration.RadarNoiseSuppressionConfiguration.RadarNoiseSuppression.RadarNoiseSuppressionControl(
                        noise_suppression_enable=bool(
                            int.from_bytes(bytes=payload[(index * 16) + 2 : (index * 16) + 4], byteorder="little", signed=False) & (0x00001 << 0)
                        ),
                        drift_suppression_enable=bool(
                            int.from_bytes(bytes=payload[(index * 16) + 2 : (index * 16) + 4], byteorder="little", signed=False) & (0x00001 << 1)
                        ),
                        drift_suppression_mode=BasebandConfiguration.RadarNoiseSuppressionConfiguration.RadarNoiseSuppression.RadarNoiseSuppressionControl.EnumRnsDriftMode(
                            int.from_bytes(bytes=payload[(index * 16) + 2 : (index * 16) + 4], byteorder="little", signed=False) & (0x00001 << 2) >> 2
                        ),
                    ),
                    noise_suppression_index_mask=int.from_bytes(bytes=payload[(index * 16) + 4 : (index * 16) + 8], byteorder="little", signed=False),
                    dc_coefficient=int.from_bytes(bytes=payload[(index * 16) + 8 : (index * 16) + 10], byteorder="little", signed=False),
                    rns_calibration_slot_index=payload[(index * 16) + 10],
                    thr_scale=payload[(index * 16) + 11],
                )
                noise_suppr_cfgs.append(cfg)

            results = BasebandConfiguration.RadarNoiseSuppressionConfiguration(
                radar_noise_suppression_cfg_rx1=noise_suppr_cfgs[0],
                radar_noise_suppression_cfg_rx2=noise_suppr_cfgs[1],
            )
            return results

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # PERFORM_AGC_CALIBRATION
    @frozen
    class PerformAgcCalibration(Configuration):
        def __init__(
            self,
            config_index: int = 0x00,
        ):
            self.config_index = config_index

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.PERFORM_AGC_CALIBRATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            return bytes

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandConfiguration.PerformAgcCalibration()
            return results

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # PLL_RECALIBRATION
    @frozen
    class PllRecalibration(Configuration):
        def __init__(
            self,
            config_index: int = 0x00,
            pll_recalib_enable: bool = True,
        ):
            self.config_index = config_index
            self.pll_recalib_enable = pll_recalib_enable

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.PLL_RECALIBRATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.pll_recalib_enable & 0xFF)
            return bytes

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandConfiguration.PllRecalibration(pll_recalib_enable=bool(payload[0]))
            return results

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    # CALLBACK_CONFIGURATION
    @frozen
    class CallbackConfiguration(Configuration):
        def __init__(
            self,
            config_index: int = 0x00,
            idle_callback_enable: bool = True,
            ready_callback_enable: bool = True,
            active_callback_enable: bool = True,
        ):
            self.config_index = config_index
            self.idle_callback_enable = idle_callback_enable
            self.ready_callback_enable = ready_callback_enable
            self.active_callback_enable = active_callback_enable

        def _get_select(self):
            return BasebandConfiguration.ConfigurationSelect.CALLBACK_CONFIGURATION

        def _get_index(self):
            return self.config_index

        def _get_data(self):
            bytes = []
            bytes.append(self.idle_callback_enable & 0xFF)
            bytes.append(self.ready_callback_enable & 0xFF)
            bytes.append(self.active_callback_enable & 0xFF)
            return bytes

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandConfiguration.CallbackConfiguration(
                idle_callback_enable=bool(payload[0]),
                ready_callback_enable=bool(payload[1]),
                active_callback_enable=bool(payload[2]),
            )
            return results

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

    def __init__(
        self,
        configuration_select: ConfigurationSelect = ConfigurationSelect.RX_RADIO_CONFIGURATION,
        configuration_index: int = 0x00,
        configuration_data: List[int] = [0x00, 0x00, 0x00, 0x00, 0x00],
    ):
        self.configuration_select = configuration_select
        self.configuration_index = configuration_index
        self.configuration_data = configuration_data

    def __str__(self) -> str:
        return class_to_str(self)

    # Factory method that creates a baseband configuration out of a specific configuration object
    @classmethod
    def from_config(cls, configuration: Configuration):
        baseband_config = BasebandConfiguration(
            configuration_select=configuration._get_select(),
            configuration_index=configuration._get_index(),
            configuration_data=configuration._get_data(),
        )
        return baseband_config


# NTF_BOOT_STATUS
@frozen
class BootStatus:
    class EnumPowerResetControlFlags(IntEnum):
        POR_RST_FLAG = 0
        RST_PIN_FLAG = 1
        DPD_RST_PIN_RST_FLAG = 2
        HPD_RST_PIN_RST_FLAG = 3
        HPD_WUP_RST_PIN_RST_FLAG = 4
        SW_MASTER_RST_FLAG = 5
        VDD_BIAS_BGAP_POK_RST_FLAG = 6
        VDD_CPU_RET_BO_ACTIVE_FLAG = 7
        VDD_CPU_RET_BO_RST_FLAG = 8
        VDD_NV_POK_RST_FLAG = 9
        VBAT_IO_OK_RST_FLAG = 10
        VBAT_IO_NV_OK_RST_FLAG = 11
        WDOG_RST_FLAG = 12
        GO_TO_FAILED_FLAG = 13
        WUP_TIMER_FLAG = 14
        WUP_SNAPSHOT_FLAG = 15
        SYSRESET_REQ_FLAG = 16
        INGFID_RST_FLAG = 17
        EDC_RST_FLAG = 18
        ANA_GLITCH_RST_FLAG = 19
        FREQ_MON_RST_FLAG = 20
        ECC_RST_FLAG = 21
        VDET_RST_FLAG = 22
        LSD_DET_RST_FLAG = 23
        SFETCH_RST_FLAG = 24
        INGFID20_RST_FLAG = 25
        GDET_LITE_RST_FLAG = 26
        FAST_BOOT_FLAG = 31

    class EnumBootStartupStatusFlags(IntEnum):
        PWR_UP_RETENTION_FLAG = 0
        TRIM_FLAG = 1
        SPI_CAN_INIT_FLAG = 8
        UCI_INIT_FLAG = 9

    def __init__(
        self,
        power_reset_control_flags: Dict[EnumPowerResetControlFlags, bool],
        boot_startup_status_flags: Dict[EnumBootStartupStatusFlags, bool],
        gpio_wup_status_flags: Dict,
    ):
        self.power_reset_control_flags = power_reset_control_flags
        self.boot_startup_status_flags = boot_startup_status_flags
        self.gpio_wup_status_flags = gpio_wup_status_flags

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_RESET_DEVICE
class EnumResetType(IntEnum):
    SW_MASTER_RST_SET = 0x00
    SW_PWR_ON_RST_SET = 0x01


# RSP_GET_FW_VERSION
@dataclass(order=True, frozen=True)
class FirmwareVersion:
    class EnumDeviceMode(IntEnum):
        DEVICE_MODE_VIRGIN = 0x00008B1F
        DEVICE_MODE_INIT = 0x00000ED4
        DEVICE_MODE_PROTECTED = 0x00009289
        DEVICE_MODE_TAMPERED = 0x0000163E

    class EnumHardwareVersion(IntEnum):
        A0 = 0x0005
        B0_B1 = 0x0006
        B2 = 0x0007

    @dataclass(order=True, frozen=True)
    class Versions:
        major_version: int  # 4 bytes
        minor_version: int  # 4 bytes
        patch_version: int  # 4 bytes
        version_id: int  # 4 bytes

        @classmethod
        def from_bytes(cls, payload: List[int]):
            return cls(
                major_version=int.from_bytes(bytes=payload[0:4], byteorder="little", signed=False),
                minor_version=int.from_bytes(bytes=payload[4:8], byteorder="little", signed=False),
                patch_version=int.from_bytes(bytes=payload[8:12], byteorder="little", signed=False),
                version_id=int.from_bytes(bytes=payload[12:16], byteorder="little", signed=False),
            )

        def __str__(self):
            return f"{self.major_version}.{self.minor_version}.{self.patch_version}  (Component ID: {self.version_id})"

        def _comparison_str(self):
            return f"{self.major_version}.{self.minor_version}.{self.patch_version}"

    @dataclass(order=True, frozen=True)
    class SwdVersion:
        swd_target_id: int  # bit 0
        jep106_id: int  # bit 1-7
        jep106_cont_code: int  # bit 8-11
        part_number: int  # bit 12-27
        revision: int  # bit 28-31

        @classmethod
        def from_bytes(cls, payload: List[int]):
            combined = int.from_bytes(bytes=payload, byteorder="little", signed=False)

            return cls(
                swd_target_id=combined & 0x01,
                jep106_id=(combined >> 1) & 0x7F,
                jep106_cont_code=(combined >> 8) & 0x0F,
                part_number=(combined >> 12) & 0xFFFF,
                revision=(combined >> 28) & 0x0F,
            )

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=2)

    testware_version: Versions  # 16 bytes
    foundation_package_version: Versions  # 16 bytes
    device_mode: EnumDeviceMode  # 4 bytes
    hardware_version: EnumHardwareVersion  # 4 bytes
    # 4 bytes RFU
    # 4 bytes RFU
    swup_core_version: Versions  # 16 bytes
    swup_version: Versions  # 16 bytes
    baseband_version: Versions  # 16 bytes
    dsp_version: Versions  # 16 bytes
    sbe_api_version: Versions  # 16 bytes
    rom_version: Versions  # 16 bytes - RFU
    swd_version: SwdVersion  # 4 bytes
    variant_information: int  # 4 bytes
    serial_number: list  # 4 bytes
    wafer_data: list  # 16 bytes
    radio_config_version: Versions  # 16 bytes
    bundle_version: Versions  # 16 bytes
    dsp_component_version: Versions  # 16 bytes
    swup_component_version: Versions  # 16 bytes
    # 160 bytes RFU

    def __str__(self):
        return class_to_str(self)


# CMD_RX_CONFIG:
@frozen
class RxConfiguration:
    @staticmethod
    # returns a list of bytes from the input config
    def sts_configuration_from_config(config: BasebandConfiguration.StsConfiguration):
        return config._get_data()

    @staticmethod
    # returns an enum from the input config
    def rx_radio_configuration_from_config(config: BasebandConfiguration.RxRadioConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def rx_dfe_configuration_from_config(config: BasebandConfiguration.RxDigitalFrontendConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def rx_ranging_control_configuration_from_config(config: BasebandConfiguration.RxRangingControlConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def rx_payload_configuration_from_config(config: BasebandConfiguration.RxPayloadConfiguration):
        return config._get_data()

    def __init__(
        self,
        sts_configuration: List[int] =
               [0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00,
                0x14, 0x14, 0x86, 0x74, 0xD1, 0xD3, 0x36, 0xAA, 0xF8, 0x60, 0x50, 0xA8, 0x14, 0xEB, 0x22, 0x0F,
                0x36, 0x2E, 0xEB, 0x34, 0xC4, 0x4F, 0xA8, 0xFB, 0xD3, 0x7E, 0xC3, 0xCA,
                0x1F, 0x9A, 0x3D, 0xE4,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00],
        rx_radio_configuration_index: int = 0x00,
        rx_radio_configuration: List[int] = [0x00, 0x00, 0x00, 0x00],
        rx_dfe_configuration_index: int = 0x00,
        rx_dfe_configuration: List[int] = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                           0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
        rx_ranging_control_configuration_index: int = 0x00,
        rx_ranging_control_configuration: List[int] = [0x00, 0xFF, 0xFF, 0xFF,
                                           0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                           0x00, 0x00, 0x00, 0x01, 0x00, 0xFF],
        rx_payload_configuration: List[int] = [0x00, 0x00, 0xFF, 0xFF]
        ):  # fmt: skip
        self.sts_configuration = sts_configuration
        self.rx_radio_configuration_index = rx_radio_configuration_index
        self.rx_radio_configuration = rx_radio_configuration
        self.rx_dfe_configuration_index = rx_dfe_configuration_index
        self.rx_dfe_configuration = rx_dfe_configuration
        self.rx_ranging_control_configuration_index = rx_ranging_control_configuration_index
        self.rx_ranging_control_configuration = rx_ranging_control_configuration
        self.rx_payload_configuration = rx_payload_configuration

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_TX_CONFIG:
@frozen
class TxConfiguration:
    @staticmethod
    # returns a list of bytes from the input config
    def sts_configuration_from_config(config: BasebandConfiguration.StsConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def tx_radio_configuration_from_config(config: BasebandConfiguration.TxRadioConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def tx_power_configuration_from_config(config: BasebandConfiguration.TxPowerConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def tx_ranging_control_configuration_from_config(config: BasebandConfiguration.TxRangingControlConfiguration):
        return config._get_data()

    @staticmethod
    # returns a list of bytes from the input config
    def tx_payload_configuration_from_config(config: BasebandConfiguration.TxPayloadConfiguration):
        return config._get_data()

    def __init__(
        self,
        sts_configuration: List[int] =
               [0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00,
                0x14, 0x14, 0x86, 0x74, 0xD1, 0xD3, 0x36, 0xAA, 0xF8, 0x60, 0x50, 0xA8, 0x14, 0xEB, 0x22, 0x0F,
                0x36, 0x2E, 0xEB, 0x34, 0xC4, 0x4F, 0xA8, 0xFB, 0xD3, 0x7E, 0xC3, 0xCA,
                0x1F, 0x9A, 0x3D, 0xE4,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00],
        tx_radio_configuration_index: int = 0x00,
        tx_radio_configuration: List[int] = [0x00, 0x00, 0x00, 0x00],
        tx_power_configuration_index: int = 0x00,
        tx_power_configuration: List[int] = [0x00, 0x00, 0x00, 0x00],
        tx_ranging_control_configuration_index: int = 0x00,
        tx_ranging_control_configuration: List[int] = [0x00, 0xFF, 0x00, 0x00, 0x00, 0x00,
                                                       0x00, 0x01, 0x00, 0xFF, 0x00,0x00],
        tx_payload_configuration: List[int] = [0x00, 0x00, 0x00, 0x00]
        ):  # fmt: skip
        self.sts_configuration = sts_configuration
        self.tx_radio_configuration_index = tx_radio_configuration_index
        self.tx_radio_configuration = tx_radio_configuration
        self.tx_power_configuration_index = tx_power_configuration_index
        self.tx_power_configuration = tx_power_configuration
        self.tx_ranging_control_configuration_index = tx_ranging_control_configuration_index
        self.tx_ranging_control_configuration = tx_ranging_control_configuration
        self.tx_payload_configuration = tx_payload_configuration

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_START_BASEBAND
@frozen
class StartBasebandConfig:
    class EnumConfigurationIndex(IntEnum):
        INDEX_0 = 0x00
        INDEX_1 = 0x01
        INDEX_2 = 0x02
        INDEX_3 = 0x03
        DO_NOT_STORE_COMMAND_CONFIGURATION_IN_INDEX = 0xFF

    @staticmethod
    def _ppm_to_bytes(ppm: float):
        ppm = ppm * 10
        signed = int(round(ppm))
        bytes = list(signed.to_bytes(length=2, byteorder="little", signed=True))
        return bytes

    @staticmethod
    # returns a list of bytes from the input config
    def command_configuration_from_config(config: BasebandConfiguration.CommandConfiguration):
        return config._get_data()

    def __init__(
        self,
        uwb_channel_frequency_khz: int = 6489600,
        ppm: float = 0,
        init_delay_us: int = 1000,
        configuration_index: int = 0x00,
        command_configuration: List[int] = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x79, 0xE0, 0x00, 0x00, 0x79, 0xE0, 0x00, 0x00],
        notification_sel_post_baseband_enable: bool = False,
        notification_sel_during_baseband_enable: bool = False,
        start_index: int = 0,
        end_index: int = 0,
        cmd_sequence_count: int = 1,
    ):  # fmt: skip
        self.uwb_channel_frequency_khz = uwb_channel_frequency_khz
        self.ppm = ppm
        self.init_delay_us = init_delay_us
        self.configuration_index = configuration_index
        self.command_configuration = command_configuration
        self.notification_sel_post_baseband_enable = notification_sel_post_baseband_enable
        self.notification_sel_during_baseband_enable = notification_sel_during_baseband_enable
        self.start_index = start_index
        self.end_index = end_index
        self.cmd_sequence_count = cmd_sequence_count

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.uwb_channel_frequency_khz = f"{self.uwb_channel_frequency_khz} kHz"
        _self.init_delay_us = str(self.init_delay_us) + " us"
        return class_to_str(_self)


# BASEBAND_RESULT_SEL
@frozen
class BasebandResultsConfig:
    class EnumResultSelect(IntEnum):
        RX_PAYLOAD_DATA = 0x00
        RANGING_CIR_DATA = 0x01
        TIMESTAMP_RESULTS = 0x02
        FIRSTPATH_RESULTS = 0x03
        PDOA_RESULTS = 0x04
        DELTA_TIMESTAMP_RESULTS = 0x05
        BASEBAND_STATUS = 0x10
        CFO_RESULTS = 0x11
        NBIC_RESULTS = 0x12
        AGC_GAIN_RESULTS = 0x13
        RADAR_CALIBRATION_GAIN_RESULTS = 0x14
        RX_RADAR_CALIBRATION_DATA = 0x15

    def __init__(self, baseband_result_select: EnumResultSelect = EnumResultSelect.RX_PAYLOAD_DATA, baseband_results_index: int = 0x00):
        self.baseband_result_select = baseband_result_select
        self.baseband_results_index = baseband_results_index

    def __str__(self) -> str:
        return class_to_str(self)


# RSP_GET_BASEBAND_RESULTS
@frozen
class BasebandResults:
    class EnumResultSelect(IntEnum):
        RX_PAYLOAD_DATA = 0x00
        RANGING_CIR_DATA = 0x01
        TIMESTAMP_RESULTS = 0x02
        FIRSTPATH_RESULTS = 0x03
        PDOA_RESULTS = 0x04
        DELTA_TIMESTAMP_RESULTS = 0x05
        BASEBAND_STATUS = 0x10
        CFO_RESULTS = 0x11
        NBIC_RESULTS = 0x12
        AGC_GAIN_RESULTS = 0x13
        RADAR_CALIBRATION_GAIN_RESULTS = 0x14
        RX_RADAR_CALIBRATION_DATA = 0x15

    class Results(ABC):
        @abstractmethod
        def _get_results(cls, payload: List[int]):
            pass

    def __init__(self, baseband_result_sel: EnumResultSelect, baseband_results_index: int, baseband_result: Results):
        self.baseband_result_sel = baseband_result_sel
        self.baseband_results_index = baseband_results_index
        self.baseband_result = baseband_result

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=False)

    # RX_PAYLOAD_DATA_CONFIGURATION
    @frozen
    class RXPayloadDataConfig(Results):
        @frozen
        class RawTimestamp:
            class EnumState(IntEnum):
                EMPTY = 0x00
                RX1 = 0x01
                RX2 = 0x02
                TX1 = 0x03
                TX2 = 0x04
                DUAL_RX1_FIRST = 0x11
                DUAL_RX1_NEXT = 0x21
                DUAL_RX2_FIRST = 0x12
                DUAL_RX2_NEXT = 0x22
                INVALID = 0x7FFFFFFF

            def __init__(self, timestamp_fractional: int, timestamp_integer: int, timestamp_ns: float, state: EnumState):
                self.timestamp_fractional = timestamp_fractional
                self.timestamp_integer = timestamp_integer
                self.timestamp_ns = timestamp_ns
                self.state = state

            @classmethod
            def from_bytes(cls, timestamp_data: List[int]):
                timestamp_fractional = int.from_bytes(bytes=timestamp_data[0:4], byteorder="little", signed=False)
                integer_and_state = int.from_bytes(bytes=timestamp_data[4:6], byteorder="little", signed=False)
                timestamp_integer = integer_and_state & 0x01FF
                # integer part resolution: 8.0128ns = 15.65 * 2^9 ps
                # fractional part resolution of: 15.65ps
                timestamp_ns = (timestamp_fractional + timestamp_integer * 2**9) * (BB_TICKS_TO_SEC_CONVERSION_FACTOR * 1e9)
                state = BasebandResults.RXPayloadDataConfig.RawTimestamp.EnumState((integer_and_state >> 9) & 0x7F)
                return cls(timestamp_fractional, timestamp_integer, timestamp_ns, state)

            @classmethod
            def create_timestamp_list(cls, payload: List[int]):
                timestamps: List[BasebandResults.RXPayloadDataConfig.RawTimestamp] = []

                for timestamp_data in chunked(payload, 6):
                    timestamps.append(cls.from_bytes(timestamp_data=timestamp_data))

                return timestamps

            def __str__(self) -> str:
                return class_to_str(self, include_title=True, indent_level=2)

        class DeltaTimestamp:
            def __init__(self, delta_timestamp_ticks: int, delta_timestamp_ns: float):
                self.delta_timestamp_ticks = delta_timestamp_ticks
                self.delta_timestamp_ns = delta_timestamp_ns

            def __str__(self):
                return class_to_str(self, include_title=True, indent_level=2)

            @classmethod
            def from_bytes(cls, timestamp_data: List[int]):
                raw_timestamp = int.from_bytes(bytes=timestamp_data[0:4], byteorder="little", signed=False)
                # integer part resolution: 8.0128ns = 15.65 * 2^9 ps
                # fractional part resolution of: 15.65ps
                timestamp_ns = raw_timestamp * (BB_TICKS_TO_SEC_CONVERSION_FACTOR * 1e9)
                return cls(raw_timestamp, timestamp_ns)

            @classmethod
            def create_timestamp_list(cls, payload: List[int]):
                timestamps: List[BasebandResults.RXPayloadDataConfig.DeltaTimestamp] = []

                for timestamp_data in chunked(payload, 4):
                    timestamps.append(cls.from_bytes(timestamp_data=timestamp_data))

                return timestamps

        def __init__(self, rx_payload_length: int, rx_phr: int, rx_payload_data: List[int]):
            self.rx_payload_length = rx_payload_length
            self.rx_phr = rx_phr
            self.rx_payload_data = rx_payload_data

        def __str__(self):
            return class_to_str(self, include_title=True, indent_level=True)

        @classmethod
        def _get_results(cls, payload):
            results = BasebandResults.RXPayloadDataConfig(
                rx_payload_length=int.from_bytes(bytes=payload[0:4], byteorder="little", signed=False),
                rx_phr=int.from_bytes(bytes=payload[4:8], byteorder="little", signed=False),
                rx_payload_data=payload[8:],
            )
            return results

        @staticmethod
        def interpret_rx_payload_data(rx_payload_data: List[int], psdu_select: RangingCommand.EnumPSDUSel):
            match psdu_select:
                case RangingCommand.EnumPSDUSel.TRANSMIT_ALL_DELTA_TIMESTAMPS:
                    timestamp_class_list = BasebandResults.RXPayloadDataConfig.DeltaTimestamp.create_timestamp_list(payload=rx_payload_data)
                case RangingCommand.EnumPSDUSel.TRANSMIT_ALL_RAW_TIMESTAMPS:
                    timestamp_class_list = BasebandResults.RXPayloadDataConfig.RawTimestamp.create_timestamp_list(payload=rx_payload_data)
                case _:
                    timestamp_class_list = None
            return timestamp_class_list

    # RANGING_CIR_DATA
    @frozen
    class RangingCIRData(Results):
        def __init__(self, cir_offset: int, cir_length: int, cir_data_taps: List[complex], cir_data_bytes: List[int]):
            self.cir_offset = cir_offset
            self.cir_length = cir_length
            self.cir_data_taps = cir_data_taps
            self.cir_data_bytes = cir_data_bytes

        def __str__(self):
            return class_to_str(self, include_title=True, indent_level=1)

        @classmethod
        def _get_results(cls, payload):
            cir_taps = []
            cir_taps_bytes = []
            # cir taps start at byte 8. One tap is 4 bytes large
            for i in range(8, len(payload) - 3, 4):
                tap = complex(
                    real=int.from_bytes(bytes=payload[i : i + 2], byteorder="little", signed=True),
                    imag=int.from_bytes(bytes=payload[i + 2 : i + 4], byteorder="little", signed=True),
                )
                cir_taps_bytes += payload[i : i + 4]
                cir_taps.append(tap)
            results = BasebandResults.RangingCIRData(
                cir_offset=(payload[0] | (payload[1] << 8) | (payload[2] << 16) | (payload[3] << 24)),
                cir_length=(payload[4] | (payload[5] << 8) | (payload[6] << 16) | (payload[7] << 24)),
                cir_data_taps=cir_taps,
                cir_data_bytes=cir_taps_bytes,
            )
            return results

    # TIMESTAMP_RESULTS
    @frozen
    class TimestampResults(Results):
        @frozen
        class Timestamp:
            class EnumState(IntEnum):
                EMPTY = 0x00
                RX1 = 0x01
                RX2 = 0x02
                TX1 = 0x03
                TX2 = 0x04
                DUAL_RX1_FIRST = 0x11
                DUAL_RX1_NEXT = 0x21
                DUAL_RX2_FIRST = 0x12
                DUAL_RX2_NEXT = 0x22
                INVALID = 0x7FFFFFFF

            def __init__(self, timestamp_fractional: int, timestamp_integer: int, timestamp_ns: float, state: EnumState):
                self.timestamp_fractional = timestamp_fractional
                self.timestamp_integer = timestamp_integer
                self.timestamp_ns = timestamp_ns
                self.state = state

            def __str__(self) -> str:
                return class_to_str(self, include_title=True, indent_level=2)

        def __init__(self, timestamps: List[Timestamp]):
            self.timestamps = timestamps

        def __str__(self) -> str:
            space = "    "
            indent_level = 1
            msg = f"\n{space+2*space*indent_level}{self.__class__.__name__}: ["
            for item in self.timestamps:
                indent_level_2 = 2
                msg += f"{space+4*space*indent_level_2}{item}"
            msg += f"\n{space*indent_level*2}]"
            return msg

        @classmethod
        def _get_results(cls, payload):
            timestamps = []
            for i in range(0, len(payload) - 11, 12):
                fractional = payload[i] | (payload[i + 1] << 8) | (payload[i + 2] << 16) | (payload[i + 3] << 24)
                integer = payload[i + 4] | (payload[i + 5] << 8) | (payload[i + 6] << 16) | (payload[i + 7] << 24)
                state = BasebandResults.TimestampResults.Timestamp.EnumState(
                    payload[i + 8] | (payload[i + 9] << 8) | (payload[i + 10] << 16) | (payload[i + 11] << 24)
                )
                # integer part resolution: 8.0128ns = 15.65 * 2^9 ps
                # fractional part resolution of: 15.65ps
                time_ns = (fractional + integer * 2**9) * (BB_TICKS_TO_SEC_CONVERSION_FACTOR * 1e9)
                stamp = cls.Timestamp(fractional, integer, time_ns, state)
                timestamps.append(stamp)
            results = BasebandResults.TimestampResults(timestamps=timestamps)
            return results

    # FIRSTPATH_RESULTS
    @frozen
    class FirstpathResults(Results):
        @staticmethod
        def _power_int_to_dbm(input: int) -> float:
            dbm = log10(2) * 10 * float(input) / 0x200
            return dbm

        def _path_index_to_ns(bb_ticks: int) -> float:
            time_ns = bb_ticks * BB_TICKS_TO_SEC_CONVERSION_FACTOR * 1e9
            return time_ns

        def __init__(
            self,
            edge_index_ns: int,
            threshold_power_dbm: float,
            firstpath_index_ns: float,
            firstpath_power_dbm: float,
            max_index_ns: float,
            max_power_dbm: float,
            noise_power_dbm: float,
            overall_rx_power_dbm: float,
            toa_time_ns: float,
        ):
            self.edge_index_ns = edge_index_ns
            self.threshold_power_dbm = threshold_power_dbm
            self.firstpath_index_ns = firstpath_index_ns
            self.firstpath_power_dbm = firstpath_power_dbm
            self.max_index_ns = max_index_ns
            self.max_power_dbm = max_power_dbm
            self.noise_power_dbm = noise_power_dbm
            self.overall_rx_power_dbm = overall_rx_power_dbm
            self.toa_time_ns = toa_time_ns

        def __str__(self) -> str:
            _self = deepcopy(self)

            _self.edge_index_ns = f"{self.edge_index_ns} ns (CIR bin)"
            _self.threshold_power_dbm = f"{self.threshold_power_dbm: .8f} dBm"
            _self.firstpath_index_ns = f"{self.firstpath_index_ns: .8f} ns"
            _self.firstpath_power_dbm = f"{self.firstpath_power_dbm: .8f} dBm"
            _self.max_index_ns = f"{self.firstpath_index_ns: .8f} ns"
            _self.max_power_dbm = f"{self.max_power_dbm: .8f} dBm"
            _self.noise_power_dbm = f"{self.noise_power_dbm: .8f} dBm"
            _self.overall_rx_power_dbm = f"{self.overall_rx_power_dbm: .8f} dBm"
            _self.toa_time_ns = f"{self.toa_time_ns: .8f} ns"

            return class_to_str(_self, include_title=False, indent_level=2)

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandResults.FirstpathResults(
                edge_index_ns=int.from_bytes(bytes=payload[0:2], byteorder="little", signed=False),
                threshold_power_dbm=cls._power_int_to_dbm(int.from_bytes(bytes=payload[2:4], byteorder="little", signed=True)),
                firstpath_index_ns=cls._path_index_to_ns(int.from_bytes(bytes=payload[4:6], byteorder="little", signed=False)),
                firstpath_power_dbm=cls._power_int_to_dbm(int.from_bytes(bytes=payload[6:8], byteorder="little", signed=True)),
                max_index_ns=cls._path_index_to_ns(int.from_bytes(bytes=payload[8:10], byteorder="little", signed=False)),
                max_power_dbm=cls._power_int_to_dbm(int.from_bytes(bytes=payload[10:12], byteorder="little", signed=True)),
                noise_power_dbm=cls._power_int_to_dbm(int.from_bytes(bytes=payload[12:14], byteorder="little", signed=True)),
                overall_rx_power_dbm=cls._power_int_to_dbm(int.from_bytes(bytes=payload[14:16], byteorder="little", signed=True)),
                toa_time_ns=cls._path_index_to_ns(int.from_bytes(bytes=payload[16:18], byteorder="little", signed=False)),
            )

            return results

    # PDOA_RESULTS
    @frozen
    class PdoaResults(Results):
        @staticmethod
        def _int_to_pdoa(input: int):
            """
            PDOA[degree] = ((float)(int16_t)PDOA) / 128
            (Range is +/- 180 degrees)
            """
            return float(input) / 128

        @staticmethod
        def _int_to_snr(input: int):
            """
            SNR[dB] = (log10(2) * 10 * (float)(int16_t)snr) / 0x200
            """
            return (log10(2) * 10 * float(input)) / 0x200

        def __init__(self, pdoa_int: int, pdoa_deg: float, snr_int: int, snr_dB: float):
            self.pdoa_int = pdoa_int
            self.pdoa_deg = pdoa_deg
            self.snr_int = snr_int
            self.snr_dB = snr_dB

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=2)

        @classmethod
        def _get_results(cls, payload: List[int]):
            pdoa_int = int.from_bytes(bytes=payload[0:2], byteorder="little", signed=True)
            pdoa_deg = cls._int_to_pdoa(pdoa_int)
            snr_int = int.from_bytes(bytes=payload[2:4], byteorder="little", signed=True)
            snr_dB = cls._int_to_snr(snr_int)

            results = BasebandResults.PdoaResults(
                pdoa_int=pdoa_int,
                pdoa_deg=pdoa_deg,
                snr_int=snr_int,
                snr_dB=snr_dB,
            )
            return results

    # DELTA_TIMESTAMP_RESULTS
    @frozen
    class DeltaTimestampResults(Results):
        def __init__(self, delta_timestamps_ticks: List[int], delta_timestamps_ns: List[float]):
            self.delta_timestamps_ticks = delta_timestamps_ticks
            self.delta_timestamps_ns = delta_timestamps_ns

        def __str__(self):
            return class_to_str(self, include_title=True, indent_level=1)

        @classmethod
        def _get_results(cls, payload: List[int]):
            timestamps_ticks = []
            timestamps_ns = []
            for i in range(0, len(payload) - 3, 4):
                timestamp = payload[i] | (payload[i + 1] << 8) | (payload[i + 2] << 16) | (payload[i + 3] << 24)
                timestamps_ticks.append(timestamp)
                # Convert from ticks to ns. 1 tick = 15.65ps
                timestamps_ns.append(timestamp * (BB_TICKS_TO_SEC_CONVERSION_FACTOR * 1e9))
            results = BasebandResults.DeltaTimestampResults(delta_timestamps_ticks=timestamps_ticks, delta_timestamps_ns=timestamps_ns)
            return results

    # BASEBAND_STATUS
    @frozen
    class BasebandStatus(Results):
        class EnumBasebandState(IntEnum):
            UNDEFINED = 0x00
            BB_IDLE = 0x01
            BB_READY = 0x02
            RFU = 0x03
            BB_ACTIVE = 0x04

        class BasebandWarning:
            def __init__(self, bb_operation_not_timed: bool, timestamp_fifo_full: bool, timestamp_fifo_overwritten: bool):
                self.bb_operation_not_timed = bb_operation_not_timed
                self.timestamp_fifo_full = timestamp_fifo_full
                self.timestamp_fifo_overwritten = timestamp_fifo_overwritten

            def __str__(self):
                return class_to_str(self, include_title=False, indent_level=2)

            def get_set_flags(self):
                return {var_name: var_value for var_name, var_value in vars(self).items() if var_value}

            def get_not_set_flags(self):
                return {var_name: var_value for var_name, var_value in vars(self).items() if not var_value}

            def any_flag_set(self):
                return any(vars(self).values())

        class EnumRxState(IntEnum):
            NO_RECEPTION = 0x00
            RX_FRAME_RECEIVED_WITHOUT_PAYLOAD = 0x01
            RX_FRAME_RECEIVED_WITH_DECODED_PAYLOAD = 0x02
            RX_RADAR_CIR_RECEIVED = 0x03
            RX_RADAR_CIR_RECEIVED_WITH_BUFFER_WRAP = 0x04
            RX_RADAR_CIR_BUFFER_WRAP = 0x05

        class EnumRXErrorStatusIndication(IntEnum):
            PREAMBLE_TIMEOUT_FLAG = 0
            SFD_TIMEOUT_FLAG = 1
            TOA_SIGNAL_DETECTION_FAILED_FLAG = 2
            STS_MISMATCH_FLAG = 3
            RX_SECDED_DECODE_FAILURE_FLAG = 4
            RX_REED_SOLOMON_DECODE_FAILURE_FLAG = 5
            SIGNAL_LOST_FLAG = 6
            RX_TIMEOUT_FLAG = 7
            CRC_ERROR_IN_RX_PSDU_FLAG = 8

        class RxErrorStatusIndication:
            def __init__(
                self,
                preamble_timeout_flag: bool,
                sfd_timeout_flag: bool,
                toa_signal_detection_failed_flag: bool,
                sts_mismatch_flag: bool,
                rx_secded_decode_failure_flag: bool,
                rx_reed_solomon_decode_failure_flag: bool,
                signal_lost_flag: bool,
                rx_timeout_flag: bool,
                crc_error_in_rx_psdu_flag: bool,
            ):
                self.preamble_timeout_flag = preamble_timeout_flag
                self.sfd_timeout_flag = sfd_timeout_flag
                self.toa_signal_detection_failed_flag = toa_signal_detection_failed_flag
                self.sts_mismatch_flag = sts_mismatch_flag
                self.rx_secded_decode_failure_flag = rx_secded_decode_failure_flag
                self.rx_reed_solomon_decode_failure_flag = rx_reed_solomon_decode_failure_flag
                self.signal_lost_flag = signal_lost_flag
                self.rx_timeout_flag = rx_timeout_flag
                self.crc_error_in_rx_psdu_flag = crc_error_in_rx_psdu_flag

            def __str__(self):
                return class_to_str(self, include_title=False, indent_level=2)

            def get_set_flags(self):
                i = {var_name: var_value for var_name, var_value in vars(self).items() if var_value}
                return i

            def get_not_set_flags(self):
                return {var_name: var_value for var_name, var_value in vars(self).items() if not var_value}

            def any_flag_set(self):
                return any(vars(self).values())

            def to_bitfield(self):
                bitfield: int = (
                    self.preamble_timeout_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.PREAMBLE_TIMEOUT_FLAG
                    | self.sfd_timeout_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.SFD_TIMEOUT_FLAG
                    | self.toa_signal_detection_failed_flag
                    << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.TOA_SIGNAL_DETECTION_FAILED_FLAG
                    | self.sts_mismatch_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.STS_MISMATCH_FLAG
                    | self.rx_secded_decode_failure_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.RX_SECDED_DECODE_FAILURE_FLAG
                    | self.rx_reed_solomon_decode_failure_flag
                    << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.RX_REED_SOLOMON_DECODE_FAILURE_FLAG
                    | self.signal_lost_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.SIGNAL_LOST_FLAG
                    | self.rx_timeout_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.RX_TIMEOUT_FLAG
                    | self.crc_error_in_rx_psdu_flag << BasebandResults.BasebandStatus.EnumRXErrorStatusIndication.CRC_ERROR_IN_RX_PSDU_FLAG
                )
                return bitfield

        class EnumTxState(IntEnum):
            NO_TRANSMISSION = 0x00
            TX_TRANSMISSION_COMPLETED = 0x01

        class EnumToolboxStatus(IntEnum):
            TOOLBOX_EXECUTION_NOT_DONE = 0x00
            TOOLBOX_EXECUTION_DONE = 0x01

        def __init__(
            self,
            baseband_state: EnumBasebandState,
            baseband_warning: BasebandWarning,
            baseband_error: bool,
            rx_state: EnumRxState,
            rx_error_status_indication: RxErrorStatusIndication,
            tx_state: EnumTxState,
            tx_error_status_indication: bool,
            toolbox_status: EnumToolboxStatus,
        ):
            self.baseband_state = baseband_state
            self.baseband_warning = baseband_warning
            self.baseband_error = baseband_error
            self.rx_state = rx_state
            self.rx_error_status_indication = rx_error_status_indication
            self.tx_state = tx_state
            self.tx_error_status_indication = tx_error_status_indication
            self.toolbox_status = toolbox_status

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandResults.BasebandStatus(
                baseband_state=cls.EnumBasebandState(payload[0]),
                baseband_warning=cls.BasebandWarning(
                    bb_operation_not_timed=bool(payload[1] & 1 << 0),
                    timestamp_fifo_full=bool(payload[1] & 1 << 1),
                    timestamp_fifo_overwritten=bool(payload[1] & 1 << 2),
                ),
                baseband_error=bool(payload[1] & 1 << 4),
                rx_state=cls.EnumRxState(payload[4]),
                rx_error_status_indication=cls.RxErrorStatusIndication(
                    preamble_timeout_flag=bool(payload[5] & (1 << 0)),
                    sfd_timeout_flag=bool(payload[5] & (1 << 1)),
                    toa_signal_detection_failed_flag=bool(payload[5] & (1 << 2)),
                    sts_mismatch_flag=bool(payload[5] & (1 << 3)),
                    rx_secded_decode_failure_flag=bool(payload[5] & (1 << 4)),
                    rx_reed_solomon_decode_failure_flag=bool(payload[5] & (1 << 5)),
                    signal_lost_flag=bool(payload[5] & (1 << 6)),
                    rx_timeout_flag=bool(payload[5] & (1 << 7)),
                    crc_error_in_rx_psdu_flag=bool(payload[6] & (1 << 0)),
                ),
                tx_state=cls.EnumTxState(payload[8] & (1 << 0)),
                tx_error_status_indication=bool(payload[8] & (1 << 1)),
                toolbox_status=cls.EnumToolboxStatus(payload[9]),
            )
            return results

    # CFO_RESULTS
    @frozen
    class CfoResults(Results):
        @staticmethod
        def _cfo_raw_to_cfo_int(cfo_raw: int):
            # get the sign of the value since it is 21 bits long
            sign = bool(cfo_raw & (1 << 21))
            # if the sign is 1, flip the bits and add 1
            cfo_int = -((cfo_raw ^ 0x3FFFFF) + 1) if sign else cfo_raw
            return cfo_int

        @staticmethod
        def _cfo_int_to_cfo_ppm(cfo_int: int, center_frequency_khz: float):
            cfo = float(cfo_int) / 2**27
            cfo_hz = (124.8e6 / 2) * cfo
            cfo_ppm = cfo_hz / (center_frequency_khz / 1e3)
            return cfo_ppm

        def __init__(self, cfo_int: int, cfo_ppm: float):
            self.cfo_int = cfo_int
            self.cfo_ppm = cfo_ppm

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=2)

        @classmethod
        def _get_results(cls, payload: List[int], center_frequency_khz: float):
            cfo_raw = payload[0] | (payload[1] << 8) | (payload[2] << 16) | (payload[3] << 24)
            cfo_int = cls._cfo_raw_to_cfo_int(cfo_raw)
            cfo_ppm = cls._cfo_int_to_cfo_ppm(cfo_int, center_frequency_khz)

            results = BasebandResults.CfoResults(cfo_int=cfo_int, cfo_ppm=cfo_ppm)
            return results

    # NBIC_RESULTS
    @frozen
    class NbicResults(Results):
        class EnumRXJammerAbsenceIndicator(IntEnum):
            JAMMER_DETECTED = 0x00
            JAMMER_NOT_DETECTED = 0x01

        class EnumRXNBICLockStatus(IntEnum):
            UNLOCKED = 0x00
            LOCKED = 0x01

        @staticmethod
        def _int_to_frequency(input: int) -> float:
            freq = input * 500 / 32768
            return freq

        def __init__(
            self,
            momentary_rx_frequency_estimate_mhz: float,
            rx_jammer_absence_indicator: EnumRXJammerAbsenceIndicator,
            rx_nbic_lock_status: EnumRXNBICLockStatus,
        ):
            self.momentary_rx_frequency_estimate_mhz = momentary_rx_frequency_estimate_mhz
            self.rx_jammer_absence_indicator = rx_jammer_absence_indicator
            self.rx_nbic_lock_status = rx_nbic_lock_status

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=2)

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandResults.NbicResults(
                momentary_rx_frequency_estimate_mhz=cls._int_to_frequency(int.from_bytes(bytes=payload[0:2], byteorder="little", signed=True)),
                rx_jammer_absence_indicator=cls.EnumRXJammerAbsenceIndicator(payload[1] & 0x01),
                rx_nbic_lock_status=cls.EnumRXNBICLockStatus((payload[1] >> 1) & 0x01),
            )
            return results

    # AGC_GAIN_RESULTS
    @frozen
    class AgcGainResults(Results):
        def __init__(self, agc_gain_db: int):
            self.agc_gain_db = agc_gain_db

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandResults.AgcGainResults(agc_gain_db=(payload[0] | (payload[1] << 8) | (payload[2] << 16) | (payload[3] << 24)))
            return results

    # RADAR_CALIBRATION_GAIN_RESULTS
    @frozen
    class RadarCalibrationGainResults(Results):
        def __init__(self, radar_calibration_gain_db: int):
            self.radar_calibration_gain_db = radar_calibration_gain_db

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

        @classmethod
        def _get_results(cls, payload: List[int]):
            results = BasebandResults.RadarCalibrationGainResults(
                radar_calibration_gain_db=int.from_bytes(bytes=payload[0:4], byteorder="little", signed=True)
            )
            return results


# CMD_POWER_MGMT_CONFIG
@frozen
class PowerConfig:
    class EnumTargetPowerMode(IntEnum):
        ACTIVE = 0x00
        RFU = 0x01
        DPD = 0x02
        HPD = 0x03

    class EnumCpuIdleMode(IntEnum):
        WAIT_FOR_INTERRUPT = 0x00
        ACTIVE = 0x01

    class EnumSnapshotControl(IntEnum):
        DISABLE = 0x00
        SNAPSHOT_TIMER_ON_FRO = 0x01
        SNAPSHOT_TIMER_ON_XO = 0x02
        SNAPSHOT_TIMER_ON_SYSPLL = 0x03

    class EnumDspMemControl(IntEnum):
        SHUTDOWN = 0x00
        SLEEP = 0x01
        ACTIVE = 0x02

    @frozen
    class CpuMemControl:
        def __init__(
            self,
            _rfu: bool = False,
            sram1_deep_sleep_enable: bool = False,
            sram2_deep_sleep_enable: bool = False,
            sram3_deep_sleep_enable: bool = False,
            sram4_deep_sleep_enable: bool = False,
            sram5_deep_sleep_enable: bool = False,
        ):
            self._rfu = _rfu
            self.sram1_deep_sleep_enable = sram1_deep_sleep_enable
            self.sram2_deep_sleep_enable = sram2_deep_sleep_enable
            self.sram3_deep_sleep_enable = sram3_deep_sleep_enable
            self.sram4_deep_sleep_enable = sram4_deep_sleep_enable
            self.sram5_deep_sleep_enable = sram5_deep_sleep_enable

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

        def _get_bytes(self) -> list:
            bytes = []
            bytes.append(
                ((int(self._rfu)) << 0)
                | ((int(self.sram1_deep_sleep_enable)) << 1)
                | ((int(self.sram2_deep_sleep_enable)) << 2)
                | ((int(self.sram3_deep_sleep_enable)) << 3)
                | ((int(self.sram4_deep_sleep_enable)) << 4)
                | ((int(self.sram5_deep_sleep_enable)) << 5)
            )
            bytes += [0x00, 0x00, 0x00]
            return bytes

    @frozen
    class LowPowerGpioControl:
        """
        Arguments:
            target_power_mode: ACTIVE | DPD | HPD
                if DPD:
                    pin_[10-17, 20-25]_gpio_wakeup_enable,
                    pin_[10-17, 20-25]_gpio_rising_edge_enable
                if HPD:
                    pin_[14, 17, 23]_gpio_wakeup_enable
                if ACTIVE:
                    all RFU
        """

        class EnumTargetPowerMode(IntEnum):
            ACTIVE = 0x00
            RFU = 0x01
            DPD = 0x02
            HPD = 0x03

        def __init__(
            self,
            target_power_mode: EnumTargetPowerMode = EnumTargetPowerMode.DPD,
            pin_10_gpio_wakeup_enable: bool = False,
            pin_11_gpio_wakeup_enable: bool = False,
            pin_12_gpio_wakeup_enable: bool = False,
            pin_13_gpio_wakeup_enable: bool = False,
            pin_14_gpio_wakeup_enable: bool = False,
            pin_15_gpio_wakeup_enable: bool = False,
            pin_16_gpio_wakeup_enable: bool = False,
            pin_17_gpio_wakeup_enable: bool = False,
            pin_20_gpio_wakeup_enable: bool = False,
            pin_21_gpio_wakeup_enable: bool = False,
            pin_22_gpio_wakeup_enable: bool = False,
            pin_23_gpio_wakeup_enable: bool = False,
            pin_24_gpio_wakeup_enable: bool = False,
            pin_25_gpio_wakeup_enable: bool = False,
            pin_10_gpio_rising_edge_enable: bool = False,
            pin_11_gpio_rising_edge_enable: bool = False,
            pin_12_gpio_rising_edge_enable: bool = False,
            pin_13_gpio_rising_edge_enable: bool = False,
            pin_14_gpio_rising_edge_enable: bool = False,
            pin_15_gpio_rising_edge_enable: bool = False,
            pin_16_gpio_rising_edge_enable: bool = False,
            pin_17_gpio_rising_edge_enable: bool = False,
            pin_20_gpio_rising_edge_enable: bool = False,
            pin_21_gpio_rising_edge_enable: bool = False,
            pin_22_gpio_rising_edge_enable: bool = False,
            pin_23_gpio_rising_edge_enable: bool = False,
            pin_24_gpio_rising_edge_enable: bool = False,
            pin_25_gpio_rising_edge_enable: bool = False,
        ):
            self.target_power_mode = target_power_mode

            match target_power_mode:
                case self.EnumTargetPowerMode.DPD:
                    self.pin_10_gpio_wakeup_enable = pin_10_gpio_wakeup_enable
                    self.pin_11_gpio_wakeup_enable = pin_11_gpio_wakeup_enable
                    self.pin_12_gpio_wakeup_enable = pin_12_gpio_wakeup_enable
                    self.pin_13_gpio_wakeup_enable = pin_13_gpio_wakeup_enable
                    self.pin_14_gpio_wakeup_enable = pin_14_gpio_wakeup_enable
                    self.pin_15_gpio_wakeup_enable = pin_15_gpio_wakeup_enable
                    self.pin_16_gpio_wakeup_enable = pin_16_gpio_wakeup_enable
                    self.pin_17_gpio_wakeup_enable = pin_17_gpio_wakeup_enable
                    self.pin_20_gpio_wakeup_enable = pin_20_gpio_wakeup_enable
                    self.pin_21_gpio_wakeup_enable = pin_21_gpio_wakeup_enable
                    self.pin_22_gpio_wakeup_enable = pin_22_gpio_wakeup_enable
                    self.pin_23_gpio_wakeup_enable = pin_23_gpio_wakeup_enable
                    self.pin_24_gpio_wakeup_enable = pin_24_gpio_wakeup_enable
                    self.pin_25_gpio_wakeup_enable = pin_25_gpio_wakeup_enable
                    self.pin_10_gpio_rising_edge_enable = pin_10_gpio_rising_edge_enable
                    self.pin_11_gpio_rising_edge_enable = pin_11_gpio_rising_edge_enable
                    self.pin_12_gpio_rising_edge_enable = pin_12_gpio_rising_edge_enable
                    self.pin_13_gpio_rising_edge_enable = pin_13_gpio_rising_edge_enable
                    self.pin_14_gpio_rising_edge_enable = pin_14_gpio_rising_edge_enable
                    self.pin_15_gpio_rising_edge_enable = pin_15_gpio_rising_edge_enable
                    self.pin_16_gpio_rising_edge_enable = pin_16_gpio_rising_edge_enable
                    self.pin_17_gpio_rising_edge_enable = pin_17_gpio_rising_edge_enable
                    self.pin_20_gpio_rising_edge_enable = pin_20_gpio_rising_edge_enable
                    self.pin_21_gpio_rising_edge_enable = pin_21_gpio_rising_edge_enable
                    self.pin_22_gpio_rising_edge_enable = pin_22_gpio_rising_edge_enable
                    self.pin_23_gpio_rising_edge_enable = pin_23_gpio_rising_edge_enable
                    self.pin_24_gpio_rising_edge_enable = pin_24_gpio_rising_edge_enable
                    self.pin_25_gpio_rising_edge_enable = pin_25_gpio_rising_edge_enable
                case self.EnumTargetPowerMode.HPD:
                    self.pin_14_gpio_wakeup_enable = pin_14_gpio_wakeup_enable
                    self.pin_17_gpio_wakeup_enable = pin_17_gpio_wakeup_enable
                    self.pin_23_gpio_wakeup_enable = pin_23_gpio_wakeup_enable
                case _:
                    self._rfu = 0x0000000000000000

        def __str__(self) -> str:
            _self = deepcopy(self)
            del _self.target_power_mode
            return class_to_str(_self, include_title=True, indent_level=1)

        def _get_bytes(self) -> list:
            bytes = []
            match self.target_power_mode:
                case PowerConfig.EnumTargetPowerMode.DPD:
                    bytes.append(
                        ((int(self.pin_10_gpio_wakeup_enable)) << 0)
                        | ((int(self.pin_11_gpio_wakeup_enable)) << 1)
                        | ((int(self.pin_12_gpio_wakeup_enable)) << 2)
                        | ((int(self.pin_13_gpio_wakeup_enable)) << 3)
                        | ((int(self.pin_14_gpio_wakeup_enable)) << 4)
                        | ((int(self.pin_15_gpio_wakeup_enable)) << 5)
                        | ((int(self.pin_16_gpio_wakeup_enable)) << 6)
                        | ((int(self.pin_17_gpio_wakeup_enable)) << 7)
                    )
                    bytes.append(
                        ((int(self.pin_20_gpio_wakeup_enable)) << 0)
                        | ((int(self.pin_21_gpio_wakeup_enable)) << 1)
                        | ((int(self.pin_22_gpio_wakeup_enable)) << 2)
                        | ((int(self.pin_23_gpio_wakeup_enable)) << 3)
                        | ((int(self.pin_24_gpio_wakeup_enable)) << 4)
                        | ((int(self.pin_25_gpio_wakeup_enable)) << 5)
                    )
                    bytes += [0x00] * 2  # RFU
                    bytes.append(
                        ((int(self.pin_10_gpio_rising_edge_enable)) << 0)
                        | ((int(self.pin_11_gpio_rising_edge_enable)) << 1)
                        | ((int(self.pin_12_gpio_rising_edge_enable)) << 2)
                        | ((int(self.pin_13_gpio_rising_edge_enable)) << 3)
                        | ((int(self.pin_14_gpio_rising_edge_enable)) << 4)
                        | ((int(self.pin_15_gpio_rising_edge_enable)) << 5)
                        | ((int(self.pin_16_gpio_rising_edge_enable)) << 6)
                        | ((int(self.pin_17_gpio_wakeup_enable)) << 7)
                    )
                    bytes.append(
                        ((int(self.pin_20_gpio_rising_edge_enable)) << 0)
                        | ((int(self.pin_21_gpio_rising_edge_enable)) << 1)
                        | ((int(self.pin_22_gpio_rising_edge_enable)) << 2)
                        | ((int(self.pin_23_gpio_rising_edge_enable)) << 3)
                        | ((int(self.pin_24_gpio_rising_edge_enable)) << 4)
                        | ((int(self.pin_25_gpio_rising_edge_enable)) << 5)
                    )
                    bytes += [0x00] * 2  # RFU
                    return bytes
                case PowerConfig.EnumTargetPowerMode.HPD:
                    bytes.append(
                        ((int(self.pin_14_gpio_wakeup_enable)) << 0)
                        | ((int(self.pin_17_gpio_wakeup_enable)) << 1)
                        | ((int(self.pin_23_gpio_wakeup_enable)) << 2)
                    )
                    bytes += [0x00] * 7
                    return bytes
                case _:
                    return [0x00] * 8  # RFU

    @frozen
    class LowPowerLdoControls:
        """
        Arguments:
            target_power_mode: ACTIVE | DPD | HPD
                if DPD:
                    baseband_retention_dpd_enable,
                    cpu_retention_dpd_enable,
                    cpu_retention_ldo_dpd_enable,
                    current_limiter_mode_dpd,
                    fro_selection_dpd,
                    wakeup_timer_dpd_enable
                if HPD:
                    current_limiter_hpd_enable
                if ACTIVE:
                    all RFU
        """

        class EnumTargetPowerMode(IntEnum):
            ACTIVE = 0x00
            RFU = 0x01
            DPD = 0x02
            HPD = 0x03

        class EnumCurrentLimiterMode(IntEnum):
            CHARGING2BYPASS = 0x00
            FORCEDCHARGING = 0x01
            OFF = 0x02

        class EnumFROSelectionDPD(IntEnum):
            FRO_32_KHZ = 0x00
            FRO_1_MHZ = 0x01

        def __init__(
            self,
            target_power_mode: EnumTargetPowerMode = EnumTargetPowerMode.DPD,
            current_limiter_mA_active: int = 0,
            baseband_retention_dpd_enable: bool = True,
            cpu_retention_dpd_enable: bool = True,
            cpu_retention_ldo_dpd_enable: bool = False,
            current_limiter_mode_dpd: EnumCurrentLimiterMode = EnumCurrentLimiterMode.CHARGING2BYPASS,
            fro_selection_dpd: EnumFROSelectionDPD = EnumFROSelectionDPD.FRO_32_KHZ,
            wakeup_timer_dpd_enable: bool = True,
            current_limiter_hpd_enable: bool = False,
        ):
            self.target_power_mode = target_power_mode
            match target_power_mode:
                case self.EnumTargetPowerMode.ACTIVE:
                    self.current_limiter_mA_active = current_limiter_mA_active
                case self.EnumTargetPowerMode.DPD:
                    self.baseband_retention_dpd_enable = baseband_retention_dpd_enable
                    self.cpu_retention_dpd_enable = cpu_retention_dpd_enable
                    self.cpu_retention_ldo_dpd_enable = cpu_retention_ldo_dpd_enable
                    self.current_limiter_mode_dpd = current_limiter_mode_dpd
                    self.fro_selection_dpd = fro_selection_dpd
                    self.wakeup_timer_dpd_enable = wakeup_timer_dpd_enable
                case self.EnumTargetPowerMode.HPD:
                    self.current_limiter_hpd_enable = current_limiter_hpd_enable
                case _:
                    self._rfu = 0x00000000

        def __str__(self) -> str:
            _self = deepcopy(self)
            del _self.target_power_mode
            return class_to_str(_self, include_title=True, indent_level=1)

        def _get_bytes(self):
            bytes = []
            match self.target_power_mode:
                case self.EnumTargetPowerMode.ACTIVE:
                    bytes.append(int(self.current_limiter_mA_active & 0x00FF))
                    bytes.append(int(self.current_limiter_mA_active & 0xFF00) >> 8)
                    bytes += [0x00] * 2
                    return bytes
                case self.EnumTargetPowerMode.DPD:
                    bytes.append(
                        (
                            ((int(self.baseband_retention_dpd_enable)) << 0)
                            | ((int(self.cpu_retention_dpd_enable)) << 1)
                            | ((int(self.cpu_retention_ldo_dpd_enable)) << 2)
                            | (int(self.current_limiter_mode_dpd) << 3)
                            | (int(self.fro_selection_dpd) << 5)
                            | ((int(self.wakeup_timer_dpd_enable)) << 6)
                        )
                    )
                    bytes += [0x00] * 3
                    return bytes
                case self.EnumTargetPowerMode.HPD:
                    bytes.append(int(self.current_limiter_hpd_enable))
                    bytes += [0x00] * 3
                    return bytes
                case _:
                    bytes += [0x00] * 4
                    return bytes

    class DpdWakeuptimerControl:
        class EnumTargetPowerMode(IntEnum):
            ACTIVE = 0x00
            RFU = 0x01
            DPD = 0x02
            HPD = 0x03

        def __init__(
            self,
            target_power_mode: EnumTargetPowerMode = EnumTargetPowerMode.DPD,
            wakeup_timer_ticks: int = 0x00001F40,
            timer_calibration_enable: bool = True,
        ):
            self.target_power_mode = target_power_mode
            if target_power_mode == self.EnumTargetPowerMode.DPD:
                self.wakeup_timer_ticks = wakeup_timer_ticks
                self.timer_calibration_enable = timer_calibration_enable
            else:
                self._rfu = 0x0000000000000000

        def __str__(self) -> str:
            _self = deepcopy(self)
            del _self.target_power_mode
            return class_to_str(_self, include_title=True, indent_level=1)

        def _get_bytes(self):
            bytes = []
            match self.target_power_mode:
                case PowerConfig.EnumTargetPowerMode.DPD:
                    config = (self.wakeup_timer_ticks & 0xFFFFFFFF) | (self.timer_calibration_enable & 1) << 32
                    bytes.append(int(config & 0x00000000FF))
                    bytes.append(int(config & 0x000000FF00) >> 8)
                    bytes.append(int(config & 0x0000FF0000) >> 16)
                    bytes.append(int(config & 0x00FF000000) >> 24)
                    bytes.append(int(config & 0xFF00000000) >> 32)
                    bytes += [0x00] * 3
                    return bytes
                case _:
                    bytes += [0x00] * 8
                    return bytes

    @frozen
    class BasebandPowerControl:
        def __init__(self, enable_baseband: bool = True):
            self.enable_baseband = enable_baseband

        def __str__(self) -> str:
            return class_to_str(self, include_title=True, indent_level=1)

        def _get_bytes(self) -> list:
            return [((int(self.enable_baseband)) << 0)]

    def __init__(
        self,
        target_power_mode: EnumTargetPowerMode = EnumTargetPowerMode.DPD,
        cpu_idle_mode: EnumCpuIdleMode = EnumCpuIdleMode.WAIT_FOR_INTERRUPT,
        baseband_power_control: BasebandPowerControl = BasebandPowerControl(),
        snapshot_control: EnumSnapshotControl = EnumSnapshotControl.DISABLE,
        cpu_mem_control: CpuMemControl = CpuMemControl(),
        dsp_mem_control_ranging: EnumDspMemControl = EnumDspMemControl.SHUTDOWN,
        dsp_mem_control_radar: EnumDspMemControl = EnumDspMemControl.SHUTDOWN,
        low_power_gpio_control: LowPowerGpioControl = LowPowerGpioControl(),
        low_power_ldo_controls: LowPowerLdoControls = LowPowerLdoControls(),
        dpd_wakeuptimer_control: DpdWakeuptimerControl = DpdWakeuptimerControl(),
    ):
        self.target_power_mode = target_power_mode
        self.cpu_idle_mode = cpu_idle_mode
        self.baseband_power_control = baseband_power_control
        self.snapshot_control = snapshot_control
        self.cpu_mem_control = cpu_mem_control
        self.dsp_mem_control_ranging = dsp_mem_control_ranging
        self.dsp_mem_control_radar = dsp_mem_control_radar
        self.low_power_gpio_control = low_power_gpio_control
        self.low_power_ldo_controls = low_power_ldo_controls
        self.dpd_wakeuptimer_control = dpd_wakeuptimer_control

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_ACTIVATE_SWUP
@frozen
class ActivateSwup:
    class EnumSwupMode(IntEnum):
        ACTIVATE_SWUP_LOAD_USER_DEFINED_SWUP_HOST_INTERFACE = 0x00
        ACTIVATE_SWUP_LOAD_RECOVERY_INTERFACE = 0x02

    def __init__(
        self,
        swup_mode: EnumSwupMode,
    ):
        self.swup_mode = swup_mode

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_CLOCK_MGMT_CONFIG
@frozen
class ClockConfig:
    class EnumClockPinSignalSource(IntEnum):
        CRYSTAL_OSCILLATOR = 0x00
        TEMPERATURE_COMPENSATED_XO = 0x01
        EXTERNAL_CLOCK_SOURCE = 0x02

    class EnumClockPinFrequency(IntEnum):
        MHZ_38_4 = 0x01
        MHZ_52_0 = 0x02
        MHZ_55_2 = 0x03

    class EnumClockDivisionFactor(IntEnum):
        DIVISION_BY_1 = 0x00
        DIVISION_BY_2 = 0x01
        DIVISION_BY_4 = 0x02
        DIVISION_BY_8 = 0x03
        DIVISION_BY_16 = 0x04
        DIVISION_BY_32 = 0x05

    class EnumOutputP24(IntEnum):
        DISABLED = 0x00
        CPU_CLOCK_OUT_DIVIDED_BY_8 = 0x01
        CAN_CLOCK_OUT = 0x02

    class EnumOutputP33(IntEnum):
        DISABLED = 0x00
        XTAL_CLOCK_OUT_NOT_DIVIDED = 0x01
        XTAL_CLOCK_OUT_DIVIDED_BY_2 = 0x02

    class EnumOutputP13(IntEnum):
        DISABLED = 0x00
        XTAL_CLOCK_OUT_DIVIDED_BY_4 = 0x01

    class EnumClockCpuSource(IntEnum):
        FREE_RUNNING_OSCILLATOR = 0x00
        CLOCK_INPUT_PIN = 0x01
        GENERAL_PURPOSE_PHASE_LOCKED_LOOP = 0x02

    class EnumCanClockSource(IntEnum):
        CAN_CLOCK_OFF = 0x00
        CAN_CLOCK_GPPLL_40_MHZ = 0x01
        CAN_CLOCK_GPPLL_80_MHZ = 0x02
        CAN_CLOCK_HFO_FRO = 0x03

    class EnumSysTickSel(IntEnum):
        SYSTICK_TIMER_SEL_RCOSC_128 = 0x00000000
        SYSTICK_TIMER_SEL_XO_32 = 0x00000001

    def __init__(
        self,
        clock_source_select_input_pin_enable: bool = False,
        clock_source_select_gppll_enable: bool = False,
        clock_pin_signal_source_select: EnumClockPinSignalSource = EnumClockPinSignalSource.CRYSTAL_OSCILLATOR,
        clock_pin_frequency_config: EnumClockPinFrequency = EnumClockPinFrequency.MHZ_55_2,
        clock_division_factor_config: EnumClockDivisionFactor = EnumClockDivisionFactor.DIVISION_BY_1,
        clock_out_p24: EnumOutputP24 = EnumOutputP24.DISABLED,
        clock_cpu_source_select: EnumClockCpuSource = EnumClockCpuSource.FREE_RUNNING_OSCILLATOR,
        clock_out_xo_out: EnumOutputP33 = EnumOutputP33.DISABLED,
        clock_out_p13: EnumOutputP13 = EnumOutputP13.DISABLED,
        can_clock_source: EnumCanClockSource = EnumCanClockSource.CAN_CLOCK_OFF,
        xtal_bias_on: bool = False,
        c_load_pF: int = 0x00000000,
        sys_tick_sel_timer: EnumSysTickSel = EnumSysTickSel.SYSTICK_TIMER_SEL_RCOSC_128,
    ):
        self.clock_source_select_input_pin_enable = clock_source_select_input_pin_enable
        self.clock_source_select_gppll_enable = clock_source_select_gppll_enable
        self.clock_pin_signal_source_select = clock_pin_signal_source_select
        self.clock_pin_frequency_config = clock_pin_frequency_config
        self.clock_division_factor_config = clock_division_factor_config
        self.clock_out_p24 = clock_out_p24
        self.clock_cpu_source_select = clock_cpu_source_select
        self.clock_out_xo_out = clock_out_xo_out
        self.clock_out_p13 = clock_out_p13
        self.can_clock_source = can_clock_source
        self.xtal_bias_os = xtal_bias_on
        self.c_load_pF = c_load_pF
        self.sys_tick_sel_timer = sys_tick_sel_timer

    def __str__(self) -> str:
        return class_to_str(self)


# NTF_CLOCK_MGMT
@frozen
class ClockManagementNotification:
    class EnumClockManagementEventType(IntEnum):
        XTAL_FREQ_OUT_OF_RANGE = 0x000065D6
        GPPLL_UNLOCK = 0x0000B2EB

    def __init__(
        self,
        status: int = 0x00,
        event_type: EnumClockManagementEventType = EnumClockManagementEventType.GPPLL_UNLOCK,
        additional_info: int = 0x00000000,
    ):
        self.status = status
        self.event_type = event_type
        self.additional_info = additional_info

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_PIN_TOGGLE_CONFIG
@frozen
class PinConfig:
    class OperationTrigger:
        def __init__(
            self,
            baseband_trigger_enable: bool = False,
            baseband_trigger_radar_enable: bool = False,
            baseband_trigger_ranging_enable: bool = False,
            sync_in_enable: bool = False,
        ):
            self.baseband_trigger_enable = baseband_trigger_enable
            self.baseband_trigger_radar_enable = baseband_trigger_radar_enable
            self.baseband_trigger_ranging_enable = baseband_trigger_ranging_enable
            self.sync_in_enable = sync_in_enable

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

        def _get_int(self) -> int:
            return (
                (int(self.baseband_trigger_enable) << 0)
                | (int(self.baseband_trigger_radar_enable) << 1)
                | (int(self.baseband_trigger_ranging_enable) << 2)
                | (int(self.sync_in_enable) << 3)
            )

    class BasebandDebugOutPinSelect:
        def __init__(
            self,
            p12_output_enable: bool = False,
            p13_output_enable: bool = False,
            p14_output_enable: bool = False,
            p15_output_enable: bool = False,
            p16_output_enable: bool = False,
            p17_output_enable: bool = False,
        ):
            self.p12_output_enable = p12_output_enable
            self.p13_output_enable = p13_output_enable
            self.p14_output_enable = p14_output_enable
            self.p15_output_enable = p15_output_enable
            self.p16_output_enable = p16_output_enable
            self.p17_output_enable = p17_output_enable

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

        def _get_int(self) -> int:
            return (
                (int(self.p12_output_enable) << 0)
                | (int(self.p13_output_enable) << 1)
                | (int(self.p14_output_enable) << 2)
                | (int(self.p15_output_enable) << 3)
                | (int(self.p16_output_enable) << 4)
                | (int(self.p17_output_enable) << 5)
            )

    class OperationIndicationSelect:
        def __init__(
            self,
            start_baseband_indicator: bool = False,
            baseband_idle_callback_indicator: bool = False,
            baseband_ready_callback_indicator: bool = False,
            baseband_active_callback_indicator: bool = False,
            rxdone_callback_indicator: bool = False,
            txdone_callback_indicator: bool = False,
            dsp_image_loading_success_indicator: bool = False,
            crypto_operation_start_end_indicator: bool = False,
            main_application_entry_point_indicator: bool = True,
            change_in_device_power_state: bool = False,
            change_in_cmd_activate_swup: bool = False,
        ):
            self.start_baseband_indicator = start_baseband_indicator
            self.baseband_idle_callback_indicator = baseband_idle_callback_indicator
            self.baseband_ready_callback_indicator = baseband_ready_callback_indicator
            self.baseband_active_callback_indicator = baseband_active_callback_indicator
            self.rxdone_callback_indicator = rxdone_callback_indicator
            self.txdone_callback_indicator = txdone_callback_indicator
            self.dsp_image_loading_success_indicator = dsp_image_loading_success_indicator
            self.crypto_operation_start_end_indicator = crypto_operation_start_end_indicator
            self.main_application_entry_point_indicator = main_application_entry_point_indicator
            self.change_in_device_power_state = change_in_device_power_state
            self.change_in_cmd_activate_swup = change_in_cmd_activate_swup

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

        def _get_int(self) -> int:
            i = (
                (int(self.start_baseband_indicator) << 0)
                | (int(self.baseband_idle_callback_indicator) << 1)
                | (int(self.baseband_ready_callback_indicator) << 2)
                | (int(self.baseband_active_callback_indicator) << 3)
                | (int(self.rxdone_callback_indicator) << 4)
                | (int(self.txdone_callback_indicator) << 5)
                | (int(self.dsp_image_loading_success_indicator) << 6)
                | (int(self.crypto_operation_start_end_indicator) << 7)
                | (int(self.main_application_entry_point_indicator) << 8)
                | (int(self.change_in_device_power_state) << 9)
                | (int(self.change_in_cmd_activate_swup) << 10)
            )
            return i

    class EnumSyncOutPin(IntEnum):
        SYNC_OUT_DISABLED = 0x00
        SYNC_OUT_P16 = 0x01
        SYNC_OUT_P25 = 0x02

    def __init__(
        self,
        operation_trigger: OperationTrigger = OperationTrigger(),
        baseband_debug_dmux_select_set: int = 0x00,  # 0x00: DISABLE
        baseband_debug_out_pin_select: BasebandDebugOutPinSelect = BasebandDebugOutPinSelect(),
        sync_out_pin: EnumSyncOutPin = EnumSyncOutPin.SYNC_OUT_DISABLED,
        operation_indication_select: OperationIndicationSelect = OperationIndicationSelect(),
        sync_out_delay_us: int = 1000,
    ):
        self.operation_trigger = operation_trigger
        self.baseband_debug_dmux_select_set = baseband_debug_dmux_select_set
        self.baseband_debug_out_pin_select = baseband_debug_out_pin_select
        self.sync_out_pin = sync_out_pin
        self.operation_indication_select = operation_indication_select
        self.sync_out_delay_us = sync_out_delay_us
        self._rfu2 = [0x00, 0x00, 0x00]

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_GPADC_OPERATION
@frozen
class GpAdcConfig:
    class EnumGpAdcOperation(IntEnum):
        SINGLE_SHOT_MEASUREMENT = 0x00
        TDC_TEMPERATURE_MONITORING = 0x01
        STOP_ACQUISITION = 0x02
        RFU = 0x03
        SET_TEMPERATURE_THRESHOLDS = 0x04

    class EnumMeasurementType(IntEnum):
        GPADC_REF_VOLTAGE = 0x00
        CPU_RETENTION_VOLTAGE = 0x01
        VBAT_IO_VOLTAGE = 0x02
        INTERNAL_TDC_TEMPERATURE = 0x03
        EXTERNAL_TEMPERATURE = 0x04
        EXTERNAL_VOLTAGE__ADC_P__ADC_N = 0x05
        EXTERNAL_VOLTAGE__P24_P25 = 0x06

    class EnumResultNtfEnbl(IntEnum):
        OVER_TEMP_NTF = 0
        UNDER_TEMP_NTF = 1
        WARN_TEMP_NTF = 2

    @staticmethod
    def _temperature_to_bytes(temperature: int):
        # convert scale of -512 degrees to 511 degrees to 16-bit signed integer
        temperature *= 64
        temperature = int(round(temperature))
        # truncate if larger than 15 bit can carry
        temperature = temperature if temperature < 2**15 else 2**15 - 1
        temperature = temperature if temperature >= -(2**15) else -(2**15)
        bytes = list(temperature.to_bytes(length=2, byteorder="little", signed=True))
        return bytes

    @staticmethod
    def _bytes_to_temperature(bytes):
        temperature = int.from_bytes(bytes=bytes, byteorder="little", signed=True)
        temperature /= 64
        temperature = floor(temperature)
        return temperature

    class ResultNtfEnbl:
        def __init__(
            self,
            over_temp_ntf: bool = False,
            under_temp_ntf: bool = False,
            warn_temp_ntf: bool = False,
        ):
            self.over_temp_ntf = over_temp_ntf
            self.under_temp_ntf = under_temp_ntf
            self.warn_temp_ntf = warn_temp_ntf

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

    def __init__(
        self,
        gpadc_operation: EnumGpAdcOperation = EnumGpAdcOperation.SINGLE_SHOT_MEASUREMENT,
        measurement_type: EnumMeasurementType = EnumMeasurementType.GPADC_REF_VOLTAGE,
        over_temp_threshold: int = 0,
        under_temp_threshold: int = 0,
        warn_temp_threshold: int = 0,
        result_ntf_enbl: ResultNtfEnbl = ResultNtfEnbl(),
    ):
        self.gpadc_operation = gpadc_operation
        self.measurement_type = measurement_type
        self.over_temp_threshold = over_temp_threshold
        self.under_temp_threshold = under_temp_threshold
        self.warn_temp_threshold = warn_temp_threshold
        self.result_ntf_enbl = result_ntf_enbl

    def __str__(self) -> str:
        return class_to_str(self)


# RSP_GPADC_OPERATION
@frozen
class GpAdcResults:
    @frozen
    class GpAdcResult:
        def __init__(self, offset_error: int, adc_value: int):
            self.offset_error = offset_error
            self.adc_value = adc_value

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

    def __init__(self, gpadc_result_0: GpAdcResult, gpadc_result_1: GpAdcResult):
        self.gpadc_result_0 = gpadc_result_0
        self.gpadc_result_1 = gpadc_result_1

    def __str__(self) -> str:
        return class_to_str(self)


# NTF_GPADC_RESULT
@frozen
class GpAdcNotificationResult:
    @frozen
    class ThresholdStatus:
        def __init__(self, over_temp_threshold_reached: bool, under_temp_threshold_reached: bool, warn_temp_threshold_reached: bool):
            self.over_temp_threshold_reached = over_temp_threshold_reached
            self.under_temp_threshold_reached = under_temp_threshold_reached
            self.warn_temp_threshold_reached = warn_temp_threshold_reached

        def __str__(self) -> str:
            return class_to_str(self, include_title=False, indent_level=1)

    def __init__(self, threshold_status: ThresholdStatus, gpadc_result: GpAdcResults.GpAdcResult):
        self.threshold_status = threshold_status
        self.gpadc_result = gpadc_result
        self._rfu = [0x00, 0x00, 0x00, 0x00]

    def __str__(self) -> str:
        return class_to_str(self)


# NTF_BASEBAND_STATUS
@frozen
class BasebandStatusNotification:
    def __init__(
        self,
        status: EnumUciStatus,
        baseband_status: BasebandResults.BasebandStatus,
        cfo_results: BasebandResults.CfoResults,
        rx1_nbic_results: BasebandResults.NbicResults,
        rx2_nbic_results: BasebandResults.NbicResults,
        rx1_agc_gain_results_db: int,
        rx2_agc_gain_results_db: int,
        timestamp_results_0: BasebandResults.TimestampResults,
        timestamp_results_1: BasebandResults.TimestampResults,
        timestamp_results_2: BasebandResults.TimestampResults,
        rx1_firstpath_results_res_index_0: BasebandResults.FirstpathResults,
        rx1_firstpath_results_res_index_1: BasebandResults.FirstpathResults,
        rx1_firstpath_results_res_index_2: BasebandResults.FirstpathResults,
        rx1_firstpath_results_res_index_3: BasebandResults.FirstpathResults,
        rx1_firstpath_results_res_index_4: BasebandResults.FirstpathResults,
        rx2_firstpath_results_res_index_0: BasebandResults.FirstpathResults,
        rx2_firstpath_results_res_index_1: BasebandResults.FirstpathResults,
        rx2_firstpath_results_res_index_2: BasebandResults.FirstpathResults,
        rx2_firstpath_results_res_index_3: BasebandResults.FirstpathResults,
        rx2_firstpath_results_res_index_4: BasebandResults.FirstpathResults,
        pdoa_results_res_index_0: BasebandResults.PdoaResults,
        pdoa_results_res_index_1: BasebandResults.PdoaResults,
        pdoa_results_res_index_2: BasebandResults.PdoaResults,
        pdoa_results_res_index_3: BasebandResults.PdoaResults,
        pdoa_results_res_index_4: BasebandResults.PdoaResults,
        pdoa_results_res_index_5: BasebandResults.PdoaResults,
        pdoa_results_res_index_6: BasebandResults.PdoaResults,
        pdoa_results_res_index_7: BasebandResults.PdoaResults,
        pdoa_results_res_index_8: BasebandResults.PdoaResults,
        pdoa_results_res_index_9: BasebandResults.PdoaResults,
        pdoa_results_res_index_10: BasebandResults.PdoaResults,
        pdoa_results_res_index_11: BasebandResults.PdoaResults,
        pdoa_results_res_index_12: BasebandResults.PdoaResults,
        rx_payload_data_configuration: BasebandResults.RXPayloadDataConfig,
    ):
        self.status = status
        self.baseband_status = baseband_status
        self.cfo_results = cfo_results
        self.rx1_nbic_results = rx1_nbic_results
        self.rx2_nbic_results = rx2_nbic_results
        self.rx1_agc_gain_results_db = rx1_agc_gain_results_db
        self.rx2_agc_gain_results_db = rx2_agc_gain_results_db
        self.timestamp_results_0 = timestamp_results_0
        self.timestamp_results_1 = timestamp_results_1
        self.timestamp_results_2 = timestamp_results_2
        self.rx1_firstpath_results_res_index_0 = rx1_firstpath_results_res_index_0
        self.rx1_firstpath_results_res_index_1 = rx1_firstpath_results_res_index_1
        self.rx1_firstpath_results_res_index_2 = rx1_firstpath_results_res_index_2
        self.rx1_firstpath_results_res_index_3 = rx1_firstpath_results_res_index_3
        self.rx1_firstpath_results_res_index_4 = rx1_firstpath_results_res_index_4
        self.rx2_firstpath_results_res_index_0 = rx2_firstpath_results_res_index_0
        self.rx2_firstpath_results_res_index_1 = rx2_firstpath_results_res_index_1
        self.rx2_firstpath_results_res_index_2 = rx2_firstpath_results_res_index_2
        self.rx2_firstpath_results_res_index_3 = rx2_firstpath_results_res_index_3
        self.rx2_firstpath_results_res_index_4 = rx2_firstpath_results_res_index_4
        self.pdoa_results_res_index_0 = pdoa_results_res_index_0
        self.pdoa_results_res_index_1 = pdoa_results_res_index_1
        self.pdoa_results_res_index_2 = pdoa_results_res_index_2
        self.pdoa_results_res_index_3 = pdoa_results_res_index_3
        self.pdoa_results_res_index_4 = pdoa_results_res_index_4
        self.pdoa_results_res_index_5 = pdoa_results_res_index_5
        self.pdoa_results_res_index_6 = pdoa_results_res_index_6
        self.pdoa_results_res_index_7 = pdoa_results_res_index_7
        self.pdoa_results_res_index_8 = pdoa_results_res_index_8
        self.pdoa_results_res_index_9 = pdoa_results_res_index_9
        self.pdoa_results_res_index_10 = pdoa_results_res_index_10
        self.pdoa_results_res_index_11 = pdoa_results_res_index_11
        self.pdoa_results_res_index_12 = pdoa_results_res_index_12
        self.rx_payload_data_configuration = rx_payload_data_configuration

    def __str__(self):
        return class_to_str(self)


# CMD_GET_RADIO_CONFIG_VERSION
@frozen
class GetRadioConfigConfigVersion:
    class EnumConfiguration(IntEnum):
        RX_RADIO_CONFIGURATION = 0x00
        TX_RADIO_CONFIGURATION = 0x01

    def __init__(self, configuration_index: int = 0, configuration_type: EnumConfiguration = EnumConfiguration.RX_RADIO_CONFIGURATION):
        self.configuration_index = configuration_index
        self.configuration_type = configuration_type

    def __str__(self) -> str:
        return class_to_str(self)


# RSP_GET_RADIO_CONFIG_VERSION
@frozen
class RadioConfigVersion:
    def __init__(
        self,
        radio_cnf_major_version: int,
        radio_cnf_minor_version: int,
        radio_cnf_patch_version: int,
        radio_cnf_version_id: int,
    ):
        self.radio_cnf_major_version = radio_cnf_major_version
        self.radio_cnf_minor_version = radio_cnf_minor_version
        self.radio_cnf_patch_version = radio_cnf_patch_version
        self.radio_cnf_version_id = radio_cnf_version_id

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_SET_BITFIELD
@frozen
class SetBitfieldConfig:
    def __init__(self, address: int = 0, offset: int = 0, width: int = 1, value: int = 0):
        self.address = address
        self.offset = offset
        self.width = width
        self.value = value

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_GET_BITFIELD
@frozen
class GetBitfieldConfig:
    def __init__(
        self,
        address: int = 0,
        offset: int = 0,
        width: int = 1,
    ):
        self.address = address
        self.offset = offset
        self.width = width

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_RX_RADIO_CONFIG
@frozen
class RXRadioConfig:
    def __init__(self, configuration_index: int = 0, rx_radio_config_data: List[int] = []):
        self.configuration_index = configuration_index
        self.rx_radio_config_data = rx_radio_config_data

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_TX_RADIO_CONFIG
@frozen
class TXRadioConfig:
    def __init__(self, configuration_index: int = 0, tx_radio_config_data: List[int] = []):
        self.configuration_index = configuration_index
        self.tx_radio_config_data = tx_radio_config_data

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_RANGING_PAYLOAD_CONFIG
@frozen
class RangingPayloadConfig:
    class EnumCrcType(IntEnum):
        CRC32 = 0x00
        CRC16 = 0x01

    def __init__(
        self,
        payload_index: int = 0,
        ranging_payload_ctrl_crc_enable: bool = False,
        ranging_payload_ctrl_crc_type: EnumCrcType = EnumCrcType.CRC32,
        ranging_payload_length: int = 1,
        ranging_payload_data: List[int] = [0x00],
    ):
        self.payload_index = payload_index
        self.ranging_payload_ctrl_crc_enable = ranging_payload_ctrl_crc_enable
        self.ranging_payload_ctrl_crc_type = ranging_payload_ctrl_crc_type
        self.ranging_payload_length = ranging_payload_length
        self.payload_data = ranging_payload_data

    def __str__(self) -> str:
        return class_to_str(self)


# CMD_RANGING_APPLICATION_CONFIG
@frozen
class RangingApplicationConfig:
    class EnumKeepSysPll(IntEnum):
        KEEP_SYSPLL_ON = 0x00
        SWITCH_SYSPLL_OFF = 0x01

    @staticmethod
    def _ppm_to_bytes(ppm: float):
        ppm = ppm * 10
        signed = int(round(ppm))
        bytes = list(signed.to_bytes(length=2, byteorder="little", signed=True))
        return bytes

    def __init__(
        self,
        uwb_channel_frequency_khz: int = 0x0079E000,
        ppm: float = 0,  # Range: -256 - 256 | Steps: 0.1
        keep_syspll: EnumKeepSysPll = EnumKeepSysPll.KEEP_SYSPLL_ON,
        notification_sel_enable: bool = True,
        ranging_repeat_cnt: int = 0x00000001,
        ranging_repeat_interval_us: int = 0x000003E8,
        rx_start_margin_us: int = 100,
    ):
        self.uwb_channel_frequency_khz = uwb_channel_frequency_khz
        self.ppm = ppm
        self.keep_syspll = keep_syspll
        self.notification_sel_enable = notification_sel_enable
        self.ranging_repeat_cnt = ranging_repeat_cnt
        self.ranging_repeat_interval_us = ranging_repeat_interval_us
        self.rx_start_margin_us = rx_start_margin_us

    def __str__(self) -> str:
        _self = deepcopy(self)

        _self.uwb_channel_frequency_khz = f"{self.uwb_channel_frequency_khz} kHz"
        _self.ranging_repeat_interval_us = f"{self.ranging_repeat_interval_us} us"
        _self.rx_start_margin_us = f"{self.rx_start_margin_us} us"

        return class_to_str(_self)


# CMD_RANGING_SEQUENCE_CONFIG
@frozen
class RangingCommand:
    class EnumRangingAction(IntEnum):
        EMPTY = 0x00
        RX_RANGING = 0x01
        TX_RANGING = 0x02
        RX_DATA = 0x03
        TX_DATA = 0x04

    class EnumPSDUSel(IntEnum):
        NO_PSDU = 0x00
        USE_PRECONFIGURED_PSDU = 0x01
        TRANSMIT_ALL_DELTA_TIMESTAMPS = 0x02
        TRANSMIT_ALL_RAW_TIMESTAMPS = 0x03

    @staticmethod
    def _ns_to_int(time: float):
        # the steps between each index are 8.0128ns
        result = int(round(time / 8.0128))
        # check for results smaller than zero
        result = 0 if result < 0 else result
        return result

    @staticmethod
    def _int_to_ns(integer):
        # the steps between each index are 8.0128ns
        result = integer * 8.0128
        # check for results smaller than zero
        result = 0 if integer < 0 else result
        # round up
        result = ceil(result)
        return result

    def __init__(
        self,
        ranging_action: EnumRangingAction = EnumRangingAction.EMPTY,
        ranging_slot_select: int = 0x00,
        delay_us: int = 1000,
        timeout_ns: float = 2003000,
        psdu_select: EnumPSDUSel = EnumPSDUSel.NO_PSDU,
        psdu_buffer_index_select: int = 0x00,
    ):
        self.ranging_action = ranging_action
        self.ranging_slot_select = ranging_slot_select
        self.delay_us = delay_us
        self.timeout_ns = timeout_ns
        self.psdu_select = psdu_select
        self.psdu_buffer_index_select = psdu_buffer_index_select

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.delay_us = str(self.delay_us) + " us"
        _self.timeout_ns = str(self.timeout_ns) + " ns"
        return class_to_str(_self, include_title=False, indent_level=0)


# NTF_RANGING_STATUS
@frozen
class RangingStatus:
    class EnumRangingStatus(IntEnum):
        RANGING_STATUS_SUCCESSFUL = 0x00
        ERROR_DURING_RANGING = 0x01
        ABORTED = 0x02

    def __init__(self, ranging_status: EnumRangingStatus):
        self.ranging_status = ranging_status

    def __str__(self) -> str:
        return class_to_str(self)


# RSP_GET_RANGING_PAYLOAD
@frozen
class RangingPayload:
    def __init__(self, ranging_payload_control: int, ranging_payload_length: int, ranging_payload_data: List[int]):
        self.ranging_payload_control = ranging_payload_control
        self.ranging_payload_length = ranging_payload_length
        self.ranging_payload_data = ranging_payload_data

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.ranging_payload_control = {
            "automatic_CRC_calculation_after_frame_transmission": "Enable"
            if (self.ranging_payload_control & 1) == 1
            else ("Disable" if (self.ranging_payload_control & 1) == 0 else "Error"),
            "Select CRC": "CRC16" if (self.ranging_payload_control >> 1) == 1 else ("CRC32" if (self.ranging_payload_control >> 1) == 0 else "Error"),
        }
        return class_to_str(_self)


# CMD_RADAR_APPLICATION_CONFIG
@frozen
class RadarConfig:
    class EnumRadarControlConfigurationIndex(IntEnum):
        CONTROL_INDEX_0 = 0x00
        CONTROL_INDEX_1 = 0x01
        CONTROL_INDEX_2 = 0x02
        CONTROL_INDEX_3 = 0x03
        NOT_USED_FOR_THIS_OPERATION = 0xFF

    class EnumKeepSysPll(IntEnum):
        KEEP_SYSPLL_ON = 0x00
        SWITCH_SYSPLL_OFF = 0x01

    class EnumRadarSysPllMode(IntEnum):
        SYSPLL_MODE_FRACTIONAL = 0x00
        SYSPLL_MODE_INTEGER = 0x01

    class EnumRadarMode(IntEnum):
        TRX_MODE = 0x00
        RX_ONLY = 0x01
        TX_ONLY = 0x02
        FULL_CALIB_STAND_ALONE = 0x03
        FAST_CALIB_STAND_ALONE = 0x04
        NOISE_SUPP_CALIB_STAND_ALONE = 0x05
        FAST_CALIB_TRX_WIRED_SYNCH = 0x40
        FAST_CALIB_RX_WIRED_SYNCH = 0x41
        FAST_CALIB_TX_WIRED_SYNCH = 0x42
        FAST_CALIB_RNS_TRX_WIRED_SYNCH = 0x60
        FAST_CALIB_RNS_RX_WIRED_SYNCH = 0x61
        FAST_CALIB_RNS_TX_WIRED_SYNCH = 0x62
        FULL_CALIB_TRX_WIRED_SYNCH = 0x80
        FULL_CALIB_RX_WIRED_SYNCH = 0x81
        FULL_CALIB_TX_WIRED_SYNCH = 0x82
        FULL_CALIB_RNS_TRX_WIRED_SYNCH = 0xA0
        FULL_CALIB_RNS_RX_WIRED_SYNCH = 0xA1
        FULL_CALIB_RNS_TX_WIRED_SYNCH = 0xA2

    class EnumNotificationEnable(IntEnum):
        DISABLE = 0x00
        RX_NOTIFICATION_ENABLE = 0x01
        TX_NOTIFICATION_ENABLE = 0x02
        RX_TX_NOTIFICATION_ENABLE = 0x03

    @staticmethod
    def _ppm_to_bytes(ppm: float):
        ppm = ppm * 10
        signed = int(round(ppm))
        bytes = list(signed.to_bytes(length=2, byteorder="little", signed=True))
        return bytes

    @staticmethod
    def _ns_to_int(time: float):
        # the steps between each index are 8.0128ns
        result = int(round(time / 8.0128))
        # check for results smaller than zero
        result = 0 if result < 0 else result
        return result

    @staticmethod
    def _int_to_ns(integer):
        # the steps between each index are 8.0128ns
        result = integer * 8.0128
        # check for results smaller than zero
        result = 0 if integer < 0 else result
        # round up
        result = ceil(result)
        return result

    def __init__(
        self,
        uwb_channel_frequency_khz: int = 6489600,
        ppm: float = 0,
        keep_syspll: EnumKeepSysPll = EnumKeepSysPll.KEEP_SYSPLL_ON,
        radar_syspll_mode: EnumRadarSysPllMode = EnumRadarSysPllMode.SYSPLL_MODE_FRACTIONAL,
        init_delay_us: int = 1000,
        radar_mode: EnumRadarMode = EnumRadarMode.TRX_MODE,
        rx_radar_control_config_index: int = 0,
        tx_radar_control_config_index: int = 0,
        notification_enable: EnumNotificationEnable = EnumNotificationEnable.RX_TX_NOTIFICATION_ENABLE,
        frame_count: int = 32,
        frame_interval_ns: float = 250000,
        burst_count: int = 1,
        burst_delay_ns: float = 50000000,
    ):
        self.uwb_channel_frequency_khz = uwb_channel_frequency_khz
        self.ppm = ppm
        self.keep_syspll = keep_syspll
        self.radar_syspll_mode = radar_syspll_mode
        self.init_delay_us = init_delay_us
        self.radar_mode = radar_mode
        self.rx_radar_control_config_index = rx_radar_control_config_index
        self.tx_radar_control_config_index = tx_radar_control_config_index
        self.notification_enable = notification_enable
        self.frame_count = frame_count
        self.frame_interval_ns = frame_interval_ns
        self.burst_count = burst_count
        self.burst_delay_ns = burst_delay_ns

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.uwb_channel_frequency_khz = f"{self.uwb_channel_frequency_khz} kHz"
        _self.init_delay_us = str(self.init_delay_us) + " us"
        _self.frame_interval_ns = str(self.frame_interval_ns) + " ns"
        _self.burst_delay_ns = str(self.burst_delay_ns) + " ns"

        return class_to_str(_self)


# NTF_RADAR_RESULT
@frozen
class RadarResult:
    class EnumStatus(IntEnum):
        RX_SUCCESS_CIR_AVAILABLE = 0x00
        TX_SUCCESS = 0x01
        CALIBRATION_DONE = 0x02
        ABORTED = 0x03
        RX_ERROR = 0x10
        TX_ERROR = 0x11
        GENERAL_BASEBAND_ERROR = 0x12

    def __init__(self, status: EnumStatus, cir_data: CirData):
        self.status = status
        self.cir_data = cir_data

    def __str__(self):
        return class_to_str(self)


# CMD_CONFIG_CAN
@frozen
class CanConfig:
    def __init__(self, bitrate: int = 0x000F4240, bitrate_fd: int = 0x004C4B40):
        self.bitrate = bitrate
        self.bitrate_fd = bitrate_fd

    def __str__(self):
        return class_to_str(self)


# CMD_CONFIG_UCI
@frozen
class UciConfig:
    def __init__(self, max_payload_len_bytes: int = 0x0FF9):
        self.max_payload_len_bytes = max_payload_len_bytes

    def __str__(self):
        return class_to_str(self)


######################################################################################################################


class Ncj29d6Testware:
    # NTF_BOOT_STATUS
    @staticmethod
    def interpret_boot_status_notification(payload: List[int]) -> BootStatus:
        gpio_wup_status_flags_dict = {}
        bit_shift = 0
        # Pin P10 .. Pin P25
        for index in range(16):
            gpio_wup_status_flags_dict[f"Pin P{10 + index} negative edge flag"] = bool(payload[8 + floor(index / 4)] & (1 << bit_shift))
            gpio_wup_status_flags_dict[f"Pin P{10 + index} positive edge flag"] = bool(payload[8 + floor(index / 4)] & (1 << (bit_shift + 1)))
            bit_shift = bit_shift + 2 if bit_shift < 6 else 0

        status = BootStatus(
            power_reset_control_flags={
                BootStatus.EnumPowerResetControlFlags.POR_RST_FLAG: bool(payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.POR_RST_FLAG)),
                BootStatus.EnumPowerResetControlFlags.RST_PIN_FLAG: bool(payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.RST_PIN_FLAG)),
                BootStatus.EnumPowerResetControlFlags.DPD_RST_PIN_RST_FLAG: bool(
                    payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.DPD_RST_PIN_RST_FLAG)
                ),
                BootStatus.EnumPowerResetControlFlags.HPD_RST_PIN_RST_FLAG: bool(
                    payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.HPD_RST_PIN_RST_FLAG)
                ),
                BootStatus.EnumPowerResetControlFlags.HPD_WUP_RST_PIN_RST_FLAG: bool(
                    payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.HPD_WUP_RST_PIN_RST_FLAG)
                ),
                BootStatus.EnumPowerResetControlFlags.SW_MASTER_RST_FLAG: bool(
                    payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.SW_MASTER_RST_FLAG)
                ),
                BootStatus.EnumPowerResetControlFlags.VDD_BIAS_BGAP_POK_RST_FLAG: bool(
                    payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.VDD_BIAS_BGAP_POK_RST_FLAG)
                ),
                BootStatus.EnumPowerResetControlFlags.VDD_CPU_RET_BO_ACTIVE_FLAG: bool(
                    payload[0] & (1 << BootStatus.EnumPowerResetControlFlags.VDD_CPU_RET_BO_ACTIVE_FLAG)
                ),
                BootStatus.EnumPowerResetControlFlags.VDD_CPU_RET_BO_RST_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.VDD_CPU_RET_BO_RST_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.VDD_NV_POK_RST_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.VDD_NV_POK_RST_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.VBAT_IO_OK_RST_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.VBAT_IO_OK_RST_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.VBAT_IO_NV_OK_RST_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.VBAT_IO_NV_OK_RST_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.WDOG_RST_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.WDOG_RST_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.GO_TO_FAILED_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.GO_TO_FAILED_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.WUP_TIMER_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.WUP_TIMER_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.WUP_SNAPSHOT_FLAG: bool(
                    payload[1] & (1 << (BootStatus.EnumPowerResetControlFlags.WUP_SNAPSHOT_FLAG - 8))
                ),
                BootStatus.EnumPowerResetControlFlags.SYSRESET_REQ_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.SYSRESET_REQ_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.INGFID_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.INGFID_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.EDC_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.EDC_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.ANA_GLITCH_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.ANA_GLITCH_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.FREQ_MON_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.FREQ_MON_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.ECC_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.ECC_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.VDET_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.VDET_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.LSD_DET_RST_FLAG: bool(
                    payload[2] & (1 << (BootStatus.EnumPowerResetControlFlags.LSD_DET_RST_FLAG - 16))
                ),
                BootStatus.EnumPowerResetControlFlags.SFETCH_RST_FLAG: bool(
                    payload[3] & (1 << (BootStatus.EnumPowerResetControlFlags.SFETCH_RST_FLAG - 24))
                ),
                BootStatus.EnumPowerResetControlFlags.INGFID20_RST_FLAG: bool(
                    payload[3] & (1 << (BootStatus.EnumPowerResetControlFlags.INGFID20_RST_FLAG - 24))
                ),
                BootStatus.EnumPowerResetControlFlags.GDET_LITE_RST_FLAG: bool(
                    payload[3] & (1 << (BootStatus.EnumPowerResetControlFlags.GDET_LITE_RST_FLAG - 24))
                ),
                BootStatus.EnumPowerResetControlFlags.FAST_BOOT_FLAG: bool(
                    payload[3] & (1 << (BootStatus.EnumPowerResetControlFlags.FAST_BOOT_FLAG - 24))
                ),
            },
            boot_startup_status_flags={
                BootStatus.EnumBootStartupStatusFlags.PWR_UP_RETENTION_FLAG: bool(
                    payload[4] & (1 << BootStatus.EnumBootStartupStatusFlags.PWR_UP_RETENTION_FLAG)
                ),
                BootStatus.EnumBootStartupStatusFlags.TRIM_FLAG: bool(payload[4] & (1 << BootStatus.EnumBootStartupStatusFlags.TRIM_FLAG)),
                BootStatus.EnumBootStartupStatusFlags.SPI_CAN_INIT_FLAG: bool(
                    payload[5] & (1 << (BootStatus.EnumBootStartupStatusFlags.SPI_CAN_INIT_FLAG - 8))
                ),
                BootStatus.EnumBootStartupStatusFlags.UCI_INIT_FLAG: bool(
                    payload[5] & (1 << (BootStatus.EnumBootStartupStatusFlags.UCI_INIT_FLAG - 8))
                ),
            },
            gpio_wup_status_flags=gpio_wup_status_flags_dict,
        )
        return status

    # CMD_RESET_DEVICE
    @staticmethod
    def reset_device(type: EnumResetType) -> List[int]:
        payload = []
        payload.append(type.value)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        reset_device_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RESET_DEVICE,
            payload_length=len(payload),
            payload=payload,
        )
        return reset_device_command.byte_stream

    # CMD_RESET_DEVICE | INTERPRET PAYLOAD
    @staticmethod
    def interpret_reset_device_command(payload: List[int]) -> EnumResetType:
        return f"reset_type: {EnumResetType(payload[0])}"

    # CMD_GET_FW_VERSION
    @staticmethod
    def get_fw_version() -> List[int]:
        payload = []

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        get_fw_version_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GET_FW_VERSION,
            payload_length=0,
            payload=payload,
        )

        return get_fw_version_command.byte_stream

    # RSP_GET_FW_VERSION
    @staticmethod
    def interpret_get_fw_version_response(payload: List[int]) -> FirmwareVersion:
        """
        This function interprets the firmware version data from raw bytes of the response.
        If not the latest testware version is used this function might return early (expected) as firmware version data of older testware version
        contain less data as newer versions.

        [!] All other available functions of this library only support the corresponding testware version of its release
            and might do not work as expected if not used with the corresponding testware version!

        [!] (older testware versions: "foundation_package" states the version of "sdk_package_version")
        """
        index = 0

        def has_enough_data(size: int) -> bool:
            # Backwards-compatibility: Check if there's enough data in payload left in the payload to extract 'size' bytes
            return len(payload) - index >= size

        def extract_version():
            nonlocal index
            if not has_enough_data(16):
                return None
            version = FirmwareVersion.Versions.from_bytes(payload[index : index + 16])
            index += 16
            return version

        def extract_enum(enum_class: IntEnum, size: int = 4):
            nonlocal index
            if not has_enough_data(size):
                return None
            enum_value = int.from_bytes(payload[index : index + size], byteorder="little")
            index += size
            return enum_class(enum_value) if enum_value in enum_class._value2member_map_ else None

        def extract_swd_version():
            nonlocal index
            if not has_enough_data(4):
                return None
            swd_version = FirmwareVersion.SwdVersion.from_bytes(payload[index : index + 4])
            index += 4
            return swd_version

        def extract_int_from_bytes(size):
            nonlocal index
            if not has_enough_data(size):
                return None
            value = int.from_bytes(payload[index : index + size], byteorder="little")
            index += size
            return value

        def extract_list(size):
            nonlocal index
            if not has_enough_data(size):
                return None
            data = payload[index : index + size]
            index += size
            return data

        # Extract versions
        testware_version = extract_version()
        foundation_package_version = extract_version()
        device_mode = extract_enum(enum_class=FirmwareVersion.EnumDeviceMode, size=4)
        hardware_version = extract_enum(enum_class=FirmwareVersion.EnumHardwareVersion, size=4)
        # RFU: 8 bytes (skipped)
        index += 8
        swup_core_version = extract_version()
        swup_version = extract_version()
        baseband_version = extract_version()
        dsp_version = extract_version()
        sbe_api_version = extract_version()
        rom_version = extract_version()  # RFU
        swd_version = extract_swd_version()
        variant_information = extract_int_from_bytes(4)
        serial_number = extract_list(4)
        wafer_data = extract_list(16)
        radio_config_version = extract_version()
        bundle_version = extract_version()
        dsp_component_version = extract_version()
        swup_component_version = extract_version()
        # RFU: 160 bytes (skipped)

        return FirmwareVersion(
            testware_version=testware_version,
            foundation_package_version=foundation_package_version,
            device_mode=device_mode,
            hardware_version=hardware_version,
            swup_core_version=swup_core_version,
            swup_version=swup_version,
            baseband_version=baseband_version,
            dsp_version=dsp_version,
            sbe_api_version=sbe_api_version,
            rom_version=rom_version,
            swd_version=swd_version,
            variant_information=variant_information,
            serial_number=serial_number,
            wafer_data=wafer_data,
            radio_config_version=radio_config_version,
            bundle_version=bundle_version,
            dsp_component_version=dsp_component_version,
            swup_component_version=swup_component_version,
        )

    # CMD_RX_CONFIG
    @staticmethod
    def rx_config(config: RxConfiguration) -> List[int]:
        payload = []
        input_size = len(config.sts_configuration)
        for i in range(56):
            if i < input_size:
                # make sure that each input that is appended is byte sized
                payload.append(config.sts_configuration[i] & 0xFF)
            else:
                # pad the input with zeroes if it is too short
                payload.append(0x00)
        payload.append(config.rx_radio_configuration_index & 0xFF)
        payload += config.rx_radio_configuration
        payload.append(config.rx_dfe_configuration_index & 0xFF)
        input_size = len(config.rx_dfe_configuration)
        for i in range(12):
            if i < input_size:
                payload.append(config.rx_dfe_configuration[i] & 0xFF)
            else:
                payload.append(0x00)
        payload.append(config.rx_ranging_control_configuration_index & 0xFF)
        input_size = len(config.rx_ranging_control_configuration)
        for i in range(16):
            if i < input_size:
                payload.append(config.rx_ranging_control_configuration[i] & 0xFF)
            else:
                payload.append(0x00)

        input_size = len(config.rx_payload_configuration)
        for i in range(4):
            if i < input_size:
                payload.append(config.rx_payload_configuration[i] & 0xFF)
            else:
                payload.append(0x00)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        rx_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RX_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return rx_config_command.byte_stream

    # CMD_RX_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_rx_config_command(payload: List[int]) -> RxConfiguration:
        config = RxConfiguration(
            sts_configuration=BasebandConfiguration.StsConfiguration._get_results(payload[0 : (55 + 1)]),
            rx_radio_configuration_index=payload[56],
            rx_radio_configuration=BasebandConfiguration.RxRadioConfiguration._get_results(payload[57 : (60 + 1)]),
            rx_dfe_configuration_index=payload[61],
            rx_dfe_configuration=BasebandConfiguration.RxDigitalFrontendConfiguration._get_results(payload[62 : (73 + 1)]),
            rx_ranging_control_configuration_index=payload[74],
            rx_ranging_control_configuration=BasebandConfiguration.RxRangingControlConfiguration._get_results(payload[75 : (90 + 1)]),
            rx_payload_configuration=BasebandConfiguration.RxPayloadConfiguration._get_results(payload[91 : (94 + 1)]),
        )
        return config

    # CMD_TX_CONFIG
    @staticmethod
    def tx_config(config: TxConfiguration) -> List[int]:
        payload = []
        input_size = len(config.sts_configuration)
        for i in range(56):
            if i < input_size:
                # make sure that each input that is appended is byte sized
                payload.append(config.sts_configuration[i] & 0xFF)
            else:
                # pad the input with zeroes if it is too short
                payload.append(0x00)
        payload.append(config.tx_radio_configuration_index & 0xFF)
        payload += config.tx_radio_configuration
        payload.append(config.tx_power_configuration_index & 0xFF)
        input_size = len(config.tx_power_configuration)
        for i in range(4):
            if i < input_size:
                payload.append(config.tx_power_configuration[i] & 0xFF)
            else:
                payload.append(0x00)
        payload.append(config.tx_ranging_control_configuration_index & 0xFF)
        input_size = len(config.tx_ranging_control_configuration)
        for i in range(12):
            if i < input_size:
                payload.append(config.tx_ranging_control_configuration[i] & 0xFF)
            else:
                payload.append(0x00)
        for i in range(len(config.tx_payload_configuration)):
            payload.append(config.tx_payload_configuration[i] & 0xFF)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        tx_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_TX_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return tx_config_command.byte_stream

    # CMD_TX_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_tx_config_command(payload: List[int]) -> TxConfiguration:
        config = TxConfiguration(
            sts_configuration=BasebandConfiguration.StsConfiguration._get_results(payload[0 : (55 + 1)]),
            tx_radio_configuration_index=payload[56],
            tx_radio_configuration=BasebandConfiguration.TxRadioConfiguration._get_results(payload[57 : (60 + 1)]),
            tx_power_configuration_index=payload[61],
            tx_power_configuration=BasebandConfiguration.TxPowerConfiguration._get_results(payload[62 : (65 + 1)]),
            tx_ranging_control_configuration_index=payload[66],
            tx_ranging_control_configuration=BasebandConfiguration.TxRangingControlConfiguration._get_results(payload[67 : (78 + 1)]),
            tx_payload_configuration=BasebandConfiguration.TxPayloadConfiguration._get_results(payload[79:]),
        )
        return config

    # CMD_START_BASEBAND
    def start_baseband(config: StartBasebandConfig) -> List[int]:
        payload = []
        payload.append(config.uwb_channel_frequency_khz & 0x000000FF)
        payload.append((config.uwb_channel_frequency_khz & 0x0000FF00) >> 8)
        payload.append((config.uwb_channel_frequency_khz & 0x00FF0000) >> 16)
        payload.append((config.uwb_channel_frequency_khz & 0xFF000000) >> 24)
        payload += config._ppm_to_bytes(config.ppm)
        payload.append(config.init_delay_us & 0x000000FF)
        payload.append((config.init_delay_us & 0x0000FF00) >> 8)
        payload.append((config.init_delay_us & 0x00FF0000) >> 16)
        payload.append((config.init_delay_us & 0xFF000000) >> 24)
        payload.append(config.configuration_index & 0xFF)
        payload += config.command_configuration
        notification_select = int(config.notification_sel_post_baseband_enable) | (int(config.notification_sel_during_baseband_enable) << 1)
        payload.append(notification_select & 0x000000FF)
        payload.append((notification_select & 0x0000FF00) >> 8)
        payload.append((notification_select & 0x00FF0000) >> 16)
        payload.append((notification_select & 0xFF000000) >> 24)
        payload.append(config.start_index & 0x00FF)
        payload.append((config.start_index & 0xFF00) >> 8)
        payload.append(config.end_index & 0x00FF)
        payload.append((config.end_index & 0xFF00) >> 8)
        payload.append(config.cmd_sequence_count & 0x000000FF)
        payload.append((config.cmd_sequence_count & 0x0000FF00) >> 8)
        payload.append((config.cmd_sequence_count & 0x00FF0000) >> 16)
        payload.append((config.cmd_sequence_count & 0xFF000000) >> 24)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        start_baseband_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_START_BASEBAND,
            payload_length=len(payload),
            payload=payload,
        )

        return start_baseband_command.byte_stream

    # CMD_START_BASEBAND | INTERPRET PAYLOAD
    def interpret_start_baseband_command(payload: List[int]) -> StartBasebandConfig:
        config = StartBasebandConfig(
            uwb_channel_frequency_khz=int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False),
            ppm=(int.from_bytes(bytes=payload[4 : (5 + 1)], byteorder="little", signed=True)) / 10,
            init_delay_us=int.from_bytes(bytes=payload[6 : (9 + 1)], byteorder="little", signed=False),
            configuration_index=StartBasebandConfig.EnumConfigurationIndex(payload[10]),
            command_configuration=BasebandConfiguration.CommandConfiguration._get_results(payload[11 : (30 + 1)]),
            notification_sel_during_baseband_enable=bool(payload[31] & 1 << 0),
            notification_sel_post_baseband_enable=bool(payload[31] & 1 << 1),
            start_index=(int.from_bytes(bytes=payload[35 : (36 + 1)], byteorder="little", signed=False)),
            end_index=(int.from_bytes(bytes=payload[37 : (38 + 1)], byteorder="little", signed=False)),
            cmd_sequence_count=(int.from_bytes(bytes=payload[39 : (42 + 1)], byteorder="little", signed=False)),
        )
        return config

    # CMD_STOP_BASEBAND
    @staticmethod
    def stop_baseband() -> List[int]:
        payload = []

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        stop_baseband_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_STOP_BASEBAND,
            payload_length=0,
            payload=payload,
        )

        return stop_baseband_command.byte_stream

    # CMD_GET_BASEBAND_RESULTS
    @staticmethod
    def get_baseband_results(config: BasebandResultsConfig) -> List[int]:
        payload = []
        payload.append(config.baseband_result_select & 0xFF)
        payload.append(config.baseband_results_index & 0xFF)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        get_baseband_results_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GET_BASEBAND_RESULTS,
            payload_length=len(payload),
            payload=payload,
        )

        return get_baseband_results_command.byte_stream

    # CMD_GET_BASEBAND_RESULTS | INTERPRET PAYLOAD
    @staticmethod
    def interpret_get_baseband_results_command(payload: List[int]) -> BasebandResultsConfig:
        config = BasebandResultsConfig(baseband_result_select=BasebandResultsConfig.EnumResultSelect(payload[0]), baseband_results_index=payload[1])
        return config

    # RSP_GET_BASEBAND_RESULTS
    @staticmethod
    def interpret_get_baseband_results_response(payload: List[int], center_frequency_khz: float = 7987200) -> BasebandResults:
        match BasebandResults.EnumResultSelect(payload[0]):
            case BasebandResults.EnumResultSelect.RX_PAYLOAD_DATA:
                result = BasebandResults.RXPayloadDataConfig._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.RANGING_CIR_DATA:
                result = BasebandResults.RangingCIRData._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.TIMESTAMP_RESULTS:
                result = BasebandResults.TimestampResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.FIRSTPATH_RESULTS:
                result = BasebandResults.FirstpathResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.PDOA_RESULTS:
                result = BasebandResults.PdoaResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.DELTA_TIMESTAMP_RESULTS:
                result = BasebandResults.DeltaTimestampResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.BASEBAND_STATUS:
                result = BasebandResults.BasebandStatus._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.CFO_RESULTS:
                result = BasebandResults.CfoResults._get_results(payload[2:], center_frequency_khz)
            case BasebandResults.EnumResultSelect.NBIC_RESULTS:
                result = BasebandResults.NbicResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.AGC_GAIN_RESULTS:
                result = BasebandResults.AgcGainResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.RADAR_CALIBRATION_GAIN_RESULTS:
                result = BasebandResults.RadarCalibrationGainResults._get_results(payload[2:])
            case BasebandResults.EnumResultSelect.RX_RADAR_CALIBRATION_DATA:
                result = BasebandConfiguration.RxRadarCalibrationData._get_results(payload[2:])
            case _:
                pass

        results = BasebandResults(
            baseband_result_sel=BasebandResults.EnumResultSelect(payload[0]), baseband_results_index=payload[1], baseband_result=result
        )
        return results

    # CMD_POWER_MGMT_CONFIG
    @staticmethod
    def power_management_config(config: PowerConfig) -> List[int]:
        payload = []
        payload.append(config.target_power_mode & 0xFF)
        payload.append(config.cpu_idle_mode & 0xFF)
        payload += [config.baseband_power_control] if isinstance(config.baseband_power_control, int) else config.baseband_power_control._get_bytes()
        payload.append(config.snapshot_control & 0xFF)
        payload += (
            [
                config.cpu_mem_control & 0x000000FF,
                (config.cpu_mem_control & 0x0000FF00) >> 8,
                (config.cpu_mem_control & 0x00FF0000) >> 16,
                (config.cpu_mem_control & 0xFF000000) >> 24,
            ]
            if isinstance(config.cpu_mem_control, int)
            else config.cpu_mem_control._get_bytes()
        )
        payload.append(config.dsp_mem_control_ranging & 0x000000FF)
        payload.append((config.dsp_mem_control_ranging & 0x0000FF00) >> 8)
        payload.append((config.dsp_mem_control_ranging & 0x00FF0000) >> 16)
        payload.append((config.dsp_mem_control_ranging & 0xFF000000) >> 24)
        payload.append(config.dsp_mem_control_radar & 0x000000FF)
        payload.append((config.dsp_mem_control_radar & 0x0000FF00) >> 8)
        payload.append((config.dsp_mem_control_radar & 0x00FF0000) >> 16)
        payload.append((config.dsp_mem_control_radar & 0xFF000000) >> 24)
        payload += (
            [
                config.low_power_gpio_control & 0x00000000000000FF,
                (config.low_power_gpio_control & 0x000000000000FF00) >> 8,
                (config.low_power_gpio_control & 0x0000000000FF0000) >> 16,
                (config.low_power_gpio_control & 0x00000000FF000000) >> 24,
                (config.low_power_gpio_control & 0x000000FF00000000) >> 32,
                (config.low_power_gpio_control & 0x0000FF0000000000) >> 40,
                (config.low_power_gpio_control & 0x00FF000000000000) >> 48,
                (config.low_power_gpio_control & 0xFF00000000000000) >> 56,
            ]
            if isinstance(config.low_power_gpio_control, int)
            else config.low_power_gpio_control._get_bytes()
        )
        payload += (
            [
                config.low_power_ldo_controls & 0x000000FF,
                (config.low_power_ldo_controls & 0x0000FF00) >> 8,
                (config.low_power_ldo_controls & 0x00FF0000) >> 16,
                (config.low_power_ldo_controls & 0xFF000000) >> 24,
            ]
            if isinstance(config.low_power_ldo_controls, int)
            else config.low_power_ldo_controls._get_bytes()
        )
        payload += (
            [
                config.dpd_wakeuptimer_control & 0x00000000000000FF,
                (config.dpd_wakeuptimer_control & 0x000000000000FF00) >> 8,
                (config.dpd_wakeuptimer_control & 0x0000000000FF0000) >> 16,
                (config.dpd_wakeuptimer_control & 0x00000000FF000000) >> 24,
                (config.dpd_wakeuptimer_control & 0x000000FF00000000) >> 32,
                (config.dpd_wakeuptimer_control & 0x0000FF0000000000) >> 40,
                (config.dpd_wakeuptimer_control & 0x00FF000000000000) >> 48,
                (config.dpd_wakeuptimer_control & 0xFF00000000000000) >> 56,
            ]
            if isinstance(config.dpd_wakeuptimer_control, int)
            else config.dpd_wakeuptimer_control._get_bytes()
        )

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        power_management_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_POWER_MGMT_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return power_management_config_command.byte_stream

    # CMD_POWER_MGMT_CONFIG | INTERPRET PAYLOAD
    def interpret_power_management_config_command(payload: List[int]) -> PowerConfig:
        target_power_mode = PowerConfig.EnumTargetPowerMode(payload[0])
        config = PowerConfig(
            target_power_mode=PowerConfig.EnumTargetPowerMode(payload[0]),
            cpu_idle_mode=PowerConfig.EnumCpuIdleMode(payload[1]),
            baseband_power_control=PowerConfig.BasebandPowerControl(enable_baseband=bool(payload[2] & 1 << 0)),
            snapshot_control=PowerConfig.EnumSnapshotControl(payload[3]),
            cpu_mem_control=PowerConfig.CpuMemControl(
                _rfu=bool(payload[4] & 1 << 0),
                sram1_deep_sleep_enable=bool(payload[4] & 1 << 1),
                sram2_deep_sleep_enable=bool(payload[4] & 1 << 2),
                sram3_deep_sleep_enable=bool(payload[4] & 1 << 3),
                sram4_deep_sleep_enable=bool(payload[4] & 1 << 4),
                sram5_deep_sleep_enable=bool(payload[4] & 1 << 5),
            ),
            dsp_mem_control_ranging=PowerConfig.EnumDspMemControl(payload[8]),
            dsp_mem_control_radar=PowerConfig.EnumDspMemControl(payload[12]),
            low_power_gpio_control=PowerConfig.LowPowerGpioControl(
                target_power_mode=target_power_mode,
                pin_10_gpio_wakeup_enable=bool(payload[16] & 1 << 0),
                pin_11_gpio_wakeup_enable=bool(payload[16] & 1 << 1),
                pin_12_gpio_wakeup_enable=bool(payload[16] & 1 << 2),
                pin_13_gpio_wakeup_enable=bool(payload[16] & 1 << 3),
                pin_14_gpio_wakeup_enable=bool(payload[16] & 1 << 4),
                pin_15_gpio_wakeup_enable=bool(payload[16] & 1 << 5),
                pin_16_gpio_wakeup_enable=bool(payload[16] & 1 << 6),
                pin_17_gpio_wakeup_enable=bool(payload[16] & 1 << 7),
                pin_20_gpio_wakeup_enable=bool(payload[17] & 1 << 0),
                pin_21_gpio_wakeup_enable=bool(payload[17] & 1 << 1),
                pin_22_gpio_wakeup_enable=bool(payload[17] & 1 << 2),
                pin_23_gpio_wakeup_enable=bool(payload[17] & 1 << 3),
                pin_24_gpio_wakeup_enable=bool(payload[17] & 1 << 4),
                pin_25_gpio_wakeup_enable=bool(payload[17] & 1 << 5),
                pin_10_gpio_rising_edge_enable=bool(payload[20] & 1 << 0),
                pin_11_gpio_rising_edge_enable=bool(payload[20] & 1 << 1),
                pin_12_gpio_rising_edge_enable=bool(payload[20] & 1 << 2),
                pin_13_gpio_rising_edge_enable=bool(payload[20] & 1 << 3),
                pin_14_gpio_rising_edge_enable=bool(payload[20] & 1 << 4),
                pin_15_gpio_rising_edge_enable=bool(payload[20] & 1 << 5),
                pin_16_gpio_rising_edge_enable=bool(payload[20] & 1 << 6),
                pin_17_gpio_rising_edge_enable=bool(payload[20] & 1 << 7),
                pin_20_gpio_rising_edge_enable=bool(payload[21] & 1 << 0),
                pin_21_gpio_rising_edge_enable=bool(payload[21] & 1 << 1),
                pin_22_gpio_rising_edge_enable=bool(payload[21] & 1 << 2),
                pin_23_gpio_rising_edge_enable=bool(payload[21] & 1 << 3),
                pin_24_gpio_rising_edge_enable=bool(payload[21] & 1 << 4),
                pin_25_gpio_rising_edge_enable=bool(payload[21] & 1 << 5),
            )
            if target_power_mode == PowerConfig.EnumTargetPowerMode.DPD
            else PowerConfig.LowPowerGpioControl(
                target_power_mode=target_power_mode,
                pin_14_gpio_wakeup_enable=bool(payload[16] & 1 << 0),
                pin_17_gpio_wakeup_enable=bool(payload[16] & 1 << 1),
                pin_23_gpio_wakeup_enable=bool(payload[16] & 1 << 2),
            )
            if target_power_mode == PowerConfig.EnumTargetPowerMode.HPD
            else PowerConfig.LowPowerGpioControl(target_power_mode=target_power_mode),
            low_power_ldo_controls=PowerConfig.LowPowerLdoControls(
                target_power_mode=target_power_mode,
                current_limiter_mA_active=int.from_bytes(bytes=payload[24 : (27 + 1)], byteorder="little", signed=False),
            )
            if target_power_mode == PowerConfig.EnumTargetPowerMode.ACTIVE
            else PowerConfig.LowPowerLdoControls(
                target_power_mode=target_power_mode,
                baseband_retention_dpd_enable=bool(payload[24] & 1 << 0),
                cpu_retention_dpd_enable=bool(payload[24] & 1 << 1),
                cpu_retention_ldo_dpd_enable=bool(payload[24] & 1 << 2),
                current_limiter_mode_dpd=PowerConfig.LowPowerLdoControls.EnumCurrentLimiterMode((payload[24] & 3 << 3) >> 3),
                fro_selection_dpd=PowerConfig.LowPowerLdoControls.EnumFROSelectionDPD((payload[24] & 1 << 5) >> 5),
                wakeup_timer_dpd_enable=bool(payload[24] & 1 << 6),
            )
            if target_power_mode == PowerConfig.EnumTargetPowerMode.DPD
            else PowerConfig.LowPowerLdoControls(
                target_power_mode=target_power_mode,
                current_limiter_hpd_enable=bool(payload[24] & 1 << 0),
            )
            if target_power_mode == PowerConfig.EnumTargetPowerMode.HPD
            else PowerConfig.LowPowerLdoControls(target_power_mode=target_power_mode),
            dpd_wakeuptimer_control=PowerConfig.DpdWakeuptimerControl(
                target_power_mode=target_power_mode,
                wakeup_timer_ticks=int.from_bytes(bytes=payload[28 : (31 + 1)], byteorder="little", signed=False),
                timer_calibration_enable=bool(payload[32] & 1 << 0),
            )
            if target_power_mode == PowerConfig.EnumTargetPowerMode.DPD
            else PowerConfig.LowPowerLdoControls(target_power_mode=target_power_mode),
        )
        return config

    # CMD_ACTIVATE_SWUP
    @staticmethod
    def activate_swup(config: ActivateSwup) -> List[int]:
        payload = []
        payload.append(config.swup_mode & 0xFF)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        power_management_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_PROPRIETARY,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_ACTIVATE_SWUP,
            payload_length=len(payload),
            payload=payload,
        )

        return power_management_config_command.byte_stream

    # CMD_ACTIVATE_SWUP | INTERPRET PAYLOAD
    def interpret_activate_swup_command(payload: List[int]) -> ActivateSwup:
        config = ActivateSwup(swup_mode=ActivateSwup.EnumSwupMode(payload[0]))
        return config

    # CMD_GENERIC_BASEBAND_CONFIG
    @staticmethod
    def generic_baseband_config(config: BasebandConfiguration) -> List[int]:
        payload = []
        payload.append(config.configuration_select)
        payload.append(config.configuration_index)
        for i in config.configuration_data:
            payload.append(i)
        length = 2 + len(config.configuration_data)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        generic_baseband_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GENERIC_BASEBAND_CONFIG,
            payload_length=length,
            payload=payload,
        )

        return generic_baseband_config_command.byte_stream

    # CMD_GENERIC_BASEBAND_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_generic_baseband_config_command(payload: List[int]) -> BasebandConfiguration:
        match BasebandConfiguration.ConfigurationSelect(payload[0]):
            case BasebandConfiguration.ConfigurationSelect.RX_RADIO_CONFIGURATION:
                data = BasebandConfiguration.RxRadioConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_DIGITAL_FRONTEND_CONFIGURATION:
                data = BasebandConfiguration.RxDigitalFrontendConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_PAYLOAD_CONFIGURATION:
                data = BasebandConfiguration.RxPayloadConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_RANGING_CONTROL_CONFIGURATION:
                data = BasebandConfiguration.RxRangingControlConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_ANTENNA_CONFIGURATION:
                data = BasebandConfiguration.RxAntennaConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.TX_RADIO_CONFIGURATION:
                data = BasebandConfiguration.TxRadioConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.TX_POWER_CONFIGURATION:
                data = BasebandConfiguration.TxPowerConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.TX_PAYLOAD_CONFIGURATION:
                data = BasebandConfiguration.TxPayloadConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.TX_DDFS_CONFIGURATION:
                data = BasebandConfiguration.TxDdfsConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.TX_RANGING_CONTROL_CONFIGURATION:
                data = BasebandConfiguration.TxRangingControlConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.SYNC_CODE_CONFIGURATION:
                data = BasebandConfiguration.SyncCodeConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.STS_CONFIGURATION:
                data = BasebandConfiguration.StsConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.COMMAND_CONFIGURATION:
                data = BasebandConfiguration.CommandConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.SFD_CONFIGURATION:
                data = BasebandConfiguration.SfdConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_RADAR_CIR_CONFIGURATION:
                data = BasebandConfiguration.RxRadarCirConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_RADAR_CONTROL_CONFIGURATION:
                data = BasebandConfiguration.RxRadarControlConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.TX_RADAR_CONTROL_CONFIGURATION:
                data = BasebandConfiguration.TxRadarControlConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RX_RADAR_CALIBRATION_DATA:
                data = BasebandConfiguration.RxRadarCalibrationData._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.RADAR_NOISE_SUPPRESSION_CONFIGURATION:
                data = BasebandConfiguration.RadarNoiseSuppressionConfiguration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.PERFORM_AGC_CALIBRATION:
                data = BasebandConfiguration.PerformAgcCalibration._get_results()  # no payload
            case BasebandConfiguration.ConfigurationSelect.PLL_RECALIBRATION:
                data = BasebandConfiguration.PllRecalibration._get_results(payload[2:])
            case BasebandConfiguration.ConfigurationSelect.CALLBACK_CONFIGURATION:
                data = BasebandConfiguration.CallbackConfiguration._get_results(payload[2:])
            case _:
                pass

        config = BasebandConfiguration(
            configuration_select=BasebandConfiguration.ConfigurationSelect(payload[0]), configuration_index=payload[1], configuration_data=data
        )
        return config

    # CMD_CLOCK_MGMT_CONFIG
    @staticmethod
    def clock_management_config(config: ClockConfig) -> List[int]:
        payload = []
        payload.append((int(config.clock_source_select_input_pin_enable) & 0x01) | ((int(config.clock_source_select_gppll_enable) & 0x01) << 1))
        payload.append(config.clock_pin_signal_source_select & 0xFF)
        payload.append(config.clock_pin_frequency_config & 0xFF)
        payload.append(config.clock_division_factor_config & 0xFF)
        payload.append(config.clock_out_p24 & 0xFF)
        payload.append(config.clock_cpu_source_select & 0xFF)
        payload.append(config.clock_out_xo_out & 0xFF)
        payload.append(config.clock_out_p13 & 0xFF)
        payload.append(config.can_clock_source & 0xFF)
        payload.append(config.xtal_bias_os & 0xFF)
        payload.append(config.c_load_pF & 0x000000FF)
        payload.append((config.c_load_pF & 0x0000FF00) >> 8)
        payload.append((config.c_load_pF & 0x00FF0000) >> 16)
        payload.append((config.c_load_pF & 0xFF000000) >> 24)
        payload.append(config.sys_tick_sel_timer & 0x000000FF)
        payload.append((config.sys_tick_sel_timer & 0x0000FF00) >> 8)
        payload.append((config.sys_tick_sel_timer & 0x00FF0000) >> 16)
        payload.append((config.sys_tick_sel_timer & 0xFF000000) >> 24)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        clock_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_CLOCK_MGMT_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return clock_config_command.byte_stream

    # CMD_CLOCK_MGMT_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_clock_management_config_command(payload: List[int]) -> ClockConfig:
        config = ClockConfig(
            clock_source_select_input_pin_enable=bool(payload[0] & 0x01 | payload[0] & 0x03),
            clock_source_select_gppll_enable=bool(payload[0] & 0x02 | payload[0] & 0x03),
            clock_pin_signal_source_select=ClockConfig.EnumClockPinSignalSource(payload[1]),
            clock_pin_frequency_config=ClockConfig.EnumClockPinFrequency(payload[2]),
            clock_division_factor_config=ClockConfig.EnumClockDivisionFactor(payload[3]),
            clock_out_p24=ClockConfig.EnumOutputP24(payload[4]),
            clock_cpu_source_select=ClockConfig.EnumClockCpuSource(payload[5]),
            clock_out_xo_out=ClockConfig.EnumOutputP33(payload[6]),
            clock_out_p13=ClockConfig.EnumOutputP13(payload[7]),
            can_clock_source=ClockConfig.EnumCanClockSource(payload[8]),
            xtal_bias_on=bool(payload[9]),
            c_load_pF=int.from_bytes(bytes=payload[10:14], byteorder="little", signed=False),
            sys_tick_sel_timer=ClockConfig.EnumSysTickSel(int.from_bytes(bytes=payload[14:18], byteorder="little", signed=False)),
        )
        return config

    # NTF_CLOCK_MGMT
    @staticmethod
    def interpret_clock_management_notification(payload: List[int]) -> ClockManagementNotification:
        result = ClockManagementNotification(
            status=payload[0],
            event_type=int.from_bytes(bytes=payload[1:5], byteorder="little", signed=False),
            additional_info=int.from_bytes(bytes=payload[5:9], byteorder="little", signed=False),
        )
        return result

    # CMD_PIN_TOGGLE_CONFIG
    @staticmethod
    def pin_toggle_config(config: PinConfig) -> List[int]:
        payload = []
        payload.append(
            (config.operation_trigger & 0xFF) if isinstance(config.operation_trigger, int) else (config.operation_trigger._get_int() & 0xFF)
        )
        payload.append(config.baseband_debug_dmux_select_set & 0xFF)
        payload.append(
            (config.baseband_debug_out_pin_select & 0xFF)
            if isinstance(config.baseband_debug_out_pin_select, int)
            else (config.baseband_debug_out_pin_select._get_int() & 0xFF)
        )
        payload.append(config.sync_out_pin & 0xFF)
        payload += (
            [
                (config.operation_indication_select & 0x000000FF),
                ((config.operation_indication_select & 0x0000FF00) >> 8),
                ((config.operation_indication_select & 0x00FF0000) >> 16),
                ((config.operation_indication_select & 0xFF000000) >> 24),
            ]
            if isinstance(config.operation_indication_select, int)
            else [
                (config.operation_indication_select._get_int() & 0x000000FF),
                ((config.operation_indication_select._get_int() & 0x0000FF00) >> 8),
                ((config.operation_indication_select._get_int() & 0x00FF0000) >> 16),
                ((config.operation_indication_select._get_int() & 0xFF000000) >> 24),
            ]
        )
        payload += config.sync_out_delay_us.to_bytes(length=4, byteorder="little", signed=False)
        payload += config._rfu2

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        pin_toggle_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_PIN_TOGGLE_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return pin_toggle_config_command.byte_stream

    # CMD_PIN_TOGGLE_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_pin_toggle_config_command(payload: List[int]) -> PinConfig:
        config = PinConfig(
            operation_trigger=PinConfig.OperationTrigger(
                baseband_trigger_enable=bool(payload[0] & 1 << 0),
                baseband_trigger_radar_enable=bool(payload[0] & 1 << 1),
                baseband_trigger_ranging_enable=bool(payload[0] & 1 << 2),
                sync_in_enable=bool(payload[0] & 1 << 3),
            ),
            baseband_debug_dmux_select_set=payload[1],
            baseband_debug_out_pin_select=PinConfig.BasebandDebugOutPinSelect(
                p12_output_enable=bool(payload[2] & 1 << 0),
                p13_output_enable=bool(payload[2] & 1 << 1),
                p14_output_enable=bool(payload[2] & 1 << 2),
                p15_output_enable=bool(payload[2] & 1 << 3),
                p16_output_enable=bool(payload[2] & 1 << 4),
                p17_output_enable=bool(payload[2] & 1 << 5),
            ),
            sync_out_pin=PinConfig.EnumSyncOutPin(payload[3]),
            operation_indication_select=PinConfig.OperationIndicationSelect(
                start_baseband_indicator=bool(payload[4] & 1 << 0),
                baseband_idle_callback_indicator=bool(payload[4] & 1 << 1),
                baseband_ready_callback_indicator=bool(payload[4] & 1 << 2),
                baseband_active_callback_indicator=bool(payload[4] & 1 << 3),
                rxdone_callback_indicator=bool(payload[4] & 1 << 4),
                txdone_callback_indicator=bool(payload[4] & 1 << 5),
                dsp_image_loading_success_indicator=bool(payload[4] & 1 << 6),
                crypto_operation_start_end_indicator=bool(payload[4] & 1 << 7),
                main_application_entry_point_indicator=bool(payload[5] & 1 << 0),
                change_in_device_power_state=bool(payload[5] & 1 << 1),
                change_in_cmd_activate_swup=bool(payload[5] & 1 << 2),
            ),
            sync_out_delay_us=int.from_bytes(bytes=payload[8:13], byteorder="little", signed=False),
        )
        return config

    # CMD_GPADC_OPERATION
    @staticmethod
    def gpadc_operation(config: GpAdcConfig) -> List[int]:
        payload = []
        payload.append(int(config.gpadc_operation) & 0xFF)
        payload.append(int(config.measurement_type) & 0xFF)
        temperature = GpAdcConfig._temperature_to_bytes(config.over_temp_threshold)
        payload.append(temperature[0])
        payload.append(temperature[1])
        temperature = GpAdcConfig._temperature_to_bytes(config.under_temp_threshold)
        payload.append(temperature[0])
        payload.append(temperature[1])
        temperature = GpAdcConfig._temperature_to_bytes(config.warn_temp_threshold)
        payload.append(temperature[0])
        payload.append(temperature[1])
        payload.append(
            (config.result_ntf_enbl & 0xFF)
            if isinstance(config.result_ntf_enbl, int)
            else (
                ((int(config.result_ntf_enbl.over_temp_ntf) & 1) << 0)
                | ((int(config.result_ntf_enbl.under_temp_ntf) & 1) << 1)
                | ((int(config.result_ntf_enbl.warn_temp_ntf) & 1) << 2)
            )
        )

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        gpadc_operation_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GPADC_OPERATION,
            payload_length=len(payload),
            payload=payload,
        )

        return gpadc_operation_command.byte_stream

    # CMD_GPADC_OPERATION | INTERPRET PAYLOAD
    @staticmethod
    def interpret_gpadc_operation_command(payload: List[int]) -> GpAdcConfig:
        config = GpAdcConfig(
            gpadc_operation=GpAdcConfig.EnumGpAdcOperation(payload[0]),
            measurement_type=GpAdcConfig.EnumMeasurementType(payload[1]),
            over_temp_threshold=GpAdcConfig._bytes_to_temperature(bytes=payload[2 : (3 + 1)]),
            under_temp_threshold=GpAdcConfig._bytes_to_temperature(bytes=payload[4 : (5 + 1)]),
            warn_temp_threshold=GpAdcConfig._bytes_to_temperature(bytes=payload[6 : (7 + 1)]),
            result_ntf_enbl=GpAdcConfig.ResultNtfEnbl(
                over_temp_ntf=bool(payload[8] & 1 << 0), under_temp_ntf=bool(payload[8] & 1 << 1), warn_temp_ntf=bool(payload[8] & 1 << 2)
            ),
        )
        return config

    # RSP_GPADC_OPERATION
    @staticmethod
    def interpret_gpadc_operation_response(payload: List[int]) -> GpAdcResults:
        results = GpAdcResults(
            gpadc_result_0=GpAdcResults.GpAdcResult(
                offset_error=(payload[0]) | (payload[1] << 8),
                adc_value=(payload[2]) | (payload[3] << 8),
            ),
            gpadc_result_1=GpAdcResults.GpAdcResult(
                offset_error=(payload[4]) | (payload[5] << 8),
                adc_value=(payload[6]) | (payload[7] << 8),
            ),
        )
        return results

    # NTF_GPADC_OPERATION
    @staticmethod
    def interpret_gpadc_result_notification(payload: List[int]) -> GpAdcNotificationResult:
        results = GpAdcNotificationResult(
            threshold_status=GpAdcNotificationResult.ThresholdStatus(
                over_temp_threshold_reached=bool(payload[0] & (1 << 0)),
                under_temp_threshold_reached=bool(payload[0] & (1 << 1)),
                warn_temp_threshold_reached=bool(payload[0] & (1 << 2)),
            ),
            gpadc_result=GpAdcResults.GpAdcResult(offset_error=(payload[1]) | (payload[2] << 8), adc_value=(payload[3]) | (payload[4] << 8)),
        )
        return results

    # NTF_BASEBAND_STATUS
    @staticmethod
    def interpret_baseband_status_notification(payload: List[int], center_frequency_khz: float = 7987200) -> BasebandStatusNotification:
        index = 4

        def extract_int(size: int) -> int:
            nonlocal index
            value = int.from_bytes(payload[index : index + size], byteorder="little")
            index += size
            return value

        def extract_results(cls, size: int, *args):
            nonlocal index
            result = cls._get_results(payload[index : index + size], *args)
            index += size
            return result

        results = BasebandStatusNotification(
            status=EnumUciStatus(payload[0]),
            baseband_status=extract_results(BasebandResults.BasebandStatus, 12),
            cfo_results=extract_results(BasebandResults.CfoResults, 4, center_frequency_khz),
            rx1_nbic_results=extract_results(BasebandResults.NbicResults, 4),
            rx2_nbic_results=extract_results(BasebandResults.NbicResults, 4),
            rx1_agc_gain_results_db=extract_int(4),
            rx2_agc_gain_results_db=extract_int(4),
            timestamp_results_0=extract_results(BasebandResults.TimestampResults, 12),
            timestamp_results_1=extract_results(BasebandResults.TimestampResults, 12),
            timestamp_results_2=extract_results(BasebandResults.TimestampResults, 12),
            rx1_firstpath_results_res_index_0=extract_results(BasebandResults.FirstpathResults, 20),
            rx1_firstpath_results_res_index_1=extract_results(BasebandResults.FirstpathResults, 20),
            rx1_firstpath_results_res_index_2=extract_results(BasebandResults.FirstpathResults, 20),
            rx1_firstpath_results_res_index_3=extract_results(BasebandResults.FirstpathResults, 20),
            rx1_firstpath_results_res_index_4=extract_results(BasebandResults.FirstpathResults, 20),
            rx2_firstpath_results_res_index_0=extract_results(BasebandResults.FirstpathResults, 20),
            rx2_firstpath_results_res_index_1=extract_results(BasebandResults.FirstpathResults, 20),
            rx2_firstpath_results_res_index_2=extract_results(BasebandResults.FirstpathResults, 20),
            rx2_firstpath_results_res_index_3=extract_results(BasebandResults.FirstpathResults, 20),
            rx2_firstpath_results_res_index_4=extract_results(BasebandResults.FirstpathResults, 20),
            pdoa_results_res_index_0=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_1=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_2=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_3=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_4=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_5=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_6=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_7=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_8=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_9=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_10=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_11=extract_results(BasebandResults.PdoaResults, 4),
            pdoa_results_res_index_12=extract_results(BasebandResults.PdoaResults, 4),
            rx_payload_data_configuration=extract_results(BasebandResults.RXPayloadDataConfig, len(payload) - index),
        )
        return results

    # CMD_GET_RADIO_CONFIG_VERSION
    @staticmethod
    def get_radio_config_version(config: GetRadioConfigConfigVersion) -> List[int]:
        payload = []
        payload.append((config.configuration_index & 0x0F) | ((config.configuration_type & 0x0F) << 4))

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        get_radio_cnf_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GET_RADIO_CONFIG_VERSION,
            payload_length=len(payload),
            payload=payload,
        )

        return get_radio_cnf_command.byte_stream

    # CMD_GET_RADIO_CONFIG_VERSION | INTERPRET PAYLOAD
    @staticmethod
    def interpret_get_radio_config_version_command(payload: List[int]) -> GetRadioConfigConfigVersion:
        config = GetRadioConfigConfigVersion(
            configuration_index=payload[0] & 0x0F, configuration_type=GetRadioConfigConfigVersion.EnumConfiguration(payload[0] >> 4)
        )
        return config

    # RSP_GET_RADIO_CONFIG_VERSION
    @staticmethod
    def interpret_get_radio_config_version_response(payload: List[int]) -> RadioConfigVersion:
        version = RadioConfigVersion(
            radio_cnf_major_version=(payload[5 - 5] | (payload[6 - 5] << 8) | (payload[7 - 5] << 16) | (payload[8 - 5] << 24)),
            radio_cnf_minor_version=(payload[9 - 5] | (payload[10 - 5] << 8) | (payload[11 - 5] << 16) | (payload[12 - 5] << 24)),
            radio_cnf_patch_version=(payload[13 - 5] | (payload[14 - 5] << 8) | (payload[15 - 5] << 16) | (payload[16 - 5] << 24)),
            radio_cnf_version_id=(payload[17 - 5] | (payload[18 - 5] << 8) | (payload[19 - 5] << 16) | (payload[20 - 5] << 24)),
        )

        return version

    # CMD_SET_BITFIELD
    @staticmethod
    def set_bitfield(config: SetBitfieldConfig) -> List[int]:
        payload = []
        payload.append(config.address & 0x000000FF)
        payload.append((config.address & 0x0000FF00) >> 8)
        payload.append((config.address & 0x00FF0000) >> 16)
        payload.append((config.address & 0xFF000000) >> 24)
        payload.append(config.offset & 0xFF)
        payload.append(config.width & 0xFF)
        payload.append(config.value & 0x000000FF)
        payload.append((config.value & 0x0000FF00) >> 8)
        payload.append((config.value & 0x00FF0000) >> 16)
        payload.append((config.value & 0xFF000000) >> 24)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        set_bitfield_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_SET_BITFIELD,
            payload_length=len(payload),
            payload=payload,
        )

        return set_bitfield_command.byte_stream

    # CMD_SET_BITFIELD | INTERPRET PAYLOAD
    @staticmethod
    def interpret_set_bitfield_command(payload: List[int]) -> SetBitfieldConfig:
        config = SetBitfieldConfig(
            address=int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False),
            offset=payload[4],
            width=payload[5],
            value=int.from_bytes(bytes=payload[6 : (9 + 1)], byteorder="little", signed=False),
        )
        return config

    # CMD_GET_BITFIELD
    @staticmethod
    def get_bitfield(config: GetBitfieldConfig) -> List[int]:
        payload = []
        payload.append(config.address & 0x000000FF)
        payload.append((config.address & 0x0000FF00) >> 8)
        payload.append((config.address & 0x00FF0000) >> 16)
        payload.append((config.address & 0xFF000000) >> 24)
        payload.append(config.offset & 0xFF)
        payload.append(config.width & 0xFF)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        get_bitfield_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GET_BITFIELD,
            payload_length=len(payload),
            payload=payload,
        )

        return get_bitfield_command.byte_stream

    # CMD_GET_BITFIELD | INTERPRET PAYLOAD
    @staticmethod
    def interpret_get_bitfield_command(payload: List[int]) -> GetBitfieldConfig:
        config = GetBitfieldConfig(
            address=int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False), offset=payload[4], width=payload[5]
        )
        return config

    # RSP_GET_BITFIELD
    @staticmethod
    def interpret_get_bitfield_response(payload: List[int]) -> int:
        bitfield = payload[5 - 5] | (payload[6 - 5] << 8) | (payload[7 - 5] << 16) | (payload[8 - 5] << 24)

        return bitfield

    # CMD_ECHO_REV_PAYLOAD
    @staticmethod
    def echo_rev_payload(input_payload: List[int]) -> List[int]:
        payload = []
        length = len(input_payload)
        for i in range(length):
            payload.append(input_payload[i] & 0xFF)
        # Pad the payload if it is shorter than 4 bytes
        if length < 4:
            for i in range(4 - length):
                payload.append(0x00)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        echo_rev_payload_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_ECHO_REV_PAYLOAD,
            payload_length=len(payload),
            payload=payload,
        )

        return echo_rev_payload_command.byte_stream

    # CMD_ECHO_REV_PAYLOAD | INTERPRET PAYLOAD
    def interpret_echo_rev_payload_command(payload: List[int]) -> List[int]:
        return payload

    # RSP_ECHO_REV_PAYLOAD
    @staticmethod
    def interpret_echo_rev_payload_response(payload: List[int]) -> List[int]:
        return payload

    # CMD_RX_RADIO_CONFIG
    @staticmethod
    def rx_radio_config(config: RXRadioConfig) -> List[int]:
        payload = []
        payload.append(config.configuration_index & 0xFF)
        length = len(config.rx_radio_config_data)
        for i in range(length):
            payload.append(config.rx_radio_config_data[i] & 0xFF)
        # Pad the payload if it is shorter than 1024 bytes
        if length < 1024:
            for i in range(1024 - length):
                payload.append(0x00)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        rx_radio_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RX_RADIO_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return rx_radio_config_command.byte_stream

    # CMD_RX_RADIO_CONFIG | INTERPRET PAYLOAD
    def interpret_rx_radio_config_command(payload: List[int]) -> RXRadioConfig:
        config = RXRadioConfig(configuration_index=payload[0], rx_radio_config_data=payload[1:])
        return config

    # CMD_TX_RADIO_CONFIG
    @staticmethod
    def tx_radio_config(config: TXRadioConfig) -> List[int]:
        payload = []
        payload.append(config.configuration_index & 0xFF)
        length = len(config.tx_radio_config_data)
        for i in range(length):
            payload.append(config.tx_radio_config_data[i] & 0xFF)
        # Pad the payload if it is shorter than 512 bytes
        if length < 512:
            for i in range(512 - length):
                payload.append(0x00)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        tx_radio_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_TX_RADIO_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return tx_radio_config_command.byte_stream

    # CMD_TX_RADIO_CONFIG | INTERPRET PAYLOAD
    def interpret_tx_radio_config_command(payload: List[int]) -> TXRadioConfig:
        config = TXRadioConfig(configuration_index=payload[0], tx_radio_config_data=payload[1:])
        return config

    # CMD_RANGING_PAYLOAD_CONFIG
    @staticmethod
    def ranging_payload_config(config: RangingPayloadConfig) -> List[int]:
        payload = []
        payload.append(config.payload_index & 0xFF)
        payload.append((int(config.ranging_payload_ctrl_crc_enable) & 0x01) | ((config.ranging_payload_ctrl_crc_type & 0x01) << 1))
        payload.append(config.ranging_payload_length & 0xFF)

        length = len(config.payload_data)
        for i in range(length):
            payload.append(config.payload_data[i] & 0xFF)
        if length == 0:
            payload.append(0x00)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        ranging_payload_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RANGING_PAYLOAD_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return ranging_payload_command.byte_stream

    # CMD_RANGING_PAYLOAD_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_ranging_payload_config_command(payload: List[int]) -> RangingPayloadConfig:
        config = RangingPayloadConfig(
            payload_index=payload[0],
            ranging_payload_ctrl_crc_enable=bool(payload[1] & 1 << 0),
            ranging_payload_ctrl_crc_type=RangingPayloadConfig.EnumCrcType(int(bool(payload[1] & 1 << 1))),
            ranging_payload_length=payload[2],
            ranging_payload_data=payload[3:],
        )
        return config

    # CMD_RANGING_APPLICATION_CONFIG
    @staticmethod
    def ranging_application_config(config: RangingApplicationConfig) -> List[int]:
        payload = []
        payload.append(config.uwb_channel_frequency_khz & 0x000000FF)
        payload.append((config.uwb_channel_frequency_khz & 0x0000FF00) >> 8)
        payload.append((config.uwb_channel_frequency_khz & 0x00FF0000) >> 16)
        payload.append((config.uwb_channel_frequency_khz & 0xFF000000) >> 24)
        payload += config._ppm_to_bytes(config.ppm)
        payload.append(config.keep_syspll & 0xFF)
        payload.append(int(config.notification_sel_enable))
        payload.append(config.ranging_repeat_cnt & 0x000000FF)
        payload.append((config.ranging_repeat_cnt & 0x0000FF00) >> 8)
        payload.append((config.ranging_repeat_cnt & 0x00FF0000) >> 16)
        payload.append((config.ranging_repeat_cnt & 0xFF000000) >> 24)
        payload.append(config.ranging_repeat_interval_us & 0x000000FF)
        payload.append((config.ranging_repeat_interval_us & 0x0000FF00) >> 8)
        payload.append((config.ranging_repeat_interval_us & 0x00FF0000) >> 16)
        payload.append((config.ranging_repeat_interval_us & 0xFF000000) >> 24)
        payload.append(config.rx_start_margin_us & 0x000000FF)
        payload.append((config.rx_start_margin_us & 0x0000FF00) >> 8)
        payload.append((config.rx_start_margin_us & 0x00FF0000) >> 16)
        payload.append((config.rx_start_margin_us & 0xFF000000) >> 24)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        ranging_application_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RANGING_APPLICATION_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return ranging_application_command.byte_stream

    # CMD_RANGING_APPLICATION_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_ranging_application_config_command(payload: List[int]) -> RangingApplicationConfig:
        config = RangingApplicationConfig(
            uwb_channel_frequency_khz=int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False),
            ppm=(int.from_bytes(bytes=payload[4 : (5 + 1)], byteorder="little", signed=True)) / 10,
            keep_syspll=RangingApplicationConfig.EnumKeepSysPll(payload[6]),
            notification_sel_enable=bool(payload[7]),
            ranging_repeat_cnt=int.from_bytes(bytes=payload[8 : (11 + 1)], byteorder="little", signed=False),
            ranging_repeat_interval_us=int.from_bytes(bytes=payload[12 : (15 + 1)], byteorder="little", signed=False),
            rx_start_margin_us=int.from_bytes(bytes=payload[16 : (19 + 1)], byteorder="little", signed=False),
        )
        return config

    # CMD_RANGING_SEQUENCE_CONFIG
    @staticmethod
    def ranging_sequence_config(ranging_sequence: List[RangingCommand]) -> List[int]:
        payload = []
        for i in range(len(ranging_sequence)):
            payload.append(ranging_sequence[i].ranging_action & 0xFF)
            payload.append(ranging_sequence[i].ranging_slot_select & 0xFF)
            payload.append(ranging_sequence[i].delay_us & 0x000000FF)
            payload.append((ranging_sequence[i].delay_us & 0x0000FF00) >> 8)
            payload.append((ranging_sequence[i].delay_us & 0x00FF0000) >> 16)
            payload.append((ranging_sequence[i].delay_us & 0xFF000000) >> 24)
            timeout = ranging_sequence[i]._ns_to_int(ranging_sequence[i].timeout_ns)
            payload.append(timeout & 0x000000FF)
            payload.append((timeout & 0x0000FF00) >> 8)
            payload.append((timeout & 0x00FF0000) >> 16)
            payload.append((timeout & 0xFF000000) >> 24)
            payload.append(ranging_sequence[i].psdu_select & 0xFF)
            payload.append(ranging_sequence[i].psdu_buffer_index_select & 0xFF)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        ranging_sequence_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RANGING_SEQUENCE_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return ranging_sequence_command.byte_stream

    # CMD_RANGING_SEQUENCE_CONFIG | INTERPRET PAYLOAD
    @staticmethod
    def interpret_ranging_sequence_config_command(payload: List[int]) -> List[RangingCommand]:
        config = []
        COMMAND_LENGTH = 12
        command_count = int(len(payload) / COMMAND_LENGTH)
        for command_index in range(command_count):
            byte_offset = command_index * COMMAND_LENGTH
            config.append(
                RangingCommand(
                    ranging_action=RangingCommand.EnumRangingAction(payload[byte_offset]),
                    ranging_slot_select=payload[byte_offset + 1],
                    delay_us=int.from_bytes(bytes=payload[(byte_offset + 2) : (byte_offset + 5 + 1)], byteorder="little", signed=False),
                    timeout_ns=RangingCommand._int_to_ns(
                        int.from_bytes(bytes=payload[(byte_offset + 6) : (byte_offset + 9 + 1)], byteorder="little", signed=False)
                    ),
                    psdu_select=RangingCommand.EnumPSDUSel(payload[byte_offset + 10]),
                    psdu_buffer_index_select=payload[byte_offset + 11],
                )
            )
        return config

    # CMD_START_RANGING
    @staticmethod
    def start_ranging() -> List[int]:
        payload = []

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        start_radar_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_START_RANGING,
            payload_length=len(payload),
            payload=payload,
        )

        return start_radar_command.byte_stream

    # NTF_RANGING_STATUS
    @staticmethod
    def interpret_ranging_status_notification(payload: List[int]) -> RangingStatus:
        status = RangingStatus(ranging_status=RangingStatus.EnumRangingStatus(payload[0]))
        return status

    # CMD_GET_RANGING_PAYLOAD
    @staticmethod
    def get_ranging_payload(payload_index: int) -> List[int]:
        payload = []
        payload.append(payload_index & 0xFF)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        get_ranging_payload_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_GET_RANGING_PAYLOAD,
            payload_length=len(payload),
            payload=payload,
        )

        return get_ranging_payload_command.byte_stream

    # CMD_GET_RANGING_PAYLOAD | INTERPRET PAYLOAD
    @staticmethod
    def interpret_get_ranging_payload_command(payload: List[int]) -> str:
        # return f"payload_index: {'0x{:02x}'.format(payload[0])} ({payload[0]})"
        return payload[0]

    # RSP_GET_RANGING_PAYLOAD
    @staticmethod
    def interpret_get_ranging_payload_response(payload: List[int]) -> RangingPayload:
        payload_data = RangingPayload(
            ranging_payload_control=payload[5 - 5], ranging_payload_length=payload[6 - 5], ranging_payload_data=payload[7 - 5 :]
        )
        return payload_data

    # CMD_RADAR_APPLICATION_CONFIG
    @staticmethod
    def radar_application_config(config: RadarConfig) -> List[int]:
        payload = []
        payload.append(config.uwb_channel_frequency_khz & 0x000000FF)
        payload.append((config.uwb_channel_frequency_khz & 0x0000FF00) >> 8)
        payload.append((config.uwb_channel_frequency_khz & 0x00FF0000) >> 16)
        payload.append((config.uwb_channel_frequency_khz & 0xFF000000) >> 24)
        payload += config._ppm_to_bytes(config.ppm)
        payload.append(config.keep_syspll & 0xFF)
        payload.append(config.radar_syspll_mode & 0xFF)
        payload.append(config.init_delay_us & 0x000000FF)
        payload.append((config.init_delay_us & 0x0000FF00) >> 8)
        payload.append((config.init_delay_us & 0x00FF0000) >> 16)
        payload.append((config.init_delay_us & 0xFF000000) >> 24)
        payload.append(config.radar_mode & 0xFF)
        payload.append(config.rx_radar_control_config_index & 0xFF)
        payload.append(config.tx_radar_control_config_index & 0xFF)
        payload.append(config.notification_enable & 0xFF)
        payload.append(config.frame_count & 0x000000FF)
        payload.append((config.frame_count & 0x0000FF00) >> 8)
        payload.append((config.frame_count & 0x00FF0000) >> 16)
        payload.append((config.frame_count & 0xFF000000) >> 24)
        frame_interval = config._ns_to_int(config.frame_interval_ns)
        payload.append(frame_interval & 0x000000FF)
        payload.append((frame_interval & 0x0000FF00) >> 8)
        payload.append((frame_interval & 0x00FF0000) >> 16)
        payload.append((frame_interval & 0xFF000000) >> 24)
        payload.append(config.burst_count & 0x000000FF)
        payload.append((config.burst_count & 0x0000FF00) >> 8)
        payload.append((config.burst_count & 0x00FF0000) >> 16)
        payload.append((config.burst_count & 0xFF000000) >> 24)
        burst_delay = config._ns_to_int(config.burst_delay_ns)
        payload.append(burst_delay & 0x000000FF)
        payload.append((burst_delay & 0x0000FF00) >> 8)
        payload.append((burst_delay & 0x00FF0000) >> 16)
        payload.append((burst_delay & 0xFF000000) >> 24)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        application_config_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_RADAR_APPLICATION_CONFIG,
            payload_length=len(payload),
            payload=payload,
        )

        return application_config_command.byte_stream

    # CMD_RADAR_APPLICATION_CONFIG | INTERPRET CONFIG
    @staticmethod
    def interpret_radar_application_config_command(payload: List[int]) -> RadarConfig:
        config = RadarConfig(
            uwb_channel_frequency_khz=int.from_bytes(bytes=payload[0 : (3 + 1)], byteorder="little", signed=False),
            ppm=(int.from_bytes(bytes=payload[4 : (5 + 1)], byteorder="little", signed=True)) / 10,
            keep_syspll=RadarConfig.EnumKeepSysPll(payload[6]),
            radar_syspll_mode=RadarConfig.EnumRadarSysPllMode(payload[7]),
            init_delay_us=int.from_bytes(bytes=payload[8 : (11 + 1)], byteorder="little", signed=False),
            radar_mode=RadarConfig.EnumRadarMode(payload[12]),
            rx_radar_control_config_index=RadarConfig.EnumRadarControlConfigurationIndex(payload[13]),
            tx_radar_control_config_index=RadarConfig.EnumRadarControlConfigurationIndex(payload[14]),
            notification_enable=RadarConfig.EnumNotificationEnable(payload[15]),
            frame_count=int.from_bytes(bytes=payload[16 : (19 + 1)], byteorder="little", signed=False),
            frame_interval_ns=RadarConfig._int_to_ns(int.from_bytes(bytes=payload[20 : (23 + 1)], byteorder="little", signed=False)),
            burst_count=int.from_bytes(bytes=payload[24 : (27 + 1)], byteorder="little", signed=False),
            burst_delay_ns=RadarConfig._int_to_ns(int.from_bytes(bytes=payload[28 : (31 + 1)], byteorder="little", signed=False)),
        )
        return config

    # CMD_START_RADAR
    @staticmethod
    def start_radar() -> List[int]:
        payload = []

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        start_radar_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_START_RADAR,
            payload_length=len(payload),
            payload=payload,
        )

        return start_radar_command.byte_stream

    # NTF_RADAR_RESULT
    @staticmethod
    def interpret_radar_result_notification(payload: List[int]) -> RadarResult:
        cir_taps = []
        cir_taps_bytes = []
        # cir taps start at byte 24. One tap is 4 bytes large and we need to account for the header of 4 bytes
        for i in range((24 - 4), len(payload) - 2, 4):
            tap = complex(
                real=int.from_bytes(bytes=payload[i : i + 2], byteorder="little", signed=True),
                imag=int.from_bytes(bytes=payload[i + 2 : i + 4], byteorder="little", signed=True),
            )
            cir_taps_bytes += payload[i : i + 4]
            cir_taps.append(tap)

        radarResults = RadarResult(status=RadarResult.EnumStatus(payload[4 - 4]), cir_data=None)

        if len(payload) > 1:
            radarResults.cir_data = CirData(
                antenna_index=CirData.EnumAntennaIndex(payload[5 - 4]),
                agc_gain_db=(payload[6 - 4] | (payload[7 - 4] << 8) | (payload[8 - 4] << 16) | (payload[9 - 4] << 24)),
                cir_index=(payload[10 - 4] | (payload[11 - 4] << 8)),
                cir_offset=(payload[12 - 4] | (payload[13 - 4] << 8) | (payload[14 - 4] << 16) | (payload[15 - 4] << 24)),
                num_taps=(payload[16 - 4] | (payload[17 - 4] << 8) | (payload[18 - 4] << 16) | (payload[19 - 4] << 24)),
                timestamp=(payload[20 - 4] | (payload[21 - 4] << 8) | (payload[22 - 4] << 16) | (payload[23 - 4]) << 24),
                cir_taps=cir_taps,
                cir_taps_bytes=cir_taps_bytes,
            )
        return radarResults

    # CMD_CONFIG_CAN
    @staticmethod
    def config_can(config: CanConfig) -> List[int]:
        payload = []
        payload += list(config.bitrate.to_bytes(length=4, byteorder="little", signed=False))
        payload += list(config.bitrate_fd.to_bytes(length=4, byteorder="little", signed=False))

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        config_uci_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_CONFIG_CAN,
            payload_length=len(payload),
            payload=payload,
        )

        return config_uci_command.byte_stream

    # CMD_CONFIG_CAN | INTERPRET CONFIG
    @staticmethod
    def interpret_config_can_command(payload: List[int]) -> CanConfig:
        can_config = CanConfig(
            bitrate=int.from_bytes(bytes=payload[0:4], byteorder="little", signed=False),
            bitrate_fd=int.from_bytes(bytes=payload[4:8], byteorder="little", signed=False),
        )
        return can_config

    # CMD_CONFIG_UCI
    @staticmethod
    def config_uci(config: UciConfig) -> List[int]:
        payload = []
        payload.append(config.max_payload_len_bytes & 0x00FF)
        payload.append((config.max_payload_len_bytes & 0xFF00) >> 8)

        # check if the payload data requires extended payload
        extension = 1 if len(payload) > 255 else 0
        config_uci_command = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=EnumUciGid.GID_TESTWARE,
            payload_extension=extension,
            oid=EnumTestwareOid.TESTWARE_OID_CONFIG_UCI,
            payload_length=len(payload),
            payload=payload,
        )

        return config_uci_command.byte_stream

    # CMD_CONFIG_UCI | INTERPRET CONFIG
    @staticmethod
    def interpret_config_uci_command(payload: List[int]) -> UciConfig:
        uci_config = UciConfig(max_payload_len_bytes=int.from_bytes(bytes=payload[0:2], byteorder="little", signed=False))
        return uci_config


TESTWARE_MESSAGE_DICT = {
    EnumTestwareOid.TESTWARE_OID_RESET_DEVICE: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_reset_device_command},
    EnumTestwareOid.TESTWARE_OID_BOOT_STATUS: {EnumUciMessageType.UCI_MT_NOTIFICATION: Ncj29d6Testware.interpret_boot_status_notification},
    EnumTestwareOid.TESTWARE_OID_GET_FW_VERSION: {
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_get_fw_version_response,
    },
    EnumTestwareOid.TESTWARE_OID_RX_CONFIG: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_rx_config_command},
    EnumTestwareOid.TESTWARE_OID_TX_CONFIG: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_tx_config_command},
    EnumTestwareOid.TESTWARE_OID_START_BASEBAND: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_start_baseband_command},
    EnumTestwareOid.TESTWARE_OID_BASEBAND_STATUS: {EnumUciMessageType.UCI_MT_NOTIFICATION: Ncj29d6Testware.interpret_baseband_status_notification},
    EnumTestwareOid.TESTWARE_OID_GET_BASEBAND_RESULTS: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_get_baseband_results_command,
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_get_baseband_results_response,
    },
    EnumTestwareOid.TESTWARE_OID_POWER_MGMT_CONFIG: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_power_management_config_command},
    EnumTestwareOid.TESTWARE_OID_GENERIC_BASEBAND_CONFIG: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_generic_baseband_config_command
    },
    EnumTestwareOid.TESTWARE_OID_CLOCK_MGMT_CONFIG: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_clock_management_config_command,
        EnumUciMessageType.UCI_MT_NOTIFICATION: Ncj29d6Testware.interpret_clock_management_notification,
    },
    EnumTestwareOid.TESTWARE_OID_PIN_TOGGLE_CONFIG: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_pin_toggle_config_command},
    EnumTestwareOid.TESTWARE_OID_GPADC_OPERATION: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_gpadc_operation_command,
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_gpadc_operation_response,
        EnumUciMessageType.UCI_MT_NOTIFICATION: Ncj29d6Testware.interpret_gpadc_result_notification,
    },
    EnumTestwareOid.TESTWARE_OID_GET_RADIO_CONFIG_VERSION: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_get_radio_config_version_command,
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_get_radio_config_version_response,
    },
    EnumTestwareOid.TESTWARE_OID_SET_BITFIELD: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_set_bitfield_command},
    EnumTestwareOid.TESTWARE_OID_GET_BITFIELD: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_get_bitfield_command,
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_get_bitfield_response,
    },
    EnumTestwareOid.TESTWARE_OID_ECHO_REV_PAYLOAD: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_echo_rev_payload_command,
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_echo_rev_payload_response,
    },
    EnumTestwareOid.TESTWARE_OID_RX_RADIO_CONFIG: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_rx_radio_config_command},
    EnumTestwareOid.TESTWARE_OID_TX_RADIO_CONFIG: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_tx_radio_config_command},
    EnumTestwareOid.TESTWARE_OID_RANGING_PAYLOAD_CONFIG: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_ranging_payload_config_command
    },
    EnumTestwareOid.TESTWARE_OID_RANGING_APPLICATION_CONFIG: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_ranging_application_config_command
    },
    EnumTestwareOid.TESTWARE_OID_RANGING_SEQUENCE_CONFIG: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_ranging_sequence_config_command
    },
    EnumTestwareOid.TESTWARE_OID_START_RANGING: {EnumUciMessageType.UCI_MT_NOTIFICATION: Ncj29d6Testware.interpret_ranging_status_notification},
    EnumTestwareOid.TESTWARE_OID_GET_RANGING_PAYLOAD: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_get_ranging_payload_command,
        EnumUciMessageType.UCI_MT_RESPONSE: Ncj29d6Testware.interpret_get_ranging_payload_response,
    },
    EnumTestwareOid.TESTWARE_OID_RADAR_APPLICATION_CONFIG: {
        EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_radar_application_config_command
    },
    EnumTestwareOid.TESTWARE_OID_START_RADAR: {EnumUciMessageType.UCI_MT_NOTIFICATION: Ncj29d6Testware.interpret_radar_result_notification},
    EnumTestwareOid.TESTWARE_OID_CONFIG_CAN: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_config_can_command},
    EnumTestwareOid.TESTWARE_OID_CONFIG_UCI: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_config_uci_command},
    EnumTestwareOid.TESTWARE_OID_ACTIVATE_SWUP: {EnumUciMessageType.UCI_MT_COMMAND: Ncj29d6Testware.interpret_activate_swup_command},
}
