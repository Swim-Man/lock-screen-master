#    Copyright 2024-2025 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

from __future__ import annotations

import inspect
from abc import ABC, abstractmethod
from copy import deepcopy
from dataclasses import dataclass, field
from enum import IntEnum
from math import log10, pi, sqrt, ceil
import numpy as np
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple, Type, TypeVar

from more_itertools import chunked, flatten

T = TypeVar("T")

import sys

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

### Logging ###
import logging

import drivers.nxp_ncj29d6_mac_config as mac_config

from utilities.nxp_console_helpers import as_hex, class_to_str, snake_case, to_hex_list

from drivers.nxp_uci import (
    EnumOidCore,
    EnumUciGid,
    EnumUciMessageType,
    EnumUciStatus,
    UciMessage,
)

from drivers.nxp_uwb_helpers import EnumUwbChannelFrequency

name = list(filter(lambda x: x.startswith("nxp_main"), sys.path))
try:
    logger = logging.getLogger(name[0])
except IndexError:
    logger = logging.getLogger()


# Helper function to raise an exception within a lambda function
def _raise(e: Exception, m: str):
    """
    Raises the given exception with the provided message.

    Args:
        e (Exception): The exception to be raised.
        m (str): The error message.

    Raises:
        Exception: The provided exception with the given message.
    """
    raise e(m)


class EnumMacOidSessionConfig(IntEnum):
    # UWB session config group 0x01
    MAC_OID_SESSION_INIT = 0x00
    MAC_OID_SESSION_DEINIT = 0x01
    MAC_OID_SESSION_STATUS = 0x02
    MAC_OID_SESSION_SET_APP_CONFIG = 0x03
    MAC_OID_SESSION_GET_APP_CONFIG = 0x04
    MAC_OID_SESSION_GET_COUNT = 0x05
    MAC_OID_SESSION_GET_STATE = 0x06
    MAC_OID_SESSION_UPDATE_CONTROLLER_MULTICAST_LIST = 0x07
    MAC_OID_SESSION_GET_POSSIBLE_RAN_MULTIPLIER_VALUE = 0x20


class EnumMacOidRangingSession(IntEnum):
    # UWB ranging session control group 0x02
    MAC_OID_SESSION_START = 0x00  # CCC: MAC_OID_RANGE_START  # SESSION_INFO_NTF
    MAC_OID_SESSION_STOP = 0x01  # CCC: MAC_OID_RANGE_STOP
    MAC_OID_RANGE_GET_RANGING_COUNT = 0x03
    MAC_OID_RANGE_CCC_DATA = 0x20
    MAC_OID_RANGE_RESUME = 0x21
    MAC_OID_RANGE_RECOVER = 0x22


class EnumMacOidProprietary(IntEnum):
    MAC_OID_LOG = 0x00
    MAC_OID_RADIO_CONFIG_DOWNLOAD = 0x11
    MAC_OID_ACTIVATE_SWUP = 0x12
    MAC_OID_DEVICE_GET_REBOOT_REASON = 0x13
    MAC_OID_GET_DEVICE_TEMPERATURE_DATA = 0x14  # Only AiO
    MAC_OID_TEST_START = 0x20
    MAC_OID_TEST_STOP = 0x21
    MAC_OID_SET_HPRF_PSDU = 0x22
    MAC_OID_QUERY_UWB_TIMESTAMP = 0x23
    MAC_OID_DEVICE_SUSPEND = 0x24
    MAC_OID_TEST_LOOPBACK = 0x25
    MAC_OID_SET_APP_CFG_PAGE_VALUES = 0x26
    MAC_OID_GET_ALL_UWB_SESSIONS = 0x27
    MAC_OID_GET_APP_CFG_PAGE_VALUES = 0x28
    MAC_OID_USER_DEFINED_RANGE_DATA = 0x2C
    MAC_OID_SET_RADAR_CONFIG = 0x30
    MAC_OID_GET_RADAR_CONFIG = 0x31
    MAC_OID_RUN_RADAR_CALIBRATION = 0x32
    MAC_OID_RADAR_FRAME_ENABLE = 0x33  # Only AiO
    MAC_OID_RADAR_FRAME_DISABLE = 0x34  # Only AiO
    MAC_OID_RADAR_STATUS = 0x35  # Only AiO
    MAC_OID_RANGING_FRAME_DISABLE = 0x36  # Only AiO
    MAC_OID_TUSP_STORE_TTP_KEY = 0x38
    MAC_OID_TUSP_GET_ANCHOR_REQUESTS = 0x39
    MAC_OID_TUSP_STORE_LONGTERM_PAIRING_KEYS = 0x3A
    MAC_OID_TUSP_SET_EPOCH_ID = 0x3B
    MAC_OID_TUSP_ENCRYPTED_DATA = 0x3C  # CCC: MAC_OID_ENCRYPTED_RANGE_CCC_DATA
    MAC_OID_TUSP_TRANSMIT_ENCRYPTED_DATA = 0x3D


### Parser ###
########################################################################################################

END = -1
"""Use END with PayloadParser to achieve extraction of all remaining bytes"""


class PayloadParser:
    def __init__(self, payload: List[int]):
        self.payload = payload
        self.cursor = 0  # Byte index
        self.cursor_bit = 0  # Bit index (LSB = 0)
        self.payload_int = int.from_bytes(self.payload, byteorder="little", signed=False)

    def _check_for_end(self, size):
        return (len(self.payload) - self.cursor) if size == END else size

    def advance_bytes(self, byte_count: int):
        """
        Advance the cursor by a number of bytes. Set the cursor_bit to the corresponding bit position.
        """
        self.cursor += byte_count
        self.cursor_bit += byte_count * 8

    def advance_bits(self, bit_count: int):
        """
        Advance the cursor_bit by a number of bits. Advance the cursor to the next byte if necessary.
        """
        self.cursor_bit += bit_count
        self.cursor = ceil(self.cursor_bit / 8)

    def extract_int(self, size: int, signed: bool = False) -> int:
        """
        Extract an integer from the payload of the given size, advancing the cursor.
        If size is 1, directly return the byte.
        """
        size = self._check_for_end(size)
        if size == 1:
            value = self.payload[self.cursor]
        else:
            value = int.from_bytes(self.payload[self.cursor : self.cursor + size], byteorder="little", signed=signed)
        self.advance_bytes(size)
        return value

    def extract_bits(self, bit_count: int) -> int:
        """
        Extract a specific number of bits from the payload, advancing the bit cursor.
        Handles little endian bit ordering within each byte.
        """
        # Extract bits from the reversed payload integer
        value = (self.payload_int >> self.cursor_bit) & ((1 << bit_count) - 1)
        self.advance_bits(bit_count)
        return value

    def extract_list(self, size: int) -> List[int]:
        """
        Extract a list of integers (a slice) from the payload, advancing the cursor.
        """
        size = self._check_for_end(size)
        value = self.payload[self.cursor : self.cursor + size]
        self.advance_bytes(size)
        return value

    def extract_cls(self, cls: Type[T], size: int) -> T:
        """
        Extract an instance of a dataclass from the payload using its from_bytes method, advancing the cursor.
        """
        size = self._check_for_end(size)
        value = cls.from_bytes(self.payload[self.cursor : self.cursor + size])
        self.advance_bytes(size)
        return value

    def extract_enum(self, enum: Type[IntEnum], size: int = 1) -> IntEnum:
        """
        Extract an enum value from the payload, advancing the cursor.
        If the value doesn't match a valid enum member, the raw value is returned.
        """
        value = self.extract_int(size=size)
        # 'advance_bytes' handled by 'extract_int'
        return enum(value) if value in enum._value2member_map_ else value

    def extract_enum_bits(self, enum: Type[IntEnum], bit_count: int = 1) -> IntEnum:
        """
        Extract an enum value from the payload, advancing the bit cursor.
        If the value doesn't match a valid enum member, the raw value is returned.
        """
        value = self.extract_bits(bit_count=bit_count)
        # 'advance_bits' handled by 'extract_bits'
        return enum(value) if value in enum._value2member_map_ else value

    def extract_bool(self, size: int = 1) -> bool:
        """
        Extract one byte and cast as bool, advancing the cursor.
        """
        # 'advance_bytes' handled by 'extract_int'
        return bool(self.extract_int(size=size))

    def extract_set_keys_from_bitmask(self, bit_mapping: Dict[int, int], size: int) -> List[int]:
        """
        Extracts a bitmask from the payload based on a specific bit mapping and returns
        a list of the keys (e.g., pins) corresponding to the bits that are set to 1.
        bit_mapping: A dictionary mapping pin numbers or other values to bit positions (key=pin number : value=bit position).
        """
        # Extract an integer of the given byte_size from the payload
        bitmask = self.extract_int(size=size)
        # Find and return the pins/keys where the corresponding bit is set in the bitmask
        return [key for key, bit in bit_mapping.items() if bitmask & (1 << bit)]

    def extract_dict_from_bitmask(self, bit_mapping: Dict[int, int], size: int) -> List[int]:
        """
        Extracts a bitmask from the payload based on a specific bit mapping and returns
        a dict (supported: 1, unsupported: 0).
        bit_mapping: A dictionary mapping features or other values to bit positions (key=feature : value=bit position).
        """
        # Extract an integer of the given byte_size from the payload
        bitmask = self.extract_int(size=size)

        return {key: "supported" if bitmask & (1 << bit) else "not supported" for key, bit in bit_mapping.items()}


### Abstract classes ###
########################################################################################################
class CommandBase(ABC):
    """
    Base class for commands used in the NXP NCJ29D6 MAC driver.

    Attributes:
        _gid_: The group ID of the command.
        _oid_: The object ID of the command.
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "_gid_") or not hasattr(cls, "_oid_"):
            raise NotImplementedError("Subclasses of CommandBase must set _gid_ and _oid_ attributes")

    def create_command(self, custom_payload: Optional[List[int]] = None) -> List[int]:
        """
        Creates a command byte stream from the class instance, optionally with the specified custom payload.

        Args:
            custom_payload: The custom payload to use for the command.

        Returns:
            The byte stream representation of the command.
        """
        if custom_payload is None:
            payload = self.create_payload()
        else:
            payload = custom_payload

        uci_message = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=self._gid_,
            payload_extension=0,
            oid=self._oid_,
            payload_length=len(payload),
            payload=payload,
        )
        return uci_message.byte_stream

    def create_payload(self) -> List[int]:
        """
        Creates the payload byte stream.

        Returns:
            List[int]: The payload byte stream.
        """
        return []

    @classmethod
    def from_bytes(cls, payload: List[int]):
        """
        Convert the payload to an instance of the class.

        Args:
            payload (List[int]): The payload as a list of integers.

        Returns:
            An instance of the class.
        """
        pass

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=0)


class NotificationBase(ABC):
    """
    Base class for notifications used in the NXP NCJ29D6 MAC driver.

    Attributes (if no corresponding command class exists):
        _gid_: The group ID of the command.
        _oid_: The object ID of the command.
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "_gid_") or not hasattr(cls, "_oid_"):
            # Check if a corresponding command class exists with _gid_ and _oid_ set
            command_class_name = cls.__name__.replace("Ntf", "Cmd")
            command_class = globals().get(command_class_name)
            if not command_class or not hasattr(command_class, "_gid_") or not hasattr(command_class, "_oid_"):
                raise NotImplementedError(
                    "Subclasses of NotificationBase must set _gid_ and _oid_ attributes or have a corresponding command class with these attributes set"
                )

    @classmethod
    @abstractmethod
    def from_bytes(cls, payload: List[int]):
        """
        Abstract method to convert the payload from bytes to an instance of the class.

        Args:
            payload (List[int]): The payload as a list of integers.

        Returns:
            An instance of the class.
        """
        pass

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=0)


class ResponseBase(ABC):
    """
    Base class for responses used in the NXP NCJ29D6 MAC driver.
    """

    @classmethod
    @abstractmethod
    def from_bytes(cls, payload: List[int]):
        """
        Abstract method to convert the payload from bytes to an instance of the class.

        Args:
            payload (List[int]): The payload as a list of integers.

        Returns:
            An instance of the class.
        """
        pass

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=0)


@dataclass(order=True)
class TlvCommandBase(ABC):
    """
    Base class for TLV (Type-Length-Value) command objects.
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "_gid_") or not hasattr(cls, "_oid_"):
            raise NotImplementedError("Subclasses of TlvCommandBase must set _gid_ and _oid_ attributes")

    def __init__(self, params: List[Tuple[TlvParamBase, Any]] = []):
        self.params: Dict[int | str, List[Any]] = {}
        if params:
            self.set_parameters(params_list=params)
        else:
            self.number_of_parameters = 0

    @abstractmethod
    def set_parameter(self, param: TlvParamBase, value: Any):
        """
        Abstract method to set a parameter.

        Args:
            param (TlvParamBase): The parameter to be set.
            value (Any): The value to set for the parameter.
        """
        pass

    def _set_parameter_base(self, param: TlvParamBase, value: Any, param_class: Type[ParamBase], set_command=False):
        """
        Internal method to to set a parameter.

        Args:
            param (TlvParamBase): The parameter to be set.
            value (Any): The value to set for the parameter.
            param_class (Type[ParamBase]): The class of the parameter.
            set_command (bool, optional): Whether it is used for a 'set' command. Defaults to False.

        Raises:
            TypeError: If the parameter is not an instance of TlvParamBase.
            AttributeError: If the parameter is not part of the specified parameter class.
            ValueError: If the parameter is read-only and cannot be used in a set command.
        """
        if not isinstance(param, TlvParamBase):
            raise TypeError("Parameter must be an instance of TvlParamBase")
        if param not in vars(param_class).values():
            raise AttributeError(f"Param ({param}) not part of {param_class.__class__.__name__}!")
        if set_command and param.read_only:
            raise ValueError(f"Param {param} is READ_ONLY and cannot be used in a SET command")
        converted_value = param.convert_to_bytes(value)
        if param.tag in self.params:
            self.params[param.tag].append(converted_value)
        else:
            self.params[param.tag] = [converted_value]
        if hasattr(self, "number_of_parameters"):
            self.number_of_parameters += 1
        else:
            self.number_of_parameters = 1

    def set_parameters(self, params_list: List[Tuple[TlvParamBase, Any]]):
        """
        Sets multiple TLV parameters at once.

        Args:
            params_list (List[Tuple[TlvParamBase, Any]]): A list of (param, value) pairs.
        """
        for param, value in params_list:
            self.set_parameter(param, value)

    def create_command(self, custom_payload: Optional[List[int]] = None) -> List[int]:
        """
        Creates a command byte stream from the class instance.

        Args:
            custom_payload (Optional[List[int]]): A custom payload byte stream. If not provided, the payload is created based on the TLV parameters.

        Returns:
            The byte stream representation of the command.
        """
        if custom_payload is None:
            payload = self._create_payload()
        else:
            payload = custom_payload

        uci_message = UciMessage(
            message_type=EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag=0,
            gid=self._gid_,
            payload_extension=0,
            oid=self._oid_,
            payload_length=len(payload),
            payload=payload,
        )
        return uci_message.byte_stream

    def _create_payload(self) -> List[int]:
        """
        Internal method to creates the payload byte stream.

        Returns:
            List[int]: The payload byte stream.
        """
        if all(hasattr(self, attr) for attr in ("session_handle", "id_epoch", "update_epoch_key")):
            payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
            payload += to_hex_list(input=self.id_epoch, byteorder="little", forced_list_len=4)
            payload += (
                [int(self.update_epoch_key)] if int(self.update_epoch_key) in [0, 1] else _raise(ValueError, "UPDATE_EPOCH_KEY: Expected bool.")
            )
        elif hasattr(self, "session_handle"):
            payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        elif hasattr(self, "radar_config_index"):
            payload = [self.radar_config_index]
        else:
            payload = []
        payload += [self.number_of_parameters]
        for tag, values in self.params.items():
            for value in values:
                payload.extend(TlvHandler.encode_tlv(tag, value))
        return payload

    def interpret(self):
        payload = self._create_payload()
        return self.from_bytes(payload)

    @classmethod
    def _from_bytes_base(cls, payload: List[int], param_class: Type[ParamBase], **kwargs):
        """
        Internal method to convert a byte payload to an instance of the class.

        Args:
            payload (List[int]): The payload to convert.
            param_class (Type[ParamBase]): The class representing the parameters.
            session_handle (int, optional): The session handle. Defaults to None.
            radar_config_index (int, optional): The radar configuration index. Defaults to None.

        Returns:
            An instance of the class with the converted parameters.
        """

        def update_attribute(current_instance, add_instance):
            for attr in ["rx1", "rx2"]:
                current_value = getattr(current_instance, attr)
                if current_value is None:
                    new_attr_value = getattr(add_instance, attr)
                    if new_attr_value is not None:
                        setattr(current_instance, attr, new_attr_value)
                        return
            raise ValueError(f"Unexpected behavior while parsing a second {attr_name}. No suitable attribute found for update.")

        if "radar_config_index" in kwargs:
            instance = cls(radar_config_index=kwargs["radar_config_index"], params=[])
        elif all(key in kwargs for key in ("session_handle", "id_epoch", "update_epoch_key")):
            instance = cls(
                session_handle=kwargs["session_handle"],
                id_epoch=kwargs["id_epoch"],
                update_epoch_key=kwargs["update_epoch_key"],
                params=[],
            )
        elif "session_handle" in kwargs and len(kwargs) == 1:
            instance = cls(session_handle=kwargs["session_handle"], params=[])
        elif len(kwargs) != 0:
            raise TypeError(f"Unexpected argument(s): {kwargs.keys()}")
        else:
            instance = cls(params=[])

        tlv_list = TlvHandler.decode_tlvs(payload)

        for tag, length, value in tlv_list:
            param_name = param_class.find_name_by_tag(tag)
            if param_name is None:
                raise ValueError(f"Tag {tag} not found in {param_class.__class__.__name__}!")
            else:
                param_attr: TlvParamBase = getattr(param_class, param_name)
            if length == 0:
                interpreted_value = None
            if length != 0:
                interpreted_value = param_attr.interpret_com(value)

            attr_name = param_name
            if attr_name in instance.params:
                # cir_log and rx_first_path_info exists for rx1 and rx2
                if hasattr(instance.params[attr_name], "rx1"):
                    update_attribute(current_instance=instance.params[attr_name], add_instance=interpreted_value)
                # more than one of the same kind like with StaticKeysConfig
                else:
                    index = 0
                    while attr_name in instance.params:
                        index += 1
                        attr_name = attr_name + "_" + str(index)
                    instance.params[attr_name] = interpreted_value
            else:
                instance.params[attr_name] = interpreted_value

        return instance

    @classmethod
    @abstractmethod
    def from_bytes(cls, payload: List[int]):
        """
        Abstract method to convert the payload from bytes to an instance of the class.

        Args:
            payload (List[int]): The payload as a list of integers.

        Returns:
            An instance of the class.
        """
        pass

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=0)


@dataclass(order=True)
class TlvResponseBase(ABC):
    """
    Base class for TLV (Type-Length-Value) response objects.
    """

    @classmethod
    def _from_bytes_base(cls, payload: List[int], param_class: Type[ParamBase]):
        """
        Internal method to parse the TLV response payload and create a object.

        Args:
            payload (List[int]): The payload of the response.
            param_class (Type[ParamBase]): The class representing the TLV parameters.

        Returns:
            cls: An instance of the class with the converted parameters.
        """

        def update_attribute(current_instance, add_instance):
            for attr in ["rx1", "rx2"]:
                current_value = getattr(current_instance, attr)
                if current_value is None:
                    new_attr_value = getattr(add_instance, attr)
                    if new_attr_value is not None:
                        setattr(current_instance, attr, new_attr_value)
                        return
            raise ValueError(f"Unexpected behavior while parsing a second {attr_name}. No suitable attribute found for update.")

        tlv_list = TlvHandler.decode_tlvs(payload)
        response_data = {}
        for tag, length, value in tlv_list:
            for param_name, param in param_class.__dict__.items():
                tag_found = False
                if isinstance(param, TlvParamBase) and param.tag == tag:
                    if (isinstance(param.expected_resp_length, int) and length != param.expected_resp_length) or (
                        callable(param.expected_resp_length) and not param.expected_resp_length(length)
                    ):
                        logger.warning(f"Expected length ({param.expected_resp_length}) of '{param_name}' differs from received length ({length})! ")
                    interpreted_value = param.interpret_resp(value)
                    attr_name = param_name
                    if attr_name in response_data:
                        # cir_log and rx_first_path_info exists for rx1 and rx2
                        update_attribute(current_instance=response_data[attr_name], add_instance=interpreted_value)
                    else:
                        response_data[attr_name] = interpreted_value
                    tag_found = True
                    break
            if not tag_found:
                logger.warning(f"Received unexpected TLV: T: {tag} L: {length} V: {value}")
                response_data[tag] = value
        return cls(**response_data)

    @classmethod
    @abstractmethod
    def from_bytes(cls, payload: List[int]):
        """
        Abstract method to convert the payload from bytes to an instance of the class.

        Args:
            payload (List[int]): The payload as a list of integers.

        Returns:
            An instance of the class.
        """
        pass

    def get(self, param_name: str):
        """
        Returns param value. None if param does not exist.
        """
        return getattr(self, param_name, None)

    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=0)


@dataclass(order=True)
class TlvNotificationBase(ABC):
    """
    Base class for TLV (Type-Length-Value) notification objects.
    """

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "_gid_") or not hasattr(cls, "_oid_"):
            # Check if a corresponding command class exists with _gid_ and _oid_ set
            command_class_name = cls.__name__.replace("Ntf", "Cmd")
            command_class = globals().get(command_class_name)
            if not command_class or not hasattr(command_class, "_gid_") or not hasattr(command_class, "_oid_"):
                raise NotImplementedError(
                    "Subclasses of TlvNotificationBase must set _gid_ and _oid_ attributes or have a corresponding command class with these attributes set"
                )

    @classmethod
    def _from_bytes_base(cls, payload: List[int], param_class: Type[ParamBase]):
        """
        Internal method to parse the TLV notification payload and create a object.

        Args:
            payload (List[int]): The payload of the response.
            param_class (Type[ParamBase]): The class representing the TLV parameters.

        Returns:
            cls: An instance of the class with the converted parameters.
        """

        def update_attribute(current_instance, add_instance):
            for attr in ["rx1", "rx2"]:
                current_value = getattr(current_instance, attr)
                if current_value is None:
                    new_attr_value = getattr(add_instance, attr)
                    if new_attr_value is not None:
                        setattr(current_instance, attr, new_attr_value)
                        return
            raise ValueError(f"Unexpected behavior while parsing a second {attr_name}. No suitable attribute found for update.")

        tlv_list = TlvHandler.decode_tlvs(payload=payload, length_bytes_length=2)
        response_data = {}
        for tag, length, value in tlv_list:
            for param_name, param in param_class.__dict__.items():
                tag_found = False
                if isinstance(param, TlvParamBase) and param.tag == tag:
                    if (isinstance(param.expected_resp_length, int) and length != param.expected_resp_length) or (
                        callable(param.expected_resp_length) and not param.expected_resp_length(length)
                    ):
                        logger.warning(f"Expected length ({param.expected_resp_length}) of '{param_name}' differs from received length ({length})! ")
                    interpreted_value = param.interpret_resp(value)
                    attr_name = param_name
                    if attr_name in response_data:
                        # cir_log and rx_first_path_info exists for rx1 and rx2
                        update_attribute(current_instance=response_data[attr_name], add_instance=interpreted_value)
                    else:
                        response_data[attr_name] = interpreted_value
                    tag_found = True
                    break
            if not tag_found:
                logger.warning(f"Received unexpected TLV: T: {tag} L: {length} V: {value}")
                response_data[tag] = value
        return cls(**response_data)

    @classmethod
    @abstractmethod
    def from_bytes(cls, payload: List[int]):
        """
        Abstract method to convert the payload from bytes to an instance of the class.

        Args:
            payload (List[int]): The payload as a list of integers.

        Returns:
            An instance of the class.
        """
        pass

    def get(self, param_name: str):
        """
        Returns param value. None if param does not exist.
        """
        return getattr(self, param_name, None)

    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=0)


class ParamBase:
    """
    Base class for parameters.
    """

    @classmethod
    def find_name_by_tag(cls, tag: int):
        """
        Finds the name of a parameter by its tag.

        Args:
            tag (int): The tag of the parameter.

        Returns:
            str | None: The name of the parameter, or None if not found.
        """
        return next((name for name, value in vars(cls).items() if isinstance(value, TlvParamBase) and value.tag == tag), None)

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=1)


def set_param(aio: TlvParamBase | None = None, ccc: TlvParamBase | None = None):
    """Helper function to assign the correct TlvParamBase to a param variable, depending on mac_config.MAC_FW_TYPE."""
    if mac_config.MAC_FW_TYPE == "AiO":
        return aio
    elif mac_config.MAC_FW_TYPE == "CCC":
        return ccc
    else:
        raise RuntimeError(
            "mac_config.MAC_FW_TYPE is neither AiO, nor CCC. Make sure to set mac_config.MAC_FW_TYPE via 'set_mac_config.MAC_FW_TYPE' to an expected value."
        )


### TlvHandler ###
########################################################################################################
class TlvHandler:
    """
    A class that handles TLV (Tag-Length-Value) encoding and decoding.
    """

    @staticmethod
    def encode_tlv(tag: int, value: List[int]):
        """
        Encodes a TLV (Tag-Length-Value) structure.

        Args:
            tag (int): The tag value.
            value (List[int]): The value to be encoded.

        Returns:
            List[int]: The encoded TLV structure.
        """
        length = len(value)
        return [tag, length] + value

    @staticmethod
    def decode_tlvs(payload: List[int], length_bytes_length: Literal[1, 2] = 1) -> List[Tuple[int, int, List[int]]]:
        """
        Decode TLVs (Type-Length-Value) from the given payload.

        Args:
            payload (List[int]): The payload containing the TLVs.
            length_bytes_length (Literal[1, 2], optional): The number of bytes used to represent the length field. Defaults to 1.

        Returns:
            List[Tuple[int, int, List[int]]]: A list of tuples representing the decoded TLVs. Each tuple contains the tag, length, and value.

        Raises:
            ValueError: If the length_bytes_length is not supported (not 1 or 2).
        """
        tlv_list = []
        i = 0
        while i < len(payload):
            tag = payload[i]
            length = (
                payload[i + 1]
                if length_bytes_length == 1
                else int.from_bytes(bytes=payload[i + 1 : i + 3], byteorder="little", signed=False)
                if length_bytes_length == 2
                else _raise(ValueError, f"length_bytes_length: {length_bytes_length} is not supported. Choose between [1, 2]")
            )
            value = payload[i + (1 + length_bytes_length) : i + (1 + length_bytes_length) + length]
            tlv_list.append((tag, length, value))
            i += (1 + length_bytes_length) + length
        return tlv_list


@dataclass(frozen=True, order=True)
class TlvParamBase:
    """
    Base class for TLV (Tag-Length-Value) parameters.

    Attributes:
        tag (int): The tag value of the TLV parameter.
        convert_to_bytes (Callable[[Any], List[int]]): A function that converts the parameter value to a list of bytes.
        interpret_resp (Callable[[List[int]], Any]): A function that interprets the response bytes and returns the parameter value.
        interpret_com (Callable[[List[int]], Any]): A function that interprets the command bytes and returns the parameter value.
        expected_resp_length (int | Callable[[int], bool]): The expected length of the response bytes or a function that checks if the length is valid.
        expected_com_length (int | Callable[[int], bool]): The expected length of the command bytes or a function that checks if the length is valid.
        read_only (bool): Indicates if the parameter is read-only.
        write_only (bool): Indicates if the parameter is write-only.
    """

    tag: int
    convert_to_bytes: Callable[[Any], List[int]] = field(default=lambda v: [v])
    interpret_resp: Callable[[List[int]], Any] = field(default=lambda p: p[0])
    interpret_com: Callable[[List[int]], Any] | None = None
    expected_resp_length: int | Callable[[int], bool] | None = None
    expected_com_length: int | Callable[[int], bool] | None = None
    read_only: bool = False
    write_only: bool = False

    def __post_init__(self):
        """
        This method is called after the initialization of the object.
        It sets the values of `interpret_com` and `expected_com_length` if they are not already defined.
        """
        if self.interpret_com is None:  # Only set interpret_com if it's not already defined
            object.__setattr__(self, "interpret_com", self.interpret_resp)
        if self.expected_com_length is None:  # Only set expected_com_length if it's not already defined
            object.__setattr__(self, "expected_com_length", self.expected_resp_length)


@dataclass(frozen=True, order=True)
class InvalidParam:
    """
    Represents an invalid parameter.

    Attributes:
        tag (int): The tag of the parameter.
        name (str): The name of the parameter.
        error_code (str): The error code associated with the invalid parameter.
    """

    tag: int
    name: str
    error_code: str

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=1)


### Support classes ###
########################################################################################################
@dataclass(frozen=True, order=True)
class SimpleVersion:
    major: int
    minor: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        version = cls(
            major=p.extract_int(1),
            minor=p.extract_int(1),
        )
        return version

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}"


@dataclass(frozen=True, order=True)
class SimpleVersion2:
    major: int
    minor: int
    maintenance: int | None = None

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        if mac_config.MAC_FW_TYPE == "AiO":
            version = cls(
                major=p.extract_int(1),
                maintenance=p.extract_bits(4),
                minor=p.extract_bits(4),
            )
        elif mac_config.MAC_FW_TYPE == "CCC":
            version = cls(
                major=p.extract_int(1),
                maintenance=None,
                minor=p.extract_int(1),
            )
        return version

    def __str__(self) -> str:
        if mac_config.MAC_FW_TYPE == "AiO":
            return f"{self.major}.{self.minor}.{self.maintenance}"
        elif mac_config.MAC_FW_TYPE == "CCC":
            return f"{self.major}.{self.minor}"


@dataclass(frozen=True, order=True)
class SimpleVersionReversed:
    major: int
    minor: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        version = cls(
            minor=p.extract_int(1),
            major=p.extract_int(1),
        )
        return version

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}"


@dataclass(frozen=True, order=True)
class Version:
    major: int
    minor: int
    patch: int
    version_id: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        version = cls(
            major=p.extract_int(4),
            minor=p.extract_int(4),
            patch=p.extract_int(4),
            version_id=p.extract_int(4),
        )
        return version

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch} (Component ID: {self.version_id})"

    def _comparison_str(self):
        return f"{self.major}.{self.minor}.{self.patch}"


@dataclass(frozen=True, order=True)
class HardwareVersion:
    reserve_bit: int
    jep106_id: int
    jep106_cont_code: int
    part_number: int
    revision: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        hardware_version = cls(
            reserve_bit=p.extract_bits(1),
            jep106_id=p.extract_bits(7),
            jep106_cont_code=p.extract_bits(4),
            part_number=p.extract_bits(16),
            revision=p.extract_bits(4),
        )
        return hardware_version

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=3)


@dataclass(frozen=True, order=True)
class MinMaxVersion:
    min_version: SimpleVersion
    max_version: SimpleVersion

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            min_version=p.extract_cls(SimpleVersion, 2),
            max_version=p.extract_cls(SimpleVersion, 2),
        )

    def __str__(self) -> str:
        return f"Version {self.min_version} to {self.max_version} supported"


@dataclass(order=True)
class EncryptedData:
    iv: List[int]
    encrypted_data: List[int]
    authentication_tag: List[int]

    def create_payload(self):
        payload = self.iv if len(self.iv) == 12 else _raise(ValueError, f"IV: Expected 12 bytes. Got {len(self.iv)}")
        payload += self.encrypted_data if isinstance(self.encrypted_data, list) else _raise(ValueError, "ENCRYPTED_DATA: Expected byte list")
        payload += (
            self.authentication_tag
            if len(self.authentication_tag) == 16
            else _raise(ValueError, f"AUTHENTICATION_TAG: Expected 16 bytes. Got {len(self.authentication_tag)}")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            iv=p.extract_list(12),
            encrypted_data=p.extract_list(len(payload) - 12 - 16),
            authentication_tag=p.extract_list(16),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(frozen=True, order=True)
class VendorSpecificInformationParams(ParamBase):
    uci_ccc_version = TlvParamBase(
        tag=0xA0,
        interpret_resp=lambda p: SimpleVersion.from_bytes(p),
        expected_resp_length=2,
        read_only=True,
    )
    ccc_version = TlvParamBase(
        tag=0xA1,
        interpret_resp=lambda p: bytes(p).decode("ascii").strip("\x00"),
        expected_resp_length=8,
        read_only=True,
    )
    device_name = TlvParamBase(
        tag=0xE3,
        interpret_resp=lambda p: bytes(p).decode("ascii").strip("\x00"),
        expected_resp_length=8,
        read_only=True,
    )
    firmware_version = TlvParamBase(
        tag=0xE4,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    foundation_package_version = TlvParamBase(
        tag=0xE5,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    mac_version = TlvParamBase(
        tag=0xE6,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    swup_core_version = TlvParamBase(
        tag=0xE7,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    baseband_version = TlvParamBase(
        tag=0xE8,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    dsp_version = TlvParamBase(
        tag=0xE9,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    sbe_api_ext_version = TlvParamBase(
        tag=0xEA,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    rom_version = TlvParamBase(
        tag=0xEB,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )
    hardware_version = TlvParamBase(
        tag=0xEC,
        interpret_resp=lambda p: HardwareVersion.from_bytes(p),
        expected_resp_length=4,
        read_only=True,
    )
    variant_information = TlvParamBase(
        tag=0xED,
        interpret_resp=lambda p: p,
        expected_resp_length=4,
        read_only=True,
    )
    serial_number = TlvParamBase(
        tag=0xEE,
        interpret_resp=lambda p: p,
        expected_resp_length=4,
        read_only=True,
    )
    wafer_data = TlvParamBase(
        tag=0xEF,
        interpret_resp=lambda p: p,
        expected_resp_length=16,
        read_only=True,
    )
    ncj29d6_uwbmac_uci_version = TlvParamBase(
        tag=0xF0,
        interpret_resp=lambda p: Version.from_bytes(p),
        expected_resp_length=16,
        read_only=True,
    )


@dataclass(order=True)
class VendorSpecificInformation(TlvResponseBase):
    # uci_ccc_version: SimpleVersion
    ccc_version: str
    device_name: str
    firmware_version: Version
    foundation_package_version: Version
    mac_version: Version
    swup_core_version: Version
    baseband_version: Version
    dsp_version: Version
    sbe_api_ext_version: Version
    rom_version: Version
    hardware_version: HardwareVersion
    variant_information: List[int]
    serial_number: List[int]
    wafer_data: List[int]
    ncj29d6_uwbmac_uci_version: Version

    @classmethod
    def from_bytes(cls, payload: List[int]):
        return cls._from_bytes_base(payload=payload, param_class=VendorSpecificInformationParams)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(frozen=True)
class CapabilityParams(ParamBase):
    max_data_message_size: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x00,
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=2,
            read_only=True,
        ),
        ccc=None,
    )
    """Maximum size of UCI data messages the UWBS can receive."""

    max_data_packet_payload_size: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x01,
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=2,
            read_only=True,
        ),
        ccc=None,
    )
    """Maximum UCI data packet payload size the UWBS can send or receive."""

    fira_phy_version_range: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x02,
            interpret_resp=lambda p: MinMaxVersion.from_bytes(p),
            expected_resp_length=4,
            read_only=True,
        ),
        ccc=None,
    )
    """FiRa PHY supported version range."""

    fira_mac_version_range: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x03,
            interpret_resp=lambda p: MinMaxVersion.from_bytes(p),
            expected_resp_length=4,
            read_only=True,
        ),
        ccc=None,
    )
    """FiRa MAC supported version range."""

    device_type: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x04,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "controller": 0,
                    "controllee": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported device types."""

    device_roles: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x05,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Responder": 0,
                    "Initiator": 1,
                    "Advertiser": 5,
                    "Observer": 6,
                    "DT-Anchor": 7,
                    "DT-Tag": 8,
                },
                size=2,
            ),
            expected_resp_length=2,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported device roles."""

    ranging_method: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x06,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "SS-TWR with Deferred Mode": 1,
                    "DS-TWR with Deferred Mode": 2,
                    "SS-TWR with Non-deferred Mode": 3,
                    "DS-TWR with Non-deferred Mode": 4,
                    "OWR DL-TdoA": 5,
                    "OWR for AoA Measurement": 6,
                    "eSS-TWR with Non-deferred Mode for Contention-based ranging": 7,
                    "aDS-TWR for Contention-based ranging": 8,
                },
                size=2,
            ),
            expected_resp_length=2,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported ranging methods."""

    sts_config: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x07,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Static STS": 0,
                    "Dynamic STS": 1,
                    "Dynamic STS for responder Specific Sub-Session Key": 2,
                    "Provisioned STS": 3,
                    "Provisioned STS for responder Specific Sub-Session Key": 4,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported STS configurations."""

    multi_node_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x08,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "One to one": 0,
                    "One to many": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported multi node modes."""

    ranging_time_struct: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x09,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Block based scheduling": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported ranging time structures."""

    schedule_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0A,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Contention based ranging": 0,
                    "Time scheduled ranging": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported schedule modes."""

    hopping_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0B,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Default hopping mode": 0,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported hopping modes."""

    block_striding: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0C,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Default block striding": 0,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported block striding."""

    uwb_initiation_time: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0D,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "UWB initiation time": 0,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """UWB initiation time support."""

    channels: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0E,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Channel 5": 0,
                    "Channel 6": 1,
                    "Channel 8": 2,
                    "Channel 9": 3,
                    "Channel 10": 4,
                    "Channel 12": 5,
                    "Channel 13": 6,
                    "Channel 14": 7,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported UWB channels."""

    rframe_config: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0F,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "SP0": 0,
                    "SP1": 1,
                    "SP2": 2,
                    "SP3": 3,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported RFRAME configurations."""

    cc_constraint_length: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x10,
            interpret_resp=lambda p: PayloadParser(p).extract_set_keys_from_bitmask(
                bit_mapping={
                    "K=3": 0,
                    "K=7": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Specifies the constraint length of the preferred convolutional code."""

    bprf_parameter_sets: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x11,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={f"BPRF set {(i + 1)}": i for i in range(6)},
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported BPRF parameter sets."""

    hprf_parameter_sets: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x12,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={f"HPRF set {(i + 1)}": i for i in range(35)},
                size=5,
            ),
            expected_resp_length=5,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported BPRF parameter sets."""

    aoa_support: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x13,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Azimuth AoA -90° to 90°": 0,
                    "Azimuth AoA -180° to 180°": 1,
                    "Elevation AoA": 2,
                    "AoA FoM": 3,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported AoA measurements."""

    extended_mac_address_supported: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x14,
            interpret_resp=lambda p: bool(p[0]),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Extended MAC address support."""

    session_key_length: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x16,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "256 bits key length for Dynamic STS": 0,
                    "256 bits key length for Provisioned STS": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported session key lengths."""

    psdu_length_support: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x1A,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "2047": 0,
                    "4095": 1,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """Supported PSDU lengths."""

    ccc_slot_bitmask = TlvParamBase(
        tag=0xA0,
        interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
            bit_mapping={
                "3": 0,
                "4": 1,
                "6": 2,
                "8": 3,
                "9": 4,
                "12": 5,
                "24": 6,
            },
            size=1,
        ),
        expected_resp_length=1,
        read_only=True,
    )
    """Supported values of slot durations as a multiple of TChap, Nchap_per_Slot."""

    ccc_sync_code_index_bitmask = TlvParamBase(
        tag=0xA1,
        interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
            bit_mapping={str(i + 1): i for i in range(32)},
            size=4,
        ),
        expected_resp_length=4,
        read_only=True,
    )
    """Supported SYNC code indexes."""

    ccc_hopping_config_bitmask = TlvParamBase(
        tag=0xA2,
        interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
            bit_mapping={
                "AES based hopping sequence": 0,
                "Default hopping sequence (always set)": 1,
                "Adaptive Hopping mode": 2,
                "Continuous Hopping mode (always set)": 3,
                "No hopping": 4,
            },
            size=1,
        ),
        expected_resp_length=1,
        read_only=True,
    )
    """Supported hopping modes and sequences."""

    ccc_channel_bitmask = TlvParamBase(
        tag=0xA3,
        interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
            bit_mapping={
                "Channel 5": 0,
                "Channel 9": 1,
            },
            size=1,
        ),
        expected_resp_length=1,
        read_only=True,
    )
    """Supported UWB channels."""

    ccc_supported_protocol_version = TlvParamBase(
        tag=0xA4,
        interpret_resp=lambda p: [SimpleVersionReversed.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=2, strict=True)],
        expected_resp_length=lambda length: length % 2 == 0,
        read_only=True,
    )
    """Protocol version as defined in the CCC specification."""

    ccc_supported_uwb_config_id = TlvParamBase(
        tag=0xA5,
        interpret_resp=lambda p: [int.from_bytes(bytes=payload_part, byteorder="little") for payload_part in chunked(iterable=p, n=2, strict=True)],
        expected_resp_length=lambda length: length % 2 == 0,
        read_only=True,
    )
    """UWB configurations are define in chapter "21.4 UWB Frame Elements" of the CCC specification."""

    ccc_supported_pulseshape_combo = TlvParamBase(
        tag=0xA6,
        interpret_resp=lambda p: p,
        expected_resp_length=lambda length: length % 1 == 0,
        read_only=True,
    )
    """
    PulseShape combinations are defined in chapter "21.5.3 PulseShape Combinations" of the CCC specification.
    All possible values defined in CCC specification: 0x00, 0x01, 0x02, 0x10, 0x11, 0x12, 0x20, 0x21, 0x22.
    """

    ccc_minimum_ran_multiplier: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0xA7,
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
            read_only=True,
        ),
        ccc=None,
    )
    """
    Minimum RAN multiplier supported.
    T_Block RAN: RAN_Multiplier x 96 ms
    Time Range: 96 ms to 24480 ms.
    """

    max_payload_len: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0xE3,
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=2,
            read_only=True,
        ),
    )
    """Maximum PSDU length in byte resolution"""

    min_slot_len = TlvParamBase(
        tag=0xE4,
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
        read_only=True,
    )
    """Minimal slot length in RSTU resolution."""

    max_session_num = TlvParamBase(
        tag=0xE5,
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
        read_only=True,
    )
    """Maximum number of sessions."""

    max_anchor_num = TlvParamBase(
        tag=0xE6,
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
        read_only=True,
    )
    """Maximum number of anchors."""

    min_uwb_freq: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0xE7,
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=4,
            read_only=True,
        ),
    )
    """Minimal supported UWB frequency in kHz"""

    max_uwb_freq: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0xE8,
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=4,
            read_only=True,
        ),
    )
    """Maximal supported UWB frequency in kHz"""

    binary_combination: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0xE9,
            interpret_resp=lambda p: PayloadParser(p).extract_dict_from_bitmask(
                bit_mapping={
                    "Responder": 0,
                    "Initiator": 1,
                    "Test/Logging Supported": 2,
                    "Low Power Mode Supported": 3,
                },
                size=1,
            ),
            expected_resp_length=1,
            read_only=True,
        ),
    )
    """Supported Device role and protocols"""


######################################################################################
### Device classes ###################################################################


######################################################################################
### CORE #############################################################################
@dataclass(frozen=True, order=True)
class DeviceResetCmd(CommandBase):
    """
    To reset the UWBD.
        Contains: DEVICE_RESET_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_DEVICE_RESET, init=False)

    reset_configuration: int = field(default=0x00)
    """UWBD reset with 0x00"""

    def create_payload(self):
        return [int(self.reset_configuration) & 0xFF]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(reset_configuration=p.extract_int(1))


@dataclass(frozen=True, order=True)
class DeviceResetRsp(ResponseBase):
    """
    To reset the UWBD.
        Contains: DEVICE_RESET_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


class EnumDeviceStatus(IntEnum):
    STATUS_READY = 0x01  # UWBD is initialized and ready UWB session
    STATUS_ACTIVE = 0x02  # UWBD is busy with UWB session
    STATUS_NOT_SUPPORTED = 0xE3  # Unsupported UWBD type
    STATUS_TESTMODE = 0xE4  # Device is in test mode
    STATUS_REBOOT_ON_HPD_WUP_PIN = 0xFC  # Reset caused by toggling the wake up pin during hard power down
    STATUS_ERROR = 0xFF  # Error occurred within UWBD


@dataclass(frozen=True, order=True)
class DeviceStatusNtf(NotificationBase):
    """
    To notify about the current state of the UWBD. Contains:
        DEVICE_STATUS_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_DEVICE_STATUS, init=False)

    device_status: EnumDeviceStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(device_status=p.extract_enum(EnumDeviceStatus))


@dataclass(frozen=True, order=True)
class GetDeviceInfoCmd(CommandBase):
    """
    To get the UWBD device information. Contains:
        CORE_GET_DEVICE_INFO_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_GET_DEVICE_INFO, init=False)


@dataclass(frozen=True, order=True)
class GetDeviceInfoRsp(ResponseBase):
    """
    To get the UWBD device information. Contains:
        CORE_GET_DEVICE_INFO_RSP
    """

    status: EnumUciStatus
    uci_generic_version: SimpleVersion2
    fira_mac_version: SimpleVersion2
    fira_phy_version: SimpleVersion2
    fira_uci_test_version: SimpleVersion2
    vendor_specific_information_length: int
    vendor_specific_information: VendorSpecificInformation

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)

        device_info = cls(
            status=p.extract_enum(EnumUciStatus),
            uci_generic_version=p.extract_cls(SimpleVersion2, 2),
            fira_mac_version=p.extract_cls(SimpleVersion2, 2),
            fira_phy_version=p.extract_cls(SimpleVersion2, 2),
            fira_uci_test_version=p.extract_cls(SimpleVersion2, 2),
            vendor_specific_information_length=p.extract_int(1),
            vendor_specific_information=p.extract_cls(VendorSpecificInformation, END),
        )
        return device_info


@dataclass(frozen=True, order=True)
class GetCapsInfoCmd(CommandBase):
    """
    To get the UWBD capability information. Contains:
        CORE_GET_CAPS_INFO_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_GET_CAPS_INFO, init=False)


@dataclass(order=True)
class GetCapsInfoRsp(TlvResponseBase):
    """
    To get the UWBD capability information. Contains:
        CORE_GET_CAPS_INFO_RSP

    Params: CapabilityParams
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_parameters = p.extract_int(1)
        capability_data = cls._from_bytes_base(payload=p.extract_list(END), param_class=CapabilityParams) if number_of_parameters > 0 else cls()
        setattr(capability_data, "status", status)
        setattr(capability_data, "number_of_parameters", number_of_parameters)
        return capability_data

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class EnumPortSelection(IntEnum):
    GPIO_12 = 0x02
    GPIO_13 = 0x03
    GPIO_15 = 0x05
    GPIO_16 = 0x06
    GPIO_24 = 0x0C
    DISABLE = 0xFF


@dataclass(frozen=True, order=True)
class TestPinEnable:
    """
    Enable/Disable debug pins. Each octet indicates the dedicated usage of the pin toggling.

    Octet definitions:
    0: Toggle selected pin at every sequence triggering.
    1: Toggle selected pin at every UWB TX/RX done mailbox event.
    2: Toggle selected pin at every crypto operation.
    3: Toggle selected pin at every baseband operation.
    4: Toggle selected pin at every power state transition event.

    Port selection: EnumPortSelection
    """

    pin_toggle_sequence_triggering: EnumPortSelection = field(default=EnumPortSelection.DISABLE)
    pin_toggle_uwb_tx_rx_event: EnumPortSelection = field(default=EnumPortSelection.DISABLE)
    pin_toggle_crypto_operation: EnumPortSelection = field(default=EnumPortSelection.DISABLE)
    pin_toggle_baseband_operation: EnumPortSelection = field(default=EnumPortSelection.DISABLE)
    pin_toggle_power_state_transition_event: EnumPortSelection = field(default=EnumPortSelection.DISABLE)

    def create_payload(self):
        payload = [int(self.pin_toggle_sequence_triggering)]
        payload.append(int(self.pin_toggle_uwb_tx_rx_event))
        payload.append(int(self.pin_toggle_crypto_operation))
        payload.append(int(self.pin_toggle_baseband_operation))
        payload.append(int(self.pin_toggle_power_state_transition_event))
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            pin_toggle_sequence_triggering=p.extract_enum(EnumPortSelection),
            pin_toggle_uwb_tx_rx_event=p.extract_enum(EnumPortSelection),
            pin_toggle_crypto_operation=p.extract_enum(EnumPortSelection),
            pin_toggle_baseband_operation=p.extract_enum(EnumPortSelection),
            pin_toggle_power_state_transition_event=p.extract_enum(EnumPortSelection),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class ConfigParams(ParamBase):
    device_state = TlvParamBase(
        tag=0x00,
        interpret_resp=lambda p: EnumDeviceStatus(p[0]) if p[0] in EnumDeviceStatus._value2member_map_ else p[0],
        expected_resp_length=1,
        read_only=True,
    )
    """
    READ-ONLY!
    Reports device status
    """

    low_power_mode = TlvParamBase(
        tag=0x01,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1]
        else _raise(ValueError, f"LOW_POWER_MODE: {v} is not supported. Choose from True or False"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        This config is used to enable/disable the low-power mode
    False = Disable low-power mode
    True = Enable low-power mode (default)
    """

    reset_timeout = TlvParamBase(
        tag=0xE5,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if isinstance(v, int) and 0 <= v <= 65535
        else _raise(ValueError, f"RESET_TIMEOUT: {v} is not supported. Range: [0..65535]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Reset timeout in ms
        Range: 0..65535ms (Default: 100ms)
    """

    hpd_entry_timeout = TlvParamBase(
        tag=0xEA,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if isinstance(v, int) and 0 <= v <= 65535
        else _raise(ValueError, f"RESET_TIMEOUT: {v} is not supported. Range: [0..65535]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Timeout in ms to enter HPD state
        Range: 0..65535ms (Default: 500ms)
    Note: This parameter is applied if Low Power Mode is supported.
    """

    enable_ddfs = TlvParamBase(
        tag=0xFA,
        convert_to_bytes=lambda v: [int(v)] if v in [0, 1] else _raise(ValueError, f"ENABLE_DDFS: {v} is not supported. Choose from True or False"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        Enable/Disable DDFS During transmission
    False: Disable (default)
    True: Enable
    """

    testpin_enable = TlvParamBase(
        tag=0xFB,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, TestPinEnable)
        else _raise(ValueError, f"TESTPIN_ENABLE {v} is not supported. Provide instance of TestPinEnable"),
        interpret_resp=lambda p: TestPinEnable.from_bytes(p),
        expected_resp_length=2,
    )
    """
    value_type: TestPinEnable
        Enable/Disable debug pins.
    """


@dataclass(order=True)
class SetConfigCmd(TlvCommandBase):
    """
    Used to set the configuration parameters on the UWBD. Contains:
        CORE_SET_CONFIG_CMD

    Params: ConfigParams
    Pass empty list to reset all parameters.
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_SET_CONFIG, init=False)

    def set_parameter(self, param: TlvParamBase, value: Any):
        super()._set_parameter_base(param, value, param_class=ConfigParams, set_command=True)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_parameters = p.extract_int(1)
        set_config_cmd_cls = cls._from_bytes_base(payload=p.extract_list(END), param_class=ConfigParams) if number_of_parameters > 0 else cls()
        setattr(set_config_cmd_cls, "number_of_parameters", number_of_parameters)
        return set_config_cmd_cls

    def __init__(self, params: List[Tuple[TlvParamBase, Any]] = []):
        super().__init__(params)


@dataclass(order=True)
class SetConfigRsp(ResponseBase):
    """
    Used to set the configuration parameters on the UWBD. Contains:
        CORE_SET_CONFIG_RSP
    """

    status: EnumUciStatus
    number_of_invalid_parameters: int
    list_of_invalid_parameters: List[InvalidParam]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_invalid_parameters = p.extract_int(1)
        list_of_invalid_parameters = [
            InvalidParam(tag=(tag := p.extract_int(1)), name=ConfigParams.find_name_by_tag(tag=tag), error_code=p.extract_enum(EnumUciStatus))
            for _ in range(number_of_invalid_parameters)
        ]
        return cls(
            status=status,
            number_of_invalid_parameters=number_of_invalid_parameters,
            list_of_invalid_parameters=list_of_invalid_parameters,
        )


@dataclass(frozen=True, order=True)
class GetConfigCmd(CommandBase):
    """
    Used by the host to retrieve current configuration parameters of the UWBD. Contains:
        CORE_GET_CONFIG_CMD

    Params: ConfigParams
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_GET_CONFIG, init=False)

    param_list: List[TlvParamBase]
    """
    List of ConfigParams attributes.
        Example: [ConfigParams.device_state, ConfigParams.low_power_mode]
    """

    number_of_parameters: int = 0
    """Do NOT set this manually! It is set automatically based on the length of param_list."""

    def __post_init__(self):
        self.number_of_parameters = len(self.param_list)

    def create_payload(self) -> List[int]:
        payload = [len(self.param_list)]

        for param in self.param_list:
            if param not in vars(ConfigParams).values():
                raise AttributeError(f"Param ({param}) not part of {ConfigParams.__class__.__name__}!")
            payload.append(param.tag)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_parameters = p.extract_int(1)
        param_tags = p.extract_list(END)
        return cls(
            number_of_parameters=number_of_parameters,
            param_list=[ConfigParams.find_name_by_tag(tag) for tag in param_tags],
        )

    def __str__(self) -> str:
        if any([isinstance(param, str) for param in self.param_list]):
            return class_to_str(self, include_title=True, indent_level=0)
        else:
            _self = deepcopy(self)
            _self.param_list = [f"{name} ({as_hex(value.tag)})" for name, value in vars(ConfigParams).items() if value in self.param_list]
            return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(order=True)
class GetConfigRsp(TlvResponseBase):
    """
    Used by the host to retrieve current configuration parameters of the UWBD. Contains:
        CORE_GET_CONFIG_RSP
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_parameters = p.extract_int(1)
        get_config_rsp = cls._from_bytes_base(payload=p.extract_list(END), param_class=ConfigParams) if number_of_parameters > 0 else cls()
        setattr(get_config_rsp, "status", status)
        setattr(get_config_rsp, "number_of_parameters", number_of_parameters)
        return get_config_rsp

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


@dataclass(frozen=True, order=True)
class GenericErrorNtf(NotificationBase):
    """CORE_GENERIC_ERROR_NTF"""

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UCI_CORE, init=False)
    _oid_: EnumOidCore = field(default=EnumOidCore.OID_CORE_GENERIC_ERROR, init=False)

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


######################################################################
### SESSION CONFIG ###################################################


class EnumSessionType(IntEnum):
    FIRA_RANGING_SESSION = 0x00
    CCC_RANGING_SESSION = 0xA0
    RADAR_SESSION = 0xC0  # Only AiO
    DEVICE_TEST_MODE = 0xD0
    CUSTOM_SESSION = 0xE0
    CUSTOM_SESSION_ONLY_RANGING_FRAMES = 0xE1


class EnumSessionState(IntEnum):
    SESSION_STATE_INIT = 0x00
    SESSION_STATE_DEINIT = 0x01
    SESSION_STATE_ACTIVE = 0x02
    SESSION_STATE_IDLE = 0x03
    SESSION_ERROR = 0xFF


class EnumMulticastAction(IntEnum):
    ADD_CONTROLEE = 0x00
    DELETE_CONTROLEE = 0x01
    ADD_CONTROLEE_16_SUB_SESSION_KEY = 0x02
    ADD_CONTROLEE_32_SUB_SESSION_KEY = 0x03


class EnumSessionReason(IntEnum):
    # Reason codes defined in the Generic UCI Specification
    STATE_CHANGE_WITH_SESSION_MANAGEMENT_COMMANDS = 0x00
    MAX_RANGING_ROUND_RETRY_COUNT_REACHED = 0x01
    MAX_RANGING_BLOCKS_REACHED = 0x02

    # Proprietary use
    KEY_FETCH_FAILURE = 0x81
    SESSION_STOPPED_DUE_TO_INBAND_SIGNAL = 0x83
    BASEBAND_ERROR = 0x84
    TEST_MODE_TERMINATED = 0x85

    # Reason codes valid only for the CCC session
    URSK_EXPIRED = 0xA0
    TERMINATION_ON_MAX_STS = 0xA1

    # Reason codes valid only for radar sessions
    MAX_RADAR_ROUNDS_REACHED = 0xC0  # Only AiO


class EnumDeviceType(IntEnum):
    CONTROLEE = 0x00  # FiRa, User defined
    CONTROLLER = 0x01  # FiRa, User defined
    CCC_Controller__Device = 0xA0  # CCC
    CCC_Controlee__Vehicle = 0xA1  # CCC


class EnumRangingRoundUsage(IntEnum):
    SS_TWR_DEFERRED_MODE = 0x01  # FiRa only
    DS_TWR_DEFERRED_MODE = 0x02  # FiRa only


class EnumStsConfig(IntEnum):
    STATIC_STS = 0x00
    DYNAMIC_STS = 0x01
    DYNAMIC_STS_RESPONDER_SPECIFIC_SUB_SESSION_KEY = 0x02  # FiRa only # not supported
    PROVISIONED_STS = 0x03  # FiRa only
    PROVISIONED_STS_RESPONDER_SPECIFIC_SUB_SESSION_KEY = 0x04  # FiRa only # not supported


class EnumMultiNodeMode(IntEnum):
    UNICAST = 0x00  # Single device to Single device
    MULTICAST = 0x01  # One to Many


class EnumMacFcsType(IntEnum):
    CRC16 = 0x00
    CRC32 = 0x01


class EnumFiRaMessages(IntEnum):
    NONE = 0x00  # No messages enabled
    RRRM = 0x01  # Ranging Result Report Message (Bit[0])
    CM = 0x02  # Control Message (Bit[1])
    CM_AND_RRRM = 0x03  # Both Control Message and RRRM enabled (Bits[1, 0])


class EnumUserDefinedMessages(IntEnum):
    NONE = 0x00  # No messages enabled
    CM = 0x02  # Control Message (Bit[1])
    CM_AND_RRRM = 0x03  # Both Control Message and RRRM enabled (Bits[1, 0])


@dataclass(order=True, frozen=True)
class RangingRoundControl:
    """
    This parameter is used to tell the UWBS which messages will be included in a Ranging Round.

    Decoded both for fira and user defined as class has no knowledge which is correct.
    """

    fira: EnumFiRaMessages | None = None
    """value type: EnumFiRaMessages"""

    user_defined: EnumUserDefinedMessages | None = None
    """value_type: EnumUserDefinedMessages"""

    def create_payload(self) -> List[int]:
        if (self.fira is None) == (self.user_defined is None):
            raise ValueError("Set either 'fira' or 'user_defined'.")
        payload = [int(self.fira)] if self.fira is not None else [int(self.user_defined)]
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        # Determine the FiRa configuration
        fira = PayloadParser(payload).extract_enum(EnumFiRaMessages)

        # Determine the UserDefined configuration
        user_defined = PayloadParser(payload).extract_enum(EnumUserDefinedMessages)

        return cls(fira=fira, user_defined=user_defined)

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class EnumRngDataNtf(IntEnum):
    DISABLE_RANGE_DATA_NTF = 0x00
    ENABLE_RANGE_DATA_NTF = 0x01
    ENABLE_RANGE_DATA_NTF_WHILE_IN_PROXIMITY = 0x02
    ENABLE_RANGE_DATA_NTF_WHILE_IN_AOA_BOUNDS = 0x03
    ENABLE_RANGE_DATA_NTF_WHILE_IN_PROXIMITY_AND_AOA_BOUNDS = 0x04
    ENABLE_RANGE_DATA_NTF_WHEN_ENTERING_LEAVING_PROXIMITY = 0x05
    ENABLE_RANGE_DATA_NTF_WHEN_ENTERING_LEAVING_AOA_BOUNDS = 0x06
    ENABLE_RANGE_DATA_NTF_WHEN_ENTERING_LEAVING_PROXIMITY_AND_AOA_BOUNDS = 0x07


class EnumAoaResultReq(IntEnum):
    AOA_RESULTS_DISABLED = 0x00
    AOA_RESULTS_ENABLED = 0x01
    ONLY_AOA_AZIMUTH_ENABLED = 0x02
    ONLY_AOA_ELEVATION_ENABLED = 0x03


class EnumDeviceRole(IntEnum):
    RESPONDER = 0x00
    INITIATOR = 0x01


class EnumPsduDataRate(IntEnum):
    MBITS_6_81 = 0x00
    MBITS_7_80 = 0x01
    MBITS_27_2 = 0x02
    KBITS_850 = 0x04


class EnumPreambleDuration(IntEnum):
    SYMBOLS_32 = 0x00
    SYMBOLS_64 = 0x01


class EnumRangingTimeStruct(IntEnum):
    BLOCK_BASED_SCHEDULING = 0x01


@dataclass(frozen=True, order=True)
class Controlee:
    "Instance of one controlee for multicast list"

    short_address: int
    sub_session_id: int
    sub_session_key: List[int] | None = None

    def create_payload(self) -> List[int]:
        payload = []
        payload += to_hex_list(input=self.short_address, byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=int(self.sub_session_id), byteorder="little", forced_list_len=4)
        if self.sub_session_key is not None:
            payload += self.sub_session_key
        return payload

    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        short_address = p.extract_int(2)
        sub_session_id = p.extract_int(4)
        if len(payload) > 6:
            sub_session_key = p.extract_list(END)

        return cls(
            short_address=short_address,
            sub_session_id=sub_session_id,
            sub_session_key=sub_session_key,
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class MulticastStatus(IntEnum):
    STATUS_OK_MULTICAST_LIST_UPDATE = 0x00
    STATUS_ERROR_MULTICAST_LIST_FULL = 0x01
    STATUS_ERROR_KEY_FETCH_FAIL = 0x02
    STATUS_ERROR_SUB_SESSION_ID_NOT_FOUND = 0x03
    STATUS_ERROR_SUB_SESSION_KEY_NOT_FOUND = 0x04
    STATUS_ERROR_SUB_SESSION_KEY_NOT_APPLICABLE = 0x05
    STATUS_ERROR_SESSION_KEY_NOT_FOUND = 0x06
    STATUS_ERROR_ADDRESS_NOT_FOUND = 0x07
    STATUS_ERROR_ADDRESS_ALREADY_PRESENT = 0x08


class ControleeStatus:
    """Status of a controlee."""

    mac_address: int
    status: MulticastStatus

    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            mac_address=p.extract_int(2),
            status=p.extract_enum(MulticastStatus),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class AoaBoundConfig:
    """
    This parameter sets the lower and upper bound in degrees for AoA Azimuth and Elevation.
    """

    aoa_azimuth_lower_bound: float
    """value_type: float (Range: [-180° - 180°])"""
    aoa_azimuth_upper_bound: float
    """value_type: float (Range: [-180° - 180°])"""
    aoa_elevation_lower_bound: float
    """value_type: float (Range: [-90° - 90°])"""
    aoa_elevation_upper_bound: float
    """value_type: float (Range: [-90° - 90°])"""

    def create_payload(self):
        if abs(self.aoa_azimuth_lower_bound) > 180:
            raise ValueError(f"aoa_azimuth_lower_bound: {self.aoa_azimuth_lower_bound} is not supported. Range: [-180° - 180°]")
        if abs(self.aoa_azimuth_upper_bound) > 180:
            raise ValueError(f"aoa_azimuth_upper_bound: {self.aoa_azimuth_upper_bound} is not supported. Range: [-180° - 180°]")
        if abs(self.aoa_elevation_lower_bound) > 90:
            raise ValueError(f"aoa_elevation_lower_bound: {self.aoa_elevation_lower_bound} is not supported. Range: [-90° - 90°]")
        if abs(self.aoa_elevation_upper_bound) > 90:
            raise ValueError(f"aoa_elevation_upper_bound: {self.aoa_elevation_upper_bound} is not supported. Range: [-90° - 90°]")
        payload = to_hex_list(input=round(self.aoa_azimuth_lower_bound * 128), byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=round(self.aoa_azimuth_upper_bound * 128), byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=round(self.aoa_elevation_lower_bound * 128), byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=round(self.aoa_elevation_upper_bound * 128), byteorder="little", forced_list_len=2)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            aoa_azimuth_lower_bound=p.extract_int(2, signed=True) / 128,
            aoa_azimuth_upper_bound=p.extract_int(2, signed=True) / 128,
            aoa_elevation_lower_bound=p.extract_int(2, signed=True) / 128,
            aoa_elevation_upper_bound=p.extract_int(2, signed=True) / 128,
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class EnumPrfMode(IntEnum):
    MHZ_62_4_BPRF = 0x00
    MHZ_124_8_HPRF = 0x01


class EnumScheduleMode(IntEnum):
    CONTENTION_BASED_RANGING = 0x00  # not supported
    TIME_SCHEDULED_RANGING = 0x01


class EnumKeyRotation(IntEnum):
    NO_ROTATION = 0x00
    STS_KEY_ROTATION = 0x01
    DUDSK_ROTATION = 0x02
    STS_KEY_AND_DUDSK_ROTATION = 0x03


class EnumHoppingMode(IntEnum):
    NO_HOPPING = 0x00  # FiRa and CCC

    FIRA_HOPPING_ENABLED = 0x01
    FIRA_ADAPTIVE_HOPPING = 0xE0

    CCC_CONTINUOUS_HOPPING_AES = 0xA0
    CCC_CONTINUOUS_HOPPING_DEFAULT = 0xA1
    CCC_ADAPTIVE_HOPPING_AES = 0xA2
    CCC_ADAPTIVE_HOPPING_DEFAULT = 0xA3

    ADAPTIVE_HOPPING_USING_MODULO = 0x02
    CONTINUOUS_HOPPING_USING_MODULO = 0x03
    ADAPTIVE_HOPPING_USING_AES = 0x04
    CONTINUOUS_HOPPING_USING_AES = 0x05


@dataclass(order=True, frozen=True)
class ResultReportConfig:
    tof_report: bool
    aoa_azimuth_report: bool
    aoa_elevation_report: bool
    aoa_fom_report: bool

    def create_payload(self):
        payload = 0
        payload |= self.tof_report << 0
        payload |= self.aoa_azimuth_report << 1
        payload |= self.aoa_elevation_report << 2
        payload |= self.aoa_fom_report << 3
        return [payload]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            tof_report=bool(p.extract_bits(1)),
            aoa_azimuth_report=bool(p.extract_bits(1)),
            aoa_elevation_report=bool(p.extract_bits(1)),
            aoa_fom_report=bool(p.extract_bits(1)),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class EnumStsLength(IntEnum):
    SYMBOLS_32 = 0x00
    SYMBOLS_64 = 0x01
    SYMBOLS_128 = 0x02
    SYMBOLS_16 = 0xE0
    SYMBOLS_RADIO_CONFIG = 0xFF


class EnumDcFilter(IntEnum):
    DISABLE = 0x00
    ENABLE_DC_FILTER_RX1 = 0x01
    ENABLE_DC_FILTER_RX2 = 0x02
    ENABLE_DC_FILTER_RX1_RX2 = 0x03


class EnumRangingReportNtf(IntEnum):
    SESSION_INFO_NTF = 0x00
    RANGE_CCC_DATA_NTF = 0x01


class EnumAntennaSelection(IntEnum):
    RX1 = 0x00
    RX2 = 0x01


class EnumFilterBandwidthLinPhase(IntEnum):
    LIN_PHASE_12_MHZ = 0x00
    LIN_PHASE_27_MHZ = 0x01
    LIN_PHASE_56_MHZ = 0x02
    LIN_PHASE_108_MHZ = 0x03
    LIN_PHASE_160_MHZ = 0x04
    LIN_PHASE_320_MHZ = 0x05


class EnumFilterBandwidthMinimum(IntEnum):
    MINIMUM_0_6_MHZ = 0x00
    MINIMUM_1_2_MHZ = 0x01
    MINIMUM_3_MHZ = 0x02


class EnumNbicFilterType(IntEnum):
    LINEAR = 0x00
    MINIMUM = 0x01


class EnumNbicMode(IntEnum):
    DISABLED = 0x00
    ENABLED_MANUAL_JAMMER_DETECTION = 0x01
    ENABLED_AUTO_JAMMER_DETECTION = 0x02
    TRACKING_MODE_JAMMER_DETECTION = 0x03


class EnumAntennas(IntEnum):
    RX1 = 0x00
    RX2 = 0x01


@dataclass(frozen=True, order=True)
class NbicConfig:
    """
    Configuration of Narrow Band Interference Control Block (NBIC).
    NBIC enables Co- Channel rejection.
    """

    antenna_selection: EnumAntennaSelection

    filter_bandwidth: EnumFilterBandwidthLinPhase | EnumFilterBandwidthMinimum
    """
    Range: [EnumFilterBandwidthLinPhase] (12, 27, 54, 108, 160, 320 MHz) for linear phase filter type.
    Range: [EnumFilterBandwidthMinimum] (0.6, 1.2, 3 MHz) for minimum phase filter type.
    """

    filter_type: EnumNbicFilterType

    nbic_mode: EnumNbicMode

    center_frequency: int
    """Center frequency  in MHz in ~0.015 MHz steps.
        Range: [-500 MHz to (500-0.015)] MHz
    """

    def create_payload(self):
        payload = (
            [int(self.antenna_selection)]
            if isinstance(self.antenna_selection, EnumAntennaSelection)
            or (isinstance(self.antenna_selection, int) and self.antenna_selection in [0, 1])
            else _raise(
                ValueError,
                f"antenna_selection: {self.antenna_selection} not supported. Please provide an attribute of EnumAntennaSelection",
            )
        )

        filter_bw = (
            int(self.filter_bandwidth)
            if isinstance(self.filter_bandwidth, EnumFilterBandwidthLinPhase)
            or isinstance(self.filter_bandwidth, EnumFilterBandwidthLinPhase)
            or (isinstance(self.filter_bandwidth, int) and self.filter_bandwidth in [0, 1, 2, 3, 4, 5])
            else _raise(
                ValueError,
                f"filter_bandwidth: {self.filter_bandwidth} not supported. Please provide an attribute of EnumFilterBandwidthLinPhase or EnumFilterBandwidthLinPhase",
            )
        )

        filter_type = (
            int(self.filter_type)
            if isinstance(self.filter_type, EnumNbicFilterType) or (isinstance(self.filter_type, int) and self.filter_type in [0, 1])
            else _raise(
                ValueError,
                f"filter_type: {self.filter_type} not supported. Please provide an attribute of EnumNbicFilterType",
            )
        )

        conf_byte = 0x00
        # Encode Filter Bandwidth (Bits 0-3)
        conf_byte |= filter_bw & 0x0F
        # Encode Filter Type (Bits 4-7)
        conf_byte |= (filter_type & 0x0F) << 4
        # Add to payload
        payload += [conf_byte]

        payload += (
            [int(self.nbic_mode)]
            if isinstance(self.nbic_mode, EnumNbicMode) or (isinstance(self.nbic_mode, int) and self.nbic_mode in [0, 1, 2, 3])
            else _raise(
                ValueError,
                f"nbic_mode: {self.nbic_mode} not supported. Please provide an attribute of EnumNbicMode",
            )
        )

        center_frequency = (
            self.center_frequency
            if isinstance(self.center_frequency, (int, float)) and -500 <= self.center_frequency <= 500 - 0.015
            else _raise(
                ValueError,
                f"center_frequency: {self.center_frequency} not supported. Range: [-500 .. (500-0.015) MHz]; Steps: ~0.015 MHZ",
            )
        )

        # Encode Center Frequency (Bits 15-31)
        step_size = 500 / 32768  # 0.0152587890625 MHz
        center_frequency_steps = int(round(center_frequency / step_size))
        payload += to_hex_list(center_frequency_steps, byteorder="little", signed=True, forced_list_len=2)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        antenna_selection = p.extract_enum(EnumAntennaSelection)

        filter_bandwidth_raw = p.extract_bits(4)
        filter_type = p.extract_enum_bits(EnumNbicFilterType, 4)

        nbic_mode = p.extract_enum(EnumNbicMode)
        center_frequency_raw = p.extract_int(2, signed=True)

        if filter_type == EnumNbicFilterType.LINEAR:
            filter_bandwidth = (
                EnumFilterBandwidthLinPhase(filter_bandwidth_raw)
                if filter_bandwidth_raw in EnumFilterBandwidthLinPhase._value2member_map_
                else filter_bandwidth_raw
            )
        else:
            filter_bandwidth = (
                EnumFilterBandwidthMinimum(filter_bandwidth_raw)
                if filter_bandwidth_raw in EnumFilterBandwidthMinimum._value2member_map_
                else filter_bandwidth_raw
            )

        step_size = 500 / 32768
        center_frequency = center_frequency_raw * step_size  # Convert to MHz

        return cls(
            antenna_selection=antenna_selection,
            filter_bandwidth=filter_bandwidth,
            filter_type=filter_type,
            nbic_mode=nbic_mode,
            center_frequency=center_frequency,
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class EnumKeyEncryption(IntEnum):
    PLAIN = 0x00
    ENCRYPTED = 0x01


@dataclass(frozen=True, order=True)
class Ursk:
    """UWB Ranging Session Key"""

    key_encryption_information: EnumKeyEncryption = 0x00
    """Supported value: key transmitted plain (0x00)"""

    key: List[int] = field(default_factory=[])
    """UWB Ranging Session Key (URSK). Based on this key all other keys used in Ranging are derived."""

    def create_payload(self):
        if int(self.key_encryption_information) == 0 and isinstance(self.key, list) and len(self.key) == 32:
            return [int(self.key_encryption_information)] + self.key
        else:
            raise ValueError("Provided instance of Ursk is not supported.")

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            key_encryption_information=p.extract_enum(EnumKeyEncryption),
            key=p.extract_list(END),
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(frozen=True, order=True)
class FiraSessionKey:
    """FiRa session key"""

    key_encryption_information: EnumKeyEncryption = 0x00
    """Supported value: key transmitted plain (0x00)"""

    key: List[int] = field(default_factory=[])
    """FiRa session key. Based on this key all other keys used in the ranging round are derived."""

    def create_payload(self):
        if int(self.key_encryption_information) == 0 and isinstance(self.key, list) and len(self.key) == 16:
            return [int(self.key_encryption_information)] + self.key
        else:
            raise ValueError("Provided instance of FiraSessionKey is not supported.")

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            key_encryption_information=p.extract_enum(EnumKeyEncryption),
            key=p.extract_list(END),
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(frozen=True, order=True)
class StaticKeys:
    """
    CCC: Key values:
        M_URSK: 32 octets
        M_UPSK1: 16 octets
        SALTED_HASH: 16 octets
        D_URSK: 16 octets
        D_UDSK: 16 octets

    FiRa:
        DERIVED_CONFIG_DIGEST: 16 octets
        DATA_PRIVACY_KEY: 16 octets
        DATA_PROTECTION_KEY: 16 octets
        DATA_AUTHENTICATION_IV: 16 octets
        DATA_AUTHENTICATION_KEY: 16 octets
        DERIVED_PAYLOAD_KEY: 16 octets
    """

    key_type: EnumCccKeyType | EnumFiRaKeyType
    """
    CCC: EnumCccKeyType
    FiRa: EnumFiRaKeyType
    """

    key_encryption_enabled: bool
    """
    False: Key transmitted in plain.
    True: Key transmitted encrypted by SETPK (only CCC MAC firmware)
    """

    key: List[int]
    """
    Key values:

    CCC: Key values:
        M_URSK: 32 octets
        M_UPSK1: 16 octets
        SALTED_HASH: 16 octets
        D_URSK: 16 octets
        D_UDSK: 16 octets

    FiRa:
        DERIVED_CONFIG_DIGEST: 16 octets
        DATA_PRIVACY_KEY: 16 octets
        DATA_PROTECTION_KEY: 16 octets
        DATA_AUTHENTICATION_IV: 16 octets
        DATA_AUTHENTICATION_KEY: 16 octets
        DERIVED_PAYLOAD_KEY: 16 octets
    """

    def create_payload(self) -> List[int]:
        if isinstance(self.key_type, (EnumCccKeyType, EnumFiRaKeyType)) and isinstance(self.key, list):
            return [int(self.key_type), int(self.key_encryption_enabled)] + self.key
        else:
            raise ValueError("Provided instance of StaticKeys is not supported.")

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            key_type=p.extract_enum(EnumKeyType),
            key_encryption_enabled=p.extract_bool(1),
            key=p.extract_list(END),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class EnumKeyType(IntEnum):
    """
    Needed for interpretation.
    Use 'EnumCccKeyType' or 'EnumFiRaKeyType' to set key_type of StaticKeys
    """

    CCC_M_URSK__FIRA_DERIVED_CONFIG_DIGEST = 0x01
    CCC_M_UPSK1__FIRA_DATA_PRIVACY_KEY = 0x02
    CCC_SALTED_HASH__FIRA_DATA_PROTECTION_KEY = 0x03
    CCC_D_URSK__FIRA_DATA_AUTHENTICATION_IV = 0x04
    CCC_D_UDSK__FIRA_DATA_AUTHENTICATION_KEY = 0x05
    FIRA_DERIVED_PAYLOAD_KEY = 0x06


class EnumCccKeyType(IntEnum):
    M_URSK = 0x01
    M_UPSK1 = 0x02
    SALTED_HASH = 0x03
    D_URSK = 0x04
    D_UDSK = 0x05


class EnumFiRaKeyType(IntEnum):
    DERIVED_CONFIG_DIGEST = 0x01
    DATA_PRIVACY_KEY = 0x02
    DATA_PROTECTION_KEY = 0x03
    DATA_AUTHENTICATION_IV = 0x04
    DATA_AUTHENTICATION_KEY = 0x05
    DERIVED_PAYLOAD_KEY = 0x06


class EnumUsageSync(IntEnum):
    SYNCHRONIZATION_PHASE = 0x00
    AFTER_SYNCHRONIZATION = 0x01


@dataclass(frozen=True, order=True)
class RcmRxMarginTime:
    """
    Margin time in μs resolution which is used to start RX for the ranging control message(RCM).

    1st octet [EnumUsageSync]: Usage of RCM_RX_MARGIN_TIME
        0: While in synchronization phase with valid UWB_INITIATION_TIME or if the resynchronization trial number exceed RR_RETRY_THR
        1: After the session has been synchronized.

    2 Octets [int]: μs resolution margin time. Range: 50μs..40000μs / 0x32.. 0x9C40

    Default for usage 0 (SYNCHRONIZATION_PHASE): 4000μs / 0xFA0
    Default for usage 1 (AFTER_SYNCHRONIZATION): 2000μs / 0x7D0
    """

    usage: EnumUsageSync
    margin_time_us: int

    def create_payload(self) -> List[int]:
        payload = (
            [self.usage.value]
            if isinstance(self.usage, EnumUsageSync)
            else [int(self.usage)]
            if isinstance(self.usage, int) and self.usage in [0, 1]
            else _raise(ValueError, f"usage: {self.usage} not supported. Please provide an attribute of EnumUsageSync")
        )
        payload += (
            to_hex_list(input=self.margin_time_us, byteorder="little", forced_list_len=2)
            if isinstance(self.margin_time_us, int) and (0x32 <= self.margin_time_us <= 0x9C40)
            else _raise(ValueError, f"margin_time_us: {self.margin_time_us} not supported. Please provide an int in range [50 .. 40000]")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            usage=p.extract_enum(EnumUsageSync),
            margin_time_us=p.extract_int(2),
        )

    def __str__(self):
        _self = deepcopy(self)
        _self.margin_time_us = f"{self.margin_time_us} μs"
        return class_to_str(_self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class RcmRxTimeout:
    """
    Timeout in μs resolution for opening RX analog channel for ranging control message(RCM).

    1st octet [EnumUsageSync]: Usage of RCM_RX_TIMEOUT
        0: While in synchronization phase with valid UWB_INITIATION_TIME or if the resynchronization trial number exceed RR_RETRY_THR
        1: After the session has been synchronized.

    2 Octets [int]: μs resolution timeout. Range: 50us..40000μs / 0x32.. 0x9C40

    Default for usage 0 (SYNCHRONIZATION_PHASE): 4000μs / 0xFA0
    Default for usage 1 (AFTER_SYNCHRONIZATION): 1000μs / 0x7D0
    """

    usage: EnumUsageSync
    timeout_us: int

    def create_payload(self) -> List[int]:
        payload = (
            [self.usage.value]
            if isinstance(self.usage, EnumUsageSync)
            else [int(self.usage)]
            if isinstance(self.usage, int) and self.usage in [0, 1]
            else _raise(ValueError, f"usage: {self.usage} not supported. Please provide an attribute of EnumUsageSync")
        )
        payload += (
            to_hex_list(input=self.timeout_us, byteorder="little", forced_list_len=2)
            if isinstance(self.timeout_us, int) and (0x32 <= self.timeout_us <= 0x9C40)
            else _raise(ValueError, f"timeout_us: {self.timeout_us} not supported. Please provide an int in range [50 .. 40000]")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            usage=p.extract_enum(EnumUsageSync),
            timeout_us=p.extract_int(2),
        )

    def __str__(self):
        _self = deepcopy(self)
        _self.timeout_us = f"{self.timeout_us} μs"
        return class_to_str(_self, include_title=True, indent_level=2)


class EnumDynamicPriority(IntEnum):
    DISABLED = 0x00
    ENABLED = 0x01
    ENABLED_AFTER_SYNCHRONIZATION = 0x02


@dataclass(frozen=True, order=True)
class RccThreshold:
    """
    - Ranging consistency check threshold value in 0.1 ns resolution.
        0x00: RCC check is disabled.
        0.1..25.5 ns
        Default: 20 (2 ns)

    - Ranging consistency check threshold value in 0.001ppm resolution.
        0x00: RCC check is disabled.
        0.001..0.255 ppm
        Default: 75 (0.075 ppm)

    Note: If one of threshold values are 0 then RCC check is disabled.
    """

    rcc_threshold_ns: float
    """Range: [0.1..25.5]ns, Resolution: 0.1 ns"""

    rcc_threshold_ppm: float
    """Range: [0.001..0.255]ppm, Resolution: 0.001 ppm"""

    def create_payload(self) -> List[int]:
        payload = (
            [int(round(self.rcc_threshold_ns, 1) / 0.1)]
            if 0 <= self.rcc_threshold_ns <= 25.5
            else _raise(ValueError, f"rcc_threshold_ns {self.rcc_threshold_ns} is not supported. Range: [0..25.5]ns, Resolution: 0.1 ns")
        )
        payload += (
            [int(round(self.rcc_threshold_ppm, 1) / 0.001)]
            if 0 <= self.rcc_threshold_ns <= 0.255
            else _raise(ValueError, f"rcc_threshold_ppm {self.rcc_threshold_ppm} is not supported. Range: [0..0.255]ppm, Resolution: 0.001 ppm")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rcc_threshold_ns=p.extract_int(1) * 0.1,
            rcc_threshold_ppm=p.extract_int(1) * 0.001,
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class EnumRxEnable(IntEnum):
    RX1_ENABLE = 0x01
    RX2_ENABLE = 0x02
    RX1_RX2_ENABLE = 0x03


class EnumTxEnable(IntEnum):
    TX1_ENABLE = 0x01
    TX2_ENABLE = 0x02


@dataclass(frozen=True, order=True)
class RxTxEnable:
    """
    RX Enable:
        0x01: RX1 enabled.
        0x02: RX2 enabled.
        0x03: RX1 and RX2 are enabled

    TX Enable:
        0x01: TX1 enabled.
        0x02: TX2 enabled.

    Default: RX1 and TX1 are enabled.
    """

    rx_enable: EnumRxEnable
    tx_enable: EnumTxEnable

    def create_payload(self) -> List[int]:
        payload = [int(self.rx_enable), int(self.tx_enable)]
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rx_enable=p.extract_enum(EnumRxEnable),
            tx_enable=p.extract_enum(EnumTxEnable),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class LoggingEnable:
    """
    Enable/Disable logging for: radar, rx phy, tx phy.

    AiO: If the RADAR_STATUS_NTF is enabled a notification will be generated when the ranging round finished.
    CCC: Enable 'radar_status_ntf_enable' to enable 'radar_log_enable'
    """

    radar_status_ntf_enable: bool = True
    """
    AiO: enables radar notification
    CCC: enables radar log
    """
    rx_phy_logging_enable: bool = False
    tx_phy_logging_enable: bool = False

    def create_payload(self) -> List[int]:
        payload = [int(self.radar_status_ntf_enable), int(self.rx_phy_logging_enable), int(self.tx_phy_logging_enable)]
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            radar_status_ntf_enable=p.extract_bool(1),
            rx_phy_logging_enable=p.extract_bool(1),
            tx_phy_logging_enable=p.extract_bool(1),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(order=True)
class LogParamsConfig:
    rx_status_and_error: bool = False
    tx_status_and_error: bool = False
    cir_log: bool = False
    uwb_session_id: bool = False
    block_index: bool = False
    rx_timestamp: bool = False
    tx_timestamp: bool = False
    rx_psdu: bool = False
    tx_psdu: bool = False
    sts_index: bool = False
    rx_first_path_info: bool = False
    rx_carrier_frequency_offset: bool = False
    mac_decoding_status: bool = False
    reason_mac_decoding_failure: bool = False
    mac_frame_compliance: bool = False
    rx_mac_header: bool = False
    rx_mac_payload: bool = False
    scheduler_status: bool = False
    scheduler_info: bool = False
    rx_pdoa_result: bool = False
    rx_phr: bool = False

    def create_payload(self):
        payload = 0
        payload |= self.rx_status_and_error << 0
        payload |= self.tx_status_and_error << 1
        payload |= self.cir_log << 2
        payload |= self.uwb_session_id << 3
        payload |= self.block_index << 4
        payload |= self.rx_timestamp << 5
        payload |= self.tx_timestamp << 6
        payload |= self.rx_psdu << 7
        payload |= self.tx_psdu << 8
        payload |= self.sts_index << 9
        payload |= self.rx_first_path_info << 10
        payload |= self.rx_carrier_frequency_offset << 11
        payload |= self.mac_decoding_status << 12
        payload |= self.reason_mac_decoding_failure << 13
        payload |= self.mac_frame_compliance << 14
        payload |= self.rx_mac_header << 15
        payload |= self.rx_mac_payload << 16
        payload |= self.scheduler_status << 17
        payload |= self.scheduler_info << 18
        payload |= self.rx_pdoa_result << 19

        if mac_config.MAC_FW_TYPE == "AiO":
            payload |= self.rx_phr << 20

        return to_hex_list(input=payload, byteorder="little", forced_list_len=4)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rx_status_and_error=bool(p.extract_bits(1)),
            tx_status_and_error=bool(p.extract_bits(1)),
            cir_log=bool(p.extract_bits(1)),
            uwb_session_id=bool(p.extract_bits(1)),
            block_index=bool(p.extract_bits(1)),
            rx_timestamp=bool(p.extract_bits(1)),
            tx_timestamp=bool(p.extract_bits(1)),
            rx_psdu=bool(p.extract_bits(1)),
            tx_psdu=bool(p.extract_bits(1)),
            sts_index=bool(p.extract_bits(1)),
            rx_first_path_info=bool(p.extract_bits(1)),
            rx_carrier_frequency_offset=bool(p.extract_bits(1)),
            mac_decoding_status=bool(p.extract_bits(1)),
            reason_mac_decoding_failure=bool(p.extract_bits(1)),
            mac_frame_compliance=bool(p.extract_bits(1)),
            rx_mac_header=bool(p.extract_bits(1)),
            rx_mac_payload=bool(p.extract_bits(1)),
            scheduler_status=bool(p.extract_bits(1)),
            scheduler_info=bool(p.extract_bits(1)),
            rx_pdoa_result=bool(p.extract_bits(1)),
            rx_phr=bool(p.extract_bits(1)) if mac_config.MAC_FW_TYPE == "AiO" else None,
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(frozen=True, order=True)
class CryptoKeyUsageFlag:
    calculate_mUPSK1: bool = True
    """
    True: Calculate mUPSK1 (default)
    False: Use static key
    """
    calculate_mURSK: bool = True
    """
    True: Calculate mURSK (default)
    False: Use static key
    """
    calculate_salted_hash: bool = True
    """
    True: Calculate salted hash (default)
    False: Use static key
    """
    calculate_dURSK: bool = True
    """
    True: Calculate dURSK (default)
    False: Use static key
    """
    calculate_dUDSK: bool = True
    """
    True: Calculate dUDSK (default)
    False: Use static key
    """
    calculate_UAD: bool = True
    """
    True: Calculate UAD (default)
    False: Use static key
    """
    encrypt_payload: bool = True
    """
    True: Encrypt payload (default)
    False: Use plaintext payload
    """
    responder_follows_initiator_round_index: bool = True
    """
    True: Responder follows initiator's round index in the final data message. (default)
    False: Responder uses its own hopping calculation.
    """

    def create_payload(self):
        options_int = 0
        options_int |= self.calculate_mUPSK1 << 0
        options_int |= self.calculate_mURSK << 1
        options_int |= self.calculate_salted_hash << 2
        options_int |= self.calculate_dURSK << 3
        options_int |= self.calculate_dUDSK << 4
        options_int |= self.calculate_UAD << 5
        options_int |= self.encrypt_payload << 6
        options_int |= self.responder_follows_initiator_round_index << 7
        return to_hex_list(input=options_int, byteorder="little", forced_list_len=2)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            calculate_mUPSK1=bool(p.extract_bits(1)),
            calculate_mURSK=bool(p.extract_bits(1)),
            calculate_salted=bool(p.extract_bits(1)),
            calculate_dURSK=bool(p.extract_bits(1)),
            calculate_dUDSK=bool(p.extract_bits(1)),
            calculate_UAD=bool(p.extract_bits(1)),
            encrypt_payload=bool(p.extract_bits(1)),
            responder_follows_initiator_round_index=bool(p.extract_bits(1)),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


class StartMarginTimeUsage(IntEnum):
    CONFIGURE_MARGIN_TIME_FIRST_ROUND = 0x0
    """
    The parameter used to configure margin time from SESSION_START_CMD to actual starting time
    of the first ranging round. This shall be configured according to the application implementation.
    It may include session key derivation times, activates PLL times and so on.

    Note: It can be configurable only while the session is in the idle state.
    """

    CONFIGURE_MARGIN_TIME_NEXT_ROUND = 0x1
    """
    The parameter used to configure margin time from the end of the previous ranging round to the
    actual staring time of the next ranging round. This shall be configured according to the application
    implementation. It may include round key derivation times, activates PLL times and so on.
    """


@dataclass(frozen=True, order=True)
class StartMarginTime:
    usage: StartMarginTimeUsage
    margin_time_us: int
    """
    Value of the margin time.
    Range: 0 μs to 65535 μs
    Default for usage 0 (CONFIGURE_MARGIN_TIME_FIRST_ROUND): 8000 μs
    Default for usage 1 (CONFIGURE_MARGIN_TIME_NEXT_ROUND): 4000 μs
    """

    def create_payload(self) -> List[int]:
        payload = [int(self.usage)] + to_hex_list(input=self.margin_time_us, byteorder="little", forced_list_len=2)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            usage=p.extract_enum(StartMarginTimeUsage),
            margin_time_us=p.extract_int(2),
        )

    def __str__(self):
        _self = deepcopy(self)
        _self.margin_time_us = f"{self.margin_time_us} μs"
        return class_to_str(_self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class PostprocessingSlots:
    """
    The postprocessing slot configuration consists of two configuration pairs 'default' and 'optional'.
    The second configuration pair ('optional') is the optional configuration, which is used only
    in case the values of both default and optional configuration pair are >0. If both configuration
    pairs are used, the first and second configuration pairs are applied in a radar block one after the
    other. In case both configuration pairs are set to 0, the postprocessing slots are disabled.
    Postprocessing slots replace the radar slots and no radar frames can be received or transmitted
    during those slots. The postprocessing slots in a radar sequence are reserved to process radar
    data.

    Note:  Further to the programmed postprocessing, the UWBD generates a
    RADAR_STATUS_NTF upon reaching the POSTPROCESSING_THRESHOLD.
    """

    default_threshold: int
    """
    Number of radar slots before a postprocessing slot (POSTPROCESSING_THRESHOLD)
    Range: [0x0, 0x0001 ... 0x5F9F] (disabled, 1 to 24479 radar slots)
    """

    default_length: int
    """
    The postprocessing slot length (POSTPROCESSING_SLOT_LENGTH) in multiples of RADAR_SLOT_LENGTH
    Range: [0x0, 0x01 ... 0xFF] (disabled, RADAR_SLOT_LENGTH to 255 * RADAR_SLOT_LENGTH)
    """

    optional_threshold: int = 0
    """
    Optional number of radar slots before a postprocessing slot (POSTPROCESSING_THRESHOLD)
    Range: [0x0, 0x0001 ... 0x5F9F] (disabled, 1 to 24479 radar slots)
    """

    optional_length: int = 0
    """
    Optional postprocessing slot length (POSTPROCESSING_SLOT_LENGTH) in multiples of RADAR_SLOT_LENGTH
    Range: [0x0, 0x01 ... 0xFF] (disabled, RADAR_SLOT_LENGTH to 255 * RADAR_SLOT_LENGTH)
    """

    def create_payload(self) -> List[int]:
        payload = []
        payload.extend(
            to_hex_list(input=self.default_threshold, byteorder="little", forced_list_len=2)
        ) if self.default_threshold <= 0x5F9F else _raise(ValueError, "Default threshold is out of range")
        payload.append(self.default_length) if self.default_threshold <= 0xFF else _raise(ValueError, "Default length is out of range")
        payload.extend(
            to_hex_list(input=self.optional_threshold, byteorder="little", forced_list_len=2)
        ) if self.optional_threshold <= 0x5F9F else _raise(ValueError, "Optional threshold is out of range")
        payload.append(self.optional_length) if self.optional_threshold <= 0xFF else _raise(ValueError, "Optional length is out of range")
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            default_threshold=p.extract_int(2),
            default_length=p.extract_int(1),
            optional_threshold=p.extract_int(2),
            optional_length=p.extract_int(1),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class SessionRangingParams(ParamBase):
    device_type = TlvParamBase(
        tag=0x00,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 0xA0, 0xA1]
        else _raise(ValueError, "DEVICE_TYPE can only be: FiRa,User defined: [0, 1]; CCC: [0xA0, 0xA1]. Provide a value of EnumDeviceType"),
        interpret_resp=lambda p: EnumDeviceType(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumDeviceType
    session_type: All

    FiRa,User defined default value: depends on DEVICE_ROLE.
    CCC default: No default value. Mandatory parameter.
    """

    ranging_round_usage: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x01,
            convert_to_bytes=lambda v: [int(v)]
            if int(v) in [1, 2]
            else _raise(ValueError, "RANGING_ROUND_USAGE can only be 1 (SS-TWR with Deferred Mode) or 2 (DS-TWR with Deferred Mode)"),
            interpret_resp=lambda p: EnumRangingRoundUsage(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumRangingRoundUsage
    session_type: FiRa

    Default: No default value. Mandatory parameter.
    """

    sts_config = TlvParamBase(
        tag=0x02,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3, 4]
        else _raise(ValueError, "STS_CONFIG can only be [0, 1, 2, 3, 4]. Provide a value of EnumStsConfig."),
        interpret_resp=lambda p: EnumStsConfig(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumStsConfig
    session_type: CCC, FiRa
        This parameter indicates how system shall generate the STS.
    Default: CCC: Dynamic STS | FiRa: Static STS
    """

    multi_node_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x03,
            convert_to_bytes=lambda v: [int(v)]
            if int(v) in [0, 1]
            else _raise(ValueError, "MULTI_NODE_MODE can only be [0, 1]. Provide a value of EnumMultiNodeMode."),
            interpret_resp=lambda p: EnumMultiNodeMode(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumMultiNodeMode
    session_type: FiRa

    Default: No default value. Mandatory parameter.
    """

    channel_id = TlvParamBase(
        tag=0x04,
        convert_to_bytes=lambda v: [int(v)]
        if v in [5, 6, 8, 9]
        else _raise(ValueError, f"CHANNEL_ID {v} is not supported. Choose from Ch[5, 6, 8, 9]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Range: [5, 6, 8, 9]
    """

    number_of_anchors = TlvParamBase(
        tag=0x05,
        convert_to_bytes=lambda v: [int(v)] if 1 <= v <= 10 else _raise(ValueError, f"NUMBER_OF_ANCHORS: {v} is not supported. Range: 1 .. 10"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Range: 1 .. 10 (CCC, User defined) [no default, mandatory]
    Range: 1 .. 8 (FiRa) [default: 1]
    """

    device_mac_address = TlvParamBase(
        tag=0x06,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: CCC, FiRa

    CCC: Mac address of the UWBD. For responder, UWBD can override the device MAC Address. (default = 0)

    FiRa: MAC address of the UWBS itself participating in UWB session. Default: No default value. Mandatory parameter.
    """

    dst_mac_address = TlvParamBase(
        tag=0x07,
        convert_to_bytes=lambda v: list(flatten(val.to_bytes(2, byteorder="little") for val in v))
        if len(v) <= 8
        else _raise(ValueError, f"DST_MAC_ADDRESS: {v} is not supported. Max number of 2 byte mac addresses: CCC: 1 | FiRa: 1-8"),
        interpret_resp=lambda v: [int.from_bytes(bytes=chunk, byteorder="little", signed=False) for chunk in chunked(v, 2)],
        expected_resp_length=lambda length: (length % 2 == 0),
    )
    """
    value_type: List[int] (List of 2 bytes mac addresses | CCC: 1 address | FiRa: 1 - 8 addresses)
    session_type: CCC, FiRa

    CCC: Destination MAC address for broadcast ranging control messages. UWBD can override the destination MAC address (default = 0). Applied only for initiator.

    FiRa: MAC address list for NUMBER_OF_CONTROLEES (NUMBER_OF_ANCHORS) devices participating in UWB session.
    """

    ranging_slot_length = TlvParamBase(
        tag=0x08,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 1200 <= v <= 24000
        else _raise(ValueError, f"RANGING_SLOT_LENGTH {v} is not supported."),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    Unsigned integer that specifies duration of a ranging slot in the unit of RSTU.

    CCC: Possible slot length in terms of RSTU 1200, 1600, 2400, 3200, 3600, 4800, 9600
    Default: No default value. Mandatory parameter

    FiRa: Range: 1200 to 24000 RSTU
    Default: 2400 RSTU

    Note: With STS_CONFIG set to dynamic or provisioned STS configuration, the minimum supported value is 2400 RSTU.
    Note: With the Bit[0] Ranging Result Report Message (RRRM) enabled in RANGING_ ROUND_CONTROL, the supported minimum value is 2400 RSTU
    """

    ranging_interval = TlvParamBase(
        tag=0x09,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4)
        if 15 <= v <= 65535
        else _raise(ValueError, f"RANGING_INTERVAL {v} is not supported."),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
    session_type: All

    Ranging interval is time in the unit of 1200 RSTU (=1ms) between beginning of one ranging round to the beginning of the next.

    ---

    FiRa/user defined: The minimum ranging interval should be at least the duration of one ranging round length.

    ---

    CCC: Range: 96 ms to 24480 ms (RAN_Multiplier = RANGING_INTERVAL / 96)

    FiRa: Range: 15 ms to 65535 ms

    User Defined: Range: 16 ms to 65535 ms
    """

    sts_index0 = TlvParamBase(
        tag=0x0A,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4)
        if 0 <= v <= (2**30) - 1
        else _raise(ValueError, f"STS_INDEX0 {v} is not supported. Range: [0 - (2^30 - 1)]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
    session_type: CCC, FiRa

    STS index initialization value

    CCC: Range: [0 - (2^30 - 1)] (default = 0)

    FiRa: only for test purpose. Range: [0 - (2^32 - 1)] (default = 0)
    """

    mac_fcs_type = TlvParamBase(
        tag=0x0B,
        convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1] else _raise(ValueError, "MAC_FCS_TYPE can only be 0 (CRC 16) or 1 (CRC 32)"),
        interpret_resp=lambda p: EnumMacFcsType(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumMacFcsType
    session_type: All

    CRC type in MAC footer
    """

    ranging_round_control: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0C,
            convert_to_bytes=lambda v: v.create_payload()
            if isinstance(v, RangingRoundControl)
            else _raise(ValueError, f"RANGING_ROUND_CONTROL {v} is not supported. Provide instance of RangingRoundControl"),
            interpret_resp=lambda p: RangingRoundControl.from_bytes(p),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: RangingRoundControl
    session_type: FiRa, User Defined
    """

    aoa_result_req = TlvParamBase(
        tag=0x0D,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3]
        else _raise(ValueError, f"AOA_RESULT_REQ {v} is not supported. Choose from [0, 1, 2, 3]"),
        interpret_resp=lambda p: EnumAoaResultReq(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumAoaResultReq
    session_type: All

    This parameter is used to locally configure whether AoA results shall be reported in the RANGE_CCC_DATA_NTF notification.
    """

    rng_data_ntf = TlvParamBase(
        tag=0x0E,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3, 4, 5, 6, 7]
        else _raise(ValueError, f"RNG_DATA_NTF {v} is not supported. Choose from [0, 1, 2, 3, 4, 5, 6, 7]"),
        interpret_resp=lambda p: EnumRngDataNtf(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumRngDataNtf
    session_type: All

    Controls the range data ntf.
    """

    rng_data_ntf_proximity_near = TlvParamBase(
        tag=0x0F,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int (in cm)
    session_type: All

    This parameter sets the lower bound in cm above which the ranging notifications should automatically be enabled if RNG_DATA_NTF is set to 0x02.
    Should be less than or equal to RNG_DATA_NTF_PROXIMITY_FAR value.

    Default = 0 cm
    Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    rng_data_ntf_proximity_near = TlvParamBase(
        tag=0x10,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    This parameter sets the upper bound in cm above which the ranging notifications should automatically be disabled if RNG_DATA_NTF is set to 0x02.
    Should be greater than or equal to RNG_DATA_NTF_PROXIMITY_NEAR value.

    Default: 20000 cm
    Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    device_role = TlvParamBase(
        tag=0x11,
        convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1] else _raise(ValueError, f"DEVICE_ROLE {v} is not supported."),
        interpret_resp=lambda p: EnumDeviceRole(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumDeviceRole
    session_type: All

    FiRa. No default value. Mandatory parameter
    CCC:Default: 0x00 (responder).
    """

    rframe_config: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x12,
            convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1] else _raise(ValueError, f"RFRAME_CONFIG {v} is not supported."),
            interpret_resp=lambda p: EnumFrameType(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumFrameType
    session_type: FiRa

    Range frame format configuration. Only SP3 is supported.
    """

    preamble_id = TlvParamBase(
        tag=0x14,
        convert_to_bytes=lambda v: [int(v)] if 9 <= v <= 32 or v == 0xFF else _raise(ValueError, f"PREAMBLE_ID {v} is not supported."),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Ci Code index. If this value is configured as 0xFF(undefined) then Preamble ID in radio configuration will be used.
    Fw AiO:
    Range for BPRF mode: [9 … 12]
    Range for HPRF mode: [13 … 32]

    Fw CCC:
    [9-12] - support is mandatory
    [13-16], [21-24] - optional support

    Default = 0xFF: Use Preamble ID as in Radio configuration
    """

    sfd_id = TlvParamBase(
        tag=0x15,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1, 2, 3, 5, 0xFF]
        else _raise(ValueError, f"SFD_ID {v} is not supported. Range: [0, 2] or 0xFF"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Identifier for SFD sequence. If this value is configured as 0xFF (undefined) then SFD ID in radio configuration will be used.

    Values for BPRF mode: [0, 2] (Fw: CCC, AiO)
    Values for HPRF mode: [1, 2, 3] (Fw: only AiO)
    Values for proprietary long SFD: [5] (Fw: only AiO)

    Default = 0xFF: Use SFD ID as in radio configuration

    Note: Setting SFD_ID to 5 does not affect the actual SFD configuration of the UWB frame.
        The user shall choose the correct radio configuration index to use SFD ID 5 via RADIO_CFG_IDXS.
    """

    psdu_data_rate: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x16,
            convert_to_bytes=lambda v: [int(v)] if v in [0, 1, 2, 4] else _raise(ValueError, f"PSDU_DATA_RATE {v} is not supported."),
            interpret_resp=lambda p: EnumPsduDataRate(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumPsduDataRate
    session_type: All

    PSDU data rate configuration.
    """

    preamble_duration: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x17,
            convert_to_bytes=lambda v: [int(v)] if v in [0, 1, 2, 4] else _raise(ValueError, f"PREAMBLE_DURATION {v} is not supported."),
            interpret_resp=lambda p: EnumPreambleDuration(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumPreambleDuration
    session_type: All

    Preamble duration is the same as Preamble Symbol Repetitions (PSR).
    Two configurations are possible. BPRF uses only 64 symbols. HPRF can use both.
    """

    ranging_time_struct: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x1A,
            convert_to_bytes=lambda v: [int(v)] if v in [1] else _raise(ValueError, f"RANGING_TIME_STRUCT {v} is not supported."),
            interpret_resp=lambda p: EnumRangingTimeStruct(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumRangingTimeStruct
    session_type: FiRa

    Ranging time structure configuration
    """

    slots_per_rr = TlvParamBase(
        tag=0x1B,
        convert_to_bytes=lambda v: [int(v)] if v <= 0xFF else _raise(ValueError, f"SLOTS_PER_RR {v} is not supported."),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    CCC: Number of slots per ranging round. This parameter depends on number of anchors and it overrides the calculated possible minimum.
        Range: [6, 8, 9, 12, 16, 18]
        Default: 0xFF (The smallest calculated possible value will be used)

    FiRa / User Defined: Number of slots for per ranging round. This parameter is used to specify the ranging round duration in multiples of RANGING_SLOT_LENGTH.
        FiRa default: 25 slots per ranging round
        User Defined default. 12 slots per ranging round
    """

    tx_adaptive_payload_power: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x1C,
            convert_to_bytes=lambda v: [int(v)]
            if v in [0, 1]
            else _raise(ValueError, f"TX_ADAPTIVE_PAYLOAD_POWER {v} is not supported. Choose False or True"),
            interpret_resp=lambda p: bool(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: bool
    session_type: All

    Adaptive TX power configuration:
    False (default): TX power is not changed for sending the payload.
    True: TX power is adapted for sending the payload.
    """

    aoa_bound_config = TlvParamBase(
        tag=0x1D,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, AoaBoundConfig)
        else _raise(ValueError, f"AOA_BOUND_CONFIG {v} is not supported. Provide instance of AoaBoundConfig"),
        interpret_resp=lambda p: AoaBoundConfig.from_bytes(p),
        expected_resp_length=8,
    )
    """
    value_type: AoaBoundConfig
    session_type: All

    This parameter sets the lower and upper bound in degrees for AoA Azimuth and Elevation.
    """

    prf_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x1F,
            convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1] else _raise(ValueError, f"PRF_MODE {v} is not supported."),
            interpret_resp=lambda p: EnumPrfMode(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumPrfMode
    session_type: All

    This parameter is used to configure the mean PRF.
    """

    schedule_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x22,
            convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1] else _raise(ValueError, f"SCHEDULE_MODE {v} is not supported."),
            interpret_resp=lambda p: EnumScheduleMode(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumScheduleMode
    session_type: FiRa

    This parameter is used to set the multinode ranging type.
    """

    key_rotation = TlvParamBase(
        tag=0x23,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3]
        else _raise(ValueError, f"KEY_ROTATION {v} is not supported. Choose from [0, 1, 2, 3]"),
        interpret_resp=lambda p: EnumKeyRotation(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumKeyRotation
    session_type: CCC, FiRa

    CCC: This configuration is used to enable/disable STS and Final-Data protection key (dUDSK) rotation.
        STS key rotation configuration is applied only if STS_CONFIG is dynamic (0x01). (default = 0x03)

    FiRa: This configuration is used to enable/disable the key rotation feature during the
        dynamic STS ranging (STS_CONFIG: 0x01) or the provisioned STS ranging (STS_CONFIG: 0x03).
        (Only NO_ROTATION and STS_KEY_ROTATION possible)
    """

    key_rotation_rate: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x24,
            convert_to_bytes=lambda v: [int(v)] if (0 <= v <= 15) else _raise(ValueError, f"KEY_ROTATION_RATE {v} is not supported. Range: [0-15]"),
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: int
    session_type: FiRa

    The key rotation rate parameter defines n, with 2^n being the rotation rate of some keys used during the dynamic STS Ranging
    (STS_CONFIG: 0x01) or the provisioned STS ranging (STS_CONFIG: 0x03), where n is in the range of 0<=n<=15. Key rotation can
    be performed when the nth bit of the key has flipped. Default: 0
    """

    session_priority = TlvParamBase(
        tag=0x25,
        convert_to_bytes=lambda v: [int(v)]
        if (1 <= v <= 100 or v == 255)
        else _raise(ValueError, f"SESSION_PRIORITY {v} is not supported. Range: [1-100], [255]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Priority of a session:
    [1-100]: where 100 is the highest priority
    0xFF:  Preempt all other sessions disregarding of the dynamic priority calculation result.
    Default: 50
    """

    mac_address_mode: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x26,
            convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1, 2] else _raise(ValueError, f"MAC_ADDRESS_MODE {v} is not supported."),
            interpret_resp=lambda p: EnumMacAddressMode(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumMacAddressMode
    session_type: FiRa

    MAC Addressing mode to be used in UWBS.
    """

    vendor_id: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x27,
            convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
            if 0 <= v <= 0xFFFF
            else _raise(ValueError, f"VENDOR_ID {v} is not supported."),
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=2,
        ),
        ccc=None,
    )
    """
    value_type: int
    session_type: FiRa

    Unique ID for vendor. Unique ID for vendor. This parameter is used to set vUpper64[15:0] for static STS. Default: 0x0
    """

    static_sts_iv: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x28,
            convert_to_bytes=lambda v: v
            if isinstance(v, list) and len(v) == 6
            else _raise(ValueError, f"STATIC_STS_IV {v} is not supported. Provide a List[int] of 6 bytes"),
            interpret_resp=lambda p: p,
            expected_resp_length=6,
        ),
        ccc=None,
    )
    """
    value_type: List[int]
    session_type: FiRa

    Arbitrary value for static STS configuration which will be defined by the vendor. This parameter is used to set vUpper64[63:16].
    """

    number_of_sts_segments: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x29,
            convert_to_bytes=lambda v: [int(v)]
            if v in [0, 1, 2, 3, 4, 0xFF]
            else _raise(ValueError, f"NUMBER_OF_STS_SEGMENTS {v} is not supported."),
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: int
    session_type: All

    Number of STS segments in the frame:
    0x00: No STS Segments in case of non-STS frames (i.e, RFRAME_CONFIG is 0) (Not supported)

    The below values are permitted only for STS frames (RFRAME_CONFIG is 1 or 3) and have to be configured explicitly.
    0x01: 1 STS segment
    0x02: 2 STS segments (HPRF only)
    0x03: 3 STS segments (HPRF only)
    0x04: 4 STS segments (HPRF only)
    0xFF: Fetch from the radio configuration.
    """

    max_rr_retry = TlvParamBase(
        tag=0x2A,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 65535
        else _raise(ValueError, f"MAX_RR_RETRY {v} is not supported. Range: [0-65535]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    Number of failed Ranging Round (RR) attempts before terminating the session.
    The host shall receive SESSION_STATUS_NTF with MAX_RANGING_ROUND_RETRY_COUNT_REACHED status
    when consecutive ranging is not succeeded for maximum ranging round attempts.

    Range: [1 - 65535] (default = 0x00: Termination is disabled and ranging round attempt number is infinite)
    """

    uwb_initiation_time = TlvParamBase(
        tag=0x2B,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=8)
        if (0 <= v <= 2**64 - 1)
        else _raise(ValueError, f"UWB_INITIATION_TIME {v} is not supported. Range: [0], [1 - (2^64 - 1)]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=8,
    )
    """
    value_type: int (μs)
    session_type: All

    The UWB initiation time (microseconds) is the absolute time in the UWBS time domain in which the first message
    in the ranging round shall be transmitted after the session is started. The value shall be specified
    in the units of microseconds.

    Range: [0], [1 - (2^64 - 1)] (default: 0)
        0: UWB_INITIATION_TIME shall not be applicable.
    """

    hopping_mode = TlvParamBase(
        tag=0x2C,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0x00, 0x01, 0xE0, 0xA0, 0xA1, 0xA2, 0xA3]
        else _raise(ValueError, f"HOPPING_MODE {v} is not supported."),
        interpret_resp=lambda p: EnumHoppingMode(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumHoppingMode
    session_type: CCC, FiRa

    CCC: mandatory, no default
    FiRa: default: 0x00: NO_HOPPING
    """

    block_stride_length: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x2D,
            convert_to_bytes=lambda v: [int(v)]
            if (0x00 <= v <= 0xFF)
            else _raise(ValueError, f"BLOCK_STRIDE_LENGTH {v} is not supported. Range: [0x00-0xFF]"),
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: int
    session_type: FiRa

    Block Stride length indicates how many ranging blocks will be skipped after the completion of the current ranging block.
    The next ranging round is executed in the block after the Stride Length count. Block striding feature can be used to skip
    ranging blocks. When frequent ranging is not required, ranging devices can reduce power consumption by skipping ranging blocks.

    Given a stride length value N, and the current block index M, the next ranging block will have the index M + N + 1.
    0x00: No block striding Range: [0x00 … 0xFF]
    Default: 0x00 (No block striding)

    Note: This config is applicable only for controller and ignored in case of controlee.
        This parameter is applicable when RANGING_TIME_STRUCT is set to 0x01, otherwise the value set for this parameter shall be ignored.
    """

    result_report_config = TlvParamBase(
        tag=0x2E,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, ResultReportConfig)
        else _raise(ValueError, f"RESULT_REPORT_CONFIG {v} is not supported. Provide instance of ResultReportConfig"),
        interpret_resp=lambda p: ResultReportConfig.from_bytes(p),
        expected_resp_length=1,
    )
    """
    value_type: ResultReportConfig
    session_type: FiRa (CCC only with CCC MAC firmware)

    This config is used to enable/disable the result reports to be included in the RRRM or MRM Type 3.
    The ToF Report, AoA Azimuth Report, and AoA Elevation Report parameters are negotiated over OOB.
    """

    in_band_termination_attempt_count: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x2F,
            convert_to_bytes=lambda v: [int(v)]
            if (0x00 <= v <= 0x0A)
            else _raise(ValueError, f"IN_BAND_TERMINATION_ATTEMPT_COUNT {v} is not supported. Range: [0x00-0x0A]"),
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: int
    session_type: FiRa

    This parameter is used to configure how many times an in-band termination signal (i.e. Stop ranging field in the control message)
    shall be sent by a controller/initiator to a controlee. This parameter configuration shall be ignored in case of DEVICE_TYPE=0x00 (Controlee).

    0x00: Disable in-band termination attempt
    0x01-0x0A: In-band termination attempt count
    Default: 0x01

    Note: If this configuration is set to 0x00 then the controller shall not send “Stop ranging” bit set to '1' in RCM in any condition
        where the session state is changed from SESSION_ STATE_ACTIVE to SESSION_STATE_IDLE
    """

    max_number_of_measurements = TlvParamBase(
        tag=0x32,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 0xFFFF
        else _raise(ValueError, f"MAX_NUMBER_OF_MEASUREMENTS {v} is not supported. Range: [0x00 - 0xFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    Range: 0x00: Unlimited (default) | 0x01-0xFFFF: Number of Measurements

    CCC / User Defined: Numbers of blocks to be executed in a session. The host shall receive SESSION_STATUS_NTF with
        MAX_RANGING_BLOCKS_REACHED status when executed number of blocks are reached to MAX_NUMBER_OF_MEASUREMENTS.

    FiRa: Configuration parameter to set the maximum number of ranging measurements to be executed in a session.
        The session is stopped and moved to SESSION_STATE_IDLE Session State when configured ranging measurements are elapsed.

    Note: The session shall be stopped and moved to SESSION_STATE_IDLE Session State either by upon receiving an explicit
        stop command from AP or implicit in-band stop signal, irrespective of MAX_NUMBER_ OF_MEASUREMENTS value.
        If IN_BAND_ TERMINATION_ATTEMPT_COUNT is set to value greater than 0, then controller shall send an in-band stop signal
        after exhausting the MAX_NUMBER_OF_MEASUREMENTS count.
    """

    sts_length = TlvParamBase(
        tag=0x35,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0x00, 0x01, 0x02, 0xE0, 0xFF]
        else _raise(ValueError, f"STS_LENGTH {v} is not supported. Choose from [0x00, 0x01, 0x02, 0xE0, 0xFF]"),
        interpret_resp=lambda p: EnumStsLength(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumStsLength
    session_type: All

    Number of symbols in the STS segment.
    """

    session_key: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x45,
            convert_to_bytes=lambda v: v
            if isinstance(v, list) and len(v) == 16
            else _raise(ValueError, f"SESSION_KEY {v} is not supported. Provide a List[int] of 16 bytes."),
            interpret_resp=lambda p: p,
            expected_resp_length=16,
            write_only=True,
        ),
        ccc=None,
    )
    """
    value_type: List[int]
    session_type: FiRa

    FiRa session key. Based on this key all other keys used in the ranging round are derived.
    """

    hop_mode_key = TlvParamBase(
        tag=0xA0,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4)
        if isinstance(v, int) and v <= 0xFFFFFFFF
        else _raise(ValueError, f"HOP_MODE_KEY {v} is not supported. Provide a 4 bytes int"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
    session_type: CCC

    Hopping formula key to determine the next ranging round index. This value is used for all HOPPING_MODE values if hopping is enabled.
    Default: 0xBC72574C
    """

    ccc_config_quirks = TlvParamBase(
        tag=0xA1,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1]
        else _raise(ValueError, f"CCC_CONFIG_QUIRKS {v} is not supported. Choose from [0, 1]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: CCC

    0x00: Key identifier field of auxiliary security header of the MAC header as per CCC Digital Key Release 3, Version 1.0.0
    0x01 (default): Key identifier field formatted as: Source short address || Source PAN ID
    """

    responder_slot_index = TlvParamBase(
        tag=0xA2,
        convert_to_bytes=lambda v: [int(v)] if v <= 0xFF else _raise(ValueError, f"RESPONDER_SLOT_INDEX {v} is not supported. Range: [0x00 - 0xFF]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: CCC, User Defined

    This parameter is used to choose responder index in two way ranging. It is not applicable to controller.

    0: Responder 1
    1: Responder 2

    …

    N-1: Responder N
    (N is a number of anchor)

    Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    ranging_protocol_ver = TlvParamBase(
        tag=0xA3,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 0xFFFF
        else _raise(ValueError, f"RANGING_PROTOCOL_VER {v} is not supported. Range: [0x0000 - 0xFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: CCC

    Version of the ranging protocol (defined by CCC)

    Range: [0x0000 - 0xFFFF] (default = 0x0100)
    """

    uwb_config_id = TlvParamBase(
        tag=0xA4,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 0xFFFF
        else _raise(ValueError, f"UWB_CONFIG_ID {v} is not supported. Range: [0x0000 - 0xFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: CCC

    UWB Configuration ID

    Range: [0x0000 - 0xFFFF] (default = 0x0000)
    """

    pulseshape_combo = TlvParamBase(
        tag=0xA5,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0x00, 0x01, 0x02, 0x10, 0x11, 0x12, 0x20, 0x21, 0x22]
        else _raise(ValueError, f"pulseshape_combo {v} is not supported. Range: [0x00, 0x01, 0x02, 0x10, 0x11, 0x12, 0x20, 0x21, 0x22]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    Possible combinations are written in format:

    Lower Nibble - Higher Nibble: Initiator transmit pulse shape - Responder transmit pulse shape
    Example: 0x10 = Initiator: 0x1, Responder: 0x0

    Range: [0x00, 0x01, 0x02, 0x10, 0x11, 0x12, 0x20, 0x21, 0x22]
    (default = 0x00)
    """

    ursk_ttl = TlvParamBase(
        tag=0xA6,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0x001 <= v <= 0x2D0
        else _raise(ValueError, f"URSK_TTL {v} is not supported. Range: [0x0001 - 0x2D0]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: CCC

    URSK expiration time, in minutes (max 12 hours). After this time from setting URSK, the session will go to idle.

    Range: [0x001 - 0x2D0] (default = 0x2D0)
    """

    responder_listen_only = TlvParamBase(
        tag=0xA7,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1]
        else _raise(ValueError, f"RESPONDER_LISTEN_ONLY {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
    session_type: CCC

    Responder is in listen only mode. If it is enabled, then the responder will not send range frame.
    In this mode, the responder will report 0xD (responder is in listen only mode) as higher nibble of ranging status in RANGE_CCC_DATA_NTF

    False (default): Responder is in normal mode.
    True: Responder is in listen only mode
    """

    last_sts_index_used = TlvParamBase(
        tag=0xA8,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
    session_type: All

    Parameter used to get the STS index of the UWB session.
    When SESSION_GET_APP_CONFIG_CMD issued for this config during SESSION_STATE_ACTIVE
    the UWBD shall return the last STS Index of the latest completed ranging block.

    Note: The value of this parameter shall be ignored by UWBD when SESSION_SET_APP_CONFIG_CMD
        with this config is issued in SESSION_STATE_INIT/SESSION_STATE_IDLE state
    """

    dc_filter_config = TlvParamBase(
        tag=0xC3,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3]
        else _raise(ValueError, f"DC_FILTER_CONFIG {v} is not supported. Choose from [0, 1, 2, 3]"),
        interpret_resp=lambda p: EnumDcFilter(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumDcFilter
    session_type: All

    Disable/enable DC estimation filter
    """

    send_range_ccc_data_ntf: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0xC5,
            convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1] else _raise(ValueError, f"SEND_RANGE_CCC_DATA_NTF {v} is not supported."),
            interpret_resp=lambda p: EnumRangingReportNtf(p[0]),
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: EnumRangingReportNtf
    session_type: CCC

    Selects the format of the ranging result report notification.
    """

    radar_configuration_index = TlvParamBase(
        tag=0xE2,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1, 2, 3, 0xFF]
        else _raise(ValueError, f"RADAR_CONFIGURATION_INDEX: {v} is not supported. Range: [0 - 3], [255]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Radar configuration index in the range 0x00 - 0x03 from where radar configurations will be fetched.
        Default: 0xFF (no radar configuration selected)
    Note: The radar configuration must be updated with the command SET_RADAR_CONFIG_CMD before selecting the radar configuration index.
    """

    rx_start_margin = TlvParamBase(
        tag=0xE3,
        convert_to_bytes=lambda v: [int(v)] if 0 <= v <= 0xFF else _raise(ValueError, f"RX_START_MARGIN {v} is not supported. Range: [0 - 255]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Margin time in μs resolution which is used to start RX in prior than TX of counterpart.

    Range: 0..255μs / 0x00..0xFF
    default: 100μs / 0x64
    default for low-power mode: 50μs / 0x32
        Note: default value is set according to Low-power mode when the session is initialized.
    """

    rx_timeout = TlvParamBase(
        tag=0xE4,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0x64 <= v <= 0x1F4
        else _raise(ValueError, f"RX_TIMEOUT {v} is not supported. Range: [100 - 500]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    Timeout in μs resolution for opening RX analog channel.

    Range: 100us..500μs / 0x64..0x1F4
    default: 200μs / 0xC8
    default for low-power mode: 100μs /0x64
        Note: default value is set according to low-power mode when the session is initialized.
    """

    adapted_ranging_index = TlvParamBase(
        tag=0xE5,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 0xFFFF
        else _raise(ValueError, f"ADAPTED_RANGING_INDEX {v} is not supported. Range: [0x0000 - 0xFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    If the session lost synchronization in case of adaptive hopping mode, new ranging index can be configured.
    This param should be configured after configuring valid SLOTS_PER_RR and RANGING_INTERVAL
    in a separate command. This value resets to 0xFFFF in case of successfully synchronized.

    Range: [0x0 … Maximum ranging round number in configured SLOTS_PER_RR and RANGING_INTERVAL]
    0x00 … Maximum ranging round number: Jump to the index.

    Default: 0xFFFF
        Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    nbic_conf = TlvParamBase(
        tag=0xE6,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, NbicConfig)
        else _raise(ValueError, f"NBIC_CONF {v} is not supported. Provide instance of NbicConfig"),
        interpret_resp=lambda p: [NbicConfig.from_bytes(p[0:5]), NbicConfig.from_bytes(p[5:10])],
        interpret_com=lambda p: NbicConfig.from_bytes(p),
        expected_resp_length=10,
        expected_com_length=5,
    )
    """
    value_type: NbicConfig
    session_type: All

    Configuration of Narrow Band Interference Control Block (NBIC). NBIC enables Co- Channel rejection.
    """

    groupdelay_recalc_enable = TlvParamBase(
        tag=0xE7,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1]
        else _raise(ValueError, f"GROUPDELAY_RECALC_ENABLE {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
    session_type: All

    False (default): Group delay value in application configuration page will be used for this session.
    True: Group delay for this session will be recalculated at the start of the session.

    Note: For Group delay calculation, the device bypasses current limiter.
    """

    ursk__fira_session_key = TlvParamBase(
        tag=0xE8,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, (Ursk, FiraSessionKey))
        else _raise(ValueError, f"URSK / FIRA_SESSION_KEY{v} is not supported. Provide instance of Ursk for CCC or FiraSessionKey for Fira."),
        interpret_resp=lambda p: Ursk.from_bytes(p) if len(p) == 33 else FiraSessionKey.from_bytes(p),
        expected_resp_length=lambda length: length in [17, 33],
        write_only=True,
    )
    """
    value_type: Ursk (CCC) / FiraSessionKey (Fira)
    session_type: CCC, Fira
    """

    static_keys = TlvParamBase(
        tag=0xE9,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, StaticKeys)
        else _raise(
            ValueError,
            f"STATIC_KEYS {v} is not supported. Provide a instance of StaticKeys",
        ),
        interpret_resp=lambda p: StaticKeys.from_bytes(p),
        expected_resp_length=lambda length: length in (18, 34),
        write_only=True,
    )
    """
    value_type: StaticKeys
    session_type: CCC / FiRa (differentiate in StaticKeys)

    Note: This parameter is only for test purpose
    """

    rcm_rx_margin_time = TlvParamBase(
        tag=0xEA,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RcmRxMarginTime)
        else _raise(
            ValueError,
            f"RCM_RX_MARGIN_TIME {v} is not supported. Provide a instance of RcmRxMarginTime",
        ),
        interpret_resp=lambda p: [RcmRxMarginTime.from_bytes(p[0:3]), RcmRxMarginTime.from_bytes(p[3:6])],
        interpret_com=lambda p: RcmRxMarginTime.from_bytes(p),
        expected_resp_length=6,
        expected_com_length=3,
    )
    """
    value_type: RcmRxMarginTime
    session_type: All

    Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    rcm_rx_timeout = TlvParamBase(
        tag=0xEB,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RcmRxTimeout)
        else _raise(
            ValueError,
            f"RCM_RX_TIMEOUT {v} is not supported. Provide a instance of RcmRxTimeout",
        ),
        interpret_resp=lambda p: [RcmRxTimeout.from_bytes(p[0:3]), RcmRxTimeout.from_bytes(p[3:6])],
        interpret_com=lambda p: RcmRxTimeout.from_bytes(p),
        expected_resp_length=6,
        expected_com_length=3,
    )
    """
    value_type: RcmRxTimeout
    session_type: All

    Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    dynamic_priority_enable = TlvParamBase(
        tag=0xEC,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2]
        else _raise(ValueError, f"DYNAMIC_PRIORITY_ENABLE {v} is not supported. Choose from [0, 1, 2] "),
        interpret_resp=lambda p: EnumDynamicPriority(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumDynamicPriority
    session_type: All

    Flag to enable or disable the dynamic priority of current session.

    0: Dynamic priority calculation is disabled.
    1: Dynamic priority calculation is enabled.
    2: Dynamic priority calculation is enabled after the responder session is synchronized with initiator or via time synchronization.
        This value is only applicable for the responder session.

    By default, dynamic priority calculation is enabled.
    """

    adaptive_payload_power = TlvParamBase(
        tag=0xED,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1]
        else _raise(ValueError, f"ADAPTIVE_PAYLOAD_POWER {v} is not supported. Choose True or False"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        False: TX power is same for sending payload.
        True: TX power is adapted for sending payload.
    Note: This parameter is not supported if DEVICE_ROLE is responder
    """

    rcc_threshold = TlvParamBase(
        tag=0xEE,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RccThreshold)
        else _raise(ValueError, f"RCC_THRESHOLD {v} is not supported. Provide instance of RccThreshold"),
        interpret_resp=lambda p: RccThreshold.from_bytes(p),
        expected_resp_length=2,
    )
    """
    value_type: RccThreshold
    session_type: All
    """

    adaptive_hopping_threshold = TlvParamBase(
        tag=0xEF,
        convert_to_bytes=lambda v: [int(v)]
        if 0 <= v <= 0xFF
        else _raise(ValueError, f"ADAPTIVE_HOPPING_THRESHOLD {v} is not supported. Range: [0 - NUMBER_OF_CONTROLEES], [0xFF] (NUMBER_OF_CONTROLEES)"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: CCC, FiRa

    This parameter can be used to configure the required number of successful responses (T) from responders to conclude a successful ranging round.
    If the numbers of responses is less than the given threshold (T) then the initiator device triggers a hop to a different round index within the next block.

    Range: [0 < T <= NUMBER_OF_CONTROLEES]
    Default: 0xFF: NUMBER_OF_CONTROLEES

    Note: This parameter is applicable when HOPPING_MODE = 2: adaptive hopping using MODULO or 4: adaptive hopping using AES
    Note: This parameter is not supported if DEVICE_ROLE is responder.
    """

    rxtx_enable = TlvParamBase(
        tag=0xF0,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RxTxEnable)
        else _raise(RxTxEnable, f"RXTX_ENABLE {v} is not supported. Provide instance of RxTxEnable"),
        interpret_resp=lambda p: RxTxEnable.from_bytes(p),
        expected_resp_length=2,
    )
    """
    value_type: RxTxEnable
    session_type. All
    """

    rr_retry_thr = TlvParamBase(
        tag=0xF1,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 0xFFFF
        else _raise(ValueError, f"RR_RETRY_THR {v} is not supported. Range: [0x0000 - 0xFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type

    When the number of missing ranging control messages (RCM) for a Ranging Round (RR) reaches the configured threshold,
    then the session starts using RCM_RX_MARGIN_TIME index 0 and RCM_RX_TIMEOUT index 0 as margin times for the RX window
    until it reaches MAX_RR_RETRY of UCI Generic Specification

    Default: 10

    Note: This parameter is not supported if DEVICE_ROLE is initiator
    """

    tx_power_id = TlvParamBase(
        tag=0xF2,
        convert_to_bytes=lambda v: [int(round((14 - v) * 6))]
        if -21 <= v <= 14
        else _raise(ValueError, f"TX_POWER_ID {v} is not supported. Range: [-21 - +14]"),
        interpret_resp=lambda p: f"{14 - (p[0] / 6):.2f} dBm",
        expected_resp_length=1,
    )
    """
    value_type: float (in dBm)
    session_type: All
        TX output power attenuation relative to maximum TX output power.
        Range: [+14 .. -21] dBm
        Resolution: 0.17 dBm
        Default: +4 dBm
    """

    radar_slots: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0xF3,
            convert_to_bytes=lambda v: to_hex_list(input=(sum(1 << i for i in v)), forced_list_len=4)
            if isinstance(v, list)
            else _raise(ValueError, f"RADAR_SLOTS ({v}) is not supported. Provide a List[int]"),
            interpret_resp=lambda p: [i for i in range(32) if int.from_bytes(p, byteorder="little") & (1 << i)],
            expected_resp_length=4,
        ),
        ccc=None,
    )
    """
    value_type: List[int]: List if enabled radar slot indices.
    session_type: CCC, User Defined
    ONLY AiO MAC!

    This parameter is used to enable radar slots in a ranging round.
    No radar frames: Pass empty list []

    The possible values depend on the configured RESPONDER_SLOT_INDEX and the NUMBER_OF_ANCHORS in a ranging round.

    For example, if the NUMBER_OF_ANCHORS (N) is 5 and the RESPONDER_SLOT_INDEX is 1, the following indices are possible/not possible.

    Not possible:
    - 0: Slot occupied by the prepoll frame.
    - 1: Slot occupied by the poll frame.
    - 3: Slot occupied by the range frame of the responder as the RESPONDER_SLOT_INDEX is 1.
    - N+2: Slot occupied by the final frame.
    - N+3: Slot occupied by the final-data frame.

    Possible:
    - 2: Range frame slot of the responder RESPONDER_SLOT_INDEX 0; could be used for a radar frame.
    - 4: Range frame slot of the responder RESPONDER_SLOT_INDEX 2; could be used for a radar frame.
    - ...
    - N+1: Range frame slot of the responder RESPONDER_SLOT_INDEX N-1; could be used for a radar frame.
    - N+4: Empty frame slot; could be used for a radar frame.
    - ...
    - SLOTS_PER_RR-1: Empty frame slot; could be used for a radar frame.
    """

    radar_slot_index: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0xF3,
            convert_to_bytes=lambda v: [int(v)]
            if 0 <= v <= 0xFF
            else _raise(ValueError, f"RADAR_SLOT_INDEX {v} is not supported. Range: [0x00 - 0xFF]"),
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
        ),
    )
    """
    value_type: int
    ONLY CCC MAC!

    This parameter is used to select the radar slot in a ranging round.
    Range: [0 … SLOTS_PER_RR-1]

    The possible values depend on the configured RESPONDER_SLOT_INDEX and the NUMBER_OF_ANCHORS in a ranging round.
    For example,if the NUMBER_OF_ANCHORS (N) is 5 and the RESPONDER_SLOT_INDEX is 1, the following values are possible/not possible.

    Not possible:
    - 0: Slot occupied by the prepoll frame.
    - 1: Slot occupied by the poll frame.
    - 3: Slot occupied by the range frame of the responder as the RESPONDER_SLOT_INDEX is 1.
    - N+2: Slot occupied by the final frame.
    - N+3: Slot occupied by the final-data frame.

    Possible:
    - 2: Range frame slot of the responder RESPONDER_SLOT_INDEX 0; could be used for a radar frame.
    - 4: Range frame slot of the responder RESPONDER_SLOT_INDEX 2; could be used for a radar frame.
    - ...
    - N+1: Range frame slot of the responder RESPONDER_SLOT_INDEX N-1; could be used for a radar frame.
    - N+4: Empty frame slot; could be used for a radar frame.
    - ...
    - SLOTS_PER_RR-1: Empty frame slot; could be used for a radar frame.
    """

    radar_slot_delay: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0xF4,
            convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
            if -8400 <= v <= 8400
            else _raise(ValueError, f"RADAR_SLOT_DELAY {v} is not supported. Range: [-8400 ... 8400] RSTU"),
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=True),
            expected_resp_length=2,
        ),
        ccc=TlvParamBase(
            tag=0xF4,
            convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
            if 0 <= v <= 18000
            else _raise(ValueError, f"RADAR_SLOT_DELAY {v} is not supported. Range: [0 - 18000] RSTU"),
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=2,
        ),
    )
    """
    value_type: int
    session_type: CCC, User Defined

    Duration of the radar slot delay in the unit of RSTU.

    Range: -8400 to 8400 RSTU (CCC: 0 to 18000 RSTU)
    Default: 1200 RSTU

    The RADAR_SLOT_DELAY must be chosen so that the radar frame doesn't collide with a ranging slot.

    AiO Note: RADAR_SLOT_DELAY shall be in the range of -(RANGING_SLOT_LENGTH - 1200 RSTU) to (RANGING_SLOT_LENGTH - 1200 RSTU).

    CCC Note: This value shall not exceed 2 * RANGING_SLOT_LENGTH - 1200 RSTU.
    CCC Note: RADAR_SLOT_DELAY should not be same as RANGING_SLOT_DURATION.
    """

    logging_enable = TlvParamBase(
        tag=0xF5,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, LoggingEnable)
        else _raise(
            ValueError,
            f"LOGGING_ENABLE {v} is not supported. Provide a instance of LoggingEnable",
        ),
        interpret_resp=lambda p: LoggingEnable.from_bytes(p),
        expected_resp_length=3,
    )
    """
    value_type: LoggingEnable
    session_type: All
    """

    log_params_conf = TlvParamBase(
        tag=0xF6,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, LogParamsConfig)
        else _raise(
            ValueError,
            f"LOG_PARAMS_CONF {v} is not supported. Provide a instance of LogParamsConfig",
        ),
        interpret_resp=lambda p: LogParamsConfig.from_bytes(p),
        expected_resp_length=4,
    )
    """
    value_type: LogParamsConfig
    session_type: All
    """

    cir_tap_offset = TlvParamBase(
        tag=0xF7,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 1023
        else _raise(ValueError, f"CIR_TAP_OFFSET {v} is not supported. Range: [0 - 1023]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    Offset of the CIR taps to be logged. One tap is 4 bytes long, the complete log size is 4096 bytes.
    Range: [0..1023]
    Default: 0x0302 (tap index 770)

    Note: CIR_TAP_OFFSET + CIR_NUM_TAPS should not exceed 1024 taps, otherwise CIR_NUM_TAPS will be saturated.
    """

    cir_num_taps = TlvParamBase(
        tag=0xF8,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 1024
        else _raise(ValueError, f"CIR_NUM_TAPS {v} is not supported. Range: [0 - 1024]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
    session_type: All

    The number of CIR taps to be logged. One tap is 4 bytes long, the complete log size is 4096 bytes.
    Range: [0..1024]
    Default: 100 taps

    Note: CIR_TAP_OFFSET + CIR_NUM_TAPS should not exceed 1024 taps, otherwise CIR_NUM_TAPS will be saturated.
    """

    sts_index_restart = TlvParamBase(
        tag=0xF9,
        convert_to_bytes=lambda v: [int(v)] if v in [0, 1] else _raise(ValueError, f"STS_INDEX_RESTART {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
    session_type: All

    If enabled, the STS index is restarted from STS_INDEX0 for every ranging round.

    False: The STS index is incremented for each ranging round according to the CCC specification.
    True: The STS index is restarted from STS_INDEX0 for every ranging round.
    Default: 0x00 (STS index restart is disabled)
    """

    vendor_specific_oui = TlvParamBase(
        tag=0xFA,
        convert_to_bytes=lambda v: to_hex_list(input=int(v) & 0xFFFFFF, byteorder="little", forced_list_len=3)
        if isinstance(v, int)
        else _raise(ValueError, f"VENDOR_SPECIFIC_OUI {v} is not supported. Value needs to be int"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=3,
    )
    """
    value_type: int
    session_type: CCC, FiRa

    Initiator Vendor specific OUI
    Default: CCC OUI

    Example: Input: 0xFFFF04DF69 -> Transmitted (last 3 bytes): 0x04DF69
    """

    radio_cfg_idxs = TlvParamBase(
        tag=0xFB,
        convert_to_bytes=lambda v: [int(v[0]), int(v[1])]
        if all(0x00 <= x <= 0xF or x == 0xF0 for x in v)
        else _raise(ValueError, f"RADIO_CFG_IDXS {v} is not supported. Range (each): [0x00 .. 0xF] or 0xF0"),
        interpret_resp=lambda p: {"RX": p[0], "TX": p[1]},
        expected_resp_length=2,
    )
    """
    value_type: Tuple[int, int]: (rx slot index, tx slot index)
    session_type: All


    Radio configuration slot index in flash. For MAC ranging, 2 types of radio configuration is needed which are SP0 type and SP3 type.

    Range: [0x00..0xF] for RX and TX radio configuration. If this value is configured as 0xF0 (240),
        the radio configuration downloaded with RADIO_CONFIG_DOWNLOAD_CMD will be used.

    CCC / User Defined default: (0, 0) (Sc100_lin_phase_preamble_9)
    FiRa default: (8, 8) (Sc100)
    """

    rcc_expiration_block = TlvParamBase(
        tag=0xFC,
        convert_to_bytes=lambda v: [int(v)]
        if 0 <= v <= 0xFF
        else _raise(ValueError, f"RCC_EXPIRATION_BLOCK {v} is not supported. Range: [0x00 - 0x0F]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
    session_type: All

    Ranging consistency tracking values will be expired if the responder lost synchronization more than configured blocks.

    Range: [0x00..0x0F] (default: 2)
    Note: This value shall be smaller then RR_RETRY_THR.
    """

    crypto_key_usage_flag = TlvParamBase(
        tag=0xFD,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, CryptoKeyUsageFlag)
        else _raise(ValueError, f"CRYPTO_KEY_USAGE_FLAG {v} is not supported. Provide instance of CryptoKeyUsageFlag"),
        interpret_resp=lambda p: CryptoKeyUsageFlag.from_bytes(p),
        expected_resp_length=2,
    )
    """
    value_type: CryptoKeyUsageFlag
    session_type: CCC

    This flag indicates that keys are required to calculate from URSK or static key can be used.
    """

    send_final_always = TlvParamBase(
        tag=0xFE,
        convert_to_bytes=lambda v: [int(v)] if v in [0, 1] else _raise(ValueError, f"SEND_FINAL_ALWAYS {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
    session_type: All

    This flag enables/disables sending Final and Final_Data frames in the situation when no anchor responded.

    False: Disable - the frames are sent only when any anchor has responded.
    True (default): Enable - the frames are sent always.

    Note: This parameter is not supported if DEVICE_ROLE is responder
    Note: This parameter is only supported if HOP_MODE is disabled.
    """

    start_margin_time = TlvParamBase(
        tag=0xFF,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, StartMarginTime)
        else _raise(ValueError, f"START_MARGIN_TIME {v} is not supported. Provide instance of StartMarginTime"),
        interpret_resp=lambda p: [StartMarginTime.from_bytes(p[0:3]), StartMarginTime.from_bytes(p[3:6])],
        interpret_com=lambda p: StartMarginTime.from_bytes(p),
        expected_resp_length=6,
        expected_com_length=3,
    )
    """
    value_type: StartMarginTime
    session_type: All
    """


@dataclass(frozen=True, order=True)
class SessionRadarParams(ParamBase):
    """ONLY AiO"""

    radar_slot_length = TlvParamBase(
        tag=0x08,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if (1200 <= v <= 36000 or v == 0)
        else _raise(ValueError, f"RADAR_SLOT_LENGTH {v} is not supported. Range: [0, 1200 - 36000]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int

    Specifies the duration of a radar slot in the unit of RSTU. If this value is not set,
    the RADAR_SLOT_LENGTH will be set to ⌊RADAR_INTERVAL / SLOTS_PER_RR⌋.

    Range: 1200 RSTU to 36000 RSTU
    Default: 0x00 (use calculated value)
    """

    radar_interval = TlvParamBase(
        tag=0x09,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4)
        if 5 <= v <= 900000
        else _raise(ValueError, f"RADAR_INTERVAL {v} is not supported. Range: [5 - 900000]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
    The radar interval is the time in the unit of 1200 RSTU (1 ms) between the beginning of
    one radar round to the beginning of the next. The minimum radar interval is 5 ms, which is 6000 RSTU.
    Range: 15 ms to 900000 ms
    Default: 100 ms
    """

    status_ntf_conf = TlvParamBase(
        tag=0x0E,
        convert_to_bytes=lambda v: [int(v)] if v in [0, 1] else _raise(ValueError, f"STATUS_NTF_CONF {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        Controls the RADAR_STATUS_NTF
    False: Disable RADAR_STATUS_NTF
    True: Enable RADAR_STATUS_NTF

    Default: True (Enable RADAR_STATUS_NTF)

    If the RADAR_STATUS_NTF is enabled (0x01) a notification will be generated after reaching
    the POSTPROCESSING_THRESHOLD. Furthermore, a status notification containing the unreported
    radar frames is generated, in case the radar session finishes before the POSTPROCESSING_THRESHOLD is reached.
    """

    slots_per_rr = TlvParamBase(
        tag=0x1B,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 1 <= v <= 30000
        else _raise(ValueError, f"SLOTS_PER_RR {v} is not supported. Range: [1 - 30000]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int

    The number of slots per radar round; corresponds to the number of radar frames in a radar round.

    Range: 1 to 30000 radar frames

    Default: 10 radar frames

    Note:  SLOTS_PER_RR * RADAR_SLOT_LENGTH must not exceed RADAR_INTERVAL.
    Note:  In case (SLOTS_PER_RR * RADAR_SLOT_LENGTH) < RADAR_INTERVAL the remainder of the radar round is empty
    """

    session_priority = TlvParamBase(
        tag=0x25,
        convert_to_bytes=lambda v: [int(v)]
        if (1 <= v <= 100 or v == 255)
        else _raise(ValueError, f"SESSION_PRIORITY {v} is not supported. Range: [1-100], [255]"),
        interpret_resp=lambda p: EnumKeyRotation(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: int
        Priority of a session.
        [1-100] where 100 is the highest priority
        [255] Preempt all other sessions disregarding of the dynamic priority calculation result.
        Default: 50
    """

    uwb_initiation_time = TlvParamBase(
        tag=0x2B,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=8)
        if (0 <= v <= 2**64 - 1)
        else _raise(ValueError, f"UWB_INITIATION_TIME {v} is not supported. Range: [0], [1 - (2^64 - 1)]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=8,
    )
    """
    value_type: int (μs)
        The UWB initiation time (microseconds) is the absolute time in the UWBS time domain in which the first message
        in the ranging round shall be transmitted after the session is started.

        Range: [0], [1 - (2^64 - 1)] (default: 0)
            0: UWB_INITIATION_TIME shall not be applicable.
    """

    max_number_of_measurements = TlvParamBase(
        tag=0x32,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 1 <= v <= 0xFFFF
        else _raise(ValueError, f"MAX_NUMBER_OF_MEASUREMENTS {v} is not supported. Range: [0x001 - 0xFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Numbers of blocks to be executed in a session. The host shall receive SESSION_STATUS_NTF with
        MAX_RADAR_ROUNDS_REACHED status when executed number of blocks are reached to MAX_NUMBER_OF_MEASUREMENTS.
        Range: [0x0001 - 0xFFFF]
        (default = 0xFFFF)
    """

    scheduling_conf = TlvParamBase(
        tag=0xC0,
        convert_to_bytes=lambda v: [int(v)] if v in [0, 1] else _raise(ValueError, f"SCHEDULING_CONF {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
    Controls the radar session scheduling.
    False: Disable greedy scheduling. The radar session is scheduled only if the whole radar round can be done.
    True: Enable greedy scheduling. Slices of the radar session will be scheduled
            if at least one radar slot plus the applicable POSTPROCESSING_SLOTS fits.
    Default: False (greedy scheduling disabled).
    """

    postprocessing_slots = TlvParamBase(
        tag=0xC1,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, PostprocessingSlots)
        else _raise(ValueError, f"POSTPROCESSING_SLOTS {v} is not supported. Provide instance of PostprocessingSlots"),
        interpret_resp=lambda p: PostprocessingSlots.from_bytes(p),
        expected_resp_length=6,
    )
    """
    value_type: PostprocessingSlots
    """

    radar_configuration_index = TlvParamBase(
        tag=0xE2,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1, 2, 3, 0xFF]
        else _raise(ValueError, f"RADAR_CONFIGURATION_INDEX: {v} is not supported. Range: [0 - 3], [255]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
        Radar configuration index in the range 0x00 - 0x03 from where radar configurations will be fetched.
            Default: 0xFF (no radar configuration selected)
        Note: The radar configuration must be updated with the command SET_RADAR_CONFIG_CMD before selecting the radar configuration index.
    """

    dynamic_priority_enable = TlvParamBase(
        tag=0xEC,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1]
        else _raise(ValueError, f"DYNAMIC_PRIORITY_ENABLE {v} is not supported. Choose False or True"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        Flag to enable or disable the dynamic priority of current session.

    False: Dynamic priority calculation is disabled.
    True: Dynamic priority calculation is enabled.

    By default, dynamic priority calculation is enabled.
    """

    start_margin_time = TlvParamBase(
        tag=0xFF,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, StartMarginTime)
        else _raise(ValueError, f"START_MARGIN_TIME {v} is not supported. Provide instance of StartMarginTime"),
        interpret_resp=lambda p: [StartMarginTime.from_bytes(p[0:3]), StartMarginTime.from_bytes(p[3:6])],
        interpret_com=lambda p: StartMarginTime.from_bytes(p),
        expected_resp_length=6,
        expected_com_length=3,
    )
    """
    value_type: StartMarginTime
    """

    def __post_init__(self):
        if mac_config.MAC_FW_TYPE != "AiO":
            raise RuntimeError(f"{self.__class__.__name__} is only allowed when FW_TYPE is AiO, but FW_TYPE is '{mac_config.MAC_FW_TYPE}'")


@dataclass(frozen=True, order=True)
class SessionInitCmd(CommandBase):
    """
    Used to create a UWB session and initialize it with the default values. Contains:
        SESSION_INIT_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_INIT, init=False)

    session_id: int
    session_type: EnumSessionType

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_id, byteorder="little", forced_list_len=4)
        payload.append(int(self.session_type))
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_id=p.extract_int(4),
            session_type=p.extract_enum(EnumSessionType),
        )


@dataclass(frozen=True, order=True)
class SessionInitRsp(ResponseBase):
    """
    Used to create a UWB session and initialize it with the default values. Contains:
        SESSION_INIT_RSP
    """

    status: EnumUciStatus
    session_handle: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            session_handle=p.extract_int(4),
        )


@dataclass(frozen=True, order=True)
class SessionDeinitCmd(CommandBase):
    """
    Used to delete a UWB session. Contains:
        SESSION_DEINIT_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_DEINIT, init=False)


@dataclass(frozen=True, order=True)
class SessionDeinitRsp(ResponseBase):
    """
    Used to delete a UWB session. Contains:
        SESSION_DEINIT_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class SessionStatusNtf(NotificationBase):
    """
    To notify about the current UWB session state. Contains:
        SESSION_STATUS_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_STATUS, init=False)

    session_handle: int
    session_status: EnumSessionState
    reason_code: EnumSessionReason

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
            session_status=p.extract_enum(EnumSessionState),
            reason_code=p.extract_enum(EnumSessionReason),
        )


@dataclass(order=True)
class SessionSetAppConfigCmd(TlvCommandBase):
    """
    To configure a UWB session with specified configurations. Contains:
        SESSION_SET_APP_CONFIG_CMD

    Params: SessionRangingParams (AiO, CCC) or SessionRadarParams (AiO)
    Pass empty list to reset all parameters.
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_SET_APP_CONFIG, init=False)

    def set_parameter(self, param: TlvParamBase, value: Any):
        super()._set_parameter_base(param, value, param_class=self._param_class, set_command=True)

    @classmethod
    def from_bytes(cls, payload: List[int], session_type: EnumSessionType):
        p = PayloadParser(payload)
        param_class: SessionRangingParams | SessionRadarParams = choose_param_class_for_session_params(session_type)

        session_handle = p.extract_int(4)
        number_of_parameters = p.extract_int(1)
        session_set_app_config_cmd_cls = (
            cls._from_bytes_base(payload=p.extract_list(END), param_class=param_class, session_handle=session_handle)
            if number_of_parameters > 0
            else cls(session_handle=session_handle)
        )
        setattr(session_set_app_config_cmd_cls, "number_of_parameters", number_of_parameters)
        setattr(session_set_app_config_cmd_cls, "number_of_parameters", number_of_parameters)
        return session_set_app_config_cmd_cls

    def __init__(self, session_handle: int, session_type: EnumSessionType, params: List[Tuple[TlvParamBase, Any]] = []):
        self._param_class: SessionRangingParams | SessionRadarParams = choose_param_class_for_session_params(session_type)
        self.session_handle = session_handle
        super().__init__(params)

    def __str__(self):
        return class_to_str(self)


@dataclass(frozen=True, order=True)
class SessionSetAppConfigRsp(ResponseBase):
    """
    To configure a UWB session with specified configurations. Contains:
        SESSION_SET_APP_CONFIG_RSP

        Params: SessionRangingParams (AiO, CCC) or SessionRadarParams (AiO)
    """

    status: EnumUciStatus
    number_of_invalid_parameters: int
    list_of_invalid_parameters: List[InvalidParam]

    @classmethod
    def from_bytes(cls, payload: List[int], session_type: EnumSessionType):
        p = PayloadParser(payload)
        param_class: SessionRangingParams | SessionRadarParams = choose_param_class_for_session_params(session_type)

        status = p.extract_enum(EnumUciStatus)
        number_of_invalid_parameters = p.extract_int(1)
        list_of_invalid_parameters = [
            InvalidParam(tag=(tag := p.extract_int(1)), name=param_class.find_name_by_tag(tag=tag), error_code=p.extract_enum(EnumUciStatus))
            for _ in range(number_of_invalid_parameters)
        ]
        return cls(
            status=status,
            number_of_invalid_parameters=number_of_invalid_parameters,
            list_of_invalid_parameters=list_of_invalid_parameters,
        )


@dataclass(order=True)
class SessionGetAppConfigCmd(CommandBase):
    """
    To get the current configuration for specified configurations. Contains:
        SESSION_GET_APP_CONFIG_CMD

    Params: SessionRangingParams (AiO, CCC) or SessionRadarParams (AiO)
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_GET_APP_CONFIG, init=False)

    param_list: List[TlvParamBase] = field(default_factory=[])
    """
    List of SessionRangingParams/SessionRadarParams attributes. Pass empty list to get all the APP configurations IDs.
    Example: [SessionRangingParams.device_type, SessionRangingParams.ranging_round_usage]
    """

    number_of_parameters: int = 0
    """Do NOT set manually! This is set automatically based on the length of the param_list."""

    def __post_init__(self):
        self.number_of_parameters = len(self.param_list)

    def create_payload(self) -> List[int]:
        if self.number_of_parameters == 0:
            return [self.number_of_parameters]

        payload = [len(self.param_list)]

        for param in self.param_list:
            if param not in vars(SessionRangingParams).values() or param not in vars(SessionRadarParams).values():
                raise AttributeError(
                    f"Param ({param}) neither part of {SessionRangingParams.__class__.__name__} nor {SessionRadarParams.__class__.__name__}!"
                )
            payload.append(param.tag)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int], session_type: EnumSessionType):
        p = PayloadParser(payload)
        param_class: SessionRangingParams | SessionRadarParams = choose_param_class_for_session_params(session_type)

        number_of_parameters = p.extract_int(1)
        session_get_app_config_cmd = cls(
            param_list=[param_class.find_name_by_tag(tag, session_type) for tag in p.extract_list(END)]
            if number_of_parameters > 0
            else list(vars(param_class).keys()),
        )
        setattr(session_get_app_config_cmd, "_param_class", param_class)
        return session_get_app_config_cmd

    def __str__(self) -> str:
        if any([isinstance(param, str) for param in self.param_list]):
            return class_to_str(self, include_title=True, indent_level=0)
        else:
            _self = deepcopy(self)
            _self.param_list = [f"{name} ({as_hex(value.tag)})" for name, value in vars(self._param_class).items() if value in self.param_list]
            return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(order=True)
class SessionGetAppConfigRsp(TlvResponseBase):
    """
    To get the current configuration for specified configurations. Contains:
        SESSION_GET_APP_CONFIG_RSP

    Params: SessionRangingParams (AiO, CCC) or SessionRadarParams (AiO)
    """

    @classmethod
    def from_bytes(cls, payload: List[int], session_type: EnumSessionType):
        p = PayloadParser(payload)
        param_class: SessionRangingParams | SessionRadarParams = choose_param_class_for_session_params(session_type)

        status = p.extract_enum(EnumUciStatus)
        number_of_parameters = p.extract_int(1)

        get_app_config_rsp = cls._from_bytes_base(payload=p.extract_list(END), param_class=param_class) if number_of_parameters > 0 else cls()
        setattr(get_app_config_rsp, "status", status)
        setattr(get_app_config_rsp, "number_of_parameters", number_of_parameters)
        return get_app_config_rsp

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


@dataclass(frozen=True, order=True)
class SessionGetCountCmd(CommandBase):
    """
    To get the number of the UWB sessions in UWBD device. Contains:
        SESSION_GET_COUNT_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_GET_COUNT, init=False)


@dataclass(frozen=True, order=True)
class SessionGetCountRsp(ResponseBase):
    """
    To get the number of the UWB sessions in UWBD device. Contains:
        SESSION_GET_COUNT_RSP
    """

    status = EnumUciStatus
    session_count: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus), session_count=p.extract_int(1))


@dataclass(frozen=True, order=True)
class SessionGetStateCmd(CommandBase):
    """
    To get the current state of the UWB session. Contains:
        SESSION_GET_STATE_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_GET_STATE, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(session_handle=p.extract_int(4))


@dataclass(frozen=True, order=True)
class SessionGetStateRsp(ResponseBase):
    """
    To get the current state of the UWB session. Contains:
        SESSION_GET_STATE_RSP
    """

    status = EnumUciStatus
    session_state: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            session_state=p.extract_enum(EnumSessionState),
        )


@dataclass(frozen=True, order=True)
class SessionUpdateControllerMulticastListCmd(CommandBase):
    """
    To update the multicast list. Contains:
        MAC_OID_SESSION_UPDATE_CONTROLLER_MULTICAST_LIST_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_UPDATE_CONTROLLER_MULTICAST_LIST, init=False)

    session_handle: int
    action: EnumMulticastAction
    number_of_controlees: int
    controlee_list: List[Controlee]

    def create_payload(self) -> List[int]:
        payload = []
        payload += to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        payload += [int(self.action)]
        payload += [int(self.number_of_controlees)]
        payload.extend([controlee.create_payload() for controlee in self.controlee_list])
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
            action=(action := p.extract_enum(EnumMulticastAction)),
            number_of_controlees=(number_of_controlees := p.extract_int(1)),
            controlee_list=[
                p.extract_cls(
                    Controlee,
                    22
                    if action == EnumMulticastAction.ADD_CONTROLEE_16_SUB_SESSION_KEY
                    else 38
                    if action == EnumMulticastAction.ADD_CONTROLEE_32_SUB_SESSION_KEY
                    else 6,
                )
                for _ in range(number_of_controlees)
            ],
        )


@dataclass(frozen=True, order=True)
class SessionUpdateControllerMulticastListRsp(ResponseBase):
    """
    To update the multicast list. Contains:
        MAC_OID_SESSION_UPDATE_CONTROLLER_MULTICAST_LIST_RSP
    """

    status = EnumUciStatus
    number_of_controlees: int
    status_list: List[ControleeStatus]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            number_of_controlees=(number_of_controlees := p.extract_int(1)),
            status_list=[p.extract_cls(ControleeStatus, 3) for _ in range(number_of_controlees)],
        )


@dataclass(frozen=True, order=True)
class SessionUpdateControllerMulticastListNtf(NotificationBase):
    """
    To update the multicast list. Contains:
        MAC_OID_SESSION_UPDATE_CONTROLLER_MULTICAST_LIST_NTF
    """

    session_handle: int
    number_of_controlees: int
    status_list: List[ControleeStatus]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            number_of_controlees=(number_of_controlees := p.extract_int(1)),
            status_list=[p.extract_cls(ControleeStatus, 3) for _ in range(number_of_controlees)],
        )


@dataclass(frozen=True, order=True)
class SessionGetPossibleRanMultiplierValueCmd(CommandBase):
    """
    To check possible RAN multiplier value for a new session. Contains:
        SESSION_GET_POSSIBLE_RAN_MULTIPLIER_VALUE_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_SESSION_CONFIG, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidSessionConfig.MAC_OID_SESSION_GET_POSSIBLE_RAN_MULTIPLIER_VALUE, init=False)


@dataclass(frozen=True, order=True)
class SessionGetPossibleRanMultiplierValueRsp(ResponseBase):
    """
    To check possible RAN multiplier value for a new session. Contains:
        SESSION_GET_POSSIBLE_RAN_MULTIPLIER_VALUE_CMD
    """

    status: EnumUciStatus
    ran_multiplier_value: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus), ran_multiplier_value=p.extract_int(1))


######################################################################
### RANGING SESSION CONTROL ##########################################


class EnumRangingMeasurementType(IntEnum):
    FIRA_TWO_WAY = 0x01
    CCC_CONTROLLER = 0x04
    CCC_CONTROLEE = 0x05


class EnumMacAddressMode(IntEnum):
    SHORT_MAC_2_BYTES_2_BYTES_HEADER = 0x00
    EXTENDED_MAC_8_BYTES_2_BYTES_HEADER = 0x01  # not supported
    EXTENDED_MAC_8_BYTES_8_BYTES_HEADER = 0x02  # not supported


class EnumLosType(IntEnum):
    LoS = 0x00
    NLos = 0x01
    UNABLE_TO_DETERMINE = 0xFF


class EnumRangingStatus(IntEnum):
    SUCCESS = 0x0
    TRANSACTION_OVERFLOW = 0x1
    TRANSACTION_EXPIRED = 0x2
    INCORRECT_FRAME = 0x3
    RESPONDER_LISTEN_ONLY = 0xD  # not available for controller
    ANALOG_RAMPUP_TIME_TOO_SHORT_OR_TIMEOUT = 0xE
    RANGING_CONTROL_MESSAGE_LOST = 0xF  # not available for controller


@dataclass(order=True)
class ResponderRangingResults:
    responder_slot_index: int

    ranging_status: EnumUciStatus

    aoa_azimuth: float | None = None
    """
    AoA Azimuth in degrees measured at the device. Range: [-180° to +180°]

    If not calculated: "None"
    """

    aoa_azimuth_fom: int | None = None
    """
    The AoA Azimuth FOM field conveys the reliability of the estimated AOA Azimuth.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.

    If not calculated: "None"
    """

    aoa_elevation: float | None = None
    """
    AoA Elevation in degrees measured at the device. Range: [-90 to +90]

    If not calculated: "None"
    """

    aoa_elevation_fom: int | None = None
    """
    The AoA Elevation FOM field conveys the reliability of the estimated AOA Elevation.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.

    If not calculated: "None"
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        responder_slot_index = p.extract_int(1)
        ranging_status = p.extract_enum(EnumUciStatus)
        aoa_azimuth_raw = p.extract_int(2, signed=True)
        aoa_azimuth_fom_raw = p.extract_int(1)
        aoa_elevation_raw = p.extract_int(2, signed=True)
        aoa_elevation_fom_raw = p.extract_int(1)

        return cls(
            responder_slot_index=responder_slot_index,
            ranging_status=ranging_status,
            aoa_azimuth=aoa_azimuth_raw / 128 if aoa_azimuth_raw not in (0x7FFF, 0x0000) else None,
            aoa_azimuth_fom=aoa_azimuth_fom_raw if aoa_azimuth_fom_raw not in (0xFF, 0x00) else None,
            aoa_elevation=aoa_elevation_raw / 128 if aoa_elevation_raw != 0x7FFF else None,
            aoa_elevation_fom=aoa_elevation_fom_raw if aoa_elevation_fom_raw != 0xFF else None,
        )

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.aoa_azimuth = f"{self.aoa_azimuth:.2f} °" if self.aoa_azimuth is not None else self.aoa_azimuth
        _self.aoa_elevation = f"{self.aoa_elevation:.2f} °" if self.aoa_elevation is not None else self.aoa_elevation
        return class_to_str(_self, include_title=False, indent_level=1)


@dataclass(frozen=True, order=True)
class SessionStartCmd(CommandBase):
    """
    To activate a UWB ranging session. Contains:
        SESSION_START_CMD (CCC: RANGE_START_CMD)
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidRangingSession.MAC_OID_SESSION_START, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(session_handle=p.extract_int(4))


@dataclass(frozen=True, order=True)
class SessionStartRsp(ResponseBase):
    """
    To activate a UWB ranging session. Contains:
        SESSION_START_RSP (CCC: RANGE_START_RSP)
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(order=True)
class FiRaTwoWayRangingMeasurement:
    mac_address: int
    """
    Short address of the participating device. 2 Octets short address if MAC addressing mode indicator = 0x00.
    This field shall be set to 0xFFFF if the MAC address could not be determined.
    """

    ranging_status: EnumUciStatus
    """
    If Status field is other than STATUS_OK or STATUS_OK_NEGATIVE_DISTANCE_REPORT,
    then all other values except for MAC address and Slot Index shall be ignored.
    """

    nlos: EnumLosType
    """Indicates if the ranging measurement was in Line of Sight (LoS) or Non-Line of Sight (NLoS)."""

    distance_cm: int | None
    """
    Distance between initiator and anchor in cm.

    If unable to calculate distance: "None"
    """

    aoa_azimuth: float
    """AoA Azimuth in degrees measured at the device. Range: [-180° to +180°]"""

    aoa_azimuth_fom: int
    """
    The AoA Azimuth Figure of Merit (FoM) field conveys the reliability of the estimated AOA Azimuth.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    aoa_elevation: float
    """AoA Elevation in degrees measured at the device. Range: [-90 to +90]"""

    aoa_elevation_fom: int
    """
    The AoA Elevation Figure of Merit (FoM) field conveys the reliability of the estimated AOA Elevation.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    aoa_destination_azimuth: float
    """
    AoA Azimuth in degrees of the responder's report packet (Ranging Result Report Message (RRRM) or
    Measurement Report Message (MRM) Type 3). Range: [-180° to +180°]
    """

    aoa_destination_azimuth_fom: int
    """
    The AoA Destination Azimuth Figure of Merit (FoM) field conveys the reliability of the estimated AOA Azimuth.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    aoa_destination_elevation: float
    """
    AoA Elevation in degrees of the responder's report packet (Ranging Result Report Message (RRRM) or
    Measurement Report Message (MRM) Type 3). Range: [-90° to +90°]
    """

    aoa_destination_elevation_fom: int
    """
    The AoA Destination Elevation Figure of Merit (FoM) field conveys the reliability of the estimated AOA Elevation.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    slot_index: int
    """
    In case of a failure, this field indicates the slot number within the ranging round where the failure has occurred.
    Slot number starts from zero.
    """

    rssi_dbm: float | None
    """
    Range (in dBm, step: 0.5dBm) = -[0.5, 127.5]

    When the Status field is STATUS_OK, this field contains the minimum RSSI of all received
    ranging slots related to the participating device during the ranging round.
    When the Status field is not STATUS_OK, the field contains the RSSI value measured during
    the received ranging slot where the failure has occurred.

    'None' if RSSI is unavailable or reporting is disabled.
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)

        mac_address = p.extract_int(2)
        ranging_status = p.extract_enum(EnumUciStatus)
        nlos = p.extract_enum(EnumLosType)
        distance_raw = p.extract_int(2)
        distance_cm = distance_raw if distance_raw != 0xFFFF else None
        aoa_azimuth = p.extract_int(2, signed=True) / 128
        aoa_azimuth_fom = p.extract_int(1)
        aoa_elevation = p.extract_int(2, signed=True) / 128
        aoa_elevation_fom = p.extract_int(1)
        aoa_destination_azimuth = p.extract_int(2, signed=True) / 128
        aoa_destination_azimuth_fom = p.extract_int(1)
        aoa_destination_elevation = p.extract_int(2, signed=True) / 128
        aoa_destination_elevation_fom = p.extract_int(1)
        slot_index = p.extract_int(1)
        rssi_raw = p.extract_int(1)
        rssi_dbm = -(rssi_raw / 2) if rssi_raw != 0 else None

        return cls(
            mac_address=mac_address,
            ranging_status=ranging_status,
            nlos=nlos,
            distance_cm=distance_cm,
            aoa_azimuth=aoa_azimuth,
            aoa_azimuth_fom=aoa_azimuth_fom,
            aoa_elevation=aoa_elevation,
            aoa_elevation_fom=aoa_elevation_fom,
            aoa_destination_azimuth=aoa_destination_azimuth,
            aoa_destination_azimuth_fom=aoa_destination_azimuth_fom,
            aoa_destination_elevation=aoa_destination_elevation,
            aoa_destination_elevation_fom=aoa_destination_elevation_fom,
            slot_index=slot_index,
            rssi_dbm=rssi_dbm,
        )

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.distance_cm = str(self.distance_cm) + " cm" if self.distance_cm is not None else self.distance_cm
        _self.aoa_azimuth = f"{self.aoa_azimuth:.2f} °" if self.aoa_azimuth is not None else self.aoa_azimuth
        _self.aoa_elevation = f"{self.aoa_elevation:.2f} °" if self.aoa_elevation is not None else self.aoa_elevation
        _self.aoa_destination_azimuth = (
            f"{self.aoa_destination_azimuth:.2f} °" if self.aoa_destination_azimuth is not None else self.aoa_destination_azimuth
        )
        _self.aoa_destination_elevation = (
            f"{self.aoa_destination_elevation:.2f} °" if self.aoa_destination_elevation is not None else self.aoa_destination_elevation
        )
        return class_to_str(_self, include_title=True, indent_level=1)


@dataclass(order=True)
class CccControllerRangingMeasurement:
    ranging_status: EnumUciStatus
    """
    If Status field is other than STATUS_OK or STATUS_OK_NEGATIVE_DISTANCE_REPORT,
    then all other values except for MAC address and Slot Index shall be ignored.
    """

    slot_index: int
    """
    In time schedule mode, in case of a failure, this field indicates the slot number
    within the ranging round where the failure has occurred. If the Slot Index field
    is not used, then it shall be set to 0. Slot number starts from zero.
    """

    ranging_round_index: int
    """Next ranging round index."""

    sts_index: int
    """STS index of the final frame."""

    aoa_azimuth: float
    """AoA Azimuth in degrees measured at the device. Range: [-180° to +180°]"""

    aoa_azimuth_fom: int
    """
    The AoA Azimuth Figure of Merit (FoM) field conveys the reliability of the estimated AOA Azimuth.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    aoa_elevation: float
    """AoA Elevation in degrees measured at the device. Range: [-90 to +90]"""

    aoa_elevation_fom: int
    """
    The AoA Elevation Figure of Merit (FoM) field conveys the reliability of the estimated AOA Elevation.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)

        ranging_status = p.extract_enum(EnumUciStatus)
        slot_index = p.extract_int(1)
        ranging_round_index = p.extract_int(2)
        sts_index = p.extract_int(2)
        aoa_azimuth = p.extract_int(2, signed=True) / 128
        aoa_azimuth_fom = p.extract_int(1)
        aoa_elevation = p.extract_int(2, signed=True) / 128
        aoa_elevation_fom = p.extract_int(1)

        return cls(
            ranging_status=ranging_status,
            slot_index=slot_index,
            ranging_round_index=ranging_round_index,
            sts_index=sts_index,
            aoa_azimuth=aoa_azimuth,
            aoa_azimuth_fom=aoa_azimuth_fom,
            aoa_elevation=aoa_elevation,
            aoa_elevation_fom=aoa_elevation_fom,
        )

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.aoa_azimuth = f"{self.aoa_azimuth:.2f} °" if self.aoa_azimuth is not None else self.aoa_azimuth
        _self.aoa_elevation = f"{self.aoa_elevation:.2f} °" if self.aoa_elevation is not None else self.aoa_elevation
        return class_to_str(_self, include_title=True, indent_level=1)


@dataclass(order=True)
class CccControleeRangingMeasurement:
    ranging_status: EnumUciStatus
    """
    If Status field is other than STATUS_OK or STATUS_OK_NEGATIVE_DISTANCE_REPORT,
    then all other values except for MAC address and Slot Index shall be ignored.
    """

    slot_index: int
    """
    In time schedule mode, in case of a failure, this field indicates the slot number
    within the ranging round where the failure has occurred. If the Slot Index field
    is not used, then it shall be set to 0. Slot number starts from zero.
    """

    ranging_round_index: int
    """Next ranging round index."""

    sts_index: int
    """STS index of the final frame."""

    distance_cm: int | None
    """
    Distance between initiator and anchor in cm.

    If unable to calculate distance: "None"
    """

    uncertainty_responder_fom: int
    """Ranging timestamp uncertainty of controlee."""

    uncertainty_initiator_fom: int
    """Ranging timestamp uncertainty of controller."""

    aoa_azimuth: float
    """AoA Azimuth in degrees measured at the device. Range: [-180° to +180°]"""

    aoa_azimuth_fom: int
    """
    The AoA Azimuth Figure of Merit (FoM) field conveys the reliability of the estimated AOA Azimuth.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    aoa_elevation: float
    """AoA Elevation in degrees measured at the device. Range: [-90 to +90]"""

    aoa_elevation_fom: int
    """
    The AoA Elevation Figure of Merit (FoM) field conveys the reliability of the estimated AOA Elevation.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)

        ranging_status = p.extract_enum(EnumUciStatus)
        slot_index = p.extract_int(1)
        ranging_round_index = p.extract_int(2)
        sts_index = p.extract_int(2)
        distance_raw = p.extract_int(2)
        distance_cm = distance_raw if distance_raw != 0xFFFF else None
        uncertainty_responder_fom = p.extract_int(1)
        uncertainty_initiator_fom = p.extract_int(1)
        aoa_azimuth = p.extract_int(2, signed=True) / 128
        aoa_azimuth_fom = p.extract_int(1)
        aoa_elevation = p.extract_int(2, signed=True) / 128
        aoa_elevation_fom = p.extract_int(1)

        return cls(
            ranging_status=ranging_status,
            slot_index=slot_index,
            ranging_round_index=ranging_round_index,
            sts_index=sts_index,
            distance_cm=distance_cm,
            uncertainty_responder_fom=uncertainty_responder_fom,
            uncertainty_initiator_fom=uncertainty_initiator_fom,
            aoa_azimuth=aoa_azimuth,
            aoa_azimuth_fom=aoa_azimuth_fom,
            aoa_elevation=aoa_elevation,
            aoa_elevation_fom=aoa_elevation_fom,
        )

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.distance_cm = str(self.distance_cm) + " cm" if self.distance_cm is not None else self.distance_cm
        _self.aoa_azimuth = f"{self.aoa_azimuth:.2f} °" if self.aoa_azimuth is not None else self.aoa_azimuth
        _self.aoa_elevation = f"{self.aoa_elevation:.2f} °" if self.aoa_elevation is not None else self.aoa_elevation
        return class_to_str(_self, include_title=True, indent_level=1)


@dataclass(order=True)
class SessionInfoNtf(NotificationBase):
    """
    To notify the FiRa ranging results from UWBS device after ranging session has activated. Contains:
        SESSION_INFO_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidRangingSession.MAC_OID_SESSION_START, init=False)

    session_sequence_counter: int
    """
    The UWBS maintains the session sequence counter. The session sequence counter start with 0 when the session is started,
    the session sequence counter stops incrementing when SESSION_STOP_CMD is issued, and it resumes from the point where it
    stopped on subsequent SESSION_START_CMD. The session sequence counter shall be incremented by the UWBS for every
    SESSION_INFO_NTF sent to the Host. The application can make use of this counter for referencing or other bookkeeping purposes.
    """

    session_handle: int
    """Session handle of the currently active session"""

    current_ranging_interval: int
    """
    Current ranging interval setting in 1200 RSTU.
    This field is 0 if session is terminated by in band signaling
    """

    ranging_measurement_type: EnumRangingMeasurementType
    """Indicate One Way Ranging Measurement or Two Way Ranging Measurement (SS-TWR, DS-TWR)."""

    mac_addressing_mode_indicator: EnumMacAddressMode
    """MAC addressing mode in ranging measurements."""

    number_of_ranging_measurements: int
    """
    Number of ranging measurements to follow. M = 1 for “single device to single device” (Controller/Controlee).
    M = N for the multicast DS-TWR with N controlees
    """

    measurements: List[FiRaTwoWayRangingMeasurement | CccControllerRangingMeasurement | CccControleeRangingMeasurement]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        session_sequence_counter = p.extract_int(4)
        session_handle = p.extract_int(4)
        current_ranging_interval = p.extract_int(4)
        ranging_measurement_type = p.extract_enum(EnumRangingMeasurementType)
        p.advance_bytes(1)  # RFU
        mac_addressing_mode_indicator = p.extract_enum(EnumMacAddressMode)
        p.advance_bytes(8)  # RFU
        number_of_ranging_measurements = p.extract_int(1)

        measurement_num_bytes = {
            31: FiRaTwoWayRangingMeasurement,
            18: CccControllerRangingMeasurement,
            22: CccControleeRangingMeasurement,
        }
        remaining_payload_length = len(payload) - 25
        for num_bytes, cls in measurement_num_bytes.items():
            if remaining_payload_length == num_bytes * number_of_ranging_measurements:
                measurements = [p.extract_cls(cls, num_bytes) for _ in range(number_of_ranging_measurements)]
                break
        else:
            raise ValueError(f"Remaining payload length ({remaining_payload_length}) did not match any known pattern for measurements.")

        return cls(
            session_sequence_counter=session_sequence_counter,
            session_handle=session_handle,
            current_ranging_interval=current_ranging_interval,
            ranging_measurement_type=ranging_measurement_type,
            mac_addressing_mode_indicator=mac_addressing_mode_indicator,
            number_of_ranging_measurements=number_of_ranging_measurements,
            measurements=measurements,
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=0)


@dataclass(frozen=True, order=True)
class SessionStopCmd(CommandBase):
    """
    To deactivate a UWB ranging session. Contains:
        SESSION_STOP_CMD (CCC: RANGE_STOP_CMD)
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidRangingSession.MAC_OID_SESSION_STOP, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(session_handle=p.extract_int(4))


@dataclass(frozen=True, order=True)
class SessionStopRsp(ResponseBase):
    """
    To deactivate a UWB ranging session. Contains:
        SESSION_STOP_RSP (CCC: RANGE_STOP_RSP)
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class RangeGetRangingCountCmd(CommandBase):
    """
    To get the number of ranging rounds attempted. Contains:
        RANGE_GET_RANGING_COUNT_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidRangingSession.MAC_OID_RANGE_GET_RANGING_COUNT, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(session_handle=p.extract_int(4))


@dataclass(frozen=True, order=True)
class RangeGetRangingCountRsp(ResponseBase):
    """
    To get the number of ranging rounds attempted. Contains:
        RANGE_GET_RANGING_COUNT_RSP
    """

    status: EnumUciStatus
    count: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            count=p.extract_int(4),
        )


@dataclass(order=True)
class RangeCccDataNtf(NotificationBase):
    """
    To notify about the ranging results from UWBD device after successful activation of a ranging session. Contains:
        RANGE_CCC_DATA_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidRangingSession = field(default=EnumMacOidRangingSession.MAC_OID_RANGE_CCC_DATA, init=False)

    # CCC controllee and CCC controller
    session_handle: int
    """Session handle of the currently active session"""
    ranging_status: EnumUciStatus

    sts_index: int
    """STS index received in final data message"""

    rr_index: int
    """Next ranging round index"""

    device_role: EnumDeviceRole

    # Only CCC controllee (Responder)
    distance_cm: int | None = None
    """Distance between initiator and anchor in cm"""

    uncertainty_anchor_fom: int | None = None
    """Ranging timestamp uncertainty of controllee"""

    uncertainty_initiator_fom: int | None = None
    """Ranging timestamp uncertainty of controller"""

    aoa_azimuth: float | None = None
    """
    AoA Azimuth in degrees measured at the device. Range: [-180° to +180°]

    If not calculated: "None"
    """

    aoa_azimuth_fom: int | None = None
    """
    The AoA Azimuth FOM field conveys the reliability of the estimated AOA Azimuth.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.

    If not calculated: "None"
    """

    aoa_elevation: float | None = None
    """
    AoA Elevation in degrees measured at the device. Range: [-90 to +90]

    If not calculated: "None"
    """

    aoa_elevation_fom: int | None = None
    """
    The AoA Elevation FOM field conveys the reliability of the estimated AOA Elevation.
    FOM goes from 0 to 100. Higher values indicate better quality AoA estimates.
    Lower values suggest decreased reliability in the estimates.

    If not calculated: "None"
    """

    # Only CCC controller (Initiator)
    number_of_responders: int | None = None
    responder_ranging_results: List[ResponderRangingResults] | None = None

    # CCC controllee and CCC controller
    ccm_tag: List[int] | None = None
    """CCM* TAG calculated over all payload fields. CCM* TAG can be set to all 0xFF if not used."""

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        range_ccc_data = cls(
            session_handle=p.extract_int(4),
            ranging_status=p.extract_enum(EnumUciStatus),
            sts_index=p.extract_int(4),
            rr_index=p.extract_int(2),
            device_role=p.extract_enum(EnumDeviceRole),
        )
        match range_ccc_data.device_role:
            case EnumDeviceRole.RESPONDER:
                range_ccc_data.distance_cm = p.extract_int(2)
                range_ccc_data.uncertainty_anchor_fom = p.extract_int(1)
                range_ccc_data.uncertainty_initiator_fom = p.extract_int(1)
                aoa_azimuth_raw = p.extract_int(2, signed=True)
                range_ccc_data.aoa_azimuth = aoa_azimuth_raw / 128 if aoa_azimuth_raw not in (0x7FFF, 0x0000) else None
                aoa_azimuth_fom_raw = p.extract_int(1)
                range_ccc_data.aoa_azimuth_fom = aoa_azimuth_fom_raw if aoa_azimuth_fom_raw not in (0x7FFF, 0x00) else None
                aoa_elevation_raw = p.extract_int(2, signed=True)
                range_ccc_data.aoa_elevation = aoa_elevation_raw / 128 if aoa_elevation_raw != 0x7FFF else None
                aoa_elevation_fom_raw = p.extract_int(1)
                range_ccc_data.aoa_elevation_fom = aoa_elevation_fom_raw if aoa_elevation_fom_raw != 0xFF else None
                range_ccc_data.ccm_tag = p.extract_list(8)
            case EnumDeviceRole.INITIATOR:
                range_ccc_data.number_of_responders = p.extract_int(1)
                range_ccc_data.responder_ranging_results = [
                    p.extract_cls(ResponderRangingResults, 8) for _ in range(range_ccc_data.number_of_responders)
                ]
                range_ccc_data.ccm_tag = p.extract_list(8)
        return range_ccc_data

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.aoa_azimuth = f"{self.aoa_azimuth:.2f} °" if self.aoa_azimuth is not None else self.aoa_azimuth
        _self.aoa_elevation = f"{self.aoa_elevation:.2f} °" if self.aoa_elevation is not None else self.aoa_elevation
        _self.distance_cm = str(self.distance_cm) + " cm" if self.distance_cm is not None else self.distance_cm
        return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(frozen=True, order=True)
class RangeResumeCmd(CommandBase):
    """
    To resume a session, which has been stopped. Contains:
        RANGE_RESUME_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidRangingSession = field(default=EnumMacOidRangingSession.MAC_OID_RANGE_RESUME, init=False)

    session_handle: int
    sts_index: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        payload += to_hex_list(input=self.sts_index, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
            sts_index=p.extract_int(4),
        )


@dataclass(frozen=True, order=True)
class RangeResumeRsp(ResponseBase):
    """
    To resume a session, which has been stopped. Contains:
        RANGE_RESUME_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class RangeRecoverCmd(CommandBase):
    """
    Command to recover a previously configured session with a new STS_INDEX0 and UWB_INITIATION_TIME. Contains:
        RANGE_RECOVER_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL, init=False)
    _oid_: EnumMacOidRangingSession = field(default=EnumMacOidRangingSession.MAC_OID_RANGE_RECOVER, init=False)

    session_handle: int

    sts_index0: int
    """
    New STS_INDEX0 negotiated between vehicle and mobile device.
    It shall be greater than the last STS index used for ranging.
    """

    uwb_initiation_time_ms: int
    """
    The UWB initiation time is the absolute time in the UWBS time domain in which the
    first message in the ranging round shall be transmitted after the session is started.
    If the value is set to 0, then UWB_INITIATION_TIME shall not be applicable.
    Range: [1 .. (2^64 - 1)]
    Default: 0
    """

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        payload += to_hex_list(input=self.sts_index0, byteorder="little", forced_list_len=4)
        payload += to_hex_list(input=self.uwb_initiation_time_ms, byteorder="little", forced_list_len=8)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
            sts_index0=p.extract_int(4),
            uwb_initiation_time_ms=p.extract_int(8),
        )


@dataclass(frozen=True, order=True)
class RangeRecoverRsp(ResponseBase):
    """
    Command to recover a previously configured session with a new STS_INDEX0 and UWB_INITIATION_TIME. Contains:
        RANGE_RECOVER_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


######################################################################
### PROPRIETARY ######################################################


class EnumRxStatus(IntEnum):
    RX_NOT_EXECUTED = 0x00
    RX_EXECUTED_NO_DATA = 0x01
    RX_EXECUTED_WITH_DATA = 0x02


class EnumRxError(IntEnum):
    NO_ERROR = 0x000000
    PREAMBLE_TIMEOUT = 0x000001
    SFD_TIMEOUT = 0x000002
    TOA_SIGNAL_DETECTION_FAILED = 0x000004
    STS_MISMATCH = 0x000008
    RX_SECDED_DECODE_FAILURE = 0x000010
    RX_REED_SOLOMON_DECODE_FAILURE = 0x000020
    SIGNAL_LOST = 0x000040
    RX_PSDU_TIMEOUT = 0x000080
    CRC_ERROR_IN_RX_PSDU = 0x000100
    PDOA_DETECTION_FAILED = 0x000200


@dataclass(order=True)
class RxStatus:
    rx_status: EnumRxStatus
    rx_error: EnumRxError

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(rx_status=p.extract_enum(EnumRxStatus), rx_error=p.extract_enum(EnumRxError, 3))

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


class EnumTxStatus(IntEnum):
    TX_NOT_EXECUTED = 0x0
    TX_EXECUTED_FRAME_TRANSMITTED = 0x1


class EnumTxError(IntEnum):
    NO_ERROR = 0x0
    TX_ERROR = 0x1


@dataclass(order=True)
class TxStatus:
    tx_status: EnumTxStatus
    tx_error: EnumTxError

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status_bit = p.extract_bits(1)
        error_bit = p.extract_bits(7)

        return cls(
            tx_status=EnumTxStatus(status_bit) if status_bit in EnumTxStatus._value2member_map_ else status_bit,
            tx_error=EnumTxError(error_bit) if error_bit in EnumTxError._value2member_map_ else error_bit,
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


class EnumTimestampStatus(IntEnum):
    NO_TIMESTAMP_ACQUIRED = 0x00
    TIMESTAMP_ACQUIRED_RX1 = 0x01
    TIMESTAMP_ACQUIRED_RX2 = 0x02
    TIMESTAMP_ACQUIRED_TX1 = 0x03
    TIMESTAMP_ACQUIRED_TX2 = 0x04
    TIMESTAMP_ACQUIRED_RX1_AS_FIRST_PATH_FOLLOWED_RX2 = 0x11
    TIMESTAMP_ACQUIRED_RX1_AS_SECOND_PATH_PRECEDED_RX2 = 0x21
    TIMESTAMP_ACQUIRED_RX2_AS_FIRST_PATH_FOLLOWED_RX1 = 0x12
    TIMESTAMP_ACQUIRED_RX2_AS_SECOND_PATH_PRECEDED_RX1 = 0x22
    TIMESTAMP_INVALID = 0xFF


@dataclass(order=True)
class RxTimestamp:
    first_path_ticks: int
    first_path_timestamp_ns: float
    first_path_status: EnumTimestampStatus

    second_path_ticks: int
    second_path_timestamp_ns: float
    second_path_status: EnumTimestampStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        fractional_part_first_path = p.extract_int(4)
        integer_part_first_path = p.extract_int(8)
        first_path_status = p.extract_enum(EnumTimestampStatus)

        fractional_part_second_path = p.extract_int(4)
        integer_part_second_path = p.extract_int(8)
        second_path_status = p.extract_enum(EnumTimestampStatus)

        return cls(
            first_path_ticks=fractional_part_first_path + (integer_part_first_path * 2**9),
            first_path_timestamp_ns=(integer_part_first_path * 8.0128) + (fractional_part_first_path * 15.65 / 1000),
            first_path_status=first_path_status,
            second_path_ticks=fractional_part_second_path + (integer_part_second_path * 2**9),
            second_path_timestamp_ns=(integer_part_second_path * 8.0128) + (fractional_part_second_path * 15.65 / 1000),
            second_path_status=second_path_status,
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(order=True)
class TxTimestamp:
    timestamp_ns: float
    status: EnumTimestampStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        fractional_part = p.extract_int(4)
        integer_part = p.extract_int(8)
        status = p.extract_enum(EnumTimestampStatus)

        return cls(
            timestamp_ns=(integer_part * 8.0128) + (fractional_part * 15.65 / 1000),
            status=status,
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


class EnumResultIndex(IntEnum):
    RX1_STS_SEG1 = 0x01
    RX2_STS_SEG1 = 0x06


@dataclass(order=True)
class CirLogs:
    rx1: CirLog | None = None
    rx2: CirLog | None = None

    @classmethod
    def from_bytes(cls, payload: List[int]):
        cir_log = CirLog.from_bytes(payload)
        match cir_log.result_index:
            case EnumResultIndex.RX1_STS_SEG1:
                cir_logs_cls = cls(rx1=cir_log)
            case EnumResultIndex.RX2_STS_SEG1:
                cir_logs_cls = cls(rx2=cir_log)
        return cir_logs_cls

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(order=True)
class CirLog:
    result_index: EnumResultIndex
    cir_tap_offset: int
    cir_num_taps: int
    cir_taps_abs: List[int]
    cir_data: List[int]

    @staticmethod
    def calculate_cir_tap_magnitudes(cir_data: List[int]) -> List[int]:
        """
        Calculates the magnitudes of CIR taps.

        Parameters:
            cir_data

        Returns:
            A list of magnitudes, one for each CIR tap.
        """
        magnitudes = []
        for cir_tap in chunked(cir_data, 4):
            real_part = int.from_bytes(bytes=cir_tap[:2], byteorder="little", signed=True)
            imag_part = int.from_bytes(bytes=cir_tap[2:], byteorder="little", signed=True)
            magnitude = sqrt(real_part**2 + imag_part**2)
            magnitudes.append(magnitude)
        return magnitudes

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        result_index = p.extract_enum(EnumResultIndex)
        cir_tap_offset = p.extract_int(4)
        cir_num_taps = p.extract_int(4)
        cir_data = p.extract_list(END)
        cir_taps_abs = cls.calculate_cir_tap_magnitudes(cir_data)

        return cls(
            result_index=result_index,
            cir_tap_offset=cir_tap_offset,
            cir_num_taps=cir_num_taps,
            cir_taps_abs=cir_taps_abs,
            cir_data=cir_data,
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(order=True)
class RxFirstPathInfos:
    rx1: RxFirstPathInfo | None = None
    rx2: RxFirstPathInfo | None = None

    @classmethod
    def from_bytes(cls, payload: List[int]):
        if len(payload) == 48:
            rx1_info = RxFirstPathInfo.from_bytes(payload[0:24])
            rx2_info = RxFirstPathInfo.from_bytes(payload[24:48])
            rx_first_path_infos = rx1_info + rx2_info

        elif len(payload) == 24:
            rx_info = RxFirstPathInfo.from_bytes(payload)
            rx_first_path_infos = cls(rx1=rx_info) if rx_info.result_index == EnumResultIndex.RX1_STS_SEG1 else cls(rx2=rx_info)

        else:
            raise ValueError(f"Unexpected length of payload: {len(payload)}. Expected 24 or 48 bytes.")

        return rx_first_path_infos

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(order=True)
class RxFirstPathInfo:
    timestamp_lsb_ns: float = field(default=0.01565, init=False)

    result_index: EnumResultIndex

    edge_index: int
    """in ns"""

    threshold_power: float
    """ in dBm """

    firstpath_index: int
    """ in ns """

    firstpath_power: float
    """ in dBm """

    max_index: int
    """ in ns """

    max_power: float
    """ in dBm """

    noise_power: float
    """ in dBm """

    overall_rx_power: float
    """ in dBm """

    toa_time: int
    """ in 15.65 ps resolution """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        log10_of_1024 = log10(1024)

        # Extract raw values
        result_index = p.extract_enum(EnumResultIndex)
        edge_index_raw = p.extract_int(2)
        threshold_power_raw = p.extract_int(2, True)
        firstpath_index_raw = p.extract_int(2)
        firstpath_power_raw = p.extract_int(2, True)
        max_index_raw = p.extract_int(2)
        max_power_raw = p.extract_int(2, True)
        noise_power_raw = p.extract_int(2, True)
        overall_rx_power_raw = p.extract_int(2, True)
        toa_time_raw = p.extract_int(4)

        edge_index = edge_index_raw  # CIR bins (~ 1ns)
        threshold_power = log10_of_1024 * threshold_power_raw / 512  # in dBm
        firstpath_index = firstpath_index_raw * cls.timestamp_lsb_ns  # in ns
        firstpath_power = log10_of_1024 * firstpath_power_raw / 512  # in dBm
        max_index = max_index_raw * cls.timestamp_lsb_ns  # in ns
        max_power = log10_of_1024 * max_power_raw / 512  # in dBm
        noise_power = log10_of_1024 * noise_power_raw / 512  # in dBm
        overall_rx_power = log10_of_1024 * overall_rx_power_raw / 512  # in dBm
        toa_time = toa_time_raw  # in 15.65 ps resolution

        return cls(
            result_index=result_index,
            edge_index=edge_index,
            threshold_power=threshold_power,
            firstpath_index=firstpath_index,
            firstpath_power=firstpath_power,
            max_index=max_index,
            max_power=max_power,
            noise_power=noise_power,
            overall_rx_power=overall_rx_power,
            toa_time=toa_time,
        )

    def __add__(self, other: RxFirstPathInfo) -> RxFirstPathInfos:
        if not isinstance(other, RxFirstPathInfo):
            raise TypeError("Can only add RxFirstPathInfo objects together.")
        match self.result_index:
            case EnumResultIndex.RX1_STS_SEG1:
                rx1 = self
                rx2 = other if other.result_index == EnumResultIndex.RX2_STS_SEG1 else None
            case EnumResultIndex.RX2_STS_SEG1:
                rx1 = other if other.result_index == EnumResultIndex.RX1_STS_SEG1 else None
                rx2 = self
            case _:
                raise ValueError(f"Unexpected result index: {self.result_index}")
        return RxFirstPathInfos(rx1=rx1, rx2=rx2)

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.threshold_power = f"{self.threshold_power:.2f} dBm"
        _self.firstpath_index = f"{self.firstpath_index:.2f} ns"
        _self.firstpath_power = f"{self.firstpath_power:.2f} dBm"
        _self.max_index = f"{self.max_index:.2f} ns"
        _self.max_power = f"{self.max_power:.2f} dBm"
        _self.noise_power = f"{self.noise_power:.2f} dBm"
        _self.overall_rx_power = f"{self.overall_rx_power:.2f} dBm"
        _self.toa_time = f"{self.toa_time:.2f} * 15.65 ps"
        return class_to_str(_self, include_title=False, indent_level=2)


@dataclass(order=True)
class RxCarrierFrequencyOffset:
    cfo_int: int
    channel_id: int
    """Range: [5, 6, 8, 9]"""
    cfo_ppm: float = field(init=False)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        cfo_int_raw = p.extract_int(4)
        channel_id = p.extract_int(1)
        cfo_int = -((cfo_int_raw ^ 0x3FFFFF) + 1) if (cfo_int_raw & 0x200000) else cfo_int_raw & 0x1FFFFF

        return cls(
            cfo_int=cfo_int,
            channel_id=channel_id,
        )

    @staticmethod
    def cfo_int_to_cfo_ppm(cfo_int: int, center_frequency_khz: Optional[int] = None, channel_id: Optional[int] = None) -> float:
        """
        Compute the PPM from CFO_INT.

        ### Arguments:
        cfo_int: int
            The carrier frequency offset integer value.
        center_frequency_khz: int
            The center frequency in kHz (optional if channel_id is provided).
        channel_id: int, [5,6,8,9]
            The channel ID to lookup the center frequency (optional if center_frequency_khz is provided).
        """
        uwb_channel_frequency_khz_dict = {
            5: EnumUwbChannelFrequency.ch5.value,
            6: EnumUwbChannelFrequency.ch6.value,
            8: EnumUwbChannelFrequency.ch8.value,
            9: EnumUwbChannelFrequency.ch9.value,
        }

        if center_frequency_khz is None and channel_id is not None:
            center_frequency_khz = uwb_channel_frequency_khz_dict.get(channel_id)
        if cfo_int is None or center_frequency_khz is None:
            raise ValueError("cfo_int and either center_frequency_khz or channel_id must be provided.")

        # Computation steps
        cfo: float = float(cfo_int) / 2**27
        cfo_hz = (124.8e6 / 2) * cfo
        cfo_ppm = cfo_hz / (center_frequency_khz / 1e3)
        return cfo_ppm

    def __post_init__(self):
        self.cfo_ppm = self.cfo_int_to_cfo_ppm(cfo_int=self.cfo_int, channel_id=self.channel_id)

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


class EnumMacDecodingStatus(IntEnum):
    MAC_HEADER_DECODED_SUCCESSFULLY = 0x00
    MAC_PAYLOAD_DECODED_SUCCESSFULLY = 0x01
    MAC_DECODING_FAILURE = 0xFF


class EnumReasonMacDecodingFailure(IntEnum):
    REASON_UNSPECIFIED_OR_DECODING_SUCCESSFUL = 0
    INVALID_LENGTH_OF_FRAME = 1
    INVALID_CRC_VALUE = 2
    INVALID_DESTINATION_ADDRESS = 3
    INVALID_SOURCE_ADDRESS = 4

    FRAME_CONTROL_INVALID_LENGTH = 10
    FRAME_CONTROL_INVALID_FRAME_TYPE = 11
    FRAME_CONTROL_NOT_SUPPORTED_VERSION = 12
    FRAME_CONTROL_NOT_SUPPORTED_ACK_REQUEST = 13
    FRAME_CONTROL_INVALID_ADDRESSING_MODE = 14
    FRAME_CONTROL_NOT_SUPPORTED_VALUE_OF_IE_PRESENT_FIELD = 15

    AUXILIARY_HEADER_INVALID_FIELD = 20
    AUXILIARY_HEADER_INVALID_LENGTH = 21
    AUXILIARY_HEADER_INVALID_KEY_ID_MODE = 22
    AUXILIARY_HEADER_INVALID_KEY_LENGTH = 23
    AUXILIARY_HEADER_INVALID_SECURITY_LEVEL = 24
    AUXILIARY_HEADER_INVALID_KEY_INDEX = 25

    INFORMATION_ELEMENT_INVALID_FIELD = 30
    INFORMATION_ELEMENT_INVALID_LENGTH = 31
    INFORMATION_ELEMENT_INVALID_HEADER_LENGTH = 32
    INFORMATION_ELEMENT_NOT_SUPPORTED_HEADER_TYPE = 33
    INFORMATION_ELEMENT_EXPECTED_HEADER_TERMINATION1 = 34
    INFORMATION_ELEMENT_EXPECTED_HEADER_TERMINATION2 = 35
    INFORMATION_ELEMENT_REQUIRED_FIELDS_MISSING = 36

    INFORMATION_ELEMENT_CCC_INVALID_LENGTH = 40
    INFORMATION_ELEMENT_CCC_INVALID_HEADER_LENGTH = 41
    INFORMATION_ELEMENT_CCC_INVALID_MESSAGE_ID = 42
    INFORMATION_ELEMENT_CCC_INVALID_MESSAGE_LENGTH = 43

    MAC_PAYLOAD_INVALID_LENGTH = 60
    MAC_PAYLOAD_DECODING_FAILED = 61

    MAC_PAYLOAD_CCC_INVALID_LENGTH = 70
    MAC_PAYLOAD_CCC_DECRYPTION_FAILED = 71
    MAC_PAYLOAD_CCC_INVALID_MESSAGE_ID = 72
    MAC_PAYLOAD_CCC_INVALID_RCM_LENGTH = 73
    MAC_PAYLOAD_CCC_INVALID_MEASUREMENT_REPORT_LENGTH = 74
    MAC_PAYLOAD_CCC_INVALID_NUMBER_OF_IE_NODES = 75
    MAC_PAYLOAD_CCC_INVALID_PAYLOAD_DATA = 76


class EnumMacFrameCompliance(IntEnum):
    CCC_COMPLIANT = 1
    FIRA_COMPLIANT = 2
    IEEE_COMPLIANT = 4
    CUSTOMER_COMPLIANT = 8


@dataclass(order=True)
class EncodedMacHeader:
    destination_address: int
    source_address: int
    frame_counter: int
    key_source: int
    destination_pan_id: int
    source_pan_id: int
    frame_pending: bool
    sequence_number: int
    security_level: int
    key_identifier_mode: int
    frame_counter_suppression: int
    key_index: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        if mac_config.MAC_FW_TYPE == "AiO":
            encoded_mac_header = cls(
                destination_address=p.extract_int(8),
                source_address=p.extract_int(8),
                frame_counter=p.extract_int(4),
                key_source=p.extract_int(4),
                destination_pan_id=p.extract_int(2),
                source_pan_id=p.extract_int(2),
                frame_pending=p.extract_bool(1),
                sequence_number=p.extract_int(1),
                security_level=p.extract_int(1),
                key_identifier_mode=p.extract_int(1),
                frame_counter_suppression=p.extract_int(1),
                key_index=p.extract_int(1),
            )
        elif mac_config.MAC_FW_TYPE == "CCC":
            encoded_mac_header = cls(
                destination_address=p.extract_int(8),
                source_address=p.extract_int(8),
                destination_pan_id=p.extract_int(2),
                source_pan_id=p.extract_int(2),
                frame_pending=p.extract_bool(1),
                sequence_number=p.extract_int(1),
                frame_counter=p.extract_int(4),
                key_source=p.extract_int(4),
                security_level=p.extract_int(1),
                key_identifier_mode=p.extract_int(1),
                frame_counter_suppression=p.extract_int(1),
                key_index=p.extract_int(1),
            )
        else:
            raise RuntimeError(
                "mac_config.MAC_FW_TYPE is neither AiO, nor CCC. Make sure to set mac_config.MAC_FW_TYPE via 'set_mac_config.MAC_FW_TYPE' to an expected value."
            )
        return encoded_mac_header

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(order=True)
class SchedulerStatusSession:
    session_id: int
    session_handle: int
    ranging_status: EnumUciStatus
    consecutive_schedule_counter: int
    could_not_be_scheduled_counter: int
    new_priority: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_id=p.extract_int(4),
            session_handle=p.extract_int(4),
            ranging_status=p.extract_enum(EnumUciStatus),
            consecutive_schedule_counter=p.extract_int(2),
            could_not_be_scheduled_counter=p.extract_int(2),
            new_priority=p.extract_int(2),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(order=True)
class SchedulerStatus:
    number_of_active_sessions: int
    scheduler_status_per_session: List[SchedulerStatusSession]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_active_sessions = p.extract_int(1)
        if len(payload) > 1:
            scheduler_status_per_session = [p.extract_cls(SchedulerStatusSession, 15) for _ in range(number_of_active_sessions)]
        else:
            scheduler_status_per_session = None
        return cls(
            number_of_active_sessions=number_of_active_sessions,
            scheduler_status_per_session=scheduler_status_per_session,
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(order=True)
class SchedulerInfoSession:
    session_id: int
    session_handle: int
    block_index: int
    round_index: int
    synchronization_failed_counter: int
    resynchronization_attempts_counter: int
    max_block_number: int
    base_priority: int
    block_interval_ms: int
    ranging_round_durations_ms: int

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_id=p.extract_int(4),
            session_handle=p.extract_int(4),
            block_index=p.extract_int(2),
            round_index=p.extract_int(2),
            synchronization_failed_counter=p.extract_int(2),
            resynchronization_attempts_counter=p.extract_int(2),
            max_block_number=p.extract_int(2),
            base_priority=p.extract_int(1),
            block_interval_ms=p.extract_int(4),
            ranging_round_durations_ms=p.extract_int(2),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(order=True)
class SchedulerInfo:
    start_time_of_just_finished_session_ticks: int
    end_time_of_just_finished_session_ticks: int
    number_of_active_sessions: int
    scheduler_info_per_session: List[SchedulerInfoSession]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        start_time_of_just_finished_session_ticks = p.extract_int(8)
        end_time_of_just_finished_session_ticks = p.extract_int(8)
        number_of_active_sessions = p.extract_int(1)
        scheduler_info_per_session = (
            [p.extract_cls(SchedulerInfoSession, 25) for _ in range(number_of_active_sessions)] if len(payload) > 17 else None
        )
        return cls(
            start_time_of_just_finished_session_ticks=start_time_of_just_finished_session_ticks,
            end_time_of_just_finished_session_ticks=end_time_of_just_finished_session_ticks,
            number_of_active_sessions=number_of_active_sessions,
            scheduler_info_per_session=scheduler_info_per_session,
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=1)


class EnumPdoaResultIndex(IntEnum):
    Rx1_STS_SEG1_TO_Rx2_STS_SEG1 = 0x01


@dataclass(order=True)
class RxPdoa:
    """
    Phase Difference Of Arrival (PDOA) results.
    """

    result_index: EnumPdoaResultIndex

    pdoa: int
    """
    PDOA between CIRs at the first path position.
    In case of packet reception error, an invalid value of 0x7FFF is reported.
    """

    pdoa_deg: float
    """PDoA in degrees = (int16_t)PDoA / 128"""

    snr: int
    """
    Minimum SNR of the CIR taps where the PDOA is computed.
    In case of packet reception error, an invalid value of 0x7FFF is reported.
    """

    snr_db: int
    """SNR[dB] = (log10(2) * 10 * (int16_t)snr) / 0x200"""

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        result_index = p.extract_enum(EnumPdoaResultIndex)
        pdoa = p.extract_int(2, True)
        snr = p.extract_int(2, True)

        pdoa_deg = pdoa / 128 if pdoa != 0x7FFF else None
        snr_db = ((log10(2) * 10 * snr) / 0x200) if snr != 0x7FFF else None

        return cls(
            result_index=result_index,
            pdoa=pdoa,
            pdoa_deg=pdoa_deg,
            snr=snr,
            snr_db=snr_db,
        )

    def __str__(self):
        _self = deepcopy(self)
        _self.pdoa = self.pdoa if self.pdoa != 0x7FFF else "packet reception error"
        _self.pdoa_deg = f"{self.pdoa_deg:.2f} °" if self.pdoa_deg is not None else "packet reception error"
        _self.snr = self.snr if self.snr != 0x7FFF else "packet reception error"
        _self.snr_db = f"{self.snr_db:.2f} dB" if self.snr_db is not None else "packet reception error"
        return class_to_str(_self, include_title=False, indent_level=1)


@dataclass(order=True)
class RxPhr:
    """
    Received PHY PHR.
    Note: This parameter is logged only for SP0 frames.

    Interpreted for BPRF and HPRf case. User needs to decide what information to use, as this class does not know what is correct.
    """

    bprf_data_rate: int
    bprf_frame_length: int
    bprf_ranging_frame: bool
    bprf_preamble_duration: int

    hprf_frame_length: int
    hprf_ranging_frame: bool

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)  # BPRF
        q = PayloadParser(payload)  # HPRF
        return cls(
            bprf_data_rate=p.extract_bits(2),
            bprf_frame_length=p.extract_bits(6),
            bprf_ranging_frame=bool(p.extract_bits(1)),
            bprf_preamble_duration=p.extract_bits(2),
            hprf_frame_length=q.extract_bits(11),
            hprf_ranging_frame=bool(q.extract_bits(1)),
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


class EnumRadarStatus(IntEnum):
    RX_SUCCESS_CIR_AVAILABLE = 0x00
    TX_SUCCESS = 0x01
    CALIBRATION_DONE = 0x02  # Only: CCC
    RX_ERROR = 0x03
    TX_ERROR = 0x04


class EnumRadarAntennaIndex(IntEnum):
    RX1 = 0x01
    RX2 = 0x02


@dataclass(order=True)
class RadarCirLogs:
    """ONLY CCC"""

    rx1: RadarCirLog | None = None
    rx2: RadarCirLog | None = None

    @classmethod
    def from_bytes(cls, payload: List[int]):
        radar_cir_log = RadarCirLog.from_bytes(payload)
        match radar_cir_log.radar_antenna_idx:
            case EnumRadarAntennaIndex.RX1:
                radar_cir_logs_cls = cls(rx1=radar_cir_log)
            case EnumRadarAntennaIndex.RX2:
                radar_cir_logs_cls = cls(rx2=radar_cir_log)
        return radar_cir_logs_cls

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(order=True)
class RadarCirLog:
    """ONLY CCC"""

    radar_antenna_idx: EnumRadarAntennaIndex
    radar_agc_gain_dB: int
    radar_cir_idx: int
    radar_cir_offset: int
    radar_num_taps: int
    radar_timestamp: int
    radar_cir_taps_abs: List[int]
    radar_cir_data: List[int]

    @staticmethod
    def calculate_cir_tap_magnitudes(cir_data: List[int]) -> List[int]:
        """
        Calculates the magnitudes of CIR taps.

        Parameters:
            cir_data

        Returns:
            A list of magnitudes, one for each CIR tap.
        """
        magnitudes = []
        for cir_tap in chunked(cir_data, 4):
            real_part = int.from_bytes(bytes=cir_tap[:2], byteorder="little", signed=True)
            imag_part = int.from_bytes(bytes=cir_tap[2:], byteorder="little", signed=True)
            magnitude = sqrt(real_part**2 + imag_part**2)
            magnitudes.append(magnitude)
        return magnitudes

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        radar_antenna_idx = p.extract_enum(EnumRadarAntennaIndex)
        radar_agc_gain_dB = p.extract_int(4)
        radar_cir_idx = p.extract_int(2)
        radar_cir_offset = p.extract_int(4)
        radar_num_taps = p.extract_int(4)
        radar_timestamp = p.extract_int(4)
        radar_cir_data = p.extract_list(END)
        radar_cir_taps_abs = cls.calculate_cir_tap_magnitudes(radar_cir_data)
        return cls(
            radar_antenna_idx=radar_antenna_idx,
            radar_agc_gain_dB=radar_agc_gain_dB,
            radar_cir_idx=radar_cir_idx,
            radar_cir_offset=radar_cir_offset,
            radar_num_taps=radar_num_taps,
            radar_timestamp=radar_timestamp,
            radar_cir_taps_abs=radar_cir_taps_abs,
            radar_cir_data=radar_cir_data,
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(order=True)
class RadarResult:
    """ONLY AiO"""

    result_length: int
    """The number of bytes to follow."""

    radar_status: EnumRadarStatus
    """Status of radar frame."""

    slot_index: int
    """Slot index of the radar frame."""

    agc_gain_dB: int | None = None
    """
    The attenuation gain in dB for the current receiver.
        Note: Only part of the result if the status is 0x00 (RX success and CIR available).
    """

    timestamp_ns: int | None = None
    """
    Timestamp of the CIR taken by the snapshot timer in ns.
        Note: Only part of the result if the status is 0x00 (RX success and CIR available).
    """

    cir_taps_abs: List[int] | None = None
    """
    Absolute value of each CIR Tap. Calculated from cir_taps_data
        Note: Only part of the result if the status is 0x00 (RX success and CIR available).
    """

    cir_taps_data: List[int] | None = None
    """
    Each CIR tap comprises of 2 bytes of imaginary part (bits 16 to 31) and 2 bytes of real part (bits 0 to 15).
        Note: Only part of the result if the status is 0x00 (RX success and CIR available).
    """

    @staticmethod
    def calculate_cir_tap_magnitudes(cir_data: List[int]) -> List[int]:
        """
        Calculates the magnitudes of CIR taps.

        Parameters:
            cir_data

        Returns:
            A list of magnitudes, one for each CIR tap.
        """
        magnitudes = []
        for cir_tap in chunked(cir_data, 4):
            real_part = int.from_bytes(bytes=cir_tap[:2], byteorder="little", signed=True)
            imag_part = int.from_bytes(bytes=cir_tap[2:], byteorder="little", signed=True)
            magnitude = sqrt(real_part**2 + imag_part**2)
            magnitudes.append(magnitude)
        return magnitudes

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        result_length = p.extract_int(2)
        radar_status = p.extract_enum(EnumRadarAntennaIndex)
        slot_index = p.extract_int(2)

        result = cls(
            result_length=result_length,
            radar_status=radar_status,
            slot_index=slot_index,
        )

        if radar_status == EnumRadarStatus.RX_SUCCESS_CIR_AVAILABLE:
            result.agc_gain_dB = p.extract_int(4)
            result.timestamp_ns = p.extract_int(4) * 8.0128
            result.cir_taps_data = p.extract_list(END)
            result.cir_taps_abs = cls.calculate_cir_tap_magnitudes(result.cir_taps_data)

        return result

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(frozen=True, order=True)
class LogParams(ParamBase):
    rx_status = TlvParamBase(
        tag=0x00,
        interpret_resp=lambda p: RxStatus.from_bytes(p),
        expected_resp_length=4,
        read_only=True,
    )
    """ RX status and errors. """

    tx_status = TlvParamBase(
        tag=0x01,
        interpret_resp=lambda p: TxStatus.from_bytes(p),
        expected_resp_length=1,
        read_only=True,
    )
    """ TX status and errors. """

    rx_cir_log = TlvParamBase(
        tag=0x02,
        interpret_resp=lambda p: CirLogs.from_bytes(p),
        expected_resp_length=lambda length: (length % 4 == 0) and (16 <= length <= 4108),
        read_only=True,
    )
    """
    CIR on a SP3 frame reception.
        Note: It is valid if ranging bit is enabled and RX status is READY or DATA_AVAILABLE
    """

    uwb_session_id = TlvParamBase(
        tag=0x03,
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
        read_only=True,
    )
    """ Session ID of the currently active session. """

    block_index = TlvParamBase(
        tag=0x04,
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
        read_only=True,
    )
    """ Current block index. """

    rx_timestamp = TlvParamBase(
        tag=0x05,
        interpret_resp=lambda p: RxTimestamp.from_bytes(p),
        expected_resp_length=26,
        read_only=True,
    )
    """ RX timestamp in ns and status"""

    tx_timestamp = TlvParamBase(
        tag=0x06,
        interpret_resp=lambda p: TxTimestamp.from_bytes(p),
        expected_resp_length=13,
        read_only=True,
    )
    """ TX timestamp in ns """

    rx_psdu = TlvParamBase(
        tag=0x07,
        interpret_resp=lambda p: p,
        expected_resp_length=lambda length: 1 <= length <= 128,
        read_only=True,
    )
    """
    Received PHY payload
        Note: this parameter is logged only for SP0 frames.
    """

    tx_psdu_decrypted = TlvParamBase(
        tag=0x08,
        interpret_resp=lambda p: p,
        expected_resp_length=lambda length: 1 <= length <= 128,
        read_only=True,
    )
    """
    Transmitted decrypted PHY payload
        Note: this parameter is logged only for SP0 frames.
    """

    sts_index = TlvParamBase(
        tag=0x09,
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little"),  # Lower 4 Bytes: Current STS index; Upper 4 Bytes: RFU
        expected_resp_length=lambda length: length in (4, 8),
        read_only=True,
    )
    """ Current STS index """

    rx_first_path_info = TlvParamBase(
        interpret_resp=lambda p: RxFirstPathInfos.from_bytes(p),
        tag=0x0B,
        expected_resp_length=lambda length: length in (24, 48),
        read_only=True,
    )
    """
    First path information parameters.
        Note: It is valid if ranging bit is enabled and RX status is READY or DATA_AVAILABLE
    """

    rx_carrier_frequency_offset = TlvParamBase(
        tag=0x0C,
        interpret_resp=lambda p: RxCarrierFrequencyOffset.from_bytes(p),
        expected_resp_length=5,
        read_only=True,
    )
    """
    Carrier frequency offset (CFO_INT) between transmitter and receiver carrier frequency.
    """

    mac_decoding_status = TlvParamBase(
        tag=0x0D,
        interpret_resp=lambda p: EnumMacDecodingStatus(p[0]) if p[0] in EnumMacDecodingStatus._value2member_map_ else p[0],
        expected_resp_length=1,
        read_only=True,
    )
    """
    Status of decoding MAC frame.
    Note: this parameter is logged only for SP0 frames.
    """

    reason_mac_decoding_failure = TlvParamBase(
        tag=0x0E,
        interpret_resp=lambda p: EnumReasonMacDecodingFailure(p[0]) if p[0] in EnumReasonMacDecodingFailure._value2member_map_ else p[0],
        expected_resp_length=1,
        read_only=True,
    )
    """
    Reason of MAC decoding failure
    Note: this parameter is logged only for SP0 frames.
    """

    mac_frame_compliance = TlvParamBase(
        tag=0x0F,
        interpret_resp=lambda p: [compliance.name for compliance in EnumMacFrameCompliance if p[0] & compliance.value],
        expected_resp_length=1,
        read_only=True,
    )
    """
    MAC frame compliance given in form of bitmap:
    bit 1: CCC compliant
    bit 2: FiRa compliant
    bit 3: IEEE compliant
    bit 4: Compliant to the customer specification. Both CCC and FiRa are IEEE-compliant.
        Note: This parameter is logged only for SP0 frames
    """

    rx_mac_header = TlvParamBase(
        tag=0x10,
        interpret_resp=lambda p: EncodedMacHeader.from_bytes(p),
        expected_resp_length=34,
        read_only=True,
    )
    """
    Received MAC header fields
    Note: this parameter is logged only for SP0 frames.
    """

    rx_mac_payload = TlvParamBase(
        tag=0x11,
        interpret_resp=lambda p: p,
        expected_resp_length=lambda length: length == length,
        read_only=True,
    )
    """
    Received decrypted MAC Payload
    Note: this parameter is logged only for SP0 frames.
    """

    scheduler_status = TlvParamBase(
        tag=0x12,
        interpret_resp=lambda p: SchedulerStatus.from_bytes(p),
        expected_resp_length=lambda length: (length - 1) % 15 == 0,
        read_only=True,
    )
    """
    Scheduler status.
    Number of sessions is followed by consecutive session info for each active session.
    Length of the value is 1 + (15 * Number of active sessions) Octets.
    """

    scheduler_info = TlvParamBase(
        tag=0x13,
        interpret_resp=lambda p: SchedulerInfo.from_bytes(p),
        expected_resp_length=lambda length: (length - 17) % 25 == 0,
        read_only=True,
    )
    """
    Scheduler info.
    Number of sessions is followed by consecutive session info for each active session.
    Length of the value is 17 + (25 * Number of active sessions) Octets.
    """

    rx_pdoa = TlvParamBase(
        tag=0x14,
        interpret_resp=lambda p: RxPdoa.from_bytes(p),
        expected_resp_length=5,
        read_only=True,
    )
    """
    Phase Difference Of Arrival(PDOA) results.
    """

    rx_phr: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x15,
            interpret_resp=lambda p: RxPhr.from_bytes(p),
            expected_resp_length=4,
            read_only=True,
        ),
        ccc=None,
    )
    """
    Received PHY PHR.
    Note: This parameter is logged only for SP0 frames.
    """

    radar_status: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0x16,
            interpret_resp=lambda p: EnumRadarStatus(p[0]) if p[0] in EnumRadarStatus._value2member_map_ else p[0],
            expected_resp_length=1,
            read_only=True,
        ),
    )
    """
    Radar status
    ONLY CCC
    """

    radar_cir_log: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0x17,
            interpret_resp=lambda p: RadarCirLogs.from_bytes(p),
            expected_resp_length=lambda length: (length % 2 == 1) and (23 <= length <= 4115),
            read_only=True,
        ),
    )
    """
    CIR on a radar frame reception.
        Note: It is valid if ranging bit is enabled and RX status is READY or DATA_AVAILABLE
    ONLY CCC
    """


class EnumDownloadSequence(IntEnum):
    INIT_CONFIGURATION = 0x00
    DOWNLOAD_DATA = 0x01
    PROGRAM = 0x02


class EnumSwupMode(IntEnum):
    NORMAL = 0x00
    RECOVERY = 0x02


class EnumTestMode(IntEnum):
    RECEIVE_MODE = 0x00
    TRANSMIT_MODE = 0x01
    CW_TRANSMIT_MODE = 0x02
    LOOPBACK_MODE = 0x03
    ONE_TIME_SS_TWR_MODE = 0x06  # AiO only


class EnumFrameType(IntEnum):
    SP0 = 0x00
    SP1 = 0x01
    SP3 = 0x03


@dataclass(frozen=True, order=True)
class TestStartParams(ParamBase):
    mode = TlvParamBase(
        tag=0x00,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3, 6]
        else _raise(ValueError, f"MODE {v} is not supported. Choose from [0, 1, 2, 3, 6]"),
        interpret_resp=lambda p: EnumTestMode(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumTestMode

    Test mode selection.

    Note: To check test result of receive and transmit mode, LOG_PARAMS_CONF parameter in Table 34 should be configured for the test session.
    """

    delay = TlvParamBase(
        tag=0x01,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 1000 <= v <= 65535
        else _raise(ValueError, f"DELAY {v} is not supported. Range: [1000 - 65535] μs"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Start delay in microseconds.
    Range: [1000 μs - 65535 μs]
    Default: 2000 μs
    """

    frame_type = TlvParamBase(
        tag=0x02,
        convert_to_bytes=lambda v: [int(v)] if int(v) in [0, 1, 3] else _raise(ValueError, f"FRAME_TYPE {v} is not supported. Choose from [0, 1, 3]"),
        interpret_resp=lambda p: EnumFrameType(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumFrameType

    The frame type used by the test mode.

    Note: Applied for receive mode and transmit mode.
    """

    psdu = TlvParamBase(
        tag=0x03,
        convert_to_bytes=lambda v: v if isinstance(v, list) else _raise(ValueError, f"PSDU ({v}) is not supported. Provide a List[int]"),
        interpret_resp=lambda p: p,
        expected_resp_length=lambda len: len == len,  # no expected length
    )
    """
    value_type: List[int]
        Payload for transmit mode. For SP0 this is mandatory parameter.
    Note: Applied for transmit mode only.
    """

    time_out = TlvParamBase(
        tag=0x04,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 1 <= v <= 65535
        else _raise(ValueError, f"DELAY {v} is not supported. Range: [1 - 65535] ms"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Timeout value for receive mode in ms.
    Range: [1 ..65535] ms
    Default: 100 ms
    Note: Applied for receive mode only.
    """

    event_counter_max = TlvParamBase(
        tag=0x05,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4)
        if 0 <= v <= 0xFFFFFFFF
        else _raise(ValueError, f"EVENT_COUNTER_MAX {v} is not supported. Range: [0 - 0xFFFFFFFF]"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
        Specifies at which number of events the test mode will be stopped.
    0x00 (default): transmit/receive infinite number of events
    Note: Applied for receive mode and transmit mode
    """

    tx_cycle_time = TlvParamBase(
        tag=0x06,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=4)
        if 1000 <= v <= 10000000
        else _raise(ValueError, f"EVENT_COUNTER_MAX {v} is not supported. Range: [1000 - 10000000] μs"),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=4,
    )
    """
    value_type: int
        TX operation interval time (from the start of TX to the start of next TX).
    Range: [1000 .. 10000000]μs (1000 μs .. 10 s)
    Default: 1000 μs
    Note: Applied for transmit mode only.
    """

    phr_ranging_bit = TlvParamBase(
        tag=0x02,
        convert_to_bytes=lambda v: [int(v)] if v in [0, 1] else _raise(ValueError, f"PHR_RANGING_BIT ({v}) is not supported. Range: [0, 1]"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        Ranging bit in the PHR.
            False: Disable
            True: Enable
    Note: Applied for transmit mode only.
    """


@dataclass(frozen=True, order=True)
class DdfsToneValues:
    channel_id: int
    """Range: [5, 6, 8, 9]"""

    tx_ddfs_tone_0_frequency: int
    """DDFS tone 0 frequency. Frequency = TX_DDFS_TONE_0_FREQUENCY * 975kHz"""

    tx_ddfs_tone_0_phase: int
    """DDFS tone 0 phase. Phase = TX_DDFS_TONE_0_PHASE * (360 / 2^11)°"""

    tx_ddfs_tone_1_frequency: int
    """DDFS tone 1 frequency. Frequency = TX_DDFS_TONE_1_FREQUENCY * 975kHz"""

    tx_ddfs_tone_1_phase: int
    """DDFS tone 1 phase. Phase = TX_DDFS_TONE_1_PHASE * (360 / 2^11)°"""

    tx_ddfs_tone_duration: int
    """DDFS tone duration in 8.012ns resolution."""

    tx_ddfs_spur_period: int
    """Packet periodicity of spur. For example 0x64 means spur will be generated every 100 packets."""

    antenna: int
    """ 1: TX antenna 1 or 2: TX antenna 2 """

    def create_payload(self):
        payload = (
            [self.channel_id]
            if self.channel_id in [5, 6, 8, 9]
            else _raise(ValueError, f"Provided channel {self.channel_id} not supported. Range: [5, 6, 8, 9]")
        )
        payload += to_hex_list(input=self.tx_ddfs_tone_0_frequency, byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=self.tx_ddfs_tone_0_phase, byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=self.tx_ddfs_tone_1_frequency, byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=self.tx_ddfs_tone_1_phase, byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=self.tx_ddfs_tone_duration, byteorder="little", forced_list_len=2)
        payload += to_hex_list(input=self.tx_ddfs_spur_period, byteorder="little", forced_list_len=2)
        payload += (
            [int(self.antenna)]
            if int(self.antenna) in [1, 2]
            else _raise(ValueError, f"Provided channel {self.antenna} not supported. Range: [1, 2]")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            channel_id=p.extract_int(1),
            tx_ddfs_tone_0_frequency=p.extract_int(2),
            tx_ddfs_tone_0_phase=p.extract_int(2),
            tx_ddfs_tone_1_frequency=p.extract_int(2),
            tx_ddfs_tone_1_phase=p.extract_int(2),
            tx_ddfs_tone_duration=p.extract_int(2),
            tx_ddfs_spur_period=p.extract_int(2),
            antenna=p.extract_int(1),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class TxPowerDiff:
    """
    A difference between received and expected TX power.
    The difference is in range -2dB to +3 dB.
    """

    _resolution: float = field(default=0.17, init=False)

    channel_id: int
    """Range: [5, 6, 8, 9]"""

    power_offset_dB: float
    """Range: [-2dB .. 3dB] Steps: 0.17 dB"""

    def create_payload(self):
        payload = (
            [int(self.channel_id)]
            if int(self.channel_id) in [5, 6, 8, 9]
            else _raise(ValueError, f"channel_id {self.channel_id} is not supported. Range: [5, 6, 8, 9]")
        )
        payload += [0] if self.power_offset_dB >= 0 else [1]  # set sign (0 for "+" and 1 for "-")
        payload += (
            [round(abs(self.power_offset_dB) / self._resolution)]
            if -2 <= self.power_offset_dB <= 3 and isinstance(self.power_offset_dB, (int, float))
            else _raise(ValueError, f"power_offset_dB {self.power_offset_dB} is not supported. Range: [-2 .. 3]dB, Step: 0.17dB")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        channel_id = p.extract_int(1)
        sign = p.extract_int(1)
        power_offset_raw = p.extract_int(1)

        return cls(channel_id=channel_id, power_offset_dB=power_offset_raw * cls._resolution * (-1 if sign else 0))

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class FreqDiff:
    """
    A difference in ppm, representing the frequency deviation between
    expected UWB frequency and actual UWB frequency of the specific device.
        Range is [-2560 .. 2560], and resolution is 0.1 ppm.
    """

    _resolution: float = field(default=10, init=False)

    channel_id: int
    """Range: [5, 6, 8, 9]"""

    freq_diff_ppm: int
    """Range: [-2560 .. 2560]; Resolution: 0.1 ppm"""

    def create_payload(self):
        payload = (
            [int(self.channel_id)]
            if int(self.channel_id) in [5, 6, 8, 9]
            else _raise(ValueError, f"channel_id {self.channel_id} is not supported. Range: [5, 6, 8, 9]")
        )
        payload += [0] if self.freq_diff_ppm >= 0 else [1]  # set sign (0 for "+" and 1 for "-")
        payload += (
            to_hex_list(input=(int(self.freq_diff_ppm) / self._resolution), byteorder="little", forced_list_len=2)
            if -2560 <= int(self.freq_diff_ppm) <= 2560 and isinstance(self.freq_diff_ppm, int)
            else _raise(ValueError, f"freq_diff_ppm {self.freq_diff_ppm} is not supported. Range: [-2560 .. 2560]ppm, Resolution: 0.1 ppm")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        channel_id = p.extract_int(1)
        sign = p.extract_int(1)
        freq_diff_raw = p.extract_int(2)

        return cls(
            channel_id=channel_id,
            freq_diff_ppm=freq_diff_raw * cls._resolution * (-1 if sign else 0),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class AntennaDelay:
    """
    Range: [0 .. 1,025,622.75] ps
    Resolution: 15.65 ps
    """

    _resolution: float = field(default=15.65, init=False)

    channel_id: int
    """Range: [5, 6, 8, 9]"""

    antenna_index: int
    """Range: [1, 2]"""

    antenna_delay_ps: float
    """Range: [0 .. 1,025,622.75]ps; Resolution: 15.65 ps"""

    def create_payload(self):
        channel_id = (
            int(self.channel_id)
            if int(self.channel_id) in [5, 6, 8, 9]
            else _raise(ValueError, f"channel_id {self.channel_id} is not supported. Range: [5, 6, 8, 9]")
        )
        antenna_index = (
            int(self.antenna_index)
            if int(self.antenna_index) in [1, 2]
            else _raise(ValueError, f"antenna_index {self.antenna_index} is not supported. Range: [1, 2]")
        )
        antenna_delay_int = (
            round(self.antenna_delay_ps / self._resolution)
            if 0 <= int(self.antenna_delay_ps) <= 1025622.75 and isinstance(self.antenna_delay_ps, (int, float))
            else _raise(ValueError, f"antenna_delay_ps {self.antenna_delay_ps} is not supported. Range: [0 .. 1,025,622.75]ps")
        )

        payload = [channel_id | (antenna_index << 4)] + to_hex_list(input=antenna_delay_int, byteorder="little", forced_list_len=2)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        channel_id = p.extract_bits(4)
        antenna_index = p.extract_bits(4)
        antenna_delay_ps = p.extract_int(2) * cls._resolution

        return cls(channel_id=channel_id, antenna_index=antenna_index, antenna_delay_ps=antenna_delay_ps)

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class GroupDelay:
    """
    Group delay in 15.65 ps resolution
        Range is [0 .. 67,216,238,166.75]ps, and resolution is 15.65 ps.
    """

    _resolution: float = field(default=15.65, init=False)

    group_delay_index: int
    """Groupdelay index according to radio configuration index"""

    nbic_enabled: bool

    group_delay_ps: float
    """Range: [0 .. 67,216,238,166.75]ps; Resolution: 15.65 ps"""

    def create_payload(self):
        payload = (
            [int(self.group_delay_index)]
            if 0 <= int(self.group_delay_index) <= 15
            else _raise(ValueError, f"group_delay_index {self.group_delay_index} is not supported. Range: [0..15]")
        )
        payload += (
            [int(self.nbic_enabled)]
            if int(self.nbic_enabled) in [0, 1]
            else _raise(ValueError, f"nbic_enabled {self.nbic_enabled} is not supported. Range: [0,1]")
        )
        payload += (
            to_hex_list(input=(round(self.group_delay_ps / self._resolution)), byteorder="little", forced_list_len=4)
            if 0 <= int(self.group_delay_ps) <= 67216238166.75 and isinstance(self.group_delay_ps, (int, float))
            else _raise(ValueError, f"group_delay_ps {self.group_delay_ps} is not supported. Range: [0 .. 67,216,238,166.75]ps, Resolution: 15.65 ps")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            group_delay_index=p.extract_int(1),
            nbic_enabled=p.extract_bool(1),
            group_delay_ps=p.extract_int(4) * cls._resolution,
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class AdaptivePowerId:
    """
    GrefIDX, Peak delta
    """

    _scale_factor: float = field(default=6, init=False)  # Resolution: 0.17

    channel_id: int
    """Range: [5, 6, 8, 9]"""

    grefl_idx_dBm: float
    """
    The nominal TX power setting applied to the frame
    and does not account for any frame length criteria required for a boost
        Range: [-21 .. 14] dBm
        Resolution: 0.17 dB
    """

    peak_delta_dBm: float
    """
    This component is derived by measuring of SP0 frame with Nominal TX power setting
    and observing the offset w.r.t Nominal TX power with Spectral analyzer
        Range: [-3 .. +3] dBm
        Resolution: 0.17 dB
    """

    def create_payload(self):
        payload = (
            [int(self.channel_id)]
            if int(self.channel_id) in [5, 6, 8, 9]
            else _raise(ValueError, f"channel_id {self.channel_id} is not supported. Range: [5, 6, 8, 9]")
        )
        payload += (
            [round((14 - self.grefl_idx_dBm) * self._scale_factor)]
            if -21 <= self.grefl_idx_dBm <= 14 and isinstance(self.grefl_idx_dBm, (int, float))
            else _raise(ValueError, f"grefl_idx_dBm {self.grefl_idx_dBm} is not supported. Range: [-21 .. 14] dBm, Resolution: 0.17 dBm")
        )
        payload += (
            to_hex_list(
                input=round(self.peak_delta_dBm * self._scale_factor), byteorder="little", signed=True, forced_list_len=1
            )  # to_hex_list to handle negatives correctly as 2's compliment
            if -3 <= self.peak_delta_dBm <= 3 and isinstance(self.peak_delta_dBm, (int, float))
            else _raise(ValueError, f"peak_delta_dBm {self.peak_delta_dBm} is not supported. Range: [-3 .. 3] dBm, Resolution: 0.17 dBm")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            channel_id=p.extract_int(1),
            grefl_idx_dBm=14 - (p.extract_int(1) / cls._scale_factor),
            peak_delta_dBm=p.extract_int(1) / cls._scale_factor,
        )

    def __str__(self):
        _self = deepcopy(self)
        _self.grefl_idx_dBm = f"{self.grefl_idx_dBm:.2f} dBm"
        _self.peak_delta_dBm = f"{self.peak_delta_dBm:.2f} dBm"
        return class_to_str(_self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class WakeupDpdPins:
    """
    DPD wakeup pin enable mask.
    """

    pins_wakeup_enable: List[int]
    """
    List of all pins with detection enabled.
        (All other pins will disable detection)
    """

    def create_payload(self):
        pin_to_bit = {10: 0, 11: 1, 12: 2, 13: 3, 14: 4, 15: 5, 16: 6, 17: 7, 20: 8, 21: 9, 22: 10, 23: 11, 24: 12, 25: 13}
        bitmask = 0
        for pin in self.pins_wakeup_enable:
            bitmask |= 1 << pin_to_bit[pin]
        return to_hex_list(input=bitmask, byteorder="little", forced_list_len=4)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        pin_to_bit = {10: 0, 11: 1, 12: 2, 13: 3, 14: 4, 15: 5, 16: 6, 17: 7, 20: 8, 21: 9, 22: 10, 23: 11, 24: 12, 25: 13}
        return cls(pins_wakeup_enable=p.extract_set_keys_from_bitmask(pin_to_bit, 4))

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class WakeupDpdEdge:
    """
    DPD wakeup edge selection mask.
    """

    pins_rising_edge: List[int]
    """
    List of all pins with rising edge detection on pin.
        (All other pins with will use falling edge detection)
    """

    def create_payload(self):
        pin_to_bit = {10: 0, 11: 1, 12: 2, 13: 3, 14: 4, 15: 5, 16: 6, 17: 7, 20: 8, 21: 9, 22: 10, 23: 11, 24: 12, 25: 13}

        bitmask = 0
        for pin in self.pins_rising_edge:
            bitmask |= 1 << pin_to_bit[pin]
        return to_hex_list(input=bitmask, byteorder="little", forced_list_len=4)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        pin_to_bit = {10: 0, 11: 1, 12: 2, 13: 3, 14: 4, 15: 5, 16: 6, 17: 7, 20: 8, 21: 9, 22: 10, 23: 11, 24: 12, 25: 13}
        return cls(pins_rising_edge=p.extract_set_keys_from_bitmask(pin_to_bit, 4))

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class WakeupHdpPins:
    """
    HDP wakeup pin enable mask.
    """

    pins_wakeup_enable: List[int]
    """
    List of all pins with detection enabled.
        (All other pins will disable detection)
    """

    def create_payload(self):
        pin_to_bit = {14: 0, 17: 1, 23: 2}
        bitmask = 0
        for pin in self.pins_wakeup_enable:
            bitmask |= 1 << pin_to_bit[pin]
        return to_hex_list(input=bitmask, byteorder="little", forced_list_len=4)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        pin_to_bit = {14: 0, 17: 1, 23: 2}
        return cls(pins_wakeup_enable=p.extract_set_keys_from_bitmask(pin_to_bit, 4))

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=2)


@dataclass(frozen=True, order=True)
class MinimumWupTimeDpd:
    """
    Minimum idle time for which to enter the deep power down mode. If the
    next planned event is within this time, then the device will not go into
    DPD but into the sleep mode (WFI) instead.
    """

    minimum_wakeup_time: int = 0
    """
    Minimum wakeup time to keep the XTAL as clock source.
    Note: Not supported and does not have an influence on the system.
    """

    maximum_wakeup_time: int = 2000
    """
    Minimum wakeup time to switch the clock source to the Free Running Oscillator (FRO).

    Note: Shall be greater than the chosen time to keep the XTAL as clock source.
    Note: The clock source is not switched to FRO and the XTAL is kept as clock source.

    Range: [0x96 ... 0xFFFF] (150 μs to 65535 μs).

    Default to keep the XTAL as clock source: 2000 s
    Default to switch the clock source to the FRO: 10000 s
        """

    def create_payload(self):
        payload = [self.minimum_wakeup_time] if self.minimum_wakeup_time <= 0xFF else _raise(ValueError, "minimum_wakeup_time: only one byte")
        payload += to_hex_list(input=self.maximum_wakeup_time, byteorder="little", forced_list_len=2)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            minimum_wakeup_time=p.extract_int(1),
            maximum_wakeup_time=p.extract_int(2),
        )

    def __str__(self):
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(frozen=True, order=True)
class AppConfigPageParams(ParamBase):
    tx_power_diff = TlvParamBase(
        tag=0x00,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, TxPowerDiff)
        else _raise(ValueError, f"TX_POWER_DIFF {v} is not supported. Provide a instance of TxPowerDiff"),
        interpret_resp=lambda p: [TxPowerDiff.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=4, strict=True)],
        interpret_com=lambda p: TxPowerDiff.from_bytes(p),
        expected_resp_length=12,
        expected_com_length=3,
    )
    """
    value_type: TxPowerDiff
        A difference between received and expected TX power.
    Range: [-2 .. +3] dB
    """

    freq_diff = TlvParamBase(
        tag=0x01,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, FreqDiff)
        else _raise(FreqDiff, f"FREQ_DIFF {v} is not supported. Provide a instance of FreqDiff"),
        interpret_resp=lambda p: [FreqDiff.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=4, strict=True)],
        interpret_com=lambda p: FreqDiff.from_bytes(p),
        expected_resp_length=16,
        expected_com_length=4,
    )
    """
    value_type: FreqDiff
        A difference in ppm, representing the frequency deviation between expected UWB frequency
        and actual UWB frequency of the specific device.
    Range: [-2560 .. 2560]
    Resolution: 0.1 ppm
    """

    antenna_delay = TlvParamBase(
        tag=0x02,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, AntennaDelay)
        else _raise(AntennaDelay, f"ANTENNA_DELAY {v} is not supported. Provide a instance of AntennaDelay"),
        interpret_resp=lambda p: [AntennaDelay.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=3, strict=True)],
        interpret_com=lambda p: AntennaDelay.from_bytes(p),
        expected_resp_length=24,
        expected_com_length=3,
    )
    """
    value_type: AntennaDelay
        Antenna delay in 15.65 ps resolution
    Range: [0 .. 1,025,638.4] ps
    """

    current_limiter = TlvParamBase(
        tag=0x03,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0] or 5 <= v <= 20
        else _raise(ValueError, f"Provided CURRENT_LIMITER ({v}) is not supported. Range: 0, [5-20] mA"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
        Current limiter for transmitting in mA
    Range: [5 - 20] mA (default: 20 mA)
    0: disable current limiter
    """

    group_delay = TlvParamBase(
        tag=0x04,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, GroupDelay)
        else _raise(GroupDelay, f"GROUP_DELAY {v} is not supported. Provide a instance of GroupDelay"),
        interpret_resp=lambda p: [GroupDelay.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=32, strict=True)],
        interpret_com=lambda p: GroupDelay.from_bytes(p),
        expected_resp_length=192,
        expected_com_length=6,
    )
    """
    value_type: GroupDelay
        Group delay in 15.65 ps resolution
    """

    xtal_temp_compensation_enable = TlvParamBase(
        tag=0x05,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1]
        else _raise(ValueError, f"Provided XTAL_TEMP_COMPENSATION_ENABLE ({v}) is not supported. Range: [0, 1]"),
        interpret_resp=lambda p: bool(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: bool
        Enable or disable compensation of UWB frequency based on XTAL temperature.
        This parameter shall be set to 'disable' for XTAL with integrated temperature compensation, e.g. Temperature Compensated Crystal Oscillator (TCXO)
    False: Disabled
    True: Enabled (default)
    """

    adaptive_power_id = TlvParamBase(
        tag=0x06,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, AdaptivePowerId)
        else _raise(AdaptivePowerId, f"Provided ADAPTIVE_POWER_ID {v} is not supported. Provide a instance of AdaptivePowerId"),
        interpret_resp=lambda p: [AdaptivePowerId.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=4, strict=True)],
        interpret_com=lambda p: AdaptivePowerId.from_bytes(p),
        expected_resp_length=12,
        expected_com_length=3,
    )
    """
    value_type: AdaptivePowerId
        GrefIDX, Peak delta
    """

    ddfs_tone_values = TlvParamBase(
        tag=0x07,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, DdfsToneValues)
        else _raise(DdfsToneValues, f"Provided DDFS_TONE_VALUES {v} is not supported. Provide a instance of DdfsToneValues"),
        interpret_resp=lambda p: [DdfsToneValues.from_bytes(payload_part) for payload_part in chunked(iterable=p, n=14, strict=True)],
        interpret_com=lambda p: DdfsToneValues.from_bytes(p),
        expected_resp_length=56,
        expected_com_length=14,
    )
    """
    value_type: DdfsToneValues
    """

    wakeup_dpd_pin = TlvParamBase(
        tag=0x08,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, WakeupDpdPins)
        else _raise(WakeupDpdPins, f"WAKEUP_DPD_PIN {v} is not supported. Provide a instance of WakeupDpdPins"),
        interpret_resp=lambda p: WakeupDpdPins.from_bytes(p),
        expected_resp_length=4,
    )
    """
    value_type: WakeupDpdPins
        DPD wakeup pin enable mask.

    Bit values:
        False: detection disabled on pin
        True: detection enabled on pin
    Default: pins P14, P17 and P23 are enabled
    """

    wakeup_dpd_edge = TlvParamBase(
        tag=0x09,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, WakeupDpdEdge)
        else _raise(WakeupDpdEdge, f"WAKEUP_DPD_EDGE {v} is not supported. Provide a instance of WakeupDpdEdge"),
        interpret_resp=lambda p: WakeupDpdEdge.from_bytes(p),
        expected_resp_length=4,
    )
    """
    value_type: WakeupDpdEdge
        DPD wakeup edge selection mask.

    Bit values:
        False: falling edge detection on pin
        True: rising edge detection on pin
    Default: pins P14, P17 and P23 are set for rising edge detection
    """

    wakeup_hdp_pin = TlvParamBase(
        tag=0x0A,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, WakeupHdpPins)
        else _raise(WakeupHdpPins, f"WAKEUP_HDP_PIN {v} is not supported. Provide a instance of WakeupHdpPins"),
        interpret_resp=lambda p: WakeupHdpPins.from_bytes(p),
        expected_resp_length=4,
    )
    """
    value_type: WakeupHdpPins
        HPD wakeup pin enable mask.

    Bit values:
        False: detection disabled on pin
        True: detection enabled on pin
    Default: pins P14, P17 and P23 are enabled
    """

    minimum_wup_time_dpd: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x0B,
            convert_to_bytes=lambda v: v.create_payload()
            if isinstance(v, MinimumWupTimeDpd)
            else _raise(WakeupHdpPins, f"MINIMUM_WUP_TIME_DPD {v} is not supported. Provide a instance of MinimumWupTimeDpd"),
            interpret_resp=lambda p: WakeupHdpPins.from_bytes(p),
            expected_resp_length=4,
        ),
        ccc=TlvParamBase(
            tag=0x0B,
            convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
            if 150 <= v <= 65535
            else _raise(ValueError, f"MINIMUM_WUP_TIME_DPD {v} is not supported. Range: 150 - 65535 μs"),
            interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
            expected_resp_length=2,
        ),
    )
    """
    value_type: CCC: int; AiO: MinimumWupTimeDpd

    Minimum idle time for which to enter the deep power down mode.
    If the next planned event is within this time, then the device
    will not go into DPD but into the sleep mode (WFI) instead.

    CCC Range: 150μs - 65535us (default: 10000us)
    """

    distance_between_antennas = TlvParamBase(
        tag=0x0C,
        convert_to_bytes=lambda v: [int(v)]
        if 1 <= v <= 255
        else _raise(ValueError, f"DISTANCE_BETWEEN_ANTENNAS ({v}) is not supported. Range: [1-255]mm"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
        Distance between antennas in millimeters.
        Distance between the two receiving antennas for PDoA/AoA measurement.
        The default value is based on PCB design of NXP's NCJ29D6 customer demoboard,
        with two TE antennas attached to the 2 RF ports.
    Range: [1 .. 255]mm
    Default: 18 mm
    """

    sensitivity_boost_offset_rx1 = TlvParamBase(
        tag=0x10,
        convert_to_bytes=lambda v: [int(round(v * 2))]
        if 0 <= v <= 8
        else _raise(ValueError, f"SENSITIVITY_BOOST_OFFSET_RX1 ({v}) is not supported. Range: [0 - 8] ns in 0.5 ns steps"),
        interpret_resp=lambda p: p[0] / 2,
        expected_resp_length=1,
    )
    """
    value_type: float
        Specifies the delay of the coupling path from TX2 to RX1 in steps of 0.5 ns.
    Range: [0 - 8] ns, steps: 0.5 ns

    The delay can be calibrated by disabling the SENSITIVITY_BOOST in RX_RADAR_CONTROL_CONFIGURATION for radar operation and record the coupling path peak.
    Then tune the SENSITIVITY_BOOST_OFFSET_RX1 parameter with measured coupling path peak - 13 for radar data acquisition.
    E.g. suppose coupling path peak observed during SENSITIVITY_BOOST OFF is 15ns, then the SENSITIVITY_BOOST_OFFSET_RX1 parameter setting shall be 15ns - 13ns = 2ns.
    Default: 0x00: 0ns - Sensitivity boost is OFF.
    """

    sensitivity_boost_offset_rx2 = TlvParamBase(
        tag=0x11,
        convert_to_bytes=lambda v: [int(round(v * 2))]
        if 0 <= v <= 8
        else _raise(ValueError, f"SENSITIVITY_BOOST_OFFSET_RX2 ({v}) is not supported. Range: [0 - 8] ns in 0.5 ns steps"),
        interpret_resp=lambda p: p[0] / 2,
        expected_resp_length=1,
    )
    """
    value_type: float
        Specifies the delay of the coupling path from TX2 to RX1 in steps of 0.5 ns.
    Range: [0 - 8] ns, steps: 0.5 ns

    The delay can be calibrated by disabling the SENSITIVITY_BOOST in RX_RADAR_CONTROL_CONFIGURATION for radar operation and record the coupling path peak.
    Then tune the SENSITIVITY_BOOST_OFFSET_RX1 parameter with measured coupling path peak - 13 for radar data acquisition.
    E.g. suppose coupling path peak observed during SENSITIVITY_BOOST OFF is 15ns, then the SENSITIVITY_BOOST_OFFSET_RX2 parameter setting shall be 15ns - 13ns = 2ns.
    Default: 0x00: 0ns - Sensitivity boost is OFF.
    """

    adaptive_power_ctrl_preamble10 = TlvParamBase(
        tag=0x30,
        convert_to_bytes=lambda v: to_hex_list(
            input=round(v * 6), byteorder="little", signed=True, forced_list_len=1
        )  # to_hex_list to handle negatives correctly as 2's compliment
        if -4 <= v <= 4 and isinstance(v, (int, float))
        else _raise(ValueError, f"ADAPTIVE_POWER_CTRL_PREAMBLE10 ({v}) is not supported. Range: [-4 .. 4] dBm"),
        interpret_resp=lambda p: round((p[0] - 256 if p[0] > 127 else p[0]) / 6, 2),
        expected_resp_length=1,
    )
    """
    value_type: float
        Power offset to be applied when Preamble 10 is used for transition and is antenna specific. In steps of 0.17dBm.
    Range: [-4 .. 4] dBm (Default: 0xF7 (1.53 dB backoff))
    (Max back-off is of -4 dBm. Max boost is 4 dBm)
    """

    adaptive_power_ctrl_preamble27 = TlvParamBase(
        tag=0x31,
        convert_to_bytes=lambda v: to_hex_list(
            input=round(v * 6), byteorder="little", signed=True, forced_list_len=1
        )  # to_hex_list to handle negatives correctly as 2's compliment
        if -3.75 <= v <= 3.75 and isinstance(v, (int, float))
        else _raise(ValueError, f"ADAPTIVE_POWER_CTRL_PREAMBLE27 ({v}) is not supported. Range: [-4 .. 4] dBm"),
        interpret_resp=lambda p: round((p[0] - 256 if p[0] > 127 else p[0]) / 6, 2),
        expected_resp_length=1,
    )
    """
    value_type: float
        Power offset to be applied when Preamble 27 is used for transition and is antenna specific. In steps of 0.17dBm
    Range: [-4 .. 4] dBm (Default: 0xFD (0.51 dB backoff))
    (Max back-off is of -4 dBm. Max boost is 4 dBm)
    """

    preamble_10_27_payload_ps_coeffs_override = TlvParamBase(
        tag=0x32,
        convert_to_bytes=lambda v: [int(v)]
        if v in [0, 1]
        else _raise(ValueError, f"PREAMBLE_10_27_PAYLOAD_PS_COEFFS_OVERRIDE ({v}) is not supported. Range: [0, 1]"),
        interpret_resp=lambda p: False if p[0] == 2 else True,
        expected_resp_length=1,
    )
    """
    value_type: bool
        False: Disabled (default)
        True: Enabled

    If enabled, override will be applied in TX Payload Pulse Shape coefficients when Preamble ID 10 or 27 selected.

    Values applied will be:

    TX_PS_FILTER_COEFF0_3 = 0x2a1403fb
    TX_PS_FILTER_COEFF4_7 = 0x1633413d
    TX_PS_FILTER_COEFF8_11 = 0xefe3e4f7
    TX_PS_FILTER_COEFF12_15 = 0xfa0003fc
    TX_PS_FILTER_COEFF16_19 = 0xfcfaf6f6
    TX_PS_FILTER_COEFF20_23 = 0xf8f8fafc
    TX_PS_FILTER_COEFF24_27 = 0xf9fafaf9
    TX_PS_FILTER_COEFF28_31 = 0xf9fafaf9
    """

    xtal_temp_compensation_threshold: TlvParamBase = set_param(
        aio=TlvParamBase(
            tag=0x33,
            convert_to_bytes=lambda v: [int(round(v * 10))]
            if 0.1 <= v <= 25.5
            else _raise(ValueError, f"XTAL_TEMP_COMPENSATION_THRESHOLD ({v}) is not supported. Range: 0.1 ppm to 25.5 ppm in 0.1 ppm steps"),
            interpret_resp=lambda p: p[0] / 10,
            expected_resp_length=1,
        ),
        ccc=None,
    )
    """
    value_type: float

    Frequency change threshold to compensate the temperature induced XTAL clock drift for ranging.

    Note: The compensation is applied every second when a new ranging round is started.
    Range: 0.1 ppm to 25.5 ppm
    Default: 5 ppm
    """


class EnumSetAppCfgPageValueStatus(IntEnum):
    APPLIED = 0x00
    CORRUPTED = 0x01
    FAILURE = 0x02
    FAILURE_GROUPDELAY = 0x03
    NVM_ERROR = 0x04
    FAILURE_CURRENT_LIMITER = 0x05


@dataclass(frozen=True, order=True)
class SessionInfo:
    session_handle: int
    session_type: EnumSessionType
    session_state: EnumSessionState

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
            session_type=p.extract_enum(EnumSessionType),
            session_state=p.extract_enum(EnumSessionState),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=1)


class EnumRadarDriftSuppressionMode(IntEnum):
    DC_REMOVAL = 0x00
    DC_FREEZE = 0x01


@dataclass(frozen=True, order=True)
class RadarNoiseSuppression:
    """Control the radar noise suppression. RX1 and RX2 have separate noise suppression configurations."""

    rx1_enable_noise_suppr: bool = False
    rx1_enable_drift_suppr: bool = False
    rx1_drift_suppr_mode: EnumRadarDriftSuppressionMode = EnumRadarDriftSuppressionMode.DC_REMOVAL
    rx2_enable_noise_suppr: bool = False
    rx2_enable_drift_suppr: bool = False
    rx2_drift_suppr_mode: EnumRadarDriftSuppressionMode = EnumRadarDriftSuppressionMode.DC_REMOVAL

    def create_payload(self):
        payload = [int(self.rx1_enable_noise_suppr)]
        payload.append(int(self.rx1_enable_drift_suppr))
        payload.append(int(self.rx1_drift_suppr_mode))
        payload.append(int(self.rx2_enable_noise_suppr))
        payload.append(int(self.rx2_enable_drift_suppr))
        payload.append(int(self.rx2_drift_suppr_mode))
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rx1_enable_noise_suppr=p.extract_bool(1),
            rx1_enable_drift_suppr=p.extract_bool(1),
            rx1_drift_suppr_mode=p.extract_enum(EnumRadarDriftSuppressionMode),
            rx2_enable_noise_suppr=p.extract_bool(1),
            rx2_enable_drift_suppr=p.extract_bool(1),
            rx2_drift_suppr_mode=p.extract_enum(EnumRadarDriftSuppressionMode),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=3)


@dataclass(frozen=True, order=True)
class RadarSelfInterferenceTap:
    """
    Index value of self-interference CIR tap (w.r.t. CIR tap 0). RX1 and RX2 have separate self-interference CIR tap configurations.
    """

    rx1: int = 12
    """Index value of self-interference CIR tap: RX1"""
    rx2: int = 12
    """Index value of self-interference CIR tap: RX2"""

    def create_payload(self):
        rx1 = to_hex_list(input=self.rx1, byteorder="little", forced_list_len=2)
        rx2 = to_hex_list(input=self.rx2, byteorder="little", forced_list_len=2)
        return rx1 + rx2

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rx1=p.extract_int(2),
            rx2=p.extract_int(2),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=3)


@dataclass(frozen=True, order=True)
class RadarNoiseSuppressionIndexMask:
    """
    Mask to specify with each bit, for which index relative to RADAR_SELF_INTERFERENCE_TAP the noise suppression should be enabled.

    For example: RADAR_NOISE_SUPPRESSION_INDEX_MASK is 0x08000001.
    • Bit 0: enables the noise suppression on index RADAR_SELF_INTERFERENCE_TAP - 2.
    • Bit 27: enables the noise suppression on index RADAR_SELF_INTERFERENCE_TAP + 25.
    """

    rx1: int = 0x00000000
    """
    bitmask to enables the noise suppression on indexes (RX1):
        bit 0 = SELF_INTERFERENCE_TAP - 2 [...] bit 31 = SELF_INTERFERENCE_TAP + 29
    length: 4 bytes
    """

    rx2: int = 0x00000000
    """
    bitmask to enables the noise suppression on indexes (RX2):
        bit 0 = SELF_INTERFERENCE_TAP - 2 [...] bit 31 = SELF_INTERFERENCE_TAP + 29
    length: 4 bytes
    """

    def create_payload(self):
        payload = to_hex_list(input=self.rx1, byteorder="little", forced_list_len=4)
        payload += to_hex_list(input=self.rx2, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rx1=p.extract_int(4),
            rx2=p.extract_int(4),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=3)


@dataclass(order=True)
class RadarDcCoefficient:
    f_c: float
    """ 3dB corner frequency f_c in Hz for drift suppression. Recommended: f_c = 0.2 Hz """
    t_f: int
    """FRAME_INTERVAL T_f in seconds"""
    dc_coefficient: int | None = None
    """Do not set manually!. This will be calculated after init"""

    def __post_init__(self):
        self.dc_coefficient = self.calculate_dc_coefficient(f_c=self.f_c, t_f=self.t_f)

    @staticmethod
    def calculate_dc_coefficient(f_c, t_f):
        dc_coeff = 2 * pi * 2**15 * f_c * t_f
        return dc_coeff

    def __str__(self) -> str:
        return class_to_str(self, include_title=True, indent_level=1)


@dataclass(frozen=True, order=True)
class RadarDcCoefficients:
    """
    Controls the filter coefficient for the DC estimation. Sets the 3dB corner frequency f_c in Hz for drift suppression,
    relative to the radar FRAME_INTERVAL T_f in seconds.

    RX1 and RX2 have separate DC coefficient configurations.

    Provide rx1/rx2 as 'int' or as instance of 'RadarDcCoefficient'
    """

    rx1: int | RadarDcCoefficient
    """
    Provide DC_COEFFICIENT as 'int' or as instance of 'RadarDcCoefficient'
    """

    rx2: int | RadarDcCoefficient
    """
    Provide DC_COEFFICIENT as 'int' or as instance of 'RadarDcCoefficient'
    """

    def create_payload(self):
        if isinstance(self.rx1, RadarDcCoefficient):
            dc_coeff1 = self.rx1.dc_coefficient
        else:
            dc_coeff1 = self.rx1
        payload = to_hex_list(input=dc_coeff1, byteorder="little", forced_list_len=2)

        if isinstance(self.rx2, RadarDcCoefficient):
            dc_coeff2 = self.rx2.dc_coefficient
        else:
            dc_coeff2 = self.rx2
        payload += to_hex_list(input=dc_coeff2, byteorder="little", forced_list_len=2)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            rx1=p.extract_int(2),
            rx2=p.extract_int(2),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=3)


class EnumSyspllMode(IntEnum):
    FRACTIONAL_MODE = 0x00
    INTEGER_MODE = 0x01


class EnumAnalogCoupling(IntEnum):
    AC = 0x00
    DC = 0x01


class EnumRadarDataSelect(IntEnum):
    CORRELATED_DATA = 0x00
    RAW_BINNING_DATA = 0x01


@dataclass(frozen=True, order=True)
class RadarDataAcquisitionMode:
    """
    Configures the data acquisition mode options for the radar operation (analog coupling, correlation, etc).
    """

    analog_coupling: EnumAnalogCoupling
    radar_data_selection: EnumRadarDataSelect
    disable_agc_control_radar_fast_calibration: bool

    def create_payload(self) -> List[int]:
        payload = [int(self.analog_coupling) | (int(self.radar_data_selection) << 1) | (int(self.disable_agc_control_radar_fast_calibration) << 2)]
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            analog_coupling=p.extract_enum_bits(EnumAnalogCoupling, 1),
            radar_data_selection=p.extract_enum_bits(EnumRadarDataSelect, 1),
            disable_agc_control_radar_fast_calibration=bool(p.extract_bits(1)),
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=1)


class EnumRxSensitivityBoost(IntEnum):
    DISABLE_SENSITIVITY_BOOST = 0x00
    SENSITIVITY_BOOST_ENABLED_RX1 = 0x01
    SENSITIVITY_BOOST_ENABLED_RX2 = 0x02
    SENSITIVITY_BOOST_ENABLED_RX1_RX2 = 0x03


@dataclass(frozen=True, order=True)
class RadarConfigParams(ParamBase):
    radar_radio_cfg_idxs = TlvParamBase(
        tag=0x02,
        convert_to_bytes=lambda v: [int(v)]
        if 0x00 <= v <= 0xF or v == 0xF0
        else _raise(ValueError, f"RADAR_RADIO_CFG_IDXS: {v} is not supported. Range: [0x0 … 0xF]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
        Radio configuration slot index in flash.
        Range: [0x00 … 0xF] for TRX radio configuration
        If this value is configured as 0xF0 (240), the radio configuration downloaded with RADIO_CONFIG_DOWNLOAD_CMD will be used.

    Default: 0x7 (Sc131_kaiser_lin_phase TRX radio configuration slot index in the radio configuration package)
    """

    radar_rxtx_enable = TlvParamBase(
        tag=0x03,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RxTxEnable)
        else _raise(RxTxEnable, f"RXTX_ENABLE: {v} is not supported. Provide instance of RxTxEnable"),
        interpret_resp=lambda p: RxTxEnable.from_bytes(p),
        expected_resp_length=2,
    )
    """
    value_type: RxTxEnable
    """

    radar_preamble_id = TlvParamBase(
        tag=0x04,
        convert_to_bytes=lambda v: [int(v)]
        if v in [9, 10, 11, 12, 13, 14, 15, 16, 21, 22, 23, 24, 0xFF]
        else _raise(ValueError, f"RADAR_PREAMBLE_ID: {v} is not supported. Range: [9 - 12], [13 - 16], [21 - 24] or 0xFF"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
        Ci Code index for radar frame. If this value is configured as 0xFF(undefined) then Preamble ID in radio configuration will be used.\n
        [9 - 12] - support is mandatory\n
        [13 - 16], [21 - 24] - optional support\n
    Default = 0xFF: Use Preamble ID as in Radio configuration
    """

    radar_sync_symbol_cnt = TlvParamBase(
        tag=0x05,
        convert_to_bytes=lambda v: to_hex_list(input=int(v/8), byteorder="little", forced_list_len=2)
        if 8 <= v <= 4096
        else _raise(ValueError, f"RADAR_SYNC_SYMBOL_CNT: {v} is not supported. Range: [1 (8 symbols) ... 512 (4096 symbols)]"),
        interpret_resp=lambda p: int(int.from_bytes(bytes=p, byteorder="little", signed=False)*8),
        expected_resp_length=2,
    )
    """
    value_type: int
        Specifies the number of RX sync symbols to be binned
        Range: [0x1 ... 0x200], equivalent to [8 symbols … 4096 symbols]
    Default: 0x20 (256 symbols)
    """

    radar_channel_id = TlvParamBase(
        tag=0x06,
        convert_to_bytes=lambda v: [int(v)]
        if v in [5, 6, 8, 9]
        else _raise(ValueError, f"RADAR_CHANNEL_ID: {v} is not supported. Choose from Ch[5, 6, 8, 9]"),
        interpret_resp=lambda p: p[0],
        expected_resp_length=1,
    )
    """
    value_type: int
        Range: [5, 6, 8, 9]

    Default: 5
    """

    radar_tx_power = TlvParamBase(
        tag=0x07,
        convert_to_bytes=lambda v: [int(round((14 - v) * 6))]
        if -21 <= v <= 14
        else _raise(ValueError, f"RADAR_TX_POWER {v} is not supported. Range: [-21 - +14]"),
        interpret_resp=lambda p: f"{14 - (p[0] / 6):.2f} dBm",
        expected_resp_length=1,
    )
    """
    value_type: float (in dBm)
        TX output power attenuation relative to maximum TX output power.
        Range: [+14 .. -21] dBm
        Resolution: 0.17 dBm

    Default: +4 dBm
    """

    radar_ntf_threshold: TlvParamBase = set_param(
        aio=None,
        ccc=TlvParamBase(
            tag=0x0A,
            convert_to_bytes=lambda v: [int(v)]
            if 0 <= v <= 12
            else _raise(ValueError, f"RADAR_NTF_THRESHOLD: {v} is not supported. Range: [0 … 12]"),
            interpret_resp=lambda p: p[0],
            expected_resp_length=1,
        ),
    )
    """
    value_type: int
    ONLY CCC
        Radar frame number to get logging notification.
        Range: [1 … 12]

    Default: 1 (Logging notification will be generated after every 1 radar frame)
    """

    radar_cir_offset = TlvParamBase(
        tag=0x0B,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 1015
        else _raise(
            ValueError,
            f"RADAR_CIR_OFFSET: {v} is not supported. Range: [0 to 1015] (CCC and preamble code length 91: Range: [0 to 727])",
        ),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Specifies the offset from the peak CIR tap (CIR tap 0).
    Range: 0 to 1015 taps (with CCC and preamble code length 91: Range: [0 to 727])

    Default: 0x0 (tap index 0)
    Note: The maximum CIR offset is different depending on PRF type and preamble code length.
    """

    radar_cir_taps = TlvParamBase(
        tag=0x0C,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 0 <= v <= 1024
        else _raise(
            ValueError,
            f"RADAR_CIR_TAPS: {v} is not supported. Range: [0 to 1024] (CCC: Range: [0 to 1016] (preamble code length 127) | Range: [0 to 728] (preamble code length 91))",
        ),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int
        Number of radar CIR taps accumulate (starting from the tap specified by RADAR_CIR_OFFSET)
    Range: 1 to 1024 taps (CCC: Range: [0 to 1016] (preamble code length 127) | Range: [0 to 728] (preamble code length 91))

    Default: 64 taps
    Note: The maximum number of CIR taps is different depending on PRF type and preamble code length.
    """

    radar_noise_suppression = TlvParamBase(
        tag=0x12,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RadarNoiseSuppression)
        else _raise(RadarNoiseSuppression, f"RADAR_NOISE_SUPPRESSION: {v} is not supported. Provide instance of RadarNoiseSuppression"),
        interpret_resp=lambda p: RadarNoiseSuppression.from_bytes(p),
        expected_resp_length=6,
    )
    """
    value_type: RadarNoiseSuppression
    """

    radar_self_interference_tap = TlvParamBase(
        tag=0x13,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RadarSelfInterferenceTap)
        else _raise(RadarSelfInterferenceTap, f"RADAR_SELF_INTERFERENCE_TAP: {v} is not supported. Provide instance of RadarSelfInterferenceTap"),
        interpret_resp=lambda p: RadarSelfInterferenceTap.from_bytes(p),
        expected_resp_length=4,
    )
    """
    value_type: RadarSelfInterferenceTap
    """

    radar_noise_suppression_index_mask = TlvParamBase(
        tag=0x14,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RadarNoiseSuppressionIndexMask)
        else _raise(
            RadarNoiseSuppressionIndexMask,
            f"RADAR_NOISE_SUPPRESSION_INDEX_MASK: {v} is not supported. Provide instance of RadarNoiseSuppressionIndexMask",
        ),
        interpret_resp=lambda p: RadarNoiseSuppressionIndexMask.from_bytes(p),
        expected_resp_length=8,
    )
    """
    value_type: RadarNoiseSuppressionIndexMask
    """

    radar_dc_coefficient = TlvParamBase(
        tag=0x15,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RadarDcCoefficients)
        else _raise(RadarDcCoefficients, f"RADAR_DC_COEFFICIENT: {v} is not supported. Provide instance of RadarDcCoefficients"),
        interpret_resp=lambda p: RadarDcCoefficients.from_bytes(p),
        expected_resp_length=4,
    )
    """
    value_type: RadarDcCoefficients
    """

    radar_pll_mode = TlvParamBase(
        tag=0x16,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1]
        else _raise(ValueError, "RADAR_PLL_MODE can only be 0 (fractional mode) or 1 (integer mode)"),
        interpret_resp=lambda p: EnumSyspllMode(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumSyspllMode
        SYSPLL integer or fractional mode selection for radar operations.
    Default: integer mode (0x01)
    """

    radar_data_acquisition_mode = TlvParamBase(
        tag=0x17,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, RadarDataAcquisitionMode)
        else _raise(RadarDataAcquisitionMode, f"RADAR_DATA_ACQUISITION_MODE: {v} is not supported. Provide instance of RadarDataAcquisitionMode"),
        interpret_resp=lambda p: RadarDataAcquisitionMode.from_bytes(p),
        expected_resp_length=1,
    )
    """
    value_type: RadarDataAcquisitionMode

    Default: DC analog coupling, correlated data, AGC enabled for fast calibration
    """

    radar_rx_sensitivity_boost = TlvParamBase(
        tag=0x18,
        convert_to_bytes=lambda v: [int(v)]
        if int(v) in [0, 1, 2, 3]
        else _raise(ValueError, f"RADAR_RX_SENSITIVITY_BOOST: {v} is not supported. Range: [0 .. 3]"),
        interpret_resp=lambda p: EnumRxSensitivityBoost(p[0]),
        expected_resp_length=1,
    )
    """
    value_type: EnumRxSensitivityBoost
    """

    rns_frame_interval = TlvParamBase(
        tag=0x19,
        convert_to_bytes=lambda v: to_hex_list(input=v, byteorder="little", forced_list_len=2)
        if 250 <= v <= 8192
        else _raise(ValueError, f"RNS_FRAME_INTERVAL: {v} is not supported. Range: 250 μs to 8192 μs."),
        interpret_resp=lambda p: int.from_bytes(bytes=p, byteorder="little", signed=False),
        expected_resp_length=2,
    )
    """
    value_type: int

    The radar frame interval for RNS calibration in μs.

    Note: The RNS calibration shall be done with radar parameters as for the indented radar operation.
    This means that the interval should be long enough to accommodate all RADAR_SYNC_SYMBOL_CNT in a radar frame.

    Range: 250 μs to 8192 μs

    Default: 1000 μs
    """


class EnumRadarCalibrationMode(IntEnum):
    FULL_CALIBRATION = 0x00
    FAST_CALIBRATION = 0x01
    RNS_CALIBRATION = 0x02


class EnumRadarCalibrationStatus(IntEnum):
    SUCCESS = 0x00
    FAILED = 0x01
    CALIBRATION_NOT_EXECUTED = 0x02


class EnumConfigurationType(IntEnum):
    RX_RANGING_RADIO_CONFIG = 0x00
    TX_RANGING_RADIO_CONFIG = 0x01
    RX_RADAR_RADIO_CONFIG = 0x02
    TX_RADAR_RADIO_CONFIG = 0x03


@dataclass(frozen=True, order=True)
class EncryptedPmtk:
    """
    The Pairing Material Transport Key (PMTK) data for the ith UWBD.
        Octet[11:0]: IV
        Octet[43:12]: Encrypted PMTKi
        Octet[59:44]: Authentication tag
    """

    iv: List[int]
    encrypted_pmtk_i: List[int]
    authentication_tag: List[int]

    def create_payload(self):
        payload = self.iv if len(self.iv) == 12 else _raise(ValueError, f"IV: Expected 12 bytes. Got {len(self.iv)}")
        payload += (
            self.encrypted_pmtk_i
            if len(self.encrypted_pmtk_i) == 32
            else _raise(ValueError, f"ENCRYPTED_PMTK_I: Expected 32 bytes. Got {len(self.encrypted_pmtk_i)}")
        )
        payload += (
            self.authentication_tag
            if len(self.authentication_tag) == 16
            else _raise(ValueError, f"AUTHENTICATION_TAG: Expected 16 bytes. Got {len(self.authentication_tag)}")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            iv=p.extract_list(12),
            encrypted_pmtk_i=p.extract_list(32),
            authentication_tag=p.extract_list(16),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(frozen=True, order=True)
class EncryptedLtpk:
    """
    The LTPKs data for the ith UWBD.
        Octet[11:0]: IV
        Octet[75:12]: Encrypted Broadcast Long-Term Pairing Key (BLTPK) || Unicast Long-Term Pairing Key (ULTPK)i
        Octet[91:76]: Authentication tag
    """

    iv: List[int]
    longterm_pairing_key: List[int]
    authentication_tag: List[int]

    def create_payload(self):
        payload = self.iv if len(self.iv) == 12 else _raise(ValueError, f"IV: Expected 12 bytes. Got {len(self.iv)}")
        payload += (
            self.longterm_pairing_key
            if len(self.longterm_pairing_key) == 64
            else _raise(ValueError, f"LONGTERM_PAIRING_KEY: Expected 64 bytes. Got {len(self.longterm_pairing_key)}")
        )
        payload += (
            self.authentication_tag
            if len(self.authentication_tag) == 16
            else _raise(ValueError, f"AUTHENTICATION_TAG: Expected 16 bytes. Got {len(self.authentication_tag)}")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            iv=p.extract_list(12),
            encrypted_pmtk_i=p.extract_list(64),
            authentication_tag=p.extract_list(16),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=1)


@dataclass(frozen=True, order=True)
class EncryptedNEpoch:
    """
    The n_epoch data for the ith UWBD.
        Octet[11:0]: IV
        Octet[15:12]: Encrypted n_epoch
        Octet[31:16]: Authentication tag
    """

    iv: List[int]
    encrypted_n_epoch: List[int]
    authentication_tag: List[int]

    def create_payload(self):
        payload = self.iv if len(self.iv) == 12 else _raise(ValueError, f"IV: Expected 12 bytes. Got {len(self.iv)}")
        payload += (
            self.encrypted_n_epoch
            if len(self.encrypted_n_epoch) == 4
            else _raise(ValueError, f"ENCRYPTED_N_EPOCH: Expected 4 bytes. Got {len(self.encrypted_n_epoch)}")
        )
        payload += (
            self.authentication_tag
            if len(self.authentication_tag) == 16
            else _raise(ValueError, f"AUTHENTICATION_TAG: Expected 16 bytes. Got {len(self.authentication_tag)}")
        )
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            iv=p.extract_list(12),
            encrypted_n_epoch=p.extract_list(4),
            authentication_tag=p.extract_list(16),
        )

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=1)


class EnumTypeEncryptedData(IntEnum):
    RANGE_CCC_DATA_NTF = 0x00
    SESSION_INFO_NTF = 0x01


@dataclass(frozen=True, order=True)
class EncryptedDataParams(ParamBase):
    encrypted_ursk = TlvParamBase(
        tag=0x00,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, EncryptedData) and len(v.encrypted_data) == 32
        else _raise(ValueError, f"ENCRYPTED_URSK: {v} is unexpected. Expected type: EncryptedData | Encrypted URSK bytes: 32"),
        interpret_resp=lambda p: EncryptedData.from_bytes(payload=p),
        expected_resp_length=60,
    )
    """
    value_type: EncryptedData
        encrypted URSK bytes: 32
    """

    encrypted_m_ursk = TlvParamBase(
        tag=0x01,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, EncryptedData) and len(v.encrypted_data) == 32
        else _raise(ValueError, f"ENCRYPTED_M_URSK: {v} is unexpected. Expected type: EncryptedData | Encrypted mURSK bytes: 32"),
        interpret_resp=lambda p: EncryptedData.from_bytes(payload=p),
        expected_resp_length=60,
    )
    """
    value_type: EncryptedData
        encrypted mURSK bytes: 32
    """

    encrypted_m_ursk1 = TlvParamBase(
        tag=0x02,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, EncryptedData) and len(v.encrypted_data) == 16
        else _raise(ValueError, f"ENCRYPTED_M_URSK1: {v} is unexpected. Expected type: EncryptedData | Encrypted mURSK1 bytes: 16"),
        interpret_resp=lambda p: EncryptedData.from_bytes(payload=p),
        expected_resp_length=44,
    )
    """
    value_type: EncryptedData
        encrypted mURSK1 bytes: 16
    """

    encrypted_salted_hash = TlvParamBase(
        tag=0x03,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, EncryptedData) and len(v.encrypted_data) == 16
        else _raise(ValueError, f"ENCRYPTED_SALTED_HASH: {v} is unexpected. Expected type: EncryptedData | Encrypted SALTED_HASH bytes: 16"),
        interpret_resp=lambda p: EncryptedData.from_bytes(payload=p),
        expected_resp_length=44,
    )
    """
    value_type: EncryptedData
        Encrypted SALTED_HASH: 16
    """

    encrypted_d_ursk = TlvParamBase(
        tag=0x04,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, EncryptedData) and len(v.encrypted_data) == 16
        else _raise(ValueError, f"ENCRYPTED_D_URSK: {v} is unexpected. Expected type: EncryptedData | Encrypted dURSK bytes: 16"),
        interpret_resp=lambda p: EncryptedData.from_bytes(payload=p),
        expected_resp_length=44,
    )
    """
    value_type: EncryptedData
        Encrypted dURSK: 16
    """

    encrypted_d_udsk = TlvParamBase(
        tag=0x05,
        convert_to_bytes=lambda v: v.create_payload()
        if isinstance(v, EncryptedData) and len(v.encrypted_data) == 16
        else _raise(ValueError, f"ENCRYPTED_D_UDSK: {v} is unexpected. Expected type: EncryptedData | Encrypted dUDSK bytes: 16"),
        interpret_resp=lambda p: EncryptedData.from_bytes(payload=p),
        expected_resp_length=44,
    )
    """
    value_type: EncryptedData
        Encrypted dUDSK: 16
    """


##


@dataclass(order=True)
class LogNtf(TlvNotificationBase):
    """
    Notification with log information. Contains:
        LOG_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_LOG, init=False)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_parameters = p.extract_int(1)
        log_ntf = cls._from_bytes_base(payload=p.extract_list(END), param_class=LogParams) if number_of_parameters > 0 else cls()
        setattr(log_ntf, "number_of_parameters", number_of_parameters)
        return log_ntf

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def __str__(self) -> str:
        _self = deepcopy(self)
        if hasattr(_self, "rx_carrier_frequency_offset"):
            _self.rx_carrier_frequency_offset = str(self.rx_carrier_frequency_offset)
        return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(frozen=True, order=True)
class RadioConfigDownloadCmd(CommandBase):
    """
    Command to download a radio configuration to the UWBD RAM. Contains:
        RADIO_CONFIG_DOWNLOAD_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_RADIO_CONFIG_DOWNLOAD, init=False)

    sequence: EnumDownloadSequence
    """
    0x00: Init Configuration
    0x01: Download Data
    0x02: Program
    """

    # Init Configuration
    configuration_type: EnumConfigurationType | None = None
    """
    Required: Init Configuration
    value_type: EnumConfigurationType
    """

    # Download Data
    offset: int | None = None
    """
    Required: Download Data
    Offset in byte resolution.
    Range:
        [0..1023] for RX radio configuration (Offset + Length should not exceed 1024 bytes)
        [0..511] for TX radio configuration (Offset + Length should not exceed 512 bytes)
    """

    length: int | None = None
    """
    Required: Download Data
    Length in byte resolution
        Range: [1..251] his command can be executed multiple times to transfer the complete radio configuration image
        RX radio configuration: 1024 bytes
        TX radio configuration: 512 bytes
    """
    data: List[int] | None = None
    """Required: Download Data"""

    # Program
    crc: int | None = None
    """
    Required: Program
    CRC value for downloaded image as a result of KERMIT- CRC16 calculation.
    """

    def create_payload(self) -> List[int]:
        match self.sequence:
            case EnumDownloadSequence.INIT_CONFIGURATION:
                payload = [int(self.sequence)]
                payload.append(
                    int(self.configuration_type)
                    if self.configuration_type in EnumConfigurationType._value2member_map_
                    else _raise(ValueError, f"Provided 'configuration_type' {self.configuration_type} not supported. Range: [0 .. 3]")
                )
                return payload
            case EnumDownloadSequence.DOWNLOAD_DATA:
                payload = [int(self.sequence)]
                payload += (
                    to_hex_list(input=self.offset, byteorder="little", forced_list_len=2)
                    if 0 <= self.offset <= 1023
                    else _raise(ValueError, f"Provided 'offset' {self.offset} not supported. Range: RX:[0..1023] TX:[0..511]")
                )
                payload += (
                    [int(self.length)]
                    if 1 <= self.length <= 251
                    else _raise(ValueError, f"Provided 'length' {self.length} not supported. Range: [1..251]")
                )
                payload += self.data
                return payload
            case EnumDownloadSequence.PROGRAM:
                payload = [int(self.sequence)]
                payload += to_hex_list(input=self.crc, byteorder="little", forced_list_len=2)
                return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        sequence = p.extract_enum(EnumDownloadSequence)

        match sequence:
            case EnumDownloadSequence.INIT_CONFIGURATION:
                return cls(sequence=sequence, radio_index=p.extract_int(1))

            case EnumDownloadSequence.DOWNLOAD_DATA:
                return cls(sequence=sequence, offset=p.extract_int(2), length=p.extract_int(1), data=p.extract_list(END))

            case EnumDownloadSequence.PROGRAM:
                return cls(sequence=sequence, crc=p.extract_int(2))


@dataclass(frozen=True, order=True)
class RadioConfigDownloadRsp(ResponseBase):
    """
    Command to download a radio configuration to the UWBD RAM. Contains:
        RADIO_CONFIG_DOWNLOAD_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class RadioConfigDownloadNtf(NotificationBase):
    """
    Command to download a radio configuration to the UWBD RAM. Contains:
        RADIO_CONFIG_DOWNLOAD_NTF
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class ActivateSwupCmd(CommandBase):
    """
    Command to activate the SWUP mode. Contains:
        ACTIVATE_SWUP_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_ACTIVATE_SWUP, init=False)

    swup_mode: EnumSwupMode

    def create_payload(self) -> List[int]:
        return [int(self.swup_mode)]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(swup_mode=p.extract_enum(EnumSwupMode))


@dataclass(frozen=True, order=True)
class ActivateSwupRsp(ResponseBase):
    """
    Command to activate the SWUP mode. Contains:
        ACTIVATE_SWUP_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class DeviceGetRebootReasonCmd(CommandBase):
    """
    Command to get device reboot reason. Contains:
        DEVICE_GET_REBOOT_REASON_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_DEVICE_GET_REBOOT_REASON, init=False)


@dataclass(frozen=True, order=True)
class DeviceGetRebootReasonRsp(ResponseBase):
    """
    Command to get device reboot reason. Contains:
        DEVICE_GET_REBOOT_REASON_RSP
    """

    status: EnumUciStatus
    reboot_reasons: List[str]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        reason_to_bit: Dict[str, int] = {
            "POR": 0,
            "RST_PIN": 1,
            "DPD_RST_PIN": 2,
            "HPD_RST_PIN": 3,
            "HPD_WUP_PIN": 4,
            "SOFTWARE_MASTER_RST": 5,
            "FAIL_VDD_BIAS_BGAP": 6,
            "FAIL_VDD_CPU_RET": 7,
            "BROWNOUT_CPU_RET": 8,
            "FAIL_VDD_PFLASH": 9,
            "FAIL_IO": 10,
            "FAIL_IO_NV": 11,
            "WDOG_RST": 12,
            "FAILED_STATE_CHANGE": 13,
            "WUP_TIMER_FLAG": 14,
            "WUP_SNAPSHOT_FLAG": 15,
            "SYSRST": 16,
            "INGFIDRST": 17,
            "EDCRST": 18,
            "GLITCHRST": 19,
            "FAIL_FREQ_MON": 20,
        }

        return cls(
            status=p.extract_enum(EnumUciStatus),
            reboot_reasons=p.extract_set_keys_from_bitmask(reason_to_bit, 4),
        )


@dataclass(frozen=True, order=True)
class GetDeviceTemperatureDataCmd(CommandBase):
    """
    Command to get the device temperature data. Contains:
        GET_DEVICE_TEMPERATURE_DATA_CMD
    Only AiO
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_GET_DEVICE_TEMPERATURE_DATA, init=False)


@dataclass(order=True)
class GetDeviceTemperatureDataRsp(ResponseBase):
    """
    Command to get the device temperature data. Contains:
        GET_DEVICE_TEMPERATURE_DATA_RSP
    Only AiO
    """

    status: EnumUciStatus
    internal_device_temperature_c: int
    offset_error_1: int
    adc_value_1: int
    offset_error_2: int
    adc_value_2: int
    external_temperature_c: float

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        internal_device_temperature_c = p.extract_int(2, signed=True)
        offset_error_1 = p.extract_int(2, signed=True)
        adc_value_1 = p.extract_int(2, signed=True)
        offset_error_2 = p.extract_int(2, signed=True)
        adc_value_2 = p.extract_int(2, signed=True)
        external_temperature_c = calculate_external_temperature(adc_value_1, adc_value_2, offset_error_1, offset_error_2)

        return cls(
            status=status,
            internal_device_temperature_c=internal_device_temperature_c,
            offset_error_1=offset_error_1,
            adc_value_1=adc_value_1,
            offset_error_2=offset_error_2,
            adc_value_2=adc_value_2,
            external_temperature_c=external_temperature_c,
        )

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.external_temperature_c = round(self.external_temperature_c, 2)
        return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(order=True)
class TestStartCmd(TlvCommandBase):
    """
    Command used to start test mode. Contains:
        TEST_START_CMD

    Params: TestStartParams
    Pass empty list to reset all parameters.
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TEST_START, init=False)

    def set_parameter(self, param: TlvParamBase, value: Any):
        super()._set_parameter_base(param, value, param_class=TestStartParams, set_command=True)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_parameters = p.extract_int(1)
        test_start_cmd = cls._from_bytes_base(payload=p.extract_list(END), param_class=TestStartParams) if number_of_parameters > 0 else cls()
        setattr(test_start_cmd, "number_of_parameters", number_of_parameters)
        return test_start_cmd

    def __init__(self, params: List[Tuple[TlvParamBase, Any]] = []):
        super().__init__(params)


@dataclass(frozen=True, order=True)
class TestStartRsp(ResponseBase):
    """
    Command used to start test mode. Contains:
        TEST_START_RSP
    """

    status: EnumUciStatus
    number_of_invalid_parameters: int
    list_of_invalid_parameters: List[InvalidParam]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_invalid_parameters = p.extract_int(1)
        list_of_invalid_parameters = [
            InvalidParam(tag=(tag := p.extract_int(1)), name=TestStartParams.find_name_by_tag(tag=tag), error_code=p.extract_enum(EnumUciStatus))
            for _ in range(number_of_invalid_parameters)
        ]
        return cls(
            status=status,
            number_of_invalid_parameters=number_of_invalid_parameters,
            list_of_invalid_parameters=list_of_invalid_parameters,
        )


@dataclass(frozen=True, order=True)
class TestStopCmd(CommandBase):
    """
    Command used to stop test mode. Contains:
        TEST_STOP_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TEST_STOP, init=False)


@dataclass(frozen=True, order=True)
class TestStopRsp(ResponseBase):
    """
    Command used to stop test mode. Contains:
        TEST_STOP_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class TestStopNtf(NotificationBase):
    """
    Command used to stop test mode. Contains:
        TEST_STOP_NTF
    """

    @classmethod
    def from_bytes(cls, payload: List[int] = []):
        return cls()


@dataclass(frozen=True, order=True)
class SetHprfPsduCmd(CommandBase):
    """
    Command to the TX payload for HPRF frames for test mode. Contains:
        SET_HPRF_PSDU_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_SET_HPRF_PSDU, init=False)

    offset: int = 0
    """
    Offset in byte resolution.
    Range: 0 to 4095 bytes
    Note: Offset + length should not exceed 4095 bytes.
    """

    length: int = 0
    """
    Length in byte resolution
    Range: 1 to 252
    Will be calculated from data, no need manually to set.
    """

    data: List[int] = field(default_factory=[])
    """PSDU data"""

    def __post_init__(self):
        self.length = len(self.data)

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.offset, byteorder="little", forced_list_len=2)
        payload.append(self.length) if 1 <= self.length <= 252 else _raise(ValueError, f"'Length' {self.length} not supported. Range: 1 to 252.")
        payload += self.data

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            offset=p.extract_int(2),
            length=p.extract_int(1),
            data=p.extract_list(END),
        )


@dataclass(frozen=True, order=True)
class SetHprfPsduRsp(ResponseBase):
    """
    To the TX payload for HPRF frames for test mode. Contains:
        SET_HPRF_PSDU_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class QueryUwbTimestampCmd(CommandBase):
    """
    To get UWB time for CCC time synchronization. Contains:
        QUERY_UWB_TIMESTAMP_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_QUERY_UWB_TIMESTAMP, init=False)


@dataclass(frozen=True, order=True)
class QueryUwbTimestampRsp(ResponseBase):
    """
    To get UWB time for CCC time synchronization. Contains:
        QUERY_UWB_TIMESTAMP_RSP
    """

    status: EnumUciStatus

    uwb_timestamp_ms: int
    """UWB device timestamps in microsecond resolution"""

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            uwb_timestamp_ms=p.extract_int(8),
        )


@dataclass(frozen=True, order=True)
class DeviceSuspendCmd(CommandBase):
    """
    Command used to enter low-power mode. Contains:
        DEVICE_SUSPEND_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_DEVICE_SUSPEND, init=False)


@dataclass(frozen=True, order=True)
class DeviceSuspendRsp(ResponseBase):
    """
    Command used to enter low-power mode. Contains:
        DEVICE_SUSPEND_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumUciStatus))


@dataclass(frozen=True, order=True)
class TestLoopbackNtf(NotificationBase):
    """
    Loopback notification is sent when the test in the loopback mode has been finished. Contains:
        TEST_LOOPBACK_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TEST_LOOPBACK, init=False)

    status: EnumUciStatus

    group_delay_ns: int
    """Calculated group delay"""

    # 1LSB = 15.65 ps
    # Group delay = 0x3654 = 13908 decimal
    # 13908 * 15.65 ps = 2.1766e+05 ps = 217.66 ns

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            group_delay_ns=p.extract_int(4) * 0.01565,
        )


@dataclass(order=True)
class SetAppCfgPageValuesCmd(TlvCommandBase):
    """
    Command used to configure application configuration page values. Contains:
        SET_APP_CFG_PAGE_VALUES_CMD

    Params: AppConfigPageParams
    Pass empty list to reset all parameters.
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_SET_APP_CFG_PAGE_VALUES, init=False)

    def set_parameter(self, param: TlvParamBase, value: Any):
        super()._set_parameter_base(param, value, param_class=AppConfigPageParams, set_command=True)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_parameters = p.extract_int(1)
        set_app_cfg_page_values_cmd = (
            cls._from_bytes_base(payload=p.extract_list(END), param_class=AppConfigPageParams) if number_of_parameters > 0 else cls()
        )
        setattr(set_app_cfg_page_values_cmd, "number_of_parameters", number_of_parameters)
        return set_app_cfg_page_values_cmd

    def __init__(self, params: List[Tuple[TlvParamBase, Any]] = []):
        super().__init__(params)


@dataclass(frozen=True, order=True)
class SetAppCfgPageValuesRsp(ResponseBase):
    """
    Contains:
        SET_APP_CFG_PAGE_VALUES_RSP
    """

    status: EnumUciStatus
    number_of_invalid_parameters: int
    list_of_invalid_parameters: List[InvalidParam]

    class ErrorCodes:
        error_codes: Dict[EnumUciStatus, str] = {
            EnumUciStatus.UCI_STATUS_INVALID_PARAM: "unrecognized tag",
            EnumUciStatus.UCI_STATUS_SYNTAX_ERROR: "invalid length",
            EnumUciStatus.UCI_STATUS_INVALID_RANGE: "invalid value",
        }

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_invalid_parameters = p.extract_int(1)
        list_of_invalid_parameters = [
            InvalidParam(
                tag=(tag := p.extract_int(1)),
                name=AppConfigPageParams.find_name_by_tag(tag=tag),
                error_code=cls.ErrorCodes.error_codes[p.extract_enum(EnumUciStatus)],
            )
            for _ in range(number_of_invalid_parameters)
        ]
        return cls(
            status=status,
            number_of_invalid_parameters=number_of_invalid_parameters,
            list_of_invalid_parameters=list_of_invalid_parameters,
        )


@dataclass(frozen=True, order=True)
class SetAppCfgPageValuesNtf(NotificationBase):
    """
    Contains:
        SET_APP_CFG_PAGE_VALUES_NTF
    """

    status: EnumSetAppCfgPageValueStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(status=p.extract_enum(EnumSetAppCfgPageValueStatus))


@dataclass(frozen=True, order=True)
class GetAllUwbSessionsCmd(CommandBase):
    """
    Command used to get the list of initialized UWB sessions. Contains:
        GET_ALL_UWB_SESSIONS_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_GET_ALL_UWB_SESSIONS, init=False)


@dataclass(frozen=True, order=True)
class GetAllUwbSessionsRsp(ResponseBase):
    """
    Command used to get the list of initialized UWB sessions. Contains:
        GET_ALL_UWB_SESSIONS_RSP
    """

    status: EnumUciStatus
    session_count: int
    session_info: List[SessionInfo]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        session_count = p.extract_int(1)
        session_info = [p.extract_cls(SessionInfo, 6) for _ in range(session_count)]
        return cls(
            status=status,
            session_count=session_count,
            session_info=session_info,
        )


@dataclass(order=True)
class GetAppCfgPageValuesCmd(CommandBase):
    """
    Command used to read application configuration page values. Contains:
        GET_APP_CFG_PAGE_VALUES_CMD

    Params: AppConfigPageParams
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_GET_APP_CFG_PAGE_VALUES, init=False)

    param_list: List[TlvParamBase] = field(default_factory=[])
    """
    List of AppConfigPageParams attributes. Pass empty list to read all parameters.
        Example:
            [AppConfigPageParams.antenna_delay, AppConfigPageParams.current_limiter]
    """
    number_of_parameters: int = 0
    """Do NOT set this parameter. It will be set automatically based on the length of 'param_list'"""

    def __post_init__(self):
        self.number_of_parameters = len(self.param_list)

    def create_payload(self) -> List[int]:
        payload = [len(self.param_list)]

        for param in self.param_list:
            if param not in vars(AppConfigPageParams).values():
                raise AttributeError(f"Param ({param}) not part of {AppConfigPageParams.__class__.__name__}!")
            payload.append(param.tag)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        number_of_parameters = p.extract_int(1)
        param_list = (
            [AppConfigPageParams.find_name_by_tag(p.extract_int(1)) for _ in range(number_of_parameters)]
            if number_of_parameters > 0
            else list(vars(AppConfigPageParams).keys())
        )

        return cls(
            number_of_parameters=number_of_parameters,
            param_list=param_list,
        )

    def __str__(self) -> str:
        if any([isinstance(param, str) for param in self.param_list]):
            return class_to_str(self, include_title=True, indent_level=0)
        else:
            _self = deepcopy(self)
            _self.param_list = [f"{name} ({as_hex(value.tag)})" for name, value in vars(AppConfigPageParams).items() if value in self.param_list]
            return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(order=True)
class GetAppCfgPageValuesRsp(TlvResponseBase):
    """
    Command used to read application configuration page values. Contains:
        GET_APP_CFG_PAGE_VALUES_RSP
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_parameters = p.extract_int(1)
        get_config_rsp = cls._from_bytes_base(payload=p.extract_list(END), param_class=AppConfigPageParams) if number_of_parameters > 0 else cls()
        setattr(get_config_rsp, "status", status)
        setattr(get_config_rsp, "number_of_parameters", number_of_parameters)
        return get_config_rsp

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


@dataclass(frozen=True, order=True)
class UserDefinedRangeDataNtf(NotificationBase):
    """
    Ranging data notification for user-defined session 0xE1. Contains:
        USER_DEFINED_RANGE_DATA_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_USER_DEFINED_RANGE_DATA, init=False)

    session_handle: int
    """Session Handle of the currently active session"""

    sts_index: int
    """Current STS index"""

    timestamp_between_poll_to_range_ps: float
    """time value between Poll to Range"""

    timestamp_between_poll_to_final_ps: float
    """time value between Poll to Final"""

    uncertainty_fom: int
    """Ranging timestamp uncertainty"""

    ccm_tag: List[int]
    """CCM TAG calculated over all payload fields. CCM TAG will be set to all 0xFF if not used."""

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
            sts_index=p.extract_int(4),
            timestamp_between_poll_to_range_ps=p.extract_int(4) * 15.65,
            timestamp_between_poll_to_final_ps=p.extract_int(4) * 15.65,
            uncertainty_fom=p.extract_int(1),
            ccm_tag=p.extract_list(8),
        )


@dataclass(order=True)
class SetRadarConfigCmd(TlvCommandBase):
    """
    Command used to store radar configuration to a specific radar configuration index. Contains:
        SET_RADAR_CONFIG_CMD

    Params: RadarConfigParams
    Pass empty list to reset all parameters.
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_SET_RADAR_CONFIG, init=False)

    def set_parameter(self, param: TlvParamBase, value: Any):
        super()._set_parameter_base(param, value, param_class=RadarConfigParams, set_command=True)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        radar_config_index = p.extract_int(1)
        number_of_parameters = p.extract_int(1)
        radar_config_cmd_cls = (
            cls._from_bytes_base(payload=p.extract_list(END), param_class=RadarConfigParams, radar_config_index=radar_config_index)
            if number_of_parameters > 0
            else cls(radar_config_index=radar_config_index)
        )
        setattr(radar_config_cmd_cls, "number_of_parameters", number_of_parameters)
        return radar_config_cmd_cls

    def __init__(self, radar_config_index: int, params: List[Tuple[TlvParamBase, Any]] = []):
        self.radar_config_index = radar_config_index
        super().__init__(params)


@dataclass(frozen=True, order=True)
class SetRadarConfigRsp(ResponseBase):
    """
    Command used to store radar configuration to a specific radar configuration index. Contains:
        SET_RADAR_CONFIG_RSP
    """

    status: EnumUciStatus
    number_of_invalid_parameters: int
    list_of_invalid_parameters: List[InvalidParam]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_invalid_parameters = p.extract_int(1)
        list_of_invalid_parameters = [
            InvalidParam(tag=(tag := p.extract_int(1)), name=RadarConfigParams.find_name_by_tag(tag=tag), error_code=p.extract_enum(EnumUciStatus))
            for _ in range(number_of_invalid_parameters)
        ]
        return cls(
            status=status,
            number_of_invalid_parameters=number_of_invalid_parameters,
            list_of_invalid_parameters=list_of_invalid_parameters,
        )


@dataclass(order=True)
class GetRadarConfigCmd(CommandBase):
    """
    Command used to obtain radar configuration from a specific radar configuration index. Contains:
        GET_RADAR_CONFIG_CMD

    Params: RadarConfigParams
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_GET_RADAR_CONFIG, init=False)

    radar_config_index: int = 0

    param_list: List[TlvParamBase] = field(default_factory=[])
    """
    List of RadarConfigParams attributes. Pass empty list to get all the APP configurations IDs.
    Example: [RadarConfigParams.radar_channel_id, RadarConfigParams.radar_dc_coefficient]
    """

    number_of_parameters: int = 0
    """Do NOT set manually! This is set automatically based on the length of the param_list."""

    def __post_init__(self):
        self.number_of_parameters = len(self.param_list)

    def create_payload(self) -> List[int]:
        payload = [self.radar_config_index]

        if self.number_of_parameters == 0:
            payload.append(self.number_of_parameters)
            return payload

        payload.append(len(self.param_list))

        for param in self.param_list:
            if param not in vars(RadarConfigParams).values():
                raise AttributeError(f"Param ({param}) not part of {RadarConfigParams.__class__.__name__}!")
            payload.append(param.tag)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        radar_config_index = p.extract_int(1)
        number_of_parameters = p.extract_int(1)
        param_list = (
            [RadarConfigParams.find_name_by_tag(p.extract_int(1)) for _ in range(number_of_parameters)]
            if number_of_parameters > 0
            else list(vars(RadarConfigParams).keys())
        )
        return cls(
            radar_config_index=radar_config_index,
            number_of_parameters=number_of_parameters,
            param_list=param_list,
        )

    def __str__(self) -> str:
        if any([isinstance(param, str) for param in self.param_list]):
            return class_to_str(self, include_title=True, indent_level=0)
        else:
            _self = deepcopy(self)
            _self.param_list = [f"{name} ({as_hex(value.tag)})" for name, value in vars(RadarConfigParams).items() if value in self.param_list]
            return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(order=True)
class GetRadarConfigRsp(TlvResponseBase):
    """
    Command used to obtain radar configuration from a specific radar configuration index. Contains:
        GET_RADAR_CONFIG_RSP

    Params: RadarConfigParams
    """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_parameters = p.extract_int(1)
        get_app_config_rsp = cls._from_bytes_base(payload=p.extract_list(END), param_class=RadarConfigParams) if number_of_parameters > 0 else cls()
        setattr(get_app_config_rsp, "status", status)
        setattr(get_app_config_rsp, "number_of_parameters", number_of_parameters)
        return get_app_config_rsp

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


@dataclass(frozen=True, order=True)
class RunRadarCalibrationCmd(CommandBase):
    """
    Command to run radar calibration for radar configuration stored in a specific radar configuration index. Contains:
        RUN_RADAR_CALIBRATION_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_RUN_RADAR_CALIBRATION, init=False)

    radar_config_index: int
    radar_calibration_mode: EnumRadarCalibrationMode

    def create_payload(self):
        payload = [self.radar_config_index]
        payload.append(int(self.radar_calibration_mode))
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            radar_config_index=p.extract_int(1),
            radar_calibration_mode=p.extract_enum(EnumRadarCalibrationMode),
        )


@dataclass(frozen=True, order=True)
class RunRadarCalibrationRsp(ResponseBase):
    """
    Command to run radar calibration for radar configuration stored in a specific radar configuration index. Contains:
        RUN_RADAR_CALIBRATION_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
        )


@dataclass(order=True)
class RunRadarCalibrationNtf(NotificationBase):
    """
    Command to run radar calibration for radar configuration stored in a specific radar configuration index. Contains:
        RUN_RADAR_CALIBRATION_NTF
    """

    radar_config_index: int

    radar_calibration_status_rx1: EnumRadarCalibrationStatus

    radar_calibration_status_rx2: EnumRadarCalibrationStatus

    calibration_gain_rx1: int
    """
    Gain delta during the calibration phase of RX1
        Calibration gain >= -2, Calibration is successful.

        Calibration gain < -2, Calibration was not successful.
            User shall redo the calibration with different sensitivityBoostOffset or with sensitivityBoost OFF.

    Note: The value is not valid if the radar calibration is not performed/failed on channel RX1.
    """

    calibration_gain_rx2: int
    """
    Gain delta during the calibration phase of  RX2
        Calibration gain >= -2, Calibration is successful.

        Calibration gain < -2, Calibration was not successful.
            User shall redo the calibration with different sensitivityBoostOffset or with sensitivityBoost OFF.

    Note: The value is not valid if the radar calibration is not performed/failed on channel RX1.
    """

    agc_gain_rx1: int
    """ AGC gain of RX1 [0 dB ... -88 dB] """

    agc_gain_rx2: int
    """ AGC gain of RX2 [0 dB ... -88 dB] """

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            radar_config_index=p.extract_int(1),
            radar_calibration_status_rx1=p.extract_enum(EnumRadarCalibrationStatus),
            radar_calibration_status_rx2=p.extract_enum(EnumRadarCalibrationStatus),
            calibration_gain_rx1=p.extract_int(4),
            calibration_gain_rx2=p.extract_int(4),
            agc_gain_rx1=(-p.extract_int(4)),
            agc_gain_rx2=(-p.extract_int(4)),
        )

    def __str__(self):
        _self = deepcopy(self)
        _self.agc_gain_rx1 = f"{self.agc_gain_rx1} dB"
        _self.agc_gain_rx2 = f"{self.agc_gain_rx2} dB"
        return class_to_str(_self, include_title=True, indent_level=0)


@dataclass(frozen=True, order=True)
class RadarFrameEnableCmd(CommandBase):
    """
    Command to activate a radar frames in the synchronized radar enabled ranging session. Contains:
        RADAR_FRAME_ENABLE_CMD
    Only AiO
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidProprietary.MAC_OID_RADAR_FRAME_ENABLE, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
        )


@dataclass(frozen=True, order=True)
class RadarFrameEnableRsp(ResponseBase):
    """
    Command to activate a radar frames in the synchronized radar enabled ranging session. Contains:
        RADAR_FRAME_ENABLE_RSP
    Only AiO
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
        )


@dataclass(frozen=True, order=True)
class RadarFrameDisableCmd(CommandBase):
    """
    Command to deactivate a radar frames in the synchronized radar enabled ranging session. Contains:
        RADAR_FRAME_DISABLE_CMD
    Only AiO
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidProprietary.MAC_OID_RADAR_FRAME_DISABLE, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
        )


@dataclass(frozen=True, order=True)
class RadarFrameDisableRsp(ResponseBase):
    """
    Command to deactivate a radar frames in the synchronized radar enabled ranging session. Contains:
        RADAR_FRAME_DISABLE_RSP
    Only AiO
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
        )


@dataclass(order=True)
class RadarStatusNtf(NotificationBase):
    """
    Notification containing the radar results from the UWBD after the
    successful activation of a radar session. Contains:
        RADAR_STATUS_NTF
    Only AiO
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidProprietary.MAC_OID_RADAR_STATUS, init=False)

    session_handle: int
    """Session handle of the currently active radar session."""

    round_index: int
    """Current round index."""

    antenna: EnumRadarAntennaIndex
    """Antenna of the CIR."""

    cir_offset: int
    """The offset from the peak CIR tap as configured in the field RADAR_CIR_OFFSET."""

    number_of_taps: int
    """Number of taps as configured in the field RADAR_CIR_TAPS."""

    number_of_results: int
    """The number of radar results to follow."""

    results: List[RadarResult]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        session_handle = p.extract_int(4)
        round_index = p.extract_int(2)
        antenna = p.extract_enum(EnumRadarAntennaIndex)
        cir_offset = p.extract_int(2)
        number_of_taps = p.extract_int(2)
        number_of_results = p.extract_int(2)
        results = [p.extract_cls(RadarResult, int((len(payload) - 13) / number_of_results)) for _ in range(number_of_results)]

        return cls(
            session_handle=session_handle,
            round_index=round_index,
            antenna=antenna,
            cir_offset=cir_offset,
            number_of_taps=number_of_taps,
            number_of_results=number_of_results,
            results=results,
        )

    def __str__(self):
        return class_to_str(self, include_title=True, indent_level=0)


@dataclass(frozen=True, order=True)
class RangingFrameDisableCmd(CommandBase):
    """
    Command to deactivate a ranging frames in the synchronized radar enabled ranging session. Contains:
        RANGING_FRAME_DISABLE_CMD
    Only AiO
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidSessionConfig = field(default=EnumMacOidProprietary.MAC_OID_RANGING_FRAME_DISABLE, init=False)

    session_handle: int

    def create_payload(self) -> List[int]:
        payload = to_hex_list(input=self.session_handle, byteorder="little", forced_list_len=4)
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            session_handle=p.extract_int(4),
        )


@dataclass(frozen=True, order=True)
class RangingFrameDisableRsp(ResponseBase):
    """
    Command to deactivate a ranging frames in the synchronized radar enabled ranging session. Contains:
        RANGING_FRAME_DISABLE_RSP
    Only AiO
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
        )


@dataclass(frozen=True, order=True)
class TuspStoreTtpKeyCmd(CommandBase):
    """
    Command to set TTP key for pairing with secure element. Contains:
        TUSP_STORE_TTP_KEY_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TUSP_STORE_TTP_KEY, init=False)

    ttp_key: List[int]

    def create_payload(self):
        return self.ttp_key if len(self.ttp_key) == 32 else _raise(ValueError, f"TTP_KEY: Expected 32 bytes. Got {len(self.ttp_key)}")

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            ttp_key=p.extract_list(32),
        )


@dataclass(frozen=True, order=True)
class TuspStoreTtpKeyRsp(ResponseBase):
    """
    Command to set TTP key for pairing with secure element. Contains:
        TUSP_STORE_TTP_KEY_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
        )


@dataclass(frozen=True, order=True)
class TuspGetAnchorRequestsCmd(CommandBase):
    """
    Command to get n_UWB for pairing with secure element. Contains:
        TUSP_GET_ANCHOR_REQUESTS_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TUSP_GET_ANCHOR_REQUESTS, init=False)


@dataclass(frozen=True, order=True)
class TuspGetAnchorRequestsRsp(ResponseBase):
    """
    Command to get n_UWB for pairing with secure element. Contains:
        TUSP_GET_ANCHOR_REQUESTS_RSP
    """

    status: EnumUciStatus
    id_uwbd: List[int]
    n_uwbd: List[int]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            id_uwbd=p.extract_list(8),
            n_uwbd=p.extract_list(32),
        )


@dataclass(frozen=True, order=True)
class TuspStoreLongtermPairingKeysCmd(CommandBase):
    """
    Command to set long-term paring keys for pairing with secure element. Contains:
        TUSP_STORE_LONG_TERM_PAIRING_KEYS_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TUSP_STORE_LONGTERM_PAIRING_KEYS, init=False)

    id_se: int
    id_uwbd: int
    salt_uwbd: List[int]
    encrypted_pmtk: EncryptedPmtk
    encrypted_ltpk: EncryptedLtpk

    def create_payload(self):
        payload = to_hex_list(input=self.id_se, byteorder="little", signed=False, forced_list_len=8)
        payload += to_hex_list(input=self.id_uwbd, byteorder="little", signed=False, forced_list_len=8)
        payload += self.salt_uwbd if len(self.salt_uwbd) == 32 else _raise(ValueError, f"SALT_UWBD: Expected 32 bytes. Got {len(self.salt_uwbd)}")
        payload += self.encrypted_pmtk.create_payload()
        payload += self.encrypted_ltpk.create_payload()
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            id_se=p.extract_int(8),
            id_uwbd=p.extract_int(8),
            salt_uwbd=p.extract_list(32),
            encrypted_pmtk=p.extract_cls(EncryptedPmtk, 60),
            encrypted_ltpk=p.extract_cls(EncryptedLtpk, 92),
        )


@dataclass(frozen=True, order=True)
class TuspStoreLongtermPairingKeysRsp(ResponseBase):
    """
    Command to set long-term paring keys for pairing with secure element. Contains:
        TUSP_STORE_LONG_TERM_PAIRING_KEYS_RSP
    """

    status: EnumUciStatus

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
        )


@dataclass(frozen=True, order=True)
class TuspSetEpochIdCmd(CommandBase):
    """
    Command used to set Epoch Id for pairing with secure element. Contains:
        TUSP_SET_EPOCH_ID_CMD
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TUSP_SET_EPOCH_ID, init=False)

    epoch_id: int
    encrypted_n_epoch: EncryptedNEpoch

    def create_payload(self):
        payload = to_hex_list(input=self.epoch_id, byteorder="little", signed=False, forced_list_len=4)
        payload += self.encrypted_n_epoch.create_payload()
        return payload

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            epoch_id=p.extract_int(4),
            encrypted_n_epoch=p.extract_cls(EncryptedNEpoch, 32),
        )


@dataclass(frozen=True, order=True)
class TuspSetEpochIdRsp(ResponseBase):
    """
    Command used to set Epoch Id for pairing with secure element. Contains:
        TUSP_SET_EPOCH_ID_RSP
    """

    status: EnumUciStatus
    id_uwbd: List[int]
    encrypted_n_epoch: List[int]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        return cls(
            status=p.extract_enum(EnumUciStatus),
            id_uwbd=p.extract_int(8),
            encrypted_n_epoch=p.extract_cls(EncryptedNEpoch, 32),
        )


@dataclass(frozen=True, order=True)
class TuspEncryptedDataNtf(NotificationBase):
    """
    Encrypted data notification . Contains:
        AiO: TUSP_ENCRYPTED_DATA_NTF
        CCC: ENCRYPTED_RANGE_CCC_DATA_NTF
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TUSP_ENCRYPTED_DATA, init=False)

    type: EnumTypeEncryptedData
    encrypted_data: EncryptedData

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        if mac_config.MAC_FW_TYPE == "AiO":
            ntf = cls(type=p.extract_enum(EnumTypeEncryptedData), encrypted_data=p.extract_cls(EncryptedData, END))
        elif mac_config.MAC_FW_TYPE == "CCC":
            ntf = cls(type=EnumTypeEncryptedData.RANGE_CCC_DATA_NTF, encrypted_data=p.extract_cls(EncryptedData, END))
        else:
            raise RuntimeError(
                "mac_config.MAC_FW_TYPE is neither AiO, nor CCC. Make sure to set mac_config.MAC_FW_TYPE via 'set_mac_config.MAC_FW_TYPE' to an expected value."
            )
        return ntf


@dataclass(order=True)
class TuspTransmitEncryptedDataCmd(TlvCommandBase):
    """
    Command used to Transmit encrypted data from the secure element to the UWBD. Contains:
        TUSP_TRANSMIT_ENCRYPTED_DATA_CMD

    Params: EncryptedDataParams
    """

    _gid_: EnumUciGid = field(default=EnumUciGid.GID_PROPRIETARY, init=False)
    _oid_: EnumMacOidProprietary = field(default=EnumMacOidProprietary.MAC_OID_TUSP_TRANSMIT_ENCRYPTED_DATA, init=False)

    def set_parameter(self, param: TlvParamBase, value: Any):
        super()._set_parameter_base(param, value, param_class=EncryptedDataParams, set_command=True)

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        session_handle = p.extract_int(4)
        epoch_id = p.extract_int(4)
        update_epoch_key = p.extract_bool(1)
        number_of_parameters = p.extract_int(1)
        tusp_transmit_encrypted_data_cls = (
            cls._from_bytes_base(
                payload=p.extract_list(END),
                param_class=EncryptedDataParams,
                session_handle=session_handle,
                epoch_id=epoch_id,
                update_epoch_key=update_epoch_key,
            )
            if number_of_parameters > 0
            else cls(session_handle=session_handle, epoch_id=epoch_id, update_epoch_key=update_epoch_key)
        )

        setattr(tusp_transmit_encrypted_data_cls, "number_of_parameters", number_of_parameters)
        return tusp_transmit_encrypted_data_cls

    def __init__(
        self,
        session_handle: int,
        epoch_id: int,
        update_epoch_key: bool,
        params: List[Tuple[TlvParamBase, Any]] = [],
    ):
        self.session_handle = session_handle
        self.epoch_id = epoch_id
        self.update_epoch_key = update_epoch_key
        super().__init__(params)

    def __str__(self):
        return class_to_str(self)


@dataclass(frozen=True, order=True)
class TuspTransmitEncryptedDataRsp(ResponseBase):
    """
    Command used to Transmit encrypted data from the secure element to the UWBD. Contains:
        TUSP_TRANSMIT_ENCRYPTED_DATA_RSP
    """

    status: EnumUciStatus
    number_of_invalid_parameters: int
    list_of_invalid_parameters: List[InvalidParam]

    @classmethod
    def from_bytes(cls, payload: List[int]):
        p = PayloadParser(payload)
        status = p.extract_enum(EnumUciStatus)
        number_of_invalid_parameters = p.extract_int(1)
        list_of_invalid_parameters = [
            InvalidParam(tag=(tag := p.extract_int(1)), name=EncryptedDataParams.find_name_by_tag(tag=tag), error_code=p.extract_enum(EnumUciStatus))
            for _ in range(number_of_invalid_parameters)
        ]
        return cls(
            status=status,
            number_of_invalid_parameters=number_of_invalid_parameters,
            list_of_invalid_parameters=list_of_invalid_parameters,
        )


###########################################################################################################
###########################################################################################################
### Helpers ###


def adc_to_temperature(adc_value: float) -> int:
    """
    Approximates the temperature based on the ADC input value using a polynomial approximation.
    """
    # Scaled polynomial coefficients
    poly = [-0.0021735675012, 0.0927637193483, -1.5433080516190, 12.5465127703194, -57.1689437853537, 161.2198977486305]

    # Normalize ADC value by 64
    normalized_adc = adc_value / 64

    # Evaluate the polynomial at the normalized ADC value
    channel_value = np.polyval(poly, normalized_adc)

    return channel_value


def calculate_external_temperature(adc_value_1: int, adc_value_2: int, offset_error_1: int, offset_error_2: int):
    v_p = (4 * (adc_value_1 - offset_error_1)) / (3 * 32768)
    v_n = (4 * (adc_value_2 - offset_error_2)) / (3 * 32768)
    adc_value = 1024 * (v_n / v_p)
    external_temperature_c = adc_to_temperature(adc_value)
    return external_temperature_c


def choose_param_class_for_session_params(session_type: EnumSessionType) -> SessionRangingParams | SessionRadarParams:
    """
    Helper: Return correct param class dependent on the session_type

    Args: session_type: EnumSessionType

    Returns: SessionRangingParams | SessionRadarParams
    """
    session_type = EnumSessionType(session_type) if isinstance(session_type, int) else session_type
    match session_type:
        case EnumSessionType.RADAR_SESSION:
            return SessionRadarParams
        case EnumSessionType():  # anything (remaining) in EnumSessionType
            return SessionRangingParams
        case _:
            raise AttributeError(f"session_type: {session_type} is not supported. Choose from EnumSessionType.")


def call_from_bytes(cls, payload: List[int], session_type: EnumSessionType = None) -> object:
    """
    Dynamically calls the `from_bytes` classmethod of a class with appropriate arguments.
    Args:
        cls: The class whose `from_bytes` classmethod is being called.
        payload: The payload to be passed to `from_bytes`.
        session_type: The type to be passed if the method accepts it.
    Returns:
        An instance of the class created by `from_bytes`.
    """
    # Ensure `from_bytes` exists as a classmethod
    from_bytes = getattr(cls, "from_bytes", None)
    if not from_bytes or not inspect.ismethod(from_bytes):
        raise AttributeError(f"Class {cls.__name__} does not have a valid `from_bytes` classmethod.")
    # Inspect the method's signature
    sig = inspect.signature(from_bytes)
    params = list(sig.parameters.values())
    # Check how many arguments the method expects
    if len(params) == 1:  # `payload`
        return from_bytes(payload)
    elif len(params) == 2:  # `payload`, and `session_type`
        return from_bytes(payload, session_type)
    else:
        raise TypeError(f"`from_bytes` method of {cls.__name__} has an unexpected signature: {sig}")


###########################################################################################################
###########################################################################################################
### GID, OID Registry and interpretation ###


# GID, OID registry
def register_classes():
    """
    Register classes based on certain criteria and return a registry dictionary.

    The function searches the current module for classes that meet the following criteria:
    - The class name ends with 'Cmd' and has '_gid_' and '_oid_' attributes.
    - The class name ends with 'Ntf', has no corresponding Cmd class and has '_gid_' and '_oid_' attributes.

    For each class that meets the criteria, the suitable class is registered in the registry dictionary
    based on the class's '_gid_', '_oid_', and message type.

    Returns:
        registry (dict): A dictionary containing the registered classes, where the keys are tuples of the form
        (gid, oid, message_type) and the values are the corresponding class objects.
    """
    registry = {}
    # Searches the current module for classes with _gid_ and _oid_ attributes
    for name, obj in inspect.getmembers(sys.modules[__name__], inspect.isclass):
        # Check whether the class ends with 'Cmd' and has _gid_ and _oid_ attributes
        if name.endswith("Cmd") and hasattr(obj, "_gid_") and hasattr(obj, "_oid_"):
            base_name = name.removesuffix("Cmd")
            # Try to find and register the suitable class for each type
            for type_ in EnumUciMessageType:
                suffix = (
                    "Cmd"
                    if type_ == EnumUciMessageType.UCI_MT_COMMAND
                    else "Rsp"
                    if type_ == EnumUciMessageType.UCI_MT_RESPONSE
                    else "Ntf"
                    if type_ == EnumUciMessageType.UCI_MT_NOTIFICATION
                    else None
                )
                if suffix is not None:
                    class_name = f"{base_name}{suffix}"
                    cls = globals().get(class_name)
                    if cls:  # Only add if the class exists
                        key = (getattr(obj, "_gid_"), getattr(obj, "_oid_"), type_)
                        registry[key] = cls
        # Check whether the class ends with 'Ntf' and has _gid_ and _oid_ attributes (no Cmd class)
        elif name.endswith("Ntf") and hasattr(obj, "_gid_") and hasattr(obj, "_oid_"):
            cls = globals().get(name)
            if cls:  # Only add if the class exists
                key = (getattr(obj, "_gid_"), getattr(obj, "_oid_"), EnumUciMessageType.UCI_MT_NOTIFICATION)
                registry[key] = cls
    return registry


# Initialize the GID, OID registry
CLASS_REGISTRY = register_classes()


def get_control_message_name(input: UciMessage | List[int], uppercase: bool = True) -> str:
    """
    Returns the name of the control message based on the input UciMessage or uci packet (List[int]).

    Args:
        input (UciMessage | List[int]): The input UciMessage or uci packet (List[int]).
        uppercase (bool, optional): Specifies whether the name should be returned in uppercase. Defaults to True.

    Returns:
        str: The name of the control message.
    """
    if isinstance(input, list):
        uci_message = UciMessage.from_bytes(bytes=input)
    else:
        uci_message = input
    try:
        key = (uci_message.gid, uci_message.oid, uci_message.message_type)
    except AttributeError:
        return None
    cls = CLASS_REGISTRY.get(key)
    if cls:
        name = snake_case(cls.__name__)
        return name.upper() if uppercase else name
    else:
        return "UNKNOWN"


def interpret_mac_uci_message(uci_message: UciMessage, session_type: EnumSessionType | None = None) -> object:
    """
    Interprets a MAC UCI message and returns the corresponding object.

    Args:
        uci_message (UciMessage): The UCI message to interpret.

    Returns:
        object: The interpreted object.

    Raises:
        ValueError: If no class is found for the given GID, OID, and message type.
    """
    payload = uci_message.payload
    key = (uci_message.gid, uci_message.oid, uci_message.message_type)
    cls = CLASS_REGISTRY.get(key)
    if not cls:
        # Check if gid is a known EnumUciGid member and format gid_str accordingly
        if uci_message.gid in EnumUciGid._value2member_map_:
            gid_enum = EnumUciGid(uci_message.gid)
            gid_str = f"{gid_enum.name} ({gid_enum.value:#x})"
        else:
            gid_str = f"Unknown GID ({uci_message.gid:#x})"
        # Lookup the appropriate Enum class for oid based on gid and handle oid_str formatting
        oid_enum_class = MAC_GID_TO_OID_DICT.get(uci_message.gid)
        if oid_enum_class and uci_message.oid in [e.value for e in oid_enum_class]:
            oid_enum = oid_enum_class(uci_message.oid)
            oid_str = f"{oid_enum.name} ({oid_enum.value:#x})"
        else:
            oid_str = f"Unknown OID ({uci_message.oid:#x})"
        raise ValueError(f"No class found for {gid_str} and {oid_str} and Type {uci_message.message_type.name}")
    return call_from_bytes(cls, payload, session_type)


MAC_GID_TO_OID_DICT = {
    EnumUciGid.GID_UCI_CORE: EnumOidCore,
    EnumUciGid.GID_UWB_SESSION_CONFIG: EnumMacOidSessionConfig,
    EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL: EnumMacOidRangingSession,
    EnumUciGid.GID_PROPRIETARY: EnumMacOidProprietary,
}
