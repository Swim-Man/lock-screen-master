#    Copyright 2022 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

### Logging ###
import logging
import sys
import textwrap
from enum import Enum, IntEnum

import numpy as np

name = list(filter(lambda x: x.startswith("nxp_main"), sys.path))
try:
    logger = logging.getLogger(name[0])
except IndexError:
    logger = logging.getLogger()

# Speed of light (in vacuum) = 299792458 m/s
# Refractive index of air = 1.0003
# Speed of light (in air) = 299792458 / 1.0003 = 299702547 m/s
SPEED_OF_LIGHT_METERS_PER_SEC = 299702547

BB_TICKS_TO_SEC_CONVERSION_FACTOR = 15.65 * 1e-12  # one bb tick is equal to 15.65 ps
BB_TICKS_TO_PICOSEC_CONVERSION_FACTOR = 15.65  # one bb tick is equal to 15.65 ps


class EnumUwbChannelFrequency(IntEnum):
    ch5 = 6489600
    ch6 = 6988800
    # ch7 center frequency is same as ch5 but with a wider bandwidth (1081.6 MHz)
    ch8 = 7488000
    ch9 = 7987200
    # ch10 = 8486400 # not supported
    # ch11 center frequency is same as ch9 but with a wider bandwidth (1331.2 MHz)  # not supported
    # ch12 = 8985600 # not supported
    # ch13 = 9484800 # not supported
    # ch14 = 9984000 # not supported
    # ch15 center frequency is same as ch13 but with a wider bandwidth (1354.97 MHz)  # not supported


class EnumAoaCalculationMethod(Enum):
    AOA_CALC_ARCSIN = 0
    AOA_CALC_ARCSIN_POLY = 1
    AOA_CALC_ARCSIN_LUT = 2
    AOA_CALC_ARCCOS = 3
    AOA_CALC_ARCTAN = 4
    AOA_CALC_ARCTAN2 = 5


def calculate_tof_ticks_twrds(trnd1: int, trsp1: int, trnd2: int, trsp2: int, group_delay_ticks: int = 0):
    tof_ticks = ((trnd1 * trnd2) - (trsp1 * trsp2)) / (trnd1 + trsp1 + trnd2 + trsp2)
    tof_ticks -= group_delay_ticks
    return int(tof_ticks)


def convert_tof_ticks_to_sec(tof_ticks: int):
    tof_sec = tof_ticks * BB_TICKS_TO_SEC_CONVERSION_FACTOR
    return tof_sec


def convert_ticks_to_distance(ticks: int):
    distance_meter = ticks * BB_TICKS_TO_SEC_CONVERSION_FACTOR * SPEED_OF_LIGHT_METERS_PER_SEC
    return distance_meter


def convert_tof_to_distance(tof_sec: float):
    distance_meter = tof_sec * SPEED_OF_LIGHT_METERS_PER_SEC
    return distance_meter


def convert_dc_cutoff_freq_to_dc_coeff(dc_cutoff_freq_hz: float, frame_interval_ns: int) -> int:
    dc_coefficient = 2 * np.pi * dc_cutoff_freq_hz * (frame_interval_ns * 1e-9) * (2**15)
    return int(dc_coefficient)


class ArcSinLookupTable:
    def __init__(self, arcSinLutResolution: int = 128, logger: logging.Logger = None):  # FIXME: remove logger from argument - not needed
        def log_data():
            if logger is not None:
                logger.debug(
                    f"index = {int(trig_input_rad_clipped * self.arcSinLutResolution): 8},\
 trig_input_fxp = {trig_input_fxp:8}, trig_input_rad: {trig_input_rad:+7.7f}, trig_input_rad_clipped = {trig_input_rad_clipped:+7.7f},\
 aoa_rad = {aoa_rad:+7.7f}, aoa_deg = {aoa_deg:+7.7f}, aoa_deg_fxp = {aoa_deg_fxp:8}"
                )

        def log_c_style_array(itemSizeBytes):
            if logger is not None:
                if itemSizeBytes == 1:
                    type_str = "int8_t"
                elif itemSizeBytes == 2:
                    type_str = "int16_t"
                elif itemSizeBytes == 4:
                    type_str = "int32_t"
                else:
                    type_str = "int64_t"

                logger.debug(
                    f"""
C-style lookup table to get the arcsin value from input range [-1 .. 1].
Since the arcsin function is symmetrical around 0, only the positive part of the arcsin curve is required for the lookup table for input range [0 .. 1], to save memory on embedded devices (e.g. NCJ29D6).
This means index 0 is equivalent to arcsin input 0, and index {len(self.arcSinDegLut) - 1} is equivalent to arcsin max. input 1 and also min. input -1.
For negative input range [-1 .. 0[, the absolute positive value of input shall be used for accessing the LUT, then the output shall be negated.
This means for an input of -1, index arcSinToDegLut[{len(self.arcSinDegLut) - 1}] can be used which contains {self.arcSinDegLut[len(self.arcSinDegLut) - 1]},
then the actual value shall be negated to become -{self.arcSinDegLut[len(self.arcSinDegLut) - 1]}.
\nThe output arcsin value is in resolution is {self.arcSinLutResolution} for this lookup table.
Some examples:
arcSinToDegLut[0] = arcsin(0.0) = {self.arcSinDegLut[0]} / {self.arcSinLutResolution} = {self.arcSinDegLut[0] / self.arcSinLutResolution} degrees
arcSinToDegLut[{int(len(self.arcSinDegLut)/3)}] = arcsin(0.34)  = +/-{self.arcSinDegLut[int(len(self.arcSinDegLut)/3)]} / {self.arcSinLutResolution} = +/-{self.arcSinDegLut[int(len(self.arcSinDegLut)/3)] / self.arcSinLutResolution} degrees
arcSinToDegLut[{int(len(self.arcSinDegLut)/2)}] = arcsin(0.5)  = +/-{self.arcSinDegLut[int(len(self.arcSinDegLut)/2)]} / {self.arcSinLutResolution} = +/-{self.arcSinDegLut[int(len(self.arcSinDegLut)/2)] / self.arcSinLutResolution} degrees
arcSinToDegLut[{len(self.arcSinDegLut) - 1}] = arcsin(1.0)  = +/-{self.arcSinDegLut[-1]} / {self.arcSinLutResolution} = +/-{self.arcSinDegLut[-1] / self.arcSinLutResolution} degrees
"""
                )
                logger.debug(
                    f"Total size of lookup table = {self.lutSizeBytes} bytes ({len(self.arcSinDegLut)} entries * {self.lutItemSizeBytes} byte(s) per entry)"
                )
                logger.debug(f"For more usage examples, please refer to {pdoa_to_aoa.__name__} function.\n\n")

                c_style_lut_string = f"static {type_str} arcSinToDegLut[{len(self.arcSinDegLut)}u] = {{{str(self.arcSinDegLut)[1:-1]}}};"
                logger.debug(textwrap.fill(c_style_lut_string, width=80))

        def calculate_array_size_bytes(data):
            if min(data) >= -128 and max(data) <= 127:
                # int8_t (1 byte per item)
                return len(data) * 1, 1
            elif min(data) >= -32768 and max(data) <= 32767:
                # int16_t (2 bytes per item)
                return len(data) * 2, 2
            elif min(data) >= -2_147_483_648 and max(data) <= 2_147_483_647:
                # int32_t (4 bytes per item)
                return len(data) * 4, 4
            else:
                # int64_t (8 bytes per item)
                return len(data) * 8, 8

        if arcSinLutResolution <= 0:
            raise ValueError(f"arcsin lookup table cannot have a resolution of {arcSinLutResolution}")

        if logger is not None:
            logger.debug("Lookup table for arcsin function for PDoA/AoA measurement")

        self.arcSinLutResolution = arcSinLutResolution
        self.arcSinDegLut = []
        self.lutSizeBytes = 0
        self.lutItemSizeBytes = 0
        for trig_input_fxp in np.arange(int((0.0) * arcSinLutResolution), int(int((1.0) * arcSinLutResolution) + 1), 1):
            trig_input_rad = float(trig_input_fxp / arcSinLutResolution)
            trig_input_rad_clipped = np.clip(trig_input_rad, a_min=-1.00, a_max=1.00)

            aoa_rad = np.arcsin(trig_input_rad_clipped)
            aoa_deg = np.rad2deg(aoa_rad)
            aoa_deg_fxp = int(aoa_deg * arcSinLutResolution)

            self.arcSinDegLut.append(aoa_deg_fxp)
            log_data()

        self.lutSizeBytes, self.lutItemSizeBytes = calculate_array_size_bytes(self.arcSinDegLut)
        log_c_style_array(self.lutItemSizeBytes)


def pdoa_to_aoa(
    pdoa_bb_result: int,
    frequency_khz: int,
    distance_between_antennas_mm: int = 18,
    aoa_method: EnumAoaCalculationMethod = EnumAoaCalculationMethod.AOA_CALC_ARCSIN,
    lut: ArcSinLookupTable = None,
) -> float:
    """
    Converts the input Phase Difference of Arrival (PDoA) in degrees between the two receiving antennas to
    an Angle of Arrival (AoA) in degrees, based on theory presented in AN13943 PDoA measurements:

    AoA in degrees α = arcsin((λ * Δϕ)/(L * 2 * pi ))

    where,
    Δϕ is the input PDoA value in degrees
    λ is the wavelength of the signal in meters = c / f, which is frequency dependent,
        where
        c is the signal propagation speed in m/s (e.g. speed of light)
        and
        f is the frequency of the signal in Hz
    L is the distance between the two receiving antennas in meters. Note that this design value should not be larger than half of the wavelength λ.

    Notes
    ------
    Since pdoa_deg is in degrees, 2*pi is used as 360 degrees.

    Parameters
    ----------
    pdoa_bb_result : PDoA value in degrees (Δϕ).
        Range is [-23040 .. 23040] (equivalent to [-180.0 .. 180.0] where pdoa_deg = pdoa_bb_result / 128)
        This value is expected to be acquired from baseband.
    frequency_khz : UWB center frequency in kHz (f / 1000)
    distance_between_antennas_mm (L * 1000): Physical distance between the two receiving antennas in millimeters.
    aoa_method : AoA calculation method. AoA calculation can be performed with various trigonometric functions (e.g. arcsin, arccos, arctan or arctan2).
        The methods provide guidance when implementing AoA calculation on other platforms that might not implement the default trigonometric function.
        Default is arcsin function as demonstrated in AN13943 PDoA measurements.
    lut : the lookup table to use in case aoa_method is AOA_CALC_ARCSIN_LUT. Create a lookup table with desired resolution using @ref ArcSinLookupTable.

    Returns
    ------
    AoA in degrees (in float format). Range is [-90 .. 90]

    Raises
    ------
    ValueError : if case aoa_method is AOA_CALC_ARCSIN_LUT but no lookup table is provided (lut is None),
    or if an unknown aoa_method is requested.

    """
    # Calculate the input to the arcsin function.
    # Since pdoa_deg input is multiplied by 128 (input range [-23040 .. 23040]), a division by 128 is added to the formula to get the real PDoA in degrees.
    # No need to change frequency_khz and distance_between_antennas_mm to Hz and m respectively since they cancel each other out.
    input = (SPEED_OF_LIGHT_METERS_PER_SEC * pdoa_bb_result) / (frequency_khz * distance_between_antennas_mm * 360 * 128)

    # The inverse trigonometric function domain shall be limited to [-1 .. 1]
    input_clipped = np.clip(input, a_min=-1, a_max=1)

    match aoa_method:
        case EnumAoaCalculationMethod.AOA_CALC_ARCSIN:
            aoa_rad = np.arcsin(input_clipped)
            # convert aoa from radians to degrees
            aoa_deg = np.rad2deg(aoa_rad)

        case EnumAoaCalculationMethod.AOA_CALC_ARCSIN_POLY:
            # arcsin function can be approximated by a Taylor series. The polynomial can be extended to higher orders,
            # but the 3rd order implemented here already has extremely precise results.
            a0 = 1.5707288
            a1 = -0.2121144
            a2 = 0.0742610
            a3 = -0.0187293
            input_clipped = abs(input_clipped)
            aoa_rad = np.pi / 2 - ((np.sqrt(1 - input_clipped)) * (a0 + (a1 * input_clipped) + (a2 * input_clipped**2) + (a3 * input_clipped**3)))
            aoa_rad = aoa_rad * np.sign(input)
            # convert aoa from radians to degrees
            aoa_deg = np.rad2deg(aoa_rad)

        case EnumAoaCalculationMethod.AOA_CALC_ARCSIN_LUT:
            if lut is None:
                raise ValueError("Invalid look up table")
            # set input_clipped to its positive value if it is negative to access the lookup table value
            if input_clipped < 0:
                input_clipped = -input_clipped

            # get the fixed point aoa_deg from the LUT and divide it by the LUT resolution to get the real AoA in degrees.
            aoa_deg = lut.arcSinDegLut[int(input_clipped * lut.arcSinLutResolution)] / lut.arcSinLutResolution

            # set aoa_deg to negative if input pdoa_deg (and inherently input_clipped) is negative
            if pdoa_bb_result < 0:
                aoa_deg = -aoa_deg

        case EnumAoaCalculationMethod.AOA_CALC_ARCCOS:
            # for arccos method, the result is shifted by pi/2 (90 degrees)
            aoa_rad = (np.pi / 2) - np.arccos(input_clipped)
            # convert aoa from radians to degrees
            aoa_deg = np.rad2deg(aoa_rad)

        case EnumAoaCalculationMethod.AOA_CALC_ARCTAN:
            # arcsin can be represented by arctan method as follows:
            # arcsin α = 2 * arctan(theta / 1 + sqrt(1 - theta^2) )
            aoa_rad = 2 * np.arctan(input_clipped / (1 + np.sqrt(1 - input_clipped**2)))
            # convert aoa from radians to degrees
            aoa_deg = np.rad2deg(aoa_rad)

        case EnumAoaCalculationMethod.AOA_CALC_ARCTAN2:
            # arctan2 method is same as arctan, with the additional quadrant information.
            arctan_input = input_clipped / (1 + np.sqrt(1 - input_clipped**2))
            aoa_rad = 2 * np.arctan2(arctan_input, 1)
            # convert aoa from radians to degrees
            aoa_deg = np.rad2deg(aoa_rad)

        case _:
            raise ValueError("Unknown AoA calculation method!")

    return aoa_deg
