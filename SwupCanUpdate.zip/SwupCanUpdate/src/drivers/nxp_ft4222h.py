#    Copyright 2022 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import sys
import time
from enum import IntEnum

import ft4222

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import nxp_crc
from utilities.nxp_decorators import frozen


class EnumFtdiStatus(IntEnum):
    FTDI_STATUS_UNDEF = 0
    FTDI_STATUS_OK = 1
    FTDI_STATUS_RECEIVED_PENDING_MSG = 2
    FTDI_STATUS_ERR_GENERAL = 3
    FTDI_STATUS_ERR_TIMEOUT = 4
    FTDI_STATUS_ERR_BAD_PARAM = 5


class EnumFtdiGpio(IntEnum):
    FTDI_GPIO_RDY_N = 0
    FTDI_GPIO_INT_N = 1
    FTDI_GPIO_RST_N = 2


class EnumFtdiSpiMode(IntEnum):
    FTDI_SPI_MODE_SINGLE = 0
    FTDI_SPI_MODE_QUAD = 1


class Ft4222hDeviceManager:
    # gets the unique locations of connected ft4222 devices
    def get_device_locations():
        device_locations = []
        # by default, NCJ29D6 demoboard configures FT4222 chip to mode 0 (DCNF0 pin == 0 (GND) and DCNF1 pin == 0 (GND))
        # this mode emulates each NCJ29D6 demoboard as two separate devices (interfaces) in windows device manager:
        #  the first device 'FT4222 A' provides access to the 4 SPI master pins (SS0O, SCK, MOSI, MISO)
        #  the second device 'FT4222 B' provides access to the 4 GPIO pins (GPIO0,1,2,3)
        # only the location and index are unique for every interface
        number_of_devices = ft4222.createDeviceInfoList()
        for i in range(number_of_devices):
            # get current devices' information
            device_info = ft4222.getDeviceInfoDetail(i, False)
            # here, the function filters FTDI devices for ID 67330076 to only provide FT4222 FTDI IC's,
            # then only the SPI interface (FT4222 A) is returned to the caller
            if device_info["id"] == 67330076 and (device_info["serial"] == b"A" or device_info["description"] == b"FT4222 A"):
                device_locations.append(device_info["location"])
        return device_locations


@frozen
class Ft4222hDevice:
    ftdi_spi_interface = object
    ftdi_gpio_interface = object
    device_index = b""
    device_location = 0

    def __init__(self, index, device_location) -> None:
        self.device_index = index
        self.device_location = device_location

    # opens the initialized device based on input parameters and the pre-initialized device_location
    def open(self, spi_frequency_hz=1e07, mode=EnumFtdiSpiMode.FTDI_SPI_MODE_SINGLE):
        self.ftdi_spi_interface = ft4222.openByLocation(self.device_location)
        self.ftdi_gpio_interface = ft4222.openByLocation(self.device_location + 1)
        # initialize SPI interface as SPI host
        clock, divider = self.get_spi_clock_divider(requested_spi_frequency_hz=spi_frequency_hz)
        self.ftdi_spi_interface.setClock(clock)
        self.ftdi_spi_interface.spiMaster_Init(
            mode=ft4222.SPIMaster.Mode.SINGLE, clock=divider, cpol=ft4222.Cpol.IDLE_HIGH, cpha=ft4222.Cpha.CLK_LEADING, ssoMap=ft4222.SlaveSelect.SS0
        )
        self.ftdi_spi_interface.spi_SetDrivingStrength(
            clkStrength=ft4222.DrivingStrength.DS4MA, ioStrength=ft4222.DrivingStrength.DS4MA, ssoStrength=ft4222.DrivingStrength.DS4MA
        )
        self.ftdi_spi_interface.setTimeouts(100, 100)
        # initialize RST_N as GPIO0 output, RDY_N as GPIO1 input, CS_N as GPIO2 output, INT_N as GPIO3 input
        self.ftdi_gpio_interface.gpio_Init(
            gpio0=ft4222.GPIO.Dir.OUTPUT, gpio1=ft4222.GPIO.Dir.INPUT, gpio2=ft4222.GPIO.Dir.OUTPUT, gpio3=ft4222.GPIO.Dir.INPUT
        )
        # disable suspend out to enable GPIO2
        self.ftdi_gpio_interface.setSuspendOut(False)
        # disable wakeup interrupt to enable GPIO3
        self.ftdi_gpio_interface.setWakeUpInterrupt(False)
        # set CS_N and RST_N to high
        self.set_cs_n(True)
        self.set_rst_n(True)
        # reset the SPI interface
        self.ftdi_spi_interface.spi_Reset()
        return self

    def close(self) -> None:
        self.ftdi_spi_interface.close()
        self.ftdi_gpio_interface.close()

    # returns a tuple of both devicelist of 2 members
    def get_device_info(self):
        return (ft4222.getDeviceInfoDetail(self.device_index, False), ft4222.getDeviceInfoDetail(self.device_index + 1, False))

    # TODO: implement custom SPI frequency.
    # currently, a clock of 80MHz (SysClock.CLK_80) divided by 8 (Clock.DIV_8) ~= 10 MHz SPI clock
    def get_spi_clock_divider(self, requested_spi_frequency_hz):
        return ft4222.SysClock.CLK_80, ft4222.Clock.DIV_8

    def set_rst_n(self, gpio_level: bool) -> None:
        self.ftdi_gpio_interface.gpio_Write(ft4222.Port.P0, value=gpio_level)

    def get_rdy_n(self) -> bool:
        return bool(self.ftdi_gpio_interface.gpio_Read(ft4222.Port.P1))

    def get_int_n(self) -> bool:
        return bool(self.ftdi_gpio_interface.gpio_Read(ft4222.Port.P3))

    def set_cs_n(self, gpio_level: bool) -> None:
        self.ftdi_gpio_interface.gpio_Write(ft4222.Port.P2, value=gpio_level)

    def hard_reset(self) -> None:
        # put RST_N to low
        self.set_rst_n(False)
        # wait 10ms
        time.sleep(0.01)
        # set RST_N to high (release device)
        self.set_rst_n(True)

    def wait_for_gpio(self, pin: EnumFtdiGpio, gpio_level: bool, timeout_ms=0):
        if pin == EnumFtdiGpio.FTDI_GPIO_RDY_N:
            poll_function = self.get_rdy_n
        elif pin == EnumFtdiGpio.FTDI_GPIO_INT_N:
            poll_function = self.get_int_n
        else:
            return EnumFtdiStatus.FTDI_STATUS_ERR_BAD_PARAM

        current_gpio_level = poll_function()
        start = time.perf_counter()
        timeout_sec = timeout_ms / 1000
        while True:
            if timeout_ms != 0:
                delta = start + timeout_sec - time.perf_counter()
                if delta <= 0:
                    return EnumFtdiStatus.FTDI_STATUS_ERR_TIMEOUT

            current_gpio_level = poll_function()
            if current_gpio_level == gpio_level:
                return EnumFtdiStatus.FTDI_STATUS_OK

    def transmit_uci_command(self, input_command, append_crc=True, timeout_ms=20) -> list[EnumFtdiStatus | list[int] | bool]:
        command = list(input_command)
        target_miso_bytes = []
        status = EnumFtdiStatus.FTDI_STATUS_UNDEF
        is_crc_valid = False

        if command is None or len(command) < 4:
            status = EnumFtdiStatus.FTDI_STATUS_ERR_BAD_PARAM
            return [status, list(target_miso_bytes), is_crc_valid]

        # append CRC16 if required. If append_crc is false, the user is expected to include the crc bytes in the input command
        if append_crc is True:
            crc = nxp_crc.calculate_crc(frame=command)
            command += crc.to_bytes(length=2, byteorder="little", signed=False)

        for _ in range(50):
            # put CS_N to low to start transmission
            self.set_cs_n(False)
            # wait for RDY_N to go low
            status = self.wait_for_gpio(EnumFtdiGpio.FTDI_GPIO_RDY_N, False, timeout_ms)
            if status == EnumFtdiStatus.FTDI_STATUS_ERR_TIMEOUT:
                # put CS_N to high to stop transmission and retry
                self.set_cs_n(True)
                self.set_rst_n(gpio_level=True)
            else:
                break

        if status is not EnumFtdiStatus.FTDI_STATUS_OK:
            # put CS_N to high to stop transmission
            self.set_cs_n(True)
            self.set_rst_n(gpio_level=True)
            return [status, list(target_miso_bytes), is_crc_valid]
        # clock out the data to the device over SPI (SCLK + MOSI lines)
        # target_miso_bytes is the data returned by the device over MISO line during command transmission
        target_miso_bytes = self.ftdi_spi_interface.spiMaster_SingleReadWrite(data=bytes(command), isEndTransaction=True)
        # put CS_N to high to stop transmission
        self.set_cs_n(True)
        self.set_rst_n(gpio_level=True)
        status = EnumFtdiStatus.FTDI_STATUS_OK
        return [status, list(target_miso_bytes), is_crc_valid]

    def receive_uci_message(self, timeout_ms=500, crc_enable=True) -> list[EnumFtdiStatus | list[int] | bool]:
        uci_frame = []
        is_crc_valid = False
        status = EnumFtdiStatus.FTDI_STATUS_UNDEF
        # wait for INT_N to go low
        status = self.wait_for_gpio(EnumFtdiGpio.FTDI_GPIO_INT_N, False, timeout_ms)
        if status is not EnumFtdiStatus.FTDI_STATUS_OK:
            # put CS_N to high to stop transmission
            self.set_cs_n(gpio_level=True)
            self.set_rst_n(gpio_level=True)
            return [status, list(uci_frame), is_crc_valid]
        # put CS_N to low to start transmission
        self.set_cs_n(gpio_level=False)
        # first get the uci header (host clocks out 4 zeroes over SPI (SCLK + MOSI lines))
        header = self.ftdi_spi_interface.spiMaster_SingleReadWrite(data=bytes([0x00] * 4), isEndTransaction=False)
        if header is None or len(header) < 4:
            # put CS_N to high to stop transmission
            self.set_cs_n(gpio_level=True)
            self.set_rst_n(gpio_level=True)
            status = EnumFtdiStatus.FTDI_STATUS_ERR_GENERAL
            return [status, list(uci_frame), is_crc_valid]
        # identify payload length to receive (two bytes)
        payload_length = header[3] + (header[2] << 8)

        # increase payload length by 2 for the CRC-16 if enabled
        if crc_enable is True:
            payload_length += 2

        # only get rest of payload if payload_length is larger than 0 (regardless if it is CRC or actual payload)
        payload: bytes = b""
        if payload_length > 0:
            payload = self.ftdi_spi_interface.spiMaster_SingleReadWrite(data=bytes([0x00] * payload_length), isEndTransaction=True)

        # wait for INT_N to go high
        status = self.wait_for_gpio(EnumFtdiGpio.FTDI_GPIO_INT_N, True, timeout_ms)
        if status is not EnumFtdiStatus.FTDI_STATUS_OK:
            # put CS_N to high to stop transmission
            self.set_cs_n(gpio_level=True)
            self.set_rst_n(gpio_level=True)
            return [status, list(uci_frame), is_crc_valid]
        # put CS_N to high to stop transmission
        self.set_cs_n(gpio_level=True)
        # assemble the UCI frame
        if payload_length > 0 and payload is None:
            self.set_rst_n(gpio_level=True)
            status = EnumFtdiStatus.FTDI_STATUS_ERR_GENERAL
            return [status, list(uci_frame), is_crc_valid]
        uci_frame = header + payload
        received_crc = uci_frame[-2] | (uci_frame[-1] << 8)
        # validate the CRC16
        is_crc_valid = nxp_crc.is_crc_valid(uci_frame[:-2], received_crc) if crc_enable is True else True
        status = EnumFtdiStatus.FTDI_STATUS_OK
        self.set_rst_n(gpio_level=True)
        return [status, list(uci_frame), is_crc_valid]
