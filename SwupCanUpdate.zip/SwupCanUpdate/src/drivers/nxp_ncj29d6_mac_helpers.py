#    Copyright 2024 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import logging
import sys
import time
from dataclasses import fields, is_dataclass
from enum import IntEnum
from typing import Any, List

from tabulate import tabulate

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import drivers.nxp_ncj29d6_mac_config as mac_config

import utilities.nxp_console_helpers as console

import drivers.nxp_ncj29d6_mac as Ncj29d6Mac
from drivers.nxp_uci import EnumUciStatus, UciMessage

name = list(filter(lambda x: x.startswith("nxp_main"), sys.path))
try:
    logger = logging.getLogger(name[0])
except IndexError:
    logger = logging.getLogger()


###########################################

EXPECTED_MAC_AIO_RELEASE_VERSION_STR = "4.1.0"

EXPECTED_MAC_AIO_GET_DEVICE_INFO_RSP = Ncj29d6Mac.GetDeviceInfoRsp(
    status=EnumUciStatus.UCI_STATUS_OK,
    uci_generic_version=Ncj29d6Mac.SimpleVersion2(
        major=2,
        minor=0,
        maintenance=0,
        ),
    fira_mac_version=Ncj29d6Mac.SimpleVersion2(
        major=2,
        minor=0,
        maintenance=0,
        ),
    fira_phy_version=Ncj29d6Mac.SimpleVersion2(
        major=2,
        minor=0,
        maintenance=0,
        ),
    fira_uci_test_version=Ncj29d6Mac.SimpleVersion2(
        major=0,
        minor=0,
        maintenance=0,
        ),
    vendor_specific_information_length=0xDA,
    vendor_specific_information=Ncj29d6Mac.VendorSpecificInformation(
        ccc_version="1.2.3",
        device_name="RANGER5",
        firmware_version= Ncj29d6Mac.Version(
            major=10,
            minor=1,
            patch=1,
            version_id= 0),
        foundation_package_version= Ncj29d6Mac.Version(
            major=20,
            minor=0,
            patch=0,
            version_id= 0),
        mac_version= Ncj29d6Mac.Version(
            major=10,
            minor=1,
            patch=1,
            version_id= 0),
        swup_core_version= Ncj29d6Mac.Version(
            major=3,
            minor=1,
            patch=1,
            version_id= 0),
        baseband_version= Ncj29d6Mac.Version(
            major=14,
            minor=0,
            patch=0,
            version_id= 0),
        dsp_version=Ncj29d6Mac.Version(
            major=14,
            minor=1,
            patch=1,
            version_id= 0),
        sbe_api_ext_version=Ncj29d6Mac.Version(
            major=12,
            minor=2,
            patch=4,
            version_id= 0),
        rom_version=Ncj29d6Mac.Version(
            major=4,
            minor=0,
            patch=0,
            version_id= 0),
        hardware_version=Ncj29d6Mac.HardwareVersion(
            reserve_bit=0x00,
            jep106_id=0x2B,
            jep106_cont_code=0x00,
            part_number=0x00,
            revision=0x00),
        variant_information=[0x01, 0x00, 0x00, 0x00],
        serial_number=[],
        wafer_data=[],
        ncj29d6_uwbmac_uci_version=Ncj29d6Mac.Version(
            major=2,
            minor=4,
            patch=0,
            version_id= 0),
    ),
)  # fmt: skip

EXPECTED_MAC_CCC_GET_DEVICE_INFO_RSP = Ncj29d6Mac.GetDeviceInfoRsp(
    status=EnumUciStatus.UCI_STATUS_OK,
    uci_generic_version=Ncj29d6Mac.SimpleVersion2(
        major=1,
        minor=1,
        ),
    fira_mac_version=Ncj29d6Mac.SimpleVersion2(
        major=0,
        minor=0,
        ),
    fira_phy_version=Ncj29d6Mac.SimpleVersion2(
        major=0,
        minor=0,
        ),
    fira_uci_test_version=Ncj29d6Mac.SimpleVersion2(
        major=0,
        minor=0,
        ),
    vendor_specific_information_length=0xDA,
    vendor_specific_information=Ncj29d6Mac.VendorSpecificInformation(
        ccc_version="1.2.2",
        device_name="RANGER5",
        firmware_version= Ncj29d6Mac.Version(
            major=5,
            minor=0,
            patch=0,
            version_id= 0),
        foundation_package_version= Ncj29d6Mac.Version(
            major=20,
            minor=0,
            patch=0,
            version_id= 0),
        mac_version= Ncj29d6Mac.Version(
            major=5,
            minor=2,
            patch=0,
            version_id= 0),
        swup_core_version= Ncj29d6Mac.Version(
            major=3,
            minor=1,
            patch=1,
            version_id= 0),
        baseband_version= Ncj29d6Mac.Version(
            major=14,
            minor=0,
            patch=0,
            version_id= 0),
        dsp_version=Ncj29d6Mac.Version(
            major=14,
            minor=1,
            patch=1,
            version_id= 0),
        sbe_api_ext_version=Ncj29d6Mac.Version(
            major=12,
            minor=2,
            patch=4,
            version_id= 0),
        rom_version=Ncj29d6Mac.Version(
            major=4,
            minor=0,
            patch=0,
            version_id= 0),
        hardware_version=Ncj29d6Mac.HardwareVersion(
            reserve_bit=0x00,
            jep106_id=0x2B,
            jep106_cont_code=0x00,
            part_number=0x00,
            revision=0x00),
        variant_information=[0x01, 0x00, 0x00, 0x00],
        serial_number=[],
        wafer_data=[],
        ncj29d6_uwbmac_uci_version=Ncj29d6Mac.Version(
            major=1,
            minor=8,
            patch=0,
            version_id= 0),
    ),
)  # fmt: skip

IGNORED_FIELDS = ["hardware_version", "variant_information", "serial_number", "wafer_data"]


def check_mac_fw_version(
    received_get_device_info_rsp: Ncj29d6Mac.GetDeviceInfoRsp, device_name: str = "device", abort_on_incompatible_version: bool = False
) -> bool:
    """
    Checks compatibility of device FW version against the EXPECTED_MAC_FW_VERSION of the current release. Results will be logged (printed if no expected logger found)
    Version ID, hardware_version, variant_information, serial_number, wafer_data, device_test_data are not checked.
    Arguments:
        received_get_device_info_rsp: instance of GetDeviceInfoRsp (from response).
        device_name: custom device name used only for logging. Optional parameter (by default "device").
        abort_on_incompatible_version: raises SystemExit exception and exits the program if set to True and unexpected versions are detected
                                       Optional parameter (default False)
    Returns:
        True:   in case all major/minor/patch versions of all detected_fw_version members except hardware_version, variant_information,
                serial_number, wafer_data, device_test_data are matching with EXPECTED_GET_DEVICE_INFO_RSP
        False:  in case at at least one of major/minor/patch versions is not as expected
    Raises:
        SystemExit: in case of incompatible versions and abort_on_incompatible_version is True
    """
    differences = []

    def get_differences(expected_instance: Any, received_instance: Any, path: str = ""):
        if isinstance(expected_instance, (Ncj29d6Mac.SimpleVersion, Ncj29d6Mac.SimpleVersion2, Ncj29d6Mac.SimpleVersionReversed, Ncj29d6Mac.Version)):
            if hasattr(expected_instance, "_comparison_str"):
                if expected_instance._comparison_str() != received_instance._comparison_str():
                    differences.append([path.split(".")[-1], expected_instance._comparison_str(), received_instance._comparison_str()])
            elif str(expected_instance) != str(received_instance):
                differences.append([path.split(".")[-1], expected_instance, received_instance])
        elif is_dataclass(expected_instance) and is_dataclass(received_instance):
            for field in fields(expected_instance):
                if field.name in IGNORED_FIELDS:
                    continue  # Skip the comparison for ignored fields
                new_path = f"{path}.{field.name}" if path else field.name
                new_expected_instance = getattr(expected_instance, field.name)
                new_received_instance = getattr(received_instance, field.name)
                get_differences(new_expected_instance, new_received_instance, new_path)
        elif isinstance(expected_instance, IntEnum) and isinstance(received_instance, IntEnum):
            if expected_instance != received_instance:
                differences.append([path.split(".")[-1], expected_instance.name, received_instance.name])
        elif expected_instance != received_instance:
            differences.append([path.split(".")[-1], expected_instance, received_instance])

    if mac_config.MAC_FW_TYPE == "CCC":
        get_differences(EXPECTED_MAC_CCC_GET_DEVICE_INFO_RSP, received_get_device_info_rsp)
    elif mac_config.MAC_FW_TYPE == "AiO":
        get_differences(EXPECTED_MAC_AIO_GET_DEVICE_INFO_RSP, received_get_device_info_rsp)
    else:
        raise RuntimeError(
            "mac_config.MAC_FW_TYPE is neither AiO, nor CCC. Make sure to set mac_config.MAC_FW_TYPE via 'set_mac_config.MAC_FW_TYPE' to an expected value."
        )


    if differences and logger.name.startswith("nxp_main"):
        logger.error(f"Incompatible firmware version found on {device_name}!")
        logger.newline()
        logger.w_info(tabulate(differences, headers=["Field", "Expected", "Detected"], tablefmt="pretty"))
        time.sleep(1)  # improves readability
        if abort_on_incompatible_version:
            raise SystemExit("Program aborted due to incompatible firmware version!")
        return False

    elif differences:
        console.print(f"\nWARNING: incompatible firmware version found on {device_name}!", color=console.StrColor.RED)
        console.print(tabulate(differences, headers=["Field", "Expected", "Detected"], tablefmt="pretty"), color=console.StrColor.MAGENTA)
        time.sleep(1)  # improves readability
        if abort_on_incompatible_version:
            raise SystemExit(f"{console.StrColor.RED}Program aborted due to incompatible firmware version!{console.StrColor.RESET}")
        return False

    elif logger.name.startswith("nxp_main"):
        logger.newline()
        logger.ok(f"Firmware version of {device_name} is compatible with the current release.")
        logger.newline()
        return True
    else:
        console.print(f"\nINFO: Firmware version of {device_name} is compatible with the current release.\n", color=console.StrColor.GREEN)
        return True


def log_mac_uci_message(
    uci_message: UciMessage,
    device_name: str,
    is_successful: bool = True,
    interpret: bool = True,
    session_type: Ncj29d6Mac.EnumSessionType | None = None,
):
    logger.debug(f"RECEIVE {Ncj29d6Mac.get_control_message_name(uci_message)} from {device_name}:") if is_successful else logger.error(
        f"ERROR while receiving {Ncj29d6Mac.get_control_message_name(uci_message)} from {device_name}"
        if Ncj29d6Mac.get_control_message_name(uci_message) is not None
        else f"ERROR while receiving UCI message from {device_name}"
    )
    if uci_message is not None:
        if len(uci_message.uci_packets) == 1:
            logger.debug(console.as_hex(uci_message.uci_packets[0]))
        else:
            logger.debug(console.as_hex(uci_message.uci_packets))
        if interpret:
            logger.debug(f"{Ncj29d6Mac.interpret_mac_uci_message(uci_message=uci_message, session_type=session_type)}")
            logger.newline()


def log_mac_cmd(command: List[int], device_name: str):
    logger.debug(f"SEND {Ncj29d6Mac.get_control_message_name(command)} to {device_name}: {console.as_hex(command)}")
    logger.newline()
