#    Copyright 2022 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import sys
from enum import IntEnum

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import drivers.nxp_crc as nxp_crc
from utilities.nxp_decorators import frozen


### UCI ###############################################################
class EnumUciStatus(IntEnum):
    # generic status codes
    UCI_STATUS_OK = 0x00
    UCI_STATUS_REJECTED = 0x01
    UCI_STATUS_FAILED = 0x02
    UCI_STATUS_SYNTAX_ERROR = 0x03
    UCI_STATUS_INVALID_PARAM = 0x04
    UCI_STATUS_INVALID_RANGE = 0x05
    UCI_STATUS_INVALID_MESSAGE_SIZE = 0x06
    UCI_STATUS_UNKNOWN_GID = 0x07
    UCI_STATUS_UNKNOWN_OID = 0x08
    UCI_STATUS_READ_ONLY = 0x09
    UCI_STATUS_COMMAND_RETRY = 0x0A
    UCI_STATUS_UNKNOWN = 0x0B
    UCI_STATUS_NOT_APPLICABLE = 0x0C

    # UWB session specific status codes
    UCI_STATUS_ERROR_SESSION_NOT_EXIST = 0x11
    UCI_STATUS_ERROR_SESSION_ACTIVE = 0x13
    UCI_STATUS_ERROR_MAX_SESSIONS_EXCEEDED = 0x14
    UCI_STATUS_ERROR_SESSION_NOT_CONFIGURED = 0x15
    UCI_STATUS_ERROR_ACTIVE_SESSIONS_ONGOING = 0x16
    UCI_STATUS_ERROR_MULTICAST_LIST_FULL = 0x17
    UCI_STATUS_ERROR_UWB_INITIATION_TIME_TOO_OLD = 0x1A
    UCI_STATUS_OK_NEGATIVE_DISTANCE_REPORT = 0x1B

    # UWB ranging session specific status codes
    STATUS_RANGING_TX_FAILED = 0x20
    STATUS_RANGING_RX_TIMEOUT = 0x21
    STATUS_RANGING_RX_PHY_DEC_FAILED = 0x22
    STATUS_RANGING_RX_PHY_TOA_FAILED = 0x23
    STATUS_RANGING_RX_PHY_STS_FAILED = 0x24
    STATUS_RANGING_RX_MAC_DEC_FAILED = 0x25
    STATUS_RANGING_RX_MAC_IE_DEC_FAILED = 0x26
    STATUS_RANGING_RX_MAC_IE_MISSING = 0x27

    # Vendor specific status codes
    UCI_STATUS_INVALID_RESPONDER_SLOT_INDEX = 0xA0
    UCI_STATUS_SLOT_LEN_NOT_SUPPORTED = 0xA1
    UCI_STATUS_INVALID_SLOT_PER_RR = 0xA2
    UCI_STATUS_INVALID_STS_IDX = 0xA3
    UCI_STATUS_RESPONDER_LISTEN_ONLY_MODE = 0xA4
    STATUS_INVALID_RESPONDER_LISTEN_ONLY_MODE = 0xA5

    # Proprietary status codes
    STATUS_INVALID_RADAR_DELAY = 0x50
    STATUS_INVALID_RADAR_SLOT_INDEX = 0x51
    STATUS_ERROR_RADAR_CALIBRATION_MISSING = 0x52
    STATUS_ERROR_RADAR_SESSION_ACTIVE = 0x53
    STATUS_ERROR_RADAR_CONFIGURATION_MISSING = 0x54
    STATUS_ERROR_RADIO_CONFIGURATION_MISSING = 0x55
    STATUS_ERROR_RADAR_SESSION_CONFIGURATION_MISMATCH_ERROR = 0x56
    STATUS_ERROR_RADAR_SESSION_INVALID_INTERVAL = 0xC1
    STATUS_ERROR_RADAR_SESSION_INVALID_SCHEDULING_CONFIGURATION = 0xC2
    STATUS_ERROR_RADAR_SESSION_INVALID_POSTPROCESSING_SLOTLENGTH = 0xC3
    STATUS_ERROR_RADAR_SESSION_INVALID_POSTPROCESSING_THRESHOLD = 0xC4
    STATUS_ERROR_RADAR_SESSION_INVALID_POSTPROCESSING_SLOTS = 0xC5
    STATUS_RANGING_CONSISTENCY_CHECK_FAILED = 0xE1
    STATUS_RANGING_WDT_TIMEOUT = 0xE2
    STATUS_INVALID_ADAPTIVE_HOPPING_THRESHOLD = 0xE3
    STATUS_RANGING_BASEBAND_ERROR = 0xE4
    STATUS_PHY_CONFIGURATION_INVALID = 0xE5
    STATUS_SESSION_KEY_NOT_AVAILABLE = 0xE6
    STATUS_RANGING_STOP_PRIORITY = 0xE7

    # Testware status codes
    UCI_STATUS_VERIFICATION_FAILED = 0x7D
    UCI_STATUS_REBOOT = 0x80
    UCI_STATUS_REBOOT_WDT = 0x81
    UCI_STATUS_CRC_ERROR = 0xF8
    UCI_STATUS_NOT_IMPLEMENTED = 0xFE
    UCI_STATUS_UNDEF = 0xFF


class EnumUciMessageType(IntEnum):
    UCI_MT_COMMAND = 0x01
    UCI_MT_RESPONSE = 0x02
    UCI_MT_NOTIFICATION = 0x03
    UCI_MT_UNDEF = 0xFF


##########################################################################
### GID ##################################################################
class EnumUciGid(IntEnum):
    GID_UCI_CORE = 0x00
    GID_UWB_SESSION_CONFIG = 0x01
    GID_UWB_RANGING_SESSION_CONTROL = 0x02
    GID_TESTWARE = 0x0A
    GID_TEST = 0x0C
    GID_PROPRIETARY = 0x0E


##########################################################################
### OID ##################################################################
# UCI core group 0x00
class EnumOidCore(IntEnum):
    # UCI core group 0x00
    OID_CORE_DEVICE_RESET = 0x00  # expected from mac
    OID_CORE_DEVICE_STATUS = 0x01
    OID_CORE_GET_DEVICE_INFO = 0x02
    OID_CORE_GET_CAPS_INFO = 0x03
    OID_CORE_SET_CONFIG = 0x04
    OID_CORE_GET_CONFIG = 0x05
    OID_CORE_GENERIC_ERROR = 0x07  # expected from tw and mac


class InvalidFormatError(Exception):
    def __init__(self, input: str = ""):
        message = "Error, invalid format! " + input
        super().__init__(message)


@frozen
class UciMessage:
    def __init__(
        self,
        message_type: EnumUciMessageType,
        packet_boundary_flag: int,
        gid: int,
        payload_extension: int,
        oid: int,
        payload_length: int,
        payload: list[int],
        uci_packets: list = None,
        response_status: EnumUciStatus = None,
    ):
        self.message_type = message_type
        self.packet_boundary_flag = packet_boundary_flag
        self.gid = gid
        self.payload_extension = payload_extension
        self.oid = oid
        self.payload_length = payload_length
        self.response_status = response_status
        self.payload = payload
        self.uci_packets = uci_packets
        self.to_byte_stream()

    @classmethod
    def from_bytes(cls, bytes: list[int], remove_crc: bool = False, prior_pbf: bool = False, remove_response_status_from_payload: bool = True):
        uci_packets = [bytes]
        bytes = bytes[:-2] if remove_crc is True else bytes
        if len(bytes) >= 4:
            message_type = EnumUciMessageType(((bytes[0] & 0xE0) >> 5))
            packet_boundary_flag = (bytes[0] & 0x10) >> 4
            gid = bytes[0] & 0x0F
            payload_extension = (bytes[1] & 0x80) >> 7
            oid = bytes[1] & 0x3F
            payload_length = bytes[3] + (bytes[2] << 8)
            response_status = None
            # check if a status field is required in case it is a response
            if message_type == EnumUciMessageType.UCI_MT_RESPONSE and prior_pbf is False:
                if len(bytes) >= 5:
                    response_status = EnumUciStatus(bytes[4] & 0xFF)
                    if remove_response_status_from_payload:
                        payload = bytes[5:]
                    else:
                        payload = bytes[4:]
                else:
                    raise InvalidFormatError("UCI response status missing!")
            else:
                payload = bytes[4:]
        else:
            raise InvalidFormatError("UCI Input message too short!")
        return UciMessage(
            message_type=message_type,
            packet_boundary_flag=packet_boundary_flag,
            gid=gid,
            payload_extension=payload_extension,
            oid=oid,
            payload_length=payload_length,
            payload=payload,
            uci_packets=uci_packets,
            response_status=response_status,
        )

    def __str__(self):
        return (
            "message type: "
            + str(self.message_type.name)
            + " ("
            + str("0x{:02x}".format(self.message_type.value))
            + ")\n"
            + "packet boundary flag: "
            + str(self.packet_boundary_flag)
            + "\n"
            + "gid: "
            + str("0x{:02x}".format(self.gid))
            + "\n"
            + "payload extension: "
            + str(self.payload_extension)
            + "\n"
            + "oid: "
            + str("0x{:02x}".format(self.oid))
            + "\n"
            + "payload length: "
            + str(self.payload_length)
            + " bytes ("
            + str("0x{:02x}".format(self.payload_length))
            + ")\n"
            + "payload: "
            + str(["0x{:02x}".format(x) for x in self.payload])
        )

    def to_byte_stream(self, append_crc=False):
        self.byte_stream: list[int] = []
        # assemble the byte stream
        self.byte_stream.append(self.message_type.value << 5 | self.packet_boundary_flag << 4 | self.gid)
        self.byte_stream.append(self.payload_extension << 7 | self.oid)
        # check for extended payload size
        if self.payload_extension > 0:
            self.byte_stream.append((self.payload_length & 0xFF00) >> 8)
        else:
            self.byte_stream.append(0)
        self.byte_stream.append(self.payload_length & 0x00FF)
        if self.response_status is not None:
            self.byte_stream.append(self.response_status.value & 0xFF)
        self.byte_stream += self.payload
        if append_crc:
            crc = nxp_crc.calculate_crc(frame=self.byte_stream)
            self.byte_stream += crc.to_bytes(length=2, byteorder="little", signed=False)
        return self.byte_stream
