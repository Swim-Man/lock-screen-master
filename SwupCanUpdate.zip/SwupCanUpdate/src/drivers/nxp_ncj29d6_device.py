#    Copyright 2022-2024 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import sys
from typing import Literal

import nxp_ncj29d6_mac as Ncj29d6Mac
from nxp_ft4222h import (
    EnumFtdiSpiMode,
    EnumFtdiStatus,
    Ft4222hDevice,
    Ft4222hDeviceManager,
)
from nxp_ncj29d6_mac_helpers import check_mac_fw_version, log_mac_uci_message
from nxp_ncj29d6_testware_helpers import check_tw_fw_version
from nxp_uci import (
    EnumUciMessageType,
    EnumUciStatus,
    InvalidFormatError,
    UciMessage,
)
from nxp_uci_interpreter_helpers import get_corresponding_class_uci_message

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import utilities.nxp_console_helpers as console
from utilities.nxp_decorators import frozen

from drivers.nxp_ncj29d6_testware import Ncj29d6Testware


class NxpNcj29d6DeviceError(Exception):
    pass

class NxpNcj29d6DeviceResponseError(Exception):
        pass


class ResponseError(NxpNcj29d6DeviceError):
    pass


### Logging ###
import logging

name = list(filter(lambda x: x.startswith("nxp_main"), sys.path))
try:
    logger = logging.getLogger(name[0])
except IndexError:
    logger = logging.getLogger()


# Wrapper class around ft4222. Optional to use
@frozen
class NxpNcj29d6Device:
    """
    Wrapper for NXPs Ncj29d6-Demoboard. The device gets initialized by creating this class in application.

    Arguments:
        Either 'index' or 'device_location' needs to be provided. If both are provided provided index is discarded.
        spi_timeout_ms: optional (default: 500 ms) | Set spi timeout in ms

    -> Checks device firmware version and performs a hard reset during initialization
    """

    def __init__(
        self,
        index: int | None = None,
        device_location: int | None = None,
        fw: Literal["testware", "mac"] = "testware",
        max_payload_length: int = 4095,
        crc_enable: bool = True,
        spi_timeout_ms: int = 500,
    ):
        """
        Wrapper for NXPs Ncj29d6-Demoboard. The device gets initialized by creating this class in application.

        Arguments:
            Either 'index' or 'device_location' needs to be provided. If both are provided provided index is discarded.
            spi_timeout_ms: optional (default: 500 ms) | Set spi timeout in ms

        -> Testware: Checks device firmware version and performs a hard reset during initialization
        """

        self.max_payload_length = max_payload_length
        self.crc_enable = crc_enable
        self.fw = fw
        self.is_connected = True
        self.error_encountered = False

        ftdi_device_locations = Ft4222hDeviceManager.get_device_locations()

        if device_location in ftdi_device_locations:
            self.device_index = ftdi_device_locations.index(device_location)
            self.device_location = device_location
        elif index in range(len(ftdi_device_locations)):
            self.device_location = ftdi_device_locations[index]
            self.device_index = index
        else:
            if index is None and device_location is None:
                raise ValueError("Either 'index' or 'device_location' needs to be specified.")
            else:
                raise AttributeError("Provided 'index' or 'device_location' does not match connected devices.")

        self._ftdi = Ft4222hDevice(self.device_index, self.device_location)
        self._ftdi.open(spi_frequency_hz=1e07, mode=EnumFtdiSpiMode.FTDI_SPI_MODE_SINGLE)

        # hard reset device
        self._ftdi.hard_reset()

        match fw.lower():
            case "testware":
                # receive startup notification
                status, ntf_boot_status, is_crc_valid = self._ftdi.receive_uci_message(timeout_ms=spi_timeout_ms)
                error_detected = check_response(
                    ftdi_status=status, uci_package=ntf_boot_status, is_crc_valid=is_crc_valid, exit_on_error=False, caller_name="receive_uci_message"
                )
                if error_detected:
                    self._ftdi.close()
                    raise ResponseError

                logger.debug(f"RECEIVE NTF_BOOT_STATUS from device {self.device_index}: {console.as_hex(ntf_boot_status)}\n")

                # Get testware FW versions
                cmd_get_fw_version = Ncj29d6Testware.get_fw_version()
                logger.debug(f"SEND CMD_GET_FW_VERSION to device {self.device_index}: {console.as_hex(cmd_get_fw_version)}\n")
                status, _, _ = self._ftdi.transmit_uci_command(cmd_get_fw_version, timeout_ms=spi_timeout_ms)
                if status != EnumFtdiStatus.FTDI_STATUS_OK:
                    logger.error(f"FTDI Error: {status.name}")
                    self._ftdi.close()
                    raise NxpNcj29d6DeviceError(f"FTDI Error: {status.name}")

                # Receive RSP_GET_FW_VERSION UCI response
                status, rsp_get_fw_version, is_crc_valid = self._ftdi.receive_uci_message(timeout_ms=spi_timeout_ms)
                check_response(
                    ftdi_status=status,
                    uci_package=rsp_get_fw_version,
                    is_crc_valid=is_crc_valid,
                    exit_on_error=True,
                    caller_name="receive_uci_message",
                )
                logger.debug(f"RECEIVE RSP_GET_FW_VERSION from device {self.device_index}: {console.as_hex(rsp_get_fw_version)}\n")

                # convert raw response bytes to UciMessage
                uci_get_fw_version = UciMessage.from_bytes(rsp_get_fw_version)
                versions = Ncj29d6Testware.interpret_get_fw_version_response(uci_get_fw_version.payload)

                if check_tw_fw_version(versions, device_name=f"device {self.device_index}", abort_on_incompatible_version=False):
                    logger.debug(f"Device {self.device_index}: {versions}")

            case "mac":
                # new line
                logger.newline()

                # receive DEVICE_STATUS_NTF/GENERIC_ERROR_NTF UCI notification after hard reset
                status, uci_ntf, is_crc_valid = self._ftdi.receive_uci_message(timeout_ms=spi_timeout_ms, crc_enable=False)
                error_detected = check_response(
                    ftdi_status=status,
                    uci_package=uci_ntf,
                    is_crc_valid=is_crc_valid,
                    exit_on_error=False,
                    caller_name="receive_uci_message",
                )
                if error_detected:
                    self._ftdi.close()
                    raise ResponseError

                logger.debug(
                    f"RECEIVE {Ncj29d6Mac.get_control_message_name(uci_ntf)} ({status.name}) from device {self.device_index}: {console.as_hex(uci_ntf)}"
                )
                uci_ntf = Ncj29d6Mac.interpret_mac_uci_message(
                    uci_message=UciMessage.from_bytes(bytes=uci_ntf, remove_response_status_from_payload=False)
                )
                logger.debug(uci_ntf)
                logger.newline()
                if isinstance(uci_ntf, Ncj29d6Mac.DeviceStatusNtf) and (
                    uci_ntf.device_status != Ncj29d6Mac.EnumDeviceStatus.STATUS_READY
                    and uci_ntf.device_status != Ncj29d6Mac.EnumDeviceStatus.STATUS_REBOOT_ON_HPD_WUP_PIN
                ):
                    self._ftdi.close()
                    raise NxpNcj29d6DeviceError(
                        f"{console.StrColor.RED}Error in DEVICE_STATUS_NTF from device {self.device_index}: {uci_ntf.device_status}{console.StrColor.RESET}"
                    )
                elif isinstance(uci_ntf, Ncj29d6Mac.GenericErrorNtf):
                    self._ftdi.close()
                    raise NxpNcj29d6DeviceError(
                        f"{console.StrColor.RED}Received GENERIC_ERROR_NTF from device {self.device_index} during initialization. Aborting...{console.StrColor.RESET}"
                    )
                elif not isinstance(uci_ntf, (Ncj29d6Mac.DeviceStatusNtf, Ncj29d6Mac.GenericErrorNtf)):
                    self._ftdi.close()
                    raise NxpNcj29d6DeviceError(
                        f"{console.StrColor.RED}Received unexpected UCI notification from device {self.device_index}: {uci_ntf}{console.StrColor.RESET}"
                    )

                # Get device info, read out software versions: CORE_GET_DEVICE_INFO_CMD
                cmd_get_device_info = Ncj29d6Mac.GetDeviceInfoCmd().create_command()
                logger.debug(f"SEND CORE_GET_DEVICE_INFO_CMD to device {self.device_index}: {console.as_hex(cmd_get_device_info)}\n")
                status, _, _ = self._ftdi.transmit_uci_command(cmd_get_device_info, append_crc=False, timeout_ms=spi_timeout_ms)
                if status != EnumFtdiStatus.FTDI_STATUS_OK:
                    logger.error(f"FTDI Error: {status.name}")
                    self._ftdi.close()
                    raise NxpNcj29d6DeviceError(f"FTDI Error: {status.name}")

                # Receive CORE_GET_DEVICE_INFO_RSP UCI response
                status, core_get_device_info_rsp, is_crc_valid = self._ftdi.receive_uci_message(timeout_ms=spi_timeout_ms, crc_enable=False)
                check_response(
                    ftdi_status=status,
                    uci_package=core_get_device_info_rsp,
                    is_crc_valid=is_crc_valid,
                    exit_on_error=True,
                    caller_name="receive_uci_message",
                )

                logger.debug(f"RECEIVE CORE_GET_DEVICE_INFO_RSP from device {self.device_index}: {console.as_hex(core_get_device_info_rsp)}\n")
                device_info = Ncj29d6Mac.interpret_mac_uci_message(
                    uci_message=UciMessage.from_bytes(bytes=core_get_device_info_rsp, remove_response_status_from_payload=False)
                )
                logger.debug(f"Device {self.device_index}: {device_info}")

                check_mac_fw_version(device_info, device_name=f"device {self.device_index}", abort_on_incompatible_version=False)

            case _:
                raise ValueError(f"fw={fw} is not supported. Supported are: 'testware' and 'mac'")

    def close(self) -> None:
        self._ftdi.close()

    def hard_reset(self) -> None:
        self._ftdi.hard_reset()

    def transmit_uci_command(self, command: list[int], timeout_ms=500, exit_on_error=False) -> tuple[EnumFtdiStatus, list[int], bool]:
        """
        Wrapper to transmit uci messages and check for ftdi errors.
        Arguments:
            command: byte list of uci command
            timeout_ms: int | Set ftdi timeout
            exit_on_error: bool | Choose if program should raise an exception on ftdi error
        Returns:
            list(status, target_miso_bytes, is_crc_valid):
                status: EnumFtdiStatus
                target_miso_bytes: list with received bytes if a message was pending
                is_crc_valid: bool | True if crc of target_miso_bytes is correct | False, if target_miso_bytes is empty list (no message pending)
        """

        # check if number of bytes are more than 'max_payload_length' allows; splits command if needed.
        if len(command) <= self.max_payload_length:
            status, target_miso_bytes, is_crc_valid = self._ftdi.transmit_uci_command(
                input_command=command, append_crc=self.crc_enable, timeout_ms=timeout_ms
            )

            if status != EnumFtdiStatus.FTDI_STATUS_OK:
                logger.error(f"FTDI Error: {status.name}")
                if exit_on_error:
                    raise NxpNcj29d6DeviceError(f"FTDI Error: {status.name}")

        else:
            complete_uci_message = UciMessage.from_bytes(bytes=command, remove_crc=False)
            complete_payload = complete_uci_message.payload

            payloads = [complete_payload[i : i + self.max_payload_length] for i in range(0, len(complete_payload), self.max_payload_length)]
            logger.debug(
                f"Command exceeds defined maximum of bytes. Command is split in {len(payloads)} parts. Command length (without crc):({[len(p)+4 for p in payloads]})"
            )
            uci_messages: list[UciMessage] = []
            for payload in payloads:
                uci_messages.append(
                    UciMessage(
                        message_type=complete_uci_message.message_type,
                        packet_boundary_flag=True,
                        gid=complete_uci_message.gid,
                        payload_extension=complete_uci_message.payload_extension,
                        oid=complete_uci_message.oid,
                        payload_length=len(payload),
                        payload=payload,
                    )
                )
            uci_messages[-1].packet_boundary_flag = False
            uci_messages[-1].to_byte_stream()

            for index, uci_message in enumerate(uci_messages):
                status, target_miso_bytes, is_crc_valid = self._ftdi.transmit_uci_command(
                    input_command=uci_message.byte_stream, append_crc=self.crc_enable, timeout_ms=timeout_ms
                )
                logger.debug(f"Part {index+1}/{len(uci_messages)}: {console.as_hex(uci_message.byte_stream)}")
                if status != EnumFtdiStatus.FTDI_STATUS_OK:
                    logger.error(f"FTDI Error: {status.name}")
                    if exit_on_error:
                        raise NxpNcj29d6DeviceError(f"FTDI Error: {status.name}")

        return status, target_miso_bytes, is_crc_valid

    def receive_uci_message(self, timeout_ms=500, exit_on_error=False) -> tuple[bool, UciMessage]:
        """
        Wrapper to receive uci messages and check for errors. Supports PBF.
        Arguments:
            timeout_ms: int | Set ftdi timeout
            exit_on_error: bool | Choose if program should raise an exception on ftdi, crc and uci error
        Returns:
            is_successful: bool | Returns True if no error was detected
            complete_uci_message: UciMessage | If PBF is detected, multiple uci messages are combined to a single uci message
        """

        ftdi_status: EnumFtdiStatus
        ftdi_status, uci_package, is_crc_valid = self._ftdi.receive_uci_message(timeout_ms=timeout_ms, crc_enable=self.crc_enable)
        error_detected = check_response(
            ftdi_status=ftdi_status,
            uci_package=uci_package,
            is_crc_valid=is_crc_valid,
            exit_on_error=exit_on_error,
            caller_name="receive_uci_message",
        )
        if error_detected:
            if exit_on_error:
                raise NxpNcj29d6DeviceError("Error in receive_uci_message. Check log for details.")
            if ftdi_status == EnumFtdiStatus.FTDI_STATUS_OK:
                try:
                    uci_message = UciMessage.from_bytes(
                        bytes=uci_package, remove_crc=self.crc_enable, remove_response_status_from_payload=False if self.fw == "mac" else True
                    )
                except InvalidFormatError:
                    return False, None
                return False, uci_message
            else:
                return False, None
        complete_uci_message = UciMessage.from_bytes(
            bytes=uci_package, remove_crc=self.crc_enable, remove_response_status_from_payload=False if self.fw == "mac" else True
        )

        # PBF is not set:
        if not complete_uci_message.packet_boundary_flag:
            return True, complete_uci_message

        # PBF is set:
        while True:
            ftdi_status, uci_package, is_crc_valid = self._ftdi.receive_uci_message(timeout_ms=timeout_ms, crc_enable=self.crc_enable)

            errorflag = False
            if ftdi_status == EnumFtdiStatus.FTDI_STATUS_OK:
                if not is_crc_valid:
                    logger.error("receive_uci_message: CRC not valid!")
                    errorflag = True
            else:
                logger.error(f"receive_uci_message: FTDI Error: {ftdi_status.name}")
                errorflag = True

            if exit_on_error and errorflag:
                raise NxpNcj29d6DeviceError("Error in receive_uci_message. Check log for details.")
            elif not exit_on_error and errorflag:
                return False, complete_uci_message

            uci_message = UciMessage.from_bytes(bytes=uci_package, remove_crc=self.crc_enable, prior_pbf=True)
            complete_uci_message.payload += uci_message.payload
            complete_uci_message.payload_length += uci_message.payload_length
            complete_uci_message.packet_boundary_flag = uci_message.packet_boundary_flag
            complete_uci_message.payload_extension = 0 if complete_uci_message.payload_length <= 0xFF else 1
            complete_uci_message.uci_packets.append(uci_package)
            # PBF is not set:
            if not complete_uci_message.packet_boundary_flag:
                return True, complete_uci_message

    def send_uci_cmd_get_rsp(self, uci_command: list[int], timeout_ms=500, exit_on_error=False) -> tuple[bool, UciMessage]:
        """
        Wrapper to combine transmit_uci_command with receive_uci_message.
        If device was in a low power mode and wakes due to sending a command
        both the status ntf and the expected response are received with this function.

        Arguments:
            uci_command: byte list of uci command
            timeout_ms: int | Set ftdi timeout
            exit_on_error: bool | Choose if program should raise an exception on ftdi, crc and uci error | default = True
        Returns:
            is_successful: bool | Returns True if no error was detected
            uci_message: UciMessage of return
        """

        status: EnumFtdiStatus
        status, _, _ = self.transmit_uci_command(command=uci_command, timeout_ms=timeout_ms, exit_on_error=exit_on_error)
        if status != EnumFtdiStatus.FTDI_STATUS_OK:
            return False, None
        is_successful, uci_message = self.receive_uci_message(timeout_ms=timeout_ms, exit_on_error=exit_on_error)

        # might receive DEVICE_STATUS_NTF if device entered low power mode before
        if uci_message.oid == Ncj29d6Mac.EnumOidCore.OID_CORE_DEVICE_STATUS and uci_message.gid == Ncj29d6Mac.EnumUciGid.GID_UCI_CORE:
            device_status_ntf: Ncj29d6Mac.DeviceStatusNtf = get_corresponding_class_uci_message(uci_message=uci_message, is_crc_provided=False)
            if device_status_ntf.device_status == Ncj29d6Mac.EnumDeviceStatus.STATUS_REBOOT_ON_HPD_WUP_PIN:
                log_mac_uci_message(uci_message=uci_message, device_name=f"device_{self.device_index}", is_successful=is_successful)
                # -> read pending response
                is_successful, uci_message = self.receive_uci_message(timeout_ms=timeout_ms, exit_on_error=exit_on_error)
        return is_successful, uci_message


def check_response(
    ftdi_status: EnumFtdiStatus, uci_package: list[int], is_crc_valid: bool, crc_enable=True, exit_on_error=False, caller_name=""
) -> bool:
    """
    Checks for FTDI and CRC errors. If received message is from type 'UCI_MT_RESPONSE', the 'response_status' byte is checked as well.

    Arguments:
        ftdi_status: FTDI status flag received from device (EnumFtdiStatus)
        uci_package: The raw byte list of the received message from FTDI device
        is_crc_valid: CRC flag received from the device
        exit_on_error: bool: Set to True if exception shall be raised on any error; Set to False (default) if function shall return anyway. Consider adding error handling in application.

    Returns:
        error_detected: bool

    """

    errorflag = False
    if ftdi_status == EnumFtdiStatus.FTDI_STATUS_OK:
        if not is_crc_valid and crc_enable:
            logger.error(f"{caller_name}: CRC not valid!")
            if exit_on_error:
                raise ResponseError(f"{caller_name}: CRC not valid!")
            errorflag = True
        try:
            response = UciMessage.from_bytes(uci_package)
        except InvalidFormatError:
            logger.error(f"{caller_name}: Error. Received UciMessage to short!")
            if exit_on_error:
                raise ResponseError(f"{caller_name}: Error. Received UciMessage to short!")
            errorflag = True

        if response.message_type == EnumUciMessageType.UCI_MT_RESPONSE:
            resp_status: EnumUciStatus = response.response_status
            if resp_status != EnumUciStatus.UCI_STATUS_OK:
                logger.error(f"{caller_name}: Response status error ({resp_status.name})")
                if exit_on_error:
                    raise ResponseError(f"{caller_name}: Response status error ({resp_status.name})")
                errorflag = True
    else:
        logger.error(f"{caller_name}: FTDI Error: {ftdi_status.name}")
        if exit_on_error:
            raise ResponseError(f"{caller_name}: FTDI Error: {ftdi_status.name}")
        return True

    return True if errorflag else False
