#    Copyright 2023 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

from typing import List

import crcengine


def calculate_crc(frame: List[int]) -> int:
    """
    Calculate the CRC (Cyclic Redundancy Check) for the given frame.

    Args:
        frame (List[int]): The frame for which to calculate the CRC.

    Returns:
        int: The calculated CRC value.

    """
    crc = crcengine.new("crc16-xmodem").calculate(frame)
    return crc


def is_crc_valid(frame: List[int], received_crc: int) -> bool:
    """
    Check if the received CRC matches the calculated CRC for the given frame.

    Args:
        frame (List[int]): The frame for which the CRC is calculated.
        received_crc (int): The received CRC value.

    Returns:
        bool: True if the received CRC matches the calculated CRC, False otherwise.
    """
    actual_crc = calculate_crc(frame)
    return actual_crc == received_crc


def check_for_crc(uci_packet: List[int]):
    """
    Check the CRC of a UCI packet.

    Args:
        uci_packet (List[int]): The UCI packet to check.

    Returns:
        Tuple[List[int], Optional[List[int]]]: A tuple containing the calculated CRC and the provided CRC (if available).
    """
    payload_length = uci_packet[3] + (uci_packet[2] << 8)

    if payload_length == (len(uci_packet) - 4):
        calculated_crc_int = calculate_crc(uci_packet)
        calculated_crc = [(calculated_crc_int & 0xFF), calculated_crc_int >> 8]
        provided_crc = None
    elif payload_length == (len(uci_packet) - 6):
        calculated_crc_int = calculate_crc(uci_packet[:-2])
        calculated_crc = [(calculated_crc_int & 0xFF), calculated_crc_int >> 8]
        provided_crc = uci_packet[-2:]
    else:
        calculated_crc = None
        provided_crc = None

    return calculated_crc, provided_crc
