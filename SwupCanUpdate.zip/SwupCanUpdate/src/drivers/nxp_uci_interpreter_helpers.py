#    (c) NXP B.V. 2022. All rights reserved.

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.


import sys
from typing import List, Tuple

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import nxp_ncj29d6_mac as Ncj29d6Mac
from nxp_ncj29d6_testware import TESTWARE_MESSAGE_DICT
from nxp_uci import EnumUciGid, EnumUciMessageType, UciMessage
from utilities.nxp_console_helpers import as_hex


def get_corresponding_class_uci_message(uci_message: UciMessage, is_crc_provided: bool, center_frequency_khz: int = None, session_type: Ncj29d6Mac.EnumSessionType | None = None):
    """
    Returns the corresponding class for a given UciMessage.

    Args:
        uci_message (UciMessage): The UciMessage object.
        is_crc_provided (bool): True if payload contains crc16, False if no crc in payload
        center_frequency_khz (int, optional): The center frequency in kHz. Defaults to None.

    Returns:
        corresponding_class: The corresponding class for the UciMessage.
    """
    match EnumUciGid(uci_message.gid):
        case EnumUciGid.GID_TESTWARE:
            if not uci_message.payload:
                return None
            uci_message_tw = UciMessage.from_bytes(
                bytes=uci_message.uci_packets[0], remove_response_status_from_payload=True, remove_crc=is_crc_provided
            )
            if uci_message_tw.message_type == EnumUciMessageType.UCI_MT_RESPONSE and not uci_message_tw.payload:
                return None
            interpreter_function = TESTWARE_MESSAGE_DICT[uci_message.oid][uci_message.message_type]
            if center_frequency_khz is not None:
                corresponding_class = interpreter_function(uci_message_tw.payload, center_frequency_khz)
            else:
                corresponding_class = interpreter_function(uci_message_tw.payload)

        case (
            EnumUciGid.GID_UCI_CORE
            | EnumUciGid.GID_UWB_SESSION_CONFIG
            | EnumUciGid.GID_UWB_RANGING_SESSION_CONTROL
            | EnumUciGid.GID_TESTWARE
            | EnumUciGid.GID_PROPRIETARY
        ):
            if uci_message.gid == EnumUciGid.GID_UWB_SESSION_CONFIG and (uci_message.oid == Ncj29d6Mac.EnumMacOidSessionConfig.MAC_OID_SESSION_SET_APP_CONFIG or Ncj29d6Mac.EnumMacOidSessionConfig.MAC_OID_SESSION_GET_APP_CONFIG):
                corresponding_class = Ncj29d6Mac.interpret_mac_uci_message(uci_message, session_type=session_type)
            else:
                corresponding_class = Ncj29d6Mac.interpret_mac_uci_message(uci_message)

        case _:
            raise NotImplementedError(f"{EnumUciGid(uci_message.gid)} is not supported by 'get_corresponding_class_uci_message'.")

    return corresponding_class


def is_payload_valid(uci_packet: List[int]) -> Tuple[str | None, bool]:
    """
    Checks if the payload in the given UCI packet is valid for interpretation.

    Args:
        uci_packet (List[int]): The UCI packet to check.

    Returns:
        Tuple[str | None, bool]: A tuple containing the information string and a boolean indicating if the payload can be interpreted.
            - info_str (str | None): Information string describing the payload validity. None if the payload is valid.
            - valid_payload (bool | None): True if the payload is valid, False otherwise. None if no payload.
    """
    uci_message = UciMessage.from_bytes(uci_packet, remove_response_status_from_payload=False)
    payload_length = uci_message.payload_length

    if payload_length == 0:
        info_str = "No valid payload to interpret (payload length = 0)."
        valid_payload = None
    elif payload_length == 2 and len(uci_packet) == 6:
        info_str = (
            "WARNING: Possible invalid input as 'payload_length' is 2 and actual length of payload is either 2 or 0 depending if input includes crc. "
            "Will anticipate valid input without crc."
            "If the input includes crc, the interpretation will fail."
        )
        valid_payload = True
    elif payload_length != (len(uci_packet) - 6) and payload_length != (len(uci_packet) - 4):
        info_str = f"Invalid Payload: 'payload_length' is different from actual length of payload. Actual payload length: {len(uci_message.payload)}. No valid payload to interpret."
        valid_payload = False
    else:
        info_str = None
        valid_payload = True

    return info_str, valid_payload


def analyse_crc(provided_crc, calculated_crc):
    """
    Analyzes the CRC value of a UCI message.

    Args:
        provided_crc (list): The provided CRC value.
        calculated_crc (list): The calculated CRC value.

    Returns:
        tuple: A tuple containing the CRC value string and the CRC status string.
            - CRC value string: A string representation of the provided and calculated CRC values.
            - CRC status string: A string indicating whether the CRC is valid or not.

    Expects: CRC16
    """

    if provided_crc is not None:
        crc_value_string = "Provided CRC: " + as_hex(provided_crc)
    else:
        crc_value_string = "Provided CRC: None"

    crc_value_string += "\n" + "Calculated CRC: " + as_hex(calculated_crc)

    if provided_crc is not None and provided_crc == calculated_crc:
        crc_status_string = "CRC is valid!"
    elif provided_crc is not None and provided_crc != calculated_crc:
        crc_status_string = "CRC is NOT valid!"
    else:
        crc_status_string = None

    return crc_value_string, crc_status_string
