#    Copyright 2022-2024 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import sys
import time
from dataclasses import fields, is_dataclass
from enum import IntEnum
from typing import Any

from tabulate import tabulate

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import logging

import utilities.nxp_console_helpers as console
from utilities.nxp_decorators import frozen, strict

from drivers.nxp_ncj29d6_testware import (
    FirmwareVersion,
    RadioConfigVersion,
    RangingCommand,
)

name = list(filter(lambda x: x.startswith("nxp_main"), sys.path))
try:
    logger = logging.getLogger(name[0])
except IndexError:
    logger = logging.getLogger()

###########################################
#  CONSTANTS
MAX_NUMBER_OF_RESPONDERS = 16
MIN_NUMBER_OF_RESPONDERS = 1

EXPECTED_RADIO_SETTINGS_VERSION = RadioConfigVersion(
    radio_cnf_major_version=2, radio_cnf_minor_version=7, radio_cnf_patch_version=1, radio_cnf_version_id=0
)

EXPECTED_TW_FW_VERSION =  FirmwareVersion(
    testware_version=FirmwareVersion.Versions(
        major_version=17,
        minor_version=1,
        patch_version=1,
        version_id= 0),
    foundation_package_version=FirmwareVersion.Versions(
        major_version=20,
        minor_version=1,
        patch_version=1,
        version_id= 0),
    device_mode=FirmwareVersion.EnumDeviceMode.DEVICE_MODE_INIT,
    hardware_version=FirmwareVersion.EnumHardwareVersion.B2,
    swup_core_version=FirmwareVersion.Versions(
        major_version=3,
        minor_version=1,
        patch_version=1,
        version_id= 0),
    swup_version=FirmwareVersion.Versions(
        major_version=3,
        minor_version=0,
        patch_version=0,
        version_id= 0),
    baseband_version= FirmwareVersion.Versions(
        major_version=14,
        minor_version=2,
        patch_version=1,
        version_id= 0),
    dsp_version=FirmwareVersion.Versions(
        major_version=14,
        minor_version=2,
        patch_version=0,
        version_id= 0),
    sbe_api_version=FirmwareVersion.Versions(
        major_version=12,
        minor_version=3,
        patch_version=0,
        version_id= 0x583A),
    rom_version= FirmwareVersion.Versions(
        major_version=0,
        minor_version=0,
        patch_version=0,
        version_id= 0),
    swd_version=FirmwareVersion.SwdVersion(
            swd_target_id=0x01,
            jep106_id=0x15,
            jep106_cont_code=0x00,
            part_number=0x00,
            revision=0x00),
    variant_information=[0x00, 0x00, 0x00, 0x00],
    serial_number=[],
    wafer_data=[],
    radio_config_version=FirmwareVersion.Versions(
        major_version=2,
        minor_version=7,
        patch_version=1,
        version_id=0),
    bundle_version=FirmwareVersion.Versions(
        major_version=2,
        minor_version=1,
        patch_version=0,
        version_id=0),
    dsp_component_version=FirmwareVersion.Versions(
        major_version=14,
        minor_version=2,
        patch_version=0,
        version_id=0),
    swup_component_version=FirmwareVersion.Versions(
        major_version=3,
        minor_version=0,
        patch_version=0,
        version_id=0),
    )  # fmt: skip

IGNORED_FIELDS = ["device_mode", "variant_information", "serial_number", "wafer_data", "device_test_data", "radio_config_version", "bundle_version"]

EXPECTED_TW_VERSION_STR = f"{EXPECTED_TW_FW_VERSION.testware_version.major_version}.{EXPECTED_TW_FW_VERSION.testware_version.minor_version}.{EXPECTED_TW_FW_VERSION.testware_version.patch_version}"
###########################################


class EnumDeviceRole(IntEnum):
    ROLE_RANGING_RESPONDER = 0
    ROLE_RANGING_INITIATOR = 1


@frozen
class RangingSequenceCfg:
    def __init__(
        self,
        device_role: EnumDeviceRole,  # Choose either responder or initiator as device role
        ranging_slot_length_us: int,  # Delay in us between each frame
        ranging_seq_time_shift_us: int,  # Shifts the whole ranging sequence forward in time (in us)
        first_rx_timeout_us: int,  # RX timeout in us only for the first RX frame on the responder
        rx_timeout_us: int,  # RX timeout in us for all RX frames
        tx_timeout_us: int,  # TX timeout in us for all TX frames
        rx_delay_margin_us: int,  # Time in us to open RX window earlier (subtracted from delay parameter of ranging command)
        tx_delay_margin_us: int,  # Time in us to start TX later (added to delay parameter of ranging command)
        ranging_slot_select_ranging: int,  # Selects the radio configuration pair to be used for ranging frames
        ranging_slot_select_data: int,  # Selects the radio configuration pair to be used for data frames
        number_of_responders: int,  # The total number of responders in the ranging sequence
        responder_index: int,  # the index of the responder (zero-indexed)
        include_pre_poll: bool,  # True if PRE_POLL frame should be included in the ranging sequence
        include_final_data: bool, # True if FINAL_DATA frame should be included in the ranging sequence
    ):
        self.device_role = device_role
        self.ranging_slot_length_us = ranging_slot_length_us
        self.ranging_seq_time_shift_us = ranging_seq_time_shift_us
        self.first_rx_timeout_us = first_rx_timeout_us
        self.rx_timeout_us = rx_timeout_us
        self.tx_timeout_us = tx_timeout_us
        self.rx_delay_margin_us = rx_delay_margin_us
        self.tx_delay_margin_us = tx_delay_margin_us
        self.ranging_slot_select_ranging = ranging_slot_select_ranging
        self.ranging_slot_select_data = ranging_slot_select_data
        self.number_of_responders = number_of_responders
        self.responder_index = responder_index
        self.include_pre_poll = include_pre_poll
        self.include_final_data = include_final_data

    @property
    def device_role(self):
        return self._device_role

    @device_role.setter
    def device_role(self, value):
        if not isinstance(value, EnumDeviceRole):
            raise ValueError("Ranging device role not recognized")
        self._device_role = value

    @property
    def ranging_slot_length_us(self):
        return self._ranging_slot_length_us

    @ranging_slot_length_us.setter
    def ranging_slot_length_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for ranging_slot_length_us (expected: int)")
        if value < 0:
            raise ValueError("ranging_slot_length_us needs to be positive")
        self._ranging_slot_length_us = value

    @property
    def ranging_seq_time_shift_us(self):
        return self._ranging_seq_time_shift_us

    @ranging_seq_time_shift_us.setter
    def ranging_seq_time_shift_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for ranging_seq_time_shift_us (expected: int)")
        if value < 0:
            raise ValueError("ranging_seq_time_shift_us needs to be positive")
        self._ranging_seq_time_shift_us = value

    @property
    def first_rx_timeout_us(self):
        return self._first_rx_timeout_us

    @first_rx_timeout_us.setter
    def first_rx_timeout_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for first_rx_timeout_us (expected: int)")
        if value < 0:
            raise ValueError("first_rx_timeout_us needs to be positive")
        self._first_rx_timeout_us = value

    @property
    def rx_timeout_us(self):
        return self._rx_timeout_us

    @rx_timeout_us.setter
    def rx_timeout_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for rx_timeout_us (expected: int)")
        if value < 0:
            raise ValueError("rx_timeout_us needs to be positive")
        if value >= self.ranging_slot_length_us:
            raise ValueError("rx_timeout_us needs to be less than ranging_slot_length_us")
        self._rx_timeout_us = value

    @property
    def tx_timeout_us(self):
        return self._tx_timeout_us

    @tx_timeout_us.setter
    def tx_timeout_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for tx_timeout_us (expected: int)")
        if value < 0:
            raise ValueError("tx_timeout_us needs to be positive")
        if value >= self.ranging_slot_length_us:
            raise ValueError("tx_timeout_us needs to be less than ranging_slot_length_us")
        self._tx_timeout_us = value

    @property
    def rx_delay_margin_us(self):
        return self._rx_delay_margin_us

    @rx_delay_margin_us.setter
    def rx_delay_margin_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for rx_delay_margin_us (expected: int)")
        if value < 0:
            raise ValueError("rx_delay_margin_us needs to be positive")
        if value >= self.ranging_slot_length_us:
            raise ValueError("rx_delay_margin_us needs to be less than ranging_slot_length_us")
        self._rx_delay_margin_us = value

    @property
    def tx_delay_margin_us(self):
        return self._tx_delay_margin_us

    @tx_delay_margin_us.setter
    def tx_delay_margin_us(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for tx_delay_margin_us (expected: int)")
        if value < 0:
            raise ValueError("tx_delay_margin_us needs to be positive")
        if value >= self.ranging_slot_length_us:
            raise ValueError("tx_delay_margin_us needs to be less than ranging_slot_length_us")
        self._tx_delay_margin_us = value

    @property
    def ranging_slot_select_ranging(self):
        return self._ranging_slot_select_ranging

    @ranging_slot_select_ranging.setter
    def ranging_slot_select_ranging(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for ranging_slot_select_ranging (expected: int)")
        if value < 0:
            raise ValueError("ranging_slot_select_ranging needs to be positive")
        self._ranging_slot_select_ranging = value

    @property
    def ranging_slot_select_data(self):
        return self._ranging_slot_select_data

    @ranging_slot_select_data.setter
    def ranging_slot_select_data(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for ranging_slot_select_data (expected: int)")
        if value < 0:
            raise ValueError("ranging_slot_select_data needs to be positive")
        self._ranging_slot_select_data = value

    @property
    def number_of_responders(self):
        return self._number_of_responders

    @number_of_responders.setter
    def number_of_responders(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for number_of_responders (expected: int)")
        if value > MAX_NUMBER_OF_RESPONDERS:
            raise ValueError(f"number_of_responders exceeds the maximal allowed number of devices ({MAX_NUMBER_OF_RESPONDERS})")
        if value < MIN_NUMBER_OF_RESPONDERS:
            raise ValueError(f"number_of_responders cannot be less than {MIN_NUMBER_OF_RESPONDERS}")
        self._number_of_responders = value

    @property
    def responder_index(self):
        return self._responder_index

    @responder_index.setter
    def responder_index(self, value):
        if not isinstance(value, int):
            raise TypeError("Unexpected input type for responder_index (expected: int)")
        if value < 0:
            raise ValueError("responder_index needs to be positive")
        if value >= self.number_of_responders:
            raise ValueError("responder_index is higher than number_of_responders")
        self._responder_index = value

    @property
    def include_pre_poll(self):
        return self._include_pre_poll

    @include_pre_poll.setter
    def include_pre_poll(self, value):
        if not isinstance(value, bool):
            raise TypeError("Unexpected input type for include_pre_poll (expected: bool)")
        self._include_pre_poll = value

    @property
    def include_final_data(self):
        return self._include_final_data

    @include_final_data.setter
    def include_final_data(self, value):
        if not isinstance(value, bool):
            raise TypeError("Unexpected input type for include_final_data (expected: bool)")
        self._include_final_data = value

    def __str__(self) -> str:
        return console.class_to_str(self)


def create_ranging_sequence(cfg: RangingSequenceCfg) -> list[RangingCommand]:
    # create list ranging_sequence
    ranging_sequence = []

    # Reset ranging command count
    current_frame_index = 0

    # ROLE_RANGING_RESPONDER
    if cfg.device_role == EnumDeviceRole.ROLE_RANGING_RESPONDER:
        # PRE_POLL: RX data
        if cfg.include_pre_poll is True:
            ranging_sequence.append(
                RangingCommand(
                    ranging_action=RangingCommand.EnumRangingAction.RX_DATA,
                    ranging_slot_select=cfg.ranging_slot_select_data,
                    delay_us=cfg.ranging_seq_time_shift_us
                            - cfg.rx_delay_margin_us,
                    timeout_ns=cfg.first_rx_timeout_us * 1000,
                    psdu_select=RangingCommand.EnumPSDUSel.USE_PRECONFIGURED_PSDU,
                    psdu_buffer_index_select=current_frame_index,
                )
            )
            current_frame_index += 1

        # POLL: RX ranging
        command = RangingCommand(
                ranging_action=RangingCommand.EnumRangingAction.RX_RANGING,
                ranging_slot_select=cfg.ranging_slot_select_ranging,
                delay_us=(cfg.ranging_slot_length_us * current_frame_index)
                        - cfg.rx_delay_margin_us,
                timeout_ns=cfg.rx_timeout_us * 1000,
                psdu_select=RangingCommand.EnumPSDUSel.NO_PSDU,
                psdu_buffer_index_select=current_frame_index,
        )
        if cfg.include_pre_poll is False:
            command.delay_us = cfg.ranging_seq_time_shift_us - cfg.rx_delay_margin_us
            command.timeout_ns = cfg.first_rx_timeout_us * 1000
        ranging_sequence.append(command)
        current_frame_index += 1

        # RESPONSE: TX ranging
        ranging_sequence.append(
            RangingCommand(
                ranging_action=RangingCommand.EnumRangingAction.TX_RANGING,
                ranging_slot_select=cfg.ranging_slot_select_ranging,
                delay_us=(cfg.ranging_slot_length_us * (current_frame_index + cfg.responder_index))
                        + cfg.tx_delay_margin_us,
                timeout_ns=cfg.tx_timeout_us * 1000,
                psdu_select=RangingCommand.EnumPSDUSel.NO_PSDU,
                psdu_buffer_index_select=current_frame_index,
            )
        )
        current_frame_index += 1

        # FINAL: RX ranging
        ranging_sequence.append(
            RangingCommand(
                ranging_action=RangingCommand.EnumRangingAction.RX_RANGING,
                ranging_slot_select=cfg.ranging_slot_select_ranging,
                delay_us= (cfg.ranging_slot_length_us * (current_frame_index + cfg.number_of_responders - 1))
                - cfg.rx_delay_margin_us,
                timeout_ns=cfg.rx_timeout_us * 1000,
                psdu_select=RangingCommand.EnumPSDUSel.NO_PSDU,
                psdu_buffer_index_select=current_frame_index,
            )
        )
        current_frame_index += 1

        # FINAL_DATA: RX data
        if cfg.include_final_data is True:
            ranging_sequence.append(
                RangingCommand(
                    ranging_action=RangingCommand.EnumRangingAction.RX_DATA,
                    ranging_slot_select=cfg.ranging_slot_select_data,
                    delay_us=(cfg.ranging_slot_length_us * (current_frame_index + cfg.number_of_responders - 1))
                            - cfg.rx_delay_margin_us,
                    timeout_ns=cfg.rx_timeout_us * 1000,
                    psdu_select=RangingCommand.EnumPSDUSel.USE_PRECONFIGURED_PSDU,
                    psdu_buffer_index_select=current_frame_index,
                )
            )

    # ROLE_RANGING_INITIATOR
    else:
        # PRE_POLL: TX data
        if cfg.include_pre_poll is True:
            ranging_sequence.append(
                RangingCommand(
                    ranging_action=RangingCommand.EnumRangingAction.TX_DATA,
                    ranging_slot_select=cfg.ranging_slot_select_data,
                    delay_us=cfg.ranging_seq_time_shift_us + cfg.tx_delay_margin_us,
                    timeout_ns=cfg.tx_timeout_us * 1000,
                    psdu_select=RangingCommand.EnumPSDUSel.USE_PRECONFIGURED_PSDU,
                    psdu_buffer_index_select=current_frame_index,
                )
            )
            current_frame_index += 1

        # POLL: TX ranging
        command = RangingCommand(
            ranging_action=RangingCommand.EnumRangingAction.TX_RANGING,
            ranging_slot_select=cfg.ranging_slot_select_ranging,
            delay_us=(cfg.ranging_slot_length_us * current_frame_index)
                    + cfg.tx_delay_margin_us,
            timeout_ns=cfg.tx_timeout_us * 1000,
            psdu_select=RangingCommand.EnumPSDUSel.NO_PSDU,
            psdu_buffer_index_select=current_frame_index,
        )
        if cfg.include_pre_poll is False:
            command.delay_us = cfg.ranging_seq_time_shift_us + cfg.tx_delay_margin_us
        ranging_sequence.append(command)
        current_frame_index += 1

        # RESPONSE (1x per responder): RX ranging
        for responder_index in range(cfg.number_of_responders):
            ranging_sequence.append(
                RangingCommand(
                    ranging_action=RangingCommand.EnumRangingAction.RX_RANGING,
                    ranging_slot_select=cfg.ranging_slot_select_ranging,
                    delay_us= (cfg.ranging_slot_length_us * (responder_index + current_frame_index))
                            - cfg.rx_delay_margin_us,
                    timeout_ns=cfg.rx_timeout_us * 1000,
                    psdu_select=RangingCommand.EnumPSDUSel.NO_PSDU,
                    psdu_buffer_index_select=responder_index + current_frame_index,
            )
        )
        current_frame_index += cfg.number_of_responders

        # FINAL: TX ranging
        ranging_sequence.append(
            RangingCommand(
                ranging_action=RangingCommand.EnumRangingAction.TX_RANGING,
                ranging_slot_select=cfg.ranging_slot_select_ranging,
                delay_us=(cfg.ranging_slot_length_us * current_frame_index)
                        + cfg.tx_delay_margin_us ,
                timeout_ns=cfg.tx_timeout_us * 1000,
                psdu_select=RangingCommand.EnumPSDUSel.NO_PSDU,
                psdu_buffer_index_select=current_frame_index,
            )
        )
        current_frame_index += 1

        # FINAL_DATA: TX data
        if cfg.include_final_data is True:
            ranging_sequence.append(
                RangingCommand(
                    ranging_action=RangingCommand.EnumRangingAction.TX_DATA,
                    ranging_slot_select=cfg.ranging_slot_select_data,
                    delay_us=(cfg.ranging_slot_length_us * current_frame_index)
                            + cfg.tx_delay_margin_us,
                    timeout_ns=cfg.tx_timeout_us * 1000,
                    psdu_select=RangingCommand.EnumPSDUSel.TRANSMIT_ALL_DELTA_TIMESTAMPS,
                    psdu_buffer_index_select=current_frame_index,
                )
            )

    return ranging_sequence


def check_tw_fw_version(received_fw_version: FirmwareVersion, device_name: str = "device", abort_on_incompatible_version: bool = False) -> bool:
    """
    Checks compatibility of device FW version against the EXPECTED_TW_FW_VERSION of the current release.
    Version ID, hardware_version, variant_information, serial_number, wafer_data, device_test_data are not checked.
    Arguments:
        detected_fw_version: fw versions of type FirmwareVersion read out from a device.
        device_name: custom device name used only for logging. Optional parameter (by default "device").
        abort_on_incompatible_version: raises SystemExit exception and exits the program if set to True and unexpected versions are detected
                                       Optional parameter (default False)
    Returns:
        True:   in case all major/minor/patch versions of all detected_fw_version members except hardware_version, variant_information,
                serial_number, wafer_data, device_test_data are matching EXPECTED_FW_VERSION
        False:  in case at at least one of major/minor/patch versions is not as expected
    Raises:
        SystemExit: in case of incompatible versions and abort_on_incompatible_version is True
    """
    differences = []

    def get_differences(expected_instance: Any, received_instance: Any, path: str = ""):
        if isinstance(expected_instance, FirmwareVersion.Versions):
            if hasattr(expected_instance, "_comparison_str"):
                if expected_instance._comparison_str() != received_instance._comparison_str():
                    differences.append([path.split(".")[-1], expected_instance._comparison_str(), received_instance._comparison_str()])
            elif str(expected_instance) != str(received_instance):
                differences.append([path.split(".")[-1], expected_instance, received_instance])
        elif is_dataclass(expected_instance) and is_dataclass(received_instance):
            for field in fields(expected_instance):
                if field.name in IGNORED_FIELDS:
                    continue  # Skip the comparison for ignored fields
                new_path = f"{path}.{field.name}" if path else field.name
                new_expected_instance = getattr(expected_instance, field.name)
                new_received_instance = getattr(received_instance, field.name)
                get_differences(new_expected_instance, new_received_instance, new_path)
        elif isinstance(expected_instance, IntEnum) and isinstance(received_instance, IntEnum):
            if expected_instance != received_instance:
                differences.append([path.split(".")[-1], expected_instance.name, received_instance.name])
        elif expected_instance != received_instance:
            differences.append([path.split(".")[-1], expected_instance, received_instance])

    get_differences(EXPECTED_TW_FW_VERSION, received_fw_version)

    if differences and logger.name.startswith("nxp_main"):
        logger.error(f"Incompatible firmware version found on {device_name}!")
        logger.w_info(f"\n{tabulate(differences, headers=['Field', 'Expected', 'Detected'], tablefmt='pretty')}")
        time.sleep(1)  # improves readability
        if abort_on_incompatible_version:
            raise SystemExit("Program aborted due to incompatible firmware version!")
        return False

    elif differences:
        console.print(f"\nWARNING: incompatible firmware version found on {device_name}!", color=console.StrColor.RED)
        console.print(tabulate(differences, headers=["Field", "Expected", "Detected"], tablefmt="pretty"), color=console.StrColor.MAGENTA)
        time.sleep(1)  # improves readability
        if abort_on_incompatible_version:
            raise SystemExit(f"{console.StrColor.RED}Program aborted due to incompatible firmware version!{console.StrColor.RESET}")
        return False

    elif logger.name.startswith("nxp_main"):
        logger.newline()
        logger.ok(f"Firmware version of {device_name} is compatible with the current release.")
        logger.newline()
        return True

    else:
        console.print(f"\nINFO: Firmware version of {device_name} is compatible with the current release.\n", color=console.StrColor.GREEN)
        return True


@strict
def check_radio_cfg_version(
    detected_radio_cfg_version: RadioConfigVersion, device_name: str = "device", abort_on_incompatible_version: bool = False
) -> bool:
    """
    Checks input radio cfg version against the EXPECTED_RADIO_SETTINGS_VERSION of the current release.
    Version ID is not checked.
    Arguments:
        detected_radio_cfg_version: fw versions of type FirmwareVersion read out from a device.
        device_name: custom device name used only for logging. Optional parameter (by default "device").
        abort_on_incompatible_version: raises SystemExit exception and exits the program if set to True and unexpected versions are detected
                                       Optional parameter (default False)
    Returns:
        True:   in case major/minor/patch versions of the detected_radio_cfg_version are matching with EXPECTED_RADIO_SETTINGS_VERSION
        False:  in case at at least one of major/minor/patch versions is not as expected
    Raises:
        SystemExit: in case of incompatible versions and abort_on_incompatible_version is True
    """

    if detected_radio_cfg_version is not None and isinstance(detected_radio_cfg_version, RadioConfigVersion):
        if (
            detected_radio_cfg_version.radio_cnf_major_version == EXPECTED_RADIO_SETTINGS_VERSION.radio_cnf_major_version
            and detected_radio_cfg_version.radio_cnf_minor_version == EXPECTED_RADIO_SETTINGS_VERSION.radio_cnf_minor_version
            and detected_radio_cfg_version.radio_cnf_patch_version == EXPECTED_RADIO_SETTINGS_VERSION.radio_cnf_patch_version
        ):
            return True
        else:
            if abort_on_incompatible_version is True:
                raise SystemExit(
                    f"Program aborted due to unexpected radio config version! ({detected_radio_cfg_version.radio_cnf_major_version}, {detected_radio_cfg_version.radio_cnf_minor_version}, {detected_radio_cfg_version.radio_cnf_patch_version})"
                )
        return False
    else:
        if abort_on_incompatible_version is True:
            raise SystemExit("Error in input radio cfg version!")
        return False
