#    Copyright 2024 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

import sys
import time
import math
from enum import IntEnum

import PCANBasic as pcan

# add software folder in path during runtime only
sys.path.insert(0, "./src")
sys.path.insert(0, "./src/drivers")
sys.path.insert(0, "./src/utilities")

import nxp_crc
import utilities.nxp_console_helpers as console
from utilities.nxp_decorators import frozen

class EnumPcanStatus(IntEnum):
    PCAN_STATUS_UNDEF = 0
    PCAN_STATUS_OK = 1
    PCAN_STATUS_WAITING = 5
    PCAN_STATUS_ERR_GENERAL = 2
    PCAN_STATUS_ERR_BAD_PARAM = 3
    PCAN_STATUS_ERR_TIMEOUT = 4


CAN_PADDING_BYTE_VALUE = 0xFF

class PcanDeviceManager:
    # gets the unique locations of connected PCAN devices
    def get_device_locations():

        # Checks if PCANBasic.dll is available, if not, the program terminates
        try:
            pcan_interface = pcan.PCANBasic()
        except:
            raise LookupError("Unable to find PCANBasic.dll library!")

        api_result = pcan_interface.LookUpChannel(b"devicetype=PCAN_USB")

        if api_result[0] != pcan.PCAN_ERROR_OK:
            6
            3

        handle = api_result[1]

        if handle == pcan.PCAN_NONEBUS:
            raise LookupError("Error creating PCAN handle for the found channel!")

        api_result = pcan_interface.GetValue(handle, pcan.PCAN_CHANNEL_FEATURES)

        if api_result[0] != pcan.PCAN_ERROR_OK:
            raise LookupError("There was an issue retrieving supported channel features")

        if (api_result[1] & pcan.FEATURE_FD_CAPABLE) != pcan.FEATURE_FD_CAPABLE:
            raise LookupError("Detected device is not CAN-FD capable!")

        return [handle.value]

@frozen
class PcanDevice:
    pcan_interface          = object
    device_id               = b""
    baudrate_bps            = 0
    max_can_payload_bytes   = None
    is_connected            = False
    handle                  = None
    is_fd                   = None

    def __init__(self, device_id, baudrate_bps: int, handle: int, max_can_payload_bytes: int,
                 is_fd: bool=True, use_extended_id: bool=True, enable_warnings: bool=True, en_fragmented_messages: bool=True) -> None:
        ## Checks if PCANBasic.dll is available, if not, the program terminates
        try:
            self.pcan_interface = pcan.PCANBasic()
        except:
            raise LookupError("Unable to find PCANBasic.dll library!")

        assert is_fd or max_can_payload_bytes <= 8, "Classical CAN supports maximum 8 payload bytes"
        assert max_can_payload_bytes <= 64, "CAN-FD supports a maximum of 64 payload bytes"

        self.device_id              = device_id
        self.baudrate_bps           = baudrate_bps
        self.max_can_payload_bytes  = max_can_payload_bytes
        self.is_connected           = False
        self.handle                 = handle
        self.is_fd                  = is_fd
        self.enable_warnings        = enable_warnings
        self.en_fragmented_messages = en_fragmented_messages

        if use_extended_id:
            self.extended_id_bit    = pcan.PCAN_MESSAGE_EXTENDED.value
        else:
            self.extended_id_bit    = pcan.PCAN_MESSAGE_STANDARD.value

    # Opens the initialized device based on input parameters and the pre-initialized device_location
    def open(self):
        can_fd_bitrate_string = self.get_can_fd_bitrate_params(arbitration_freq_bps = self.baudrate_bps, data_freq_bps = self.baudrate_bps)
        if self.is_fd:
            api_result = self.pcan_interface.InitializeFD(self.handle, can_fd_bitrate_string)
        else:
            api_result = self.pcan_interface.Initialize(self.handle, pcan.PCAN_BAUD_1M)

        if api_result != pcan.PCAN_ERROR_OK:
            return EnumPcanStatus.PCAN_STATUS_ERR_GENERAL

        if self.extended_id_bit:
            pcan_mode = pcan.PCAN_MODE_EXTENDED
        else:
            pcan_mode = pcan.PCAN_MODE_STANDARD

        self.pcan_interface.FilterMessages(self.handle, 0x000, 0x7FF, pcan_mode)
        if api_result != pcan.PCAN_ERROR_OK:
            return EnumPcanStatus.PCAN_STATUS_ERR_GENERAL

        self.pcan_interface.Reset(self.handle)

        self.is_connected = True
        return EnumPcanStatus.PCAN_STATUS_OK

    def close(self):
        self.pcan_interface.Uninitialize(pcan.PCAN_NONEBUS)
        self.is_connected = False
        return EnumPcanStatus.PCAN_STATUS_OK

    def transmit_uci_message(self, uci_message: list[int], append_crc: bool=False, timeout_ms: int=500) -> list[EnumPcanStatus | list[int] | bool]:

        def transmit_CAN_message(uci_fragment: list[int]):
            assert uci_fragment is not None, "uci_message shall not be empty"
            assert len(uci_fragment) <= 8, "Fragmentation failed: Classic CAN messages have a maximum length of 8 bytes"

            msgCanMessage           = pcan.TPCANMsg()
            msgCanMessage.ID        = self.device_id
            msgCanMessage.LEN       = len(uci_fragment)
            msgCanMessage.MSGTYPE   = self.extended_id_bit

            # Assign and pad CAN message buffer
            for i in range(8):
                if i < len(uci_fragment):
                    msgCanMessage.DATA[i] = uci_fragment[i]
                else:
                    msgCanMessage.DATA[i] = CAN_PADDING_BYTE_VALUE

            # Transfer and process resulting status
            status_pcan_api = self.pcan_interface.Write(self.handle, msgCanMessage)

            match status_pcan_api:
                case pcan.PCAN_ERROR_OK:
                    status              = EnumPcanStatus.PCAN_STATUS_OK
                    transmitted_data    = list(msgCanMessage.DATA[0:len(uci_fragment)])

                case _:
                    status              = EnumPcanStatus.PCAN_STATUS_ERR_GENERAL
                    transmitted_data    = None
                    if self.enable_warnings:
                        console.print(f"PCAN error code: {status_pcan_api}", console.StrColor.RED)

            return [status, transmitted_data]

        def transmit_CAN_FD_message(uci_fragment: list[int]):
            assert uci_fragment is not None, "uci_message shall not be empty"
            assert len(uci_fragment) <= 64, "Fragmentation failed: CAN-FD messages have a maximum length of 64 bytes"

            msgCanMessageFD         = pcan.TPCANMsgFD()
            msgCanMessageFD.ID      = self.device_id
            msgCanMessageFD.DLC     = self.encode_fd_dlc(len(uci_fragment))
            msgCanMessageFD.MSGTYPE = self.extended_id_bit | pcan.PCAN_MESSAGE_FD.value | pcan.PCAN_MESSAGE_BRS.value

            # Assign and pad CAN message buffer
            for i in range(self.decode_fd_dlc(msgCanMessageFD.DLC)):
                if i < len(uci_fragment):
                    msgCanMessageFD.DATA[i] = uci_fragment[i]
                else:
                    msgCanMessageFD.DATA[i] = CAN_PADDING_BYTE_VALUE

            # Transfer and process resulting status
            status_pcan_api = self.pcan_interface.WriteFD(self.handle, msgCanMessageFD)

            match status_pcan_api:
                case pcan.PCAN_ERROR_OK:
                    status              = EnumPcanStatus.PCAN_STATUS_OK
                    transmitted_data    = list(msgCanMessageFD.DATA[0:len(uci_fragment)])

                case _:
                    status              = EnumPcanStatus.PCAN_STATUS_ERR_GENERAL
                    transmitted_data    = None
                    if self.enable_warnings:
                        console.print(f"PCAN error code: {status_pcan_api}", console.StrColor.RED)

            return [status, transmitted_data]

        uci_message         = list(uci_message)

        # Append CRC16 if required
        if append_crc:
            crc         = nxp_crc.calculate_crc(frame=uci_message)
            uci_message = uci_message + crc.to_bytes(length=2, byteorder="little", signed=False)


        if self.is_fd:
            max_can_message_len = 64
        else:
            max_can_message_len = 8

        uci_fragments       = []

        if not self.en_fragmented_messages:
            uci_fragments.append(uci_message)

        else:
            uci_message_len     = len(uci_message)
            uci_header_len      = 4
            uci_payload_len     = uci_message_len - uci_header_len
            max_payload_len     = max_can_message_len - uci_header_len

            num_fragments       = max(math.ceil(uci_payload_len / max_payload_len), 1)
            last_payload_len    = uci_payload_len - (num_fragments - 1) * max_payload_len

            header_with_pbf     = [uci_message[0] | 0x10, uci_message[1], max_payload_len >> 8 & 0xFF, max_payload_len & 0xFF]
            header_without_pbf  = [uci_message[0] & 0xEF, uci_message[1], last_payload_len >> 8 & 0xFF, last_payload_len & 0xFF]

            for i in range(num_fragments):
                payload_start_idx   = uci_header_len + i * max_payload_len
                payload_end_idx     = min(payload_start_idx +  max_payload_len, uci_message_len)

                if i + 1 < num_fragments:
                    curr_header = header_with_pbf
                else:
                    curr_header = header_without_pbf

                curr_fragment       = curr_header + uci_message[payload_start_idx : payload_end_idx]
                uci_fragments.append(curr_fragment)


        for uci_fragment in uci_fragments:

            if self.is_fd:
                [status, transmitted_data] = transmit_CAN_FD_message(uci_fragment)

            else:
                [status, transmitted_data] = transmit_CAN_message(uci_fragment)

            time.sleep(0.001)

            is_crc_valid    = None                  # Implemented for compatibility with nxp_ft4222, serves no real purpose

        return [status, uci_message, uci_fragments, is_crc_valid]


    def receive_uci_message(self, timeout_ms: int=500, crc_enable=False) -> list[EnumPcanStatus | list[int] | int]:

        def receive_CAN_message():
            response_pcan_api   = self.pcan_interface.Read(self.handle)
            status_pcan_api     = response_pcan_api[0]

            match status_pcan_api:
                case pcan.PCAN_ERROR_OK:
                    status          = EnumPcanStatus.PCAN_STATUS_OK
                    received_data   = list(response_pcan_api[1].DATA[0:response_pcan_api[1].LEN])

                case pcan.PCAN_ERROR_QRCVEMPTY:
                    status          = EnumPcanStatus.PCAN_STATUS_WAITING
                    received_data   = None

                case _:
                    status          = EnumPcanStatus.PCAN_STATUS_ERR_GENERAL
                    received_data   = None
                    if self.enable_warnings:
                        console.print("PCAN error: " + status.name, console.StrColor.RED)

            message_id  = response_pcan_api[1].ID
            return [status, received_data, message_id]

        def receive_CAN_FD_message():
            response_pcan_api   = self.pcan_interface.ReadFD(self.handle)
            status_pcan_api     = response_pcan_api[0]

            match status_pcan_api:
                case pcan.PCAN_ERROR_OK:
                    status          = EnumPcanStatus.PCAN_STATUS_OK
                    received_data   = list(response_pcan_api[1].DATA[0:self.decode_fd_dlc(response_pcan_api[1].DLC)])

                case pcan.PCAN_ERROR_QRCVEMPTY:
                    status          = EnumPcanStatus.PCAN_STATUS_WAITING
                    received_data   = None

                case pcan.PCAN_ERROR_BUSWARNING | pcan.PCAN_ERROR_BUSLIGHT | pcan.PCAN_ERROR_BUSHEAVY | pcan.PCAN_ERROR_BUSPASSIVE:
                    status          = EnumPcanStatus.PCAN_STATUS_WAITING
                    received_data   = None

                case 0x40008:
                    status          = EnumPcanStatus.PCAN_STATUS_WAITING
                    received_data   = None

                case _:
                    status          = EnumPcanStatus.PCAN_STATUS_ERR_GENERAL
                    received_data   = None

                    if self.enable_warnings:
                        console.print("PCAN error: " + status.name, console.StrColor.RED)

            message_id = response_pcan_api[1].ID
            return [status, received_data, message_id]

        message_id      = None
        timeout_sec     = timeout_ms / 1000

        final_received  = False
        start           = time.perf_counter()

        uci_fragments   = []
        uci_header      = []
        uci_payload     = []

        # Receive message(s)
        while not final_received:

            # Check timeout, if enabled
            if timeout_ms != 0 and start + timeout_sec >= time.perf_counter():
                status      = EnumPcanStatus.PCAN_STATUS_ERR_TIMEOUT
                uci_payload = None
                return [status, uci_payload, uci_fragments, message_id]

            # Try to receive a message
            if self.is_fd:
                [status, received_data_fragment, message_id_new] = receive_CAN_FD_message()

            else:
                [status, received_data_fragment, message_id_new] = receive_CAN_message()


            # Proceed according to status
            match status:
                case EnumPcanStatus.PCAN_STATUS_ERR_GENERAL:
                    status      = EnumPcanStatus.PCAN_STATUS_ERR_GENERAL
                    uci_payload = None
                    return [status, uci_payload, uci_fragments, message_id]

                case EnumPcanStatus.PCAN_STATUS_WAITING:
                    pass

                case EnumPcanStatus.PCAN_STATUS_OK:
                    # Check if message ID is consistent
                    if message_id is not None and not message_id == message_id_new:
                        assert False, "Fragmented message was interrupted by a new message. This is currently not supported."

                    message_id = message_id_new

                    uci_fragments.append(received_data_fragment)

                    uci_header      = received_data_fragment[0:4]
                    uci_payload     = uci_payload + received_data_fragment[4:]

                    pbf             = (uci_header[0] & 0x10) >> 4
                    final_received  = not self.en_fragmented_messages or not pbf

                case _:
                    assert False, "Uncaught EnumPcanStatus. This point should never be reached"

        status = EnumPcanStatus.PCAN_STATUS_OK

        payload_len = len(uci_payload)
        uci_header  = [uci_header[0], uci_header[1], payload_len >> 8 & 0xFF, payload_len & 0xFF]
        uci_message = uci_header + uci_payload

        if crc_enable:
            received_crc = uci_message[-2] | (uci_message[-1] << 8)
            is_crc_valid = nxp_crc.is_crc_valid(uci_message[:-2], received_crc)     # Not returned, but kept for future integration

        return [status, uci_message, uci_fragments, message_id]




    #TODO: implement custom CAN frequency.
    #currently, settings for CAN-FD arbitration field  1Mbps and data rate 2Mbps bitrates are hard-coded
    def get_can_fd_bitrate_params(self, arbitration_freq_bps: int = 1e6, data_freq_bps: int = 2e6):
        arb_1mbps_data_2mbps = b'f_clock=80000000,nom_brp=10,nom_tseg1=5,nom_tseg2=2,nom_sjw=1,data_brp=4,data_tseg1=7,data_tseg2=2,data_sjw=1'
        arb_1mbps_data_5mbps = b'f_clock=80000000,nom_brp=10,nom_tseg1=5,nom_tseg2=2,nom_sjw=2,data_brp=1,data_tseg1=11,data_tseg2=4,data_sjw=4'
        return arb_1mbps_data_5mbps

    def encode_fd_dlc(self, data_length_bytes):
        dlc = 0

        if data_length_bytes <= 8:
            dlc = data_length_bytes
        elif data_length_bytes <= 12:
            dlc = 9
        elif data_length_bytes <= 16:
            dlc = 10
        elif data_length_bytes <= 20:
            dlc = 11
        elif data_length_bytes <= 24:
            dlc = 12
        elif data_length_bytes <= 32:
            dlc = 13
        elif data_length_bytes <= 48:
            dlc = 14
        else:
            dlc = 15

        return dlc

    def decode_fd_dlc(self, dlc):
        data_length_bytes = 0

        if dlc <= 8:
            data_length_bytes = dlc
        elif dlc == 9:
            data_length_bytes = 12
        elif dlc == 10:
            data_length_bytes = 16
        elif dlc == 11:
            data_length_bytes = 20
        elif dlc == 12:
            data_length_bytes = 24
        elif dlc == 13:
            data_length_bytes = 32
        elif dlc == 14:
            data_length_bytes = 48
        else:
            data_length_bytes = 64

        return data_length_bytes


if __name__ == "__main__":
    pcan_device_locations = PcanDeviceManager.get_device_locations()