#    Copyright 2023 NXP

#    Disclaimer
#    1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#       warranties of any kind. NXP makes no warranties to Licensee and shall not
#       indemnify Licensee or hold it harmless for any reason related to the NXP
#       Software/Source Code or otherwise be liable to the NXP customer. The NXP
#       customer acknowledges and agrees that the NXP Software/Source Code is
#       provided AS-IS and accepts all risks of utilizing the NXP Software under
#       the conditions set forth according to this disclaimer.

#    2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#       BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#       FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#       RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#       SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#       INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#       RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#       CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#       RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#       THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#       INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#       (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#       AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#       SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#       SUCH DAMAGES.

#    3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#       time, also without informing customer.

#    4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#       companies from and against any claims, suits, losses, damages,
#       liabilities, costs and expenses (including reasonable attorney's fees)
#       resulting from Licensee's and/or Licensee customer's/licensee's use of the
#       NXP Software/Source Code.

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from enum import IntEnum
from typing import List

from utilities.nxp_console_helpers import as_hex, class_to_str

### CONSTANTS ####################

FLASH_PAGE_SIZE = 4096

MANIFEST_HEADER_SIGNATURE_SIZE = 256
MANIFEST_HEADER_ORIGIN_ID_SIZE = 4
MANIFEST_HEADER_MANIFEST_VERSION_SIZE = 4
MANIFEST_HEADER_GENERATOR_VERSION_SIZE = 4
MANIFEST_HEADER_OPCODE_SIZE = 4
MANIFEST_HEADER_SIZE = (
    MANIFEST_HEADER_SIGNATURE_SIZE
    + MANIFEST_HEADER_ORIGIN_ID_SIZE
    + MANIFEST_HEADER_MANIFEST_VERSION_SIZE
    + MANIFEST_HEADER_GENERATOR_VERSION_SIZE
    + MANIFEST_HEADER_OPCODE_SIZE
)

CRYPTO_INFO_PAYLOAD_IV_SIZE = 16
CRYPTO_INFO_RFU_PAYLOAD_IV_SIZE = 16
CRYPTO_INFO_CEK_IV_SIZE = 16
CRYPTO_INFO_RFU_CEK_IV_SIZE = 16
CRYPTO_INFO_CEK_KEY_SIZE = 16
CRYPTO_INFO_RFU_CEK_KEY_SIZE = 16
CRYPTO_INFO_RFU_SIZE = 64
CRYPTO_INFO_SIZE = (
    CRYPTO_INFO_PAYLOAD_IV_SIZE
    + CRYPTO_INFO_RFU_PAYLOAD_IV_SIZE
    + CRYPTO_INFO_CEK_IV_SIZE
    + CRYPTO_INFO_RFU_CEK_IV_SIZE
    + CRYPTO_INFO_CEK_KEY_SIZE
    + CRYPTO_INFO_RFU_CEK_KEY_SIZE
    + CRYPTO_INFO_RFU_SIZE
)

BUNDLE_VERSION_SIZE = 16
BUNDLE_SECTOR_SIZE = 12
BUNDLE_SECTOR_ENTRY_COUNT = 8
BUNDLE_SECTOR_SIZE_TOTAL = BUNDLE_SECTOR_SIZE * BUNDLE_SECTOR_ENTRY_COUNT
BUNDLE_COMPONENT_SIZE = 88
BUNDLE_COMPONENT_ENTRY_COUNT = 16
BUNDLE_COMPONENT_SIZE_TOTAL = BUNDLE_COMPONENT_SIZE * BUNDLE_COMPONENT_ENTRY_COUNT
BUNDLE_APP_BOOT_ENTRY_SIZE = 4
BUNDLE_APP_BOOT_ENTRY_COUNT = 4
BUNDLE_APP_BOOT_ENTRY_SIZE_TOTAL = BUNDLE_APP_BOOT_ENTRY_SIZE * BUNDLE_APP_BOOT_ENTRY_COUNT
BUNDLE_HIF_BOOT_ENTRY_SIZE = 4
BUNDLE_HIF_BOOT_ENTRY_COUNT = 4
BUNDLE_HIF_BOOT_ENTRY_SIZE_TOTAL = BUNDLE_HIF_BOOT_ENTRY_SIZE * BUNDLE_HIF_BOOT_ENTRY_COUNT
BUNDLE_SIZE = (
    BUNDLE_VERSION_SIZE + BUNDLE_SECTOR_SIZE_TOTAL + BUNDLE_COMPONENT_SIZE_TOTAL + BUNDLE_APP_BOOT_ENTRY_SIZE_TOTAL + BUNDLE_HIF_BOOT_ENTRY_SIZE_TOTAL
)

SPECIAL_PAYLOAD_SIZE = 1600

RANDOM_PADDING_SIZE = 512

MANIFEST_SIZE = MANIFEST_HEADER_SIZE + CRYPTO_INFO_SIZE + BUNDLE_SIZE + SPECIAL_PAYLOAD_SIZE + RANDOM_PADDING_SIZE

##################################


@dataclass(order=True)
class Version:
    major_version: int = 0  # 4 bytes
    minor_version: int = 0  # 4 bytes
    patch_version: int = 0  # 4 bytes
    id: int | EnumNxpComponentId = 0  # 4 bytes

    def no_id_str(self):
        return f"{self.major_version}.{self.minor_version}.{self.patch_version}"

    def __str__(self):
        if isinstance(self.id, EnumNxpComponentId):
            return f"ID: {as_hex(self.id, prepend_bytes=2)} ({self.id.name}): {self.major_version}.{self.minor_version}.{self.patch_version}"
        elif self.id == 0x0457:
            return f"ID: {as_hex(self.id, prepend_bytes=2)} (NXP_BUNDLE_UPDATE): {self.major_version}.{self.minor_version}.{self.patch_version}"
        else:
            return f"ID: {as_hex(self.id, prepend_bytes=2)}: {self.major_version}.{self.minor_version}.{self.patch_version}"


class EnumOriginId(IntEnum):
    CUSTOMER = 0x00000002
    NXP = 0x00000004


class EnumOpCode(IntEnum):
    UPDATE_BUNDLE = 0x7C53
    DMT_INIT_TO_PROTECTED = 0x74F9
    DMT_PROTECTED_TO_INIT_NXP = 0xF14C
    DMT_PROTECTED_TO_INIT_USER = 0x6D9F
    DMT_TAMPERED_TO_PROTECTED_NXP = 0x6645
    DMT_TAMPERED_TO_PROTECTED_USER = 0xE298
    UPDATE_KEYSTORE = 0x5EEB


class EnumNxpComponentId(IntEnum):
    SWUP = 0x1EDB
    SBE = 0x583A
    DSP = 0x9199
    RADIO_CFG = 0xCAF8


class EnumSectorAttributes(IntEnum):
    """
    Enumeration of sector attributes.

    Methods:
        to_list(attributes: int) -> List[EnumSectorAttributes]: Converts the given attributes to a list of EnumSectorAttributes.
    """

    NONE = 0x0000  # no attributes
    SWUP = 0xA005  # SWUP attribute
    API = 0x500A  # API attribute
    ANY = 0xF00F  # any attribute

    @staticmethod
    def to_list(attributes: int) -> List[EnumSectorAttributes]:
        """
        Converts the given attributes to a list of EnumSectorAttributes.

        Args:
            attributes (int): The attributes to convert.

        Returns:
            List[EnumSectorAttributes]: The list of EnumSectorAttributes.
        """

        if attributes & EnumSectorAttributes.ANY == EnumSectorAttributes.ANY:
            return [EnumSectorAttributes.ANY]
        attribute_list = [attr for attr in EnumSectorAttributes if attr != EnumSectorAttributes.NONE and attributes & attr == attr]
        if not attribute_list:
            attribute_list.append(EnumSectorAttributes.NONE)
        return attribute_list


class EnumComponentAttributes(IntEnum):
    """
    Enum representing component attributes.

    Methods:
        to_list(attributes: int) -> List[EnumComponentAttributes]: Converts the given attributes to a list of EnumComponentAttributes.
    """

    CODE = 0x0550
    DATA = 0x0880
    ERASED = 0x2001
    CONSTANT = 0x4002

    @staticmethod
    def to_list(attributes: int) -> List[EnumComponentAttributes]:
        """
        Convert an integer value to a list of EnumComponentAttributes.

        Args:
            attributes (int): The integer value representing the attributes.

        Returns:
            List[EnumComponentAttributes]: The list of EnumComponentAttributes.
        """
        attribute_list = [attr for attr in EnumComponentAttributes if attributes & attr == attr]
        return attribute_list


@dataclass(order=True)
class SwupManifestHeader:
    """
    Represents the header of a SWUP manifest.

    Attributes:
        signature (List[int]): The signature of the manifest (256 bytes).
        origin_id (EnumOriginId): The origin ID of the manifest (4 bytes).
        manifest_version (Version): The version of the manifest (4 bytes).
        generator_version (Version): The version of the generator (4 bytes).
        opcode (EnumOpCode): The operation code of the manifest (4 bytes).
    """

    signature: List[int] = field(default_factory=list)  # 256 bytes
    origin_id: EnumOriginId = EnumOriginId.NXP  # 4 bytes
    manifest_version: Version = field(default_factory=Version)  # 4 bytes
    generator_version: Version = field(default_factory=Version)  # 4 bytes
    opcode: EnumOpCode = EnumOpCode.UPDATE_BUNDLE  # 4 bytes

    @classmethod
    def from_bytes(cls, bytes: List[int]) -> SwupManifestHeader:
        """
        Creates a `SwupManifestHeader` object from a list of bytes.

        Args:
            bytes (List[int]): The bytes representing the manifest header.

        Returns:
            SwupManifestHeader: The created `SwupManifestHeader` object.
        """
        manifest_header = cls()
        offset = 0
        manifest_header.signature = bytes[offset : offset + MANIFEST_HEADER_SIGNATURE_SIZE]
        offset += MANIFEST_HEADER_SIGNATURE_SIZE
        manifest_header.origin_id = EnumOriginId(
            int.from_bytes(bytes=bytes[offset : offset + MANIFEST_HEADER_ORIGIN_ID_SIZE], byteorder="little", signed=False)
        )
        offset += MANIFEST_HEADER_ORIGIN_ID_SIZE
        manifest_header.manifest_version = Version(
            id=int.from_bytes(bytes=bytes[offset : offset + 1], byteorder="little", signed=False),
            patch_version=int.from_bytes(bytes=bytes[offset + 1 : offset + 2], byteorder="little", signed=False),
            minor_version=int.from_bytes(bytes=bytes[offset + 2 : offset + 3], byteorder="little", signed=False),
            major_version=int.from_bytes(bytes=bytes[offset + 3 : offset + 4], byteorder="little", signed=False),
        )
        offset += MANIFEST_HEADER_MANIFEST_VERSION_SIZE
        manifest_header.generator_version = Version(
            id=int.from_bytes(bytes=bytes[offset : offset + 1], byteorder="little", signed=False),
            patch_version=int.from_bytes(bytes=bytes[offset + 1 : offset + 2], byteorder="little", signed=False),
            minor_version=int.from_bytes(bytes=bytes[offset + 2 : offset + 3], byteorder="little", signed=False),
            major_version=int.from_bytes(bytes=bytes[offset + 3 : offset + 4], byteorder="little", signed=False),
        )
        offset += MANIFEST_HEADER_GENERATOR_VERSION_SIZE
        manifest_header.opcode = EnumOpCode(
            int.from_bytes(bytes=bytes[offset : offset + MANIFEST_HEADER_OPCODE_SIZE], byteorder="little", signed=False)
        )
        offset += MANIFEST_HEADER_OPCODE_SIZE
        return manifest_header

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.signature = f"{as_hex(self.signature[:16])} ...\n                       {as_hex(self.signature[-16:])}"
        _self.origin_id = f"{self.origin_id.name} ({as_hex(self.origin_id.value, prepend_bytes=4)})"
        _self.manifest_version = self.manifest_version.no_id_str()
        _self.generator_version = self.generator_version.no_id_str()
        _self.opcode = f"{self.opcode.name} ({as_hex(self.opcode.value)})"
        return class_to_str(_self, include_title=False, indent_level=2)


@dataclass(order=True)
class SwupManifestCryptoInfo:
    """
    Represents the cryptographic information for a software update manifest.

    Attributes:
        payload_iv (List[int])
        cek_iv (List[int])
        cek_key (List[int])
    """

    payload_iv: List[int] = field(default_factory=list)
    cek_iv: List[int] = field(default_factory=list)
    cek_key: List[int] = field(default_factory=list)

    @classmethod
    def from_bytes(cls, bytes: List[int]) -> SwupManifestCryptoInfo:
        """
        Creates a `SwupManifestCryptoInfo` object from a list of bytes.

        Args:
            bytes: A list of bytes representing the cryptographic information.

        Returns:
            A `SwupManifestCryptoInfo` object.

        """
        crypto_info = cls()
        offset = 0
        crypto_info.payload_iv = bytes[offset : offset + CRYPTO_INFO_PAYLOAD_IV_SIZE]
        offset += CRYPTO_INFO_PAYLOAD_IV_SIZE
        offset += CRYPTO_INFO_RFU_PAYLOAD_IV_SIZE
        crypto_info.cek_iv = bytes[offset : offset + CRYPTO_INFO_CEK_IV_SIZE]
        offset += CRYPTO_INFO_CEK_IV_SIZE
        offset += CRYPTO_INFO_RFU_CEK_IV_SIZE
        crypto_info.cek_key = bytes[offset : offset + CRYPTO_INFO_CEK_KEY_SIZE]
        offset += CRYPTO_INFO_CEK_KEY_SIZE
        offset += CRYPTO_INFO_RFU_CEK_KEY_SIZE
        offset += CRYPTO_INFO_RFU_SIZE
        return crypto_info

    def __str__(self) -> str:
        return class_to_str(self, include_title=False, indent_level=2)


@dataclass(order=True)
class SwupSector:
    """
    Represents a sector in the SWUP (Software Update) process.

    Attributes:
        page_offset (int): The offset of the sector in pages.
        size (int): The size of the sector in bytes.
        attributes (List[EnumSectorAttributes]): The attributes of the sector.
    """

    page_offset: int
    size: int
    attributes: List[EnumSectorAttributes]

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.size = f"{self.size} ({as_hex(self.size, prepend_bytes=2)}) pages ({self.size * FLASH_PAGE_SIZE} bytes)"
        _self.attributes = str([attr.name for attr in self.attributes])
        return class_to_str(_self, include_title=True, indent_level=3)


@dataclass(order=True)
class SwupComponent:
    """
    Represents a software update component.

    Attributes:
        page_offset (int): The page offset of the component.
        size (int): The size of the component.
        attributes (List[EnumComponentAttributes]): The attributes of the component.
        version (Version): The version of the component.
        sha256 (List[int]): The SHA-256 hash of the component.
        data (List[int]): The data of the component.
    """

    page_offset: int
    size: int
    attributes: List[EnumComponentAttributes]
    version: Version
    sha256: List[int]
    data: List[int] = field(default_factory=list)

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.size = f"{self.size} ({as_hex(self.size, prepend_bytes=2)}) pages ({self.size * FLASH_PAGE_SIZE} bytes)"
        _self.attributes = str([attr.name for attr in self.attributes])
        _self.sha256 = f"{as_hex(self.sha256[:16])}\n                            {as_hex(self.sha256[-16:])}"
        _self.data = f"{as_hex(self.data[:16])} ...\n                          {as_hex(self.data[-16:])}" if self.data else []
        return class_to_str(_self, include_title=True, indent_level=3)


@dataclass(order=True)
class SwupBundle:
    """
    Represents a SWUP bundle.

    Attributes:
        version (Version): The version of the SWUP bundle.
        sector_table (List[SwupSector]): The sector table of the SWUP bundle.
        component_table (List[SwupComponent]): The component table of the SWUP bundle.
        app_boot_entries (List[int]): The app boot entries of the SWUP bundle.
        hif_boot_entries (List[int]): The hif boot entries of the SWUP bundle.
    """

    version: Version = field(default_factory=Version)
    sector_table: List[SwupSector] = field(default_factory=list)
    component_table: List[SwupComponent] = field(default_factory=list)
    app_boot_entries: List[int] = field(default_factory=list)
    hif_boot_entries: List[int] = field(default_factory=list)

    @classmethod
    def from_bytes(cls, bytes: List[int]) -> SwupBundle:
        """
        Creates a SwupBundle object from a list of bytes.

        Args:
            bytes (List[int]): The list of bytes representing the SWUP bundle.

        Returns:
            SwupBundle: The SwupBundle object created from the bytes.
        """
        bundle = cls()
        offset = 0
        # add version
        bundle.version = Version(
            major_version=int.from_bytes(bytes=bytes[offset : offset + 4], byteorder="little", signed=False),
            minor_version=int.from_bytes(bytes=bytes[offset + 4 : offset + 8], byteorder="little", signed=False),
            patch_version=int.from_bytes(bytes=bytes[offset + 8 : offset + 12], byteorder="little", signed=False),
            id=int.from_bytes(bytes=bytes[offset + 12 : offset + 16], byteorder="little", signed=False),
        )
        offset += BUNDLE_VERSION_SIZE
        # add sector table
        bundle.sector_table = []
        for index in range(BUNDLE_SECTOR_ENTRY_COUNT):
            sector = SwupSector(
                page_offset=int.from_bytes(bytes=bytes[offset : offset + 2], byteorder="little", signed=False),
                size=int.from_bytes(bytes=bytes[offset + 2 : offset + 4], byteorder="little", signed=False),
                attributes=EnumSectorAttributes.to_list(int.from_bytes(bytes=bytes[offset + 4 : offset + 6], byteorder="little", signed=False)),
            )
            bundle.sector_table.append(sector)
            offset += BUNDLE_SECTOR_SIZE

        # add component table
        bundle.component_table = []
        for index in range(BUNDLE_COMPONENT_ENTRY_COUNT):
            component = SwupComponent(
                page_offset=int.from_bytes(bytes=bytes[offset : offset + 2], byteorder="little", signed=False),
                size=int.from_bytes(bytes=bytes[offset + 2 : offset + 4], byteorder="little", signed=False),
                attributes=EnumComponentAttributes.to_list(int.from_bytes(bytes=bytes[offset + 4 : offset + 6], byteorder="little", signed=False)),
                version=Version(
                    major_version=int.from_bytes(bytes=bytes[offset + 8 : offset + 12], byteorder="little", signed=False),
                    minor_version=int.from_bytes(bytes=bytes[offset + 12 : offset + 16], byteorder="little", signed=False),
                    patch_version=int.from_bytes(bytes=bytes[offset + 16 : offset + 20], byteorder="little", signed=False),
                    id=int.from_bytes(bytes=bytes[offset + 20 : offset + 24], byteorder="little", signed=False),
                ),
                sha256=bytes[offset + 24 : offset + 56],
                data=[],
            )
            # try to map id to NXP component ID
            component.version.id = (
                EnumNxpComponentId(component.version.id) if component.version.id in EnumNxpComponentId._value2member_map_ else component.version.id
            )

            bundle.component_table.append(component)
            offset += BUNDLE_COMPONENT_SIZE

        # add app boot entries
        for index in range(BUNDLE_APP_BOOT_ENTRY_COUNT):
            bundle.app_boot_entries.append(
                int.from_bytes(
                    bytes=bytes[
                        offset + (index * BUNDLE_APP_BOOT_ENTRY_SIZE) : offset + (index * BUNDLE_APP_BOOT_ENTRY_SIZE) + BUNDLE_APP_BOOT_ENTRY_SIZE
                    ],
                    byteorder="little",
                    signed=False,
                )
            )
        offset += BUNDLE_APP_BOOT_ENTRY_SIZE_TOTAL

        # add hif boot entries
        for index in range(BUNDLE_HIF_BOOT_ENTRY_COUNT):
            bundle.hif_boot_entries.append(
                int.from_bytes(
                    bytes=bytes[
                        offset + (index * BUNDLE_HIF_BOOT_ENTRY_SIZE) : offset + (index * BUNDLE_HIF_BOOT_ENTRY_SIZE) + BUNDLE_HIF_BOOT_ENTRY_SIZE
                    ],
                    byteorder="little",
                    signed=False,
                )
            )
        offset += BUNDLE_HIF_BOOT_ENTRY_SIZE_TOTAL
        return bundle

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.app_boot_entries = as_hex(self.app_boot_entries, prepend_bytes=4)
        _self.hif_boot_entries = as_hex(self.hif_boot_entries, prepend_bytes=4)
        return class_to_str(_self, include_title=False, indent_level=2)


@dataclass(order=True)
class SwupManifest:
    """
    Represents a software update manifest.

    Attributes:
        manifest_header (SwupManifestHeader): The header of the manifest.
        crypto_info (SwupManifestCryptoInfo): The cryptographic information of the manifest.
        bundle (SwupBundle): The software bundle included in the manifest.
        special_update_payload (List[int]): The special update payload.
        random_padding (List[int]): The random padding.

    Methods:
        from_bytes(bytes: List[int]) -> SwupManifest: Creates a SwupManifest object from a byte array.
    """

    manifest_header: SwupManifestHeader = field(default_factory=SwupManifestHeader)
    crypto_info: SwupManifestCryptoInfo = field(default_factory=SwupManifestCryptoInfo)
    bundle: SwupBundle = field(default_factory=SwupBundle)
    special_update_payload: List[int] = field(default_factory=list)
    random_padding: List[int] = field(default_factory=list)

    @classmethod
    def from_bytes(cls, bytes: List[int]) -> SwupManifest:
        """
        Creates a SwupManifest object from a byte array.

        Args:
            bytes (List[int]): The byte array representing the manifest.

        Returns:
            SwupManifest: The SwupManifest object created from the byte array.
        """
        manifest = cls()
        offset = 0
        manifest.manifest_header = SwupManifestHeader.from_bytes(bytes=bytes[offset : offset + MANIFEST_HEADER_SIZE])
        offset += MANIFEST_HEADER_SIZE
        manifest.crypto_info = SwupManifestCryptoInfo.from_bytes(bytes=bytes[offset : offset + CRYPTO_INFO_SIZE])
        offset += CRYPTO_INFO_SIZE
        manifest.bundle = SwupBundle.from_bytes(bytes=bytes[offset : offset + BUNDLE_SIZE])
        offset += BUNDLE_SIZE
        manifest.special_update_payload = bytes[offset : offset + SPECIAL_PAYLOAD_SIZE]
        offset += SPECIAL_PAYLOAD_SIZE
        manifest.random_padding = bytes[offset : offset + RANDOM_PADDING_SIZE]
        offset += RANDOM_PADDING_SIZE
        return manifest

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.special_update_payload = (
            f"{as_hex(self.special_update_payload[:16])} ...\n                                {as_hex(self.special_update_payload[-16:])}"
        )
        _self.random_padding = f"{as_hex(self.random_padding[:16])} ...\n                        {as_hex(self.random_padding[-16:])}"

        return class_to_str(_self, include_title=False, indent_level=1)


@dataclass(order=True)
class SwupPackage:
    """
    Represents a software update package.

    Attributes:
        manifest (SwupManifest): The manifest of the software update package.
        components_data (List[int]): The data of the components in the software update package.
    """

    manifest: SwupManifest
    components_data: List[int]

    def __post_init__(self):
        """
        Performs post-initialization tasks after the object is created.

        This method checks if the length of the components data matches the total lengths of individual components in the bundle component table.
        It then adds the actual component data to each component in the bundle.

        Raises:
            ValueError: If the length of the components data does not match the total lengths of individual components in the bundle component table,
                        or if the length of a component's data does not match its length in the bundle component table.
        """
        component_sizes = [self.manifest.bundle.component_table[index].size * FLASH_PAGE_SIZE for index in range(BUNDLE_COMPONENT_ENTRY_COUNT)]

        if len(self.components_data) != sum(component_sizes):
            raise ValueError(
                f"The length of the all components data ({len(self.components_data)}) does not match the total lengths of individual components in the bundle component table ({sum(component_sizes)})."
            )

        # add actual component data
        byte_offset_in_comp_data = 0
        for component in self.manifest.bundle.component_table:
            if component.size != 0 and len(component.attributes) != 0:
                component.data = self.components_data[byte_offset_in_comp_data : byte_offset_in_comp_data + (component.size * FLASH_PAGE_SIZE)]
                if len(component.data) != (component.size * FLASH_PAGE_SIZE):
                    raise ValueError(
                        f"The length of the component data ({len(component.data)}) of component ({component.page_offset}) does not match its length in the bundle component table ({sum(component.size * FLASH_PAGE_SIZE)})."
                    )
                byte_offset_in_comp_data += component.size * FLASH_PAGE_SIZE

    @classmethod
    def from_bytes(cls, byte_stream: List[int]) -> SwupPackage:
        """
        Creates a SwupPackage instance from a byte stream.

        Args:
            byte_stream (List[int]): The byte stream representing the SwupPackage.

        Returns:
            SwupPackage: The SwupPackage instance.
        """
        manifest_bytes = byte_stream[:MANIFEST_SIZE]
        components_data = byte_stream[MANIFEST_SIZE:]

        # create manifest
        manifest = SwupManifest.from_bytes(bytes=manifest_bytes)

        # add component data based on manifest component table
        swup_package = cls(manifest=manifest, components_data=components_data)

        return swup_package

    def __str__(self) -> str:
        _self = deepcopy(self)
        _self.components_data = f"{as_hex(self.components_data[:16])} ...\n                         {as_hex(self.components_data[-16:])}"
        return class_to_str(_self, include_title=True, indent_level=0)
