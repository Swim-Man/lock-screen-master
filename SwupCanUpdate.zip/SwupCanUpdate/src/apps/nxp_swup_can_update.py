import logging
import os
import sys
import tqdm
import time
from enum import IntEnum
from pathlib import Path

# Add folders in path during runtime only
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "./../../src")
sys.path.insert(0, "./../../src/drivers")
sys.path.insert(0, "./../../src/utilities")

import utilities.nxp_console_helpers as console
from drivers.nxp_pcan_device import (
    EnumPcanStatus,
    PcanDevice,
    PcanDeviceManager,
)

from drivers.nxp_ncj29d6_swup import SwupPackage
import drivers.nxp_uci as uci

############################################################################
# CONFIGURATIONS
############################################################################
# SWUP settings

SWUP_PKGS_DICT  = { "APP_UPDATE_toApp1_usingHIF1"         : ["swup_package_generator/binaries/App1_HifA1_HifB1.pkg"],
                    "APP_UPDATE_toApp2_usingHIF1"         : ["swup_package_generator/binaries/App2_HifA1_HifB1.pkg"],
                    "NDP_UPDATE_withApp1update_usingHIF1" : ["swup_package_generator/binaries/NCJ29D6 NDP.pkg",
                                                             "swup_package_generator/binaries/App1_HifA1_HifB1.pkg"],
                    "NDP_UPDATE_withApp2update_usingHIF1" : ["swup_package_generator/binaries/NCJ29D6 NDP.pkg",
                                                             "swup_package_generator/binaries/App2_HifA1_HifB1.pkg"],
                    "HIF_UPDATE_fromHif1_toHif2"          : ["swup_package_generator/binaries/App1_HifA1_HifB1.pkg",
                                                             "swup_package_generator/binaries/App1_HifB2_HifA1_transition.pkg",
                                                             "swup_package_generator/binaries/App1_HifA2_HifB2.pkg"],

                    "APP_UPDATE_toApp1_usingHIF2"         : ["swup_package_generator/binaries/App1_HifA2_HifB2.pkg"],
                    "APP_UPDATE_toApp2_usingHIF2"         : ["swup_package_generator/binaries/App2_HifA2_HifB2.pkg"],
                    "NDP_UPDATE_withApp1update_usingHIF2" : ["swup_package_generator/binaries/NCJ29D6 NDP.pkg",
                                                             "swup_package_generator/binaries/App1_HifA2_HifB2.pkg"],
                    "NDP_UPDATE_withApp2update_usingHIF2" : ["swup_package_generator/binaries/NCJ29D6 NDP.pkg",
                                                             "swup_package_generator/binaries/App2_HifA2_HifB2.pkg"],
                    "HIF_UPDATE_fromHif2_toHif1"          : ["swup_package_generator/binaries/App1_HifA2_HifB2.pkg",
                                                             "swup_package_generator/binaries/App1_HifB1_HifA2_transition.pkg",
                                                             "swup_package_generator/binaries/App1_HifA1_HifB1.pkg"],
                    # App update App1 to App2
                    "TEST_SERIES_01_startAtApp1HIF1"      : ["swup_package_generator/binaries/update_package_SR14p0_MAC_CAN.pkg",]}

SWUP_SELECTED_UPDATE    = "TEST_SERIES_01_startAtApp1HIF1"     # Selected update procedure from above

SWUP_KEYSTORE_LOCATION  = 0x00000000    # 0 = NULL = Transport Keys, otherwise interpret this parameter as address in user-domain flash and read the key store from there.

# CAN interface settings
SPI_TIMEOUT_MS = 500
CAN_TIMEOUT_MS = 0  # Timeout for responses and notifications (in milliseconds). Set to 0 for no timeouts
CAN_IS_FD = True  # Enables CAN-FD. Otherwise: Classic CAN
CAN_USE_EXTENDED_ID = False  # If true, a 29-bit ID field is used. If false, an 11-bit ID field is used
CAN_MAX_PAYLOAD = 64  # Maximum payload for one CAN message (in bytes)

CAN_DEVICES = {
    0: 0x02,
    1: 0x04,
    2: 0x06,
    3: 0x08,
    4: 0x0A,
    5: 0x0C,
    6: 0x0E,
    7: 0x10,
    8: 0x12,
    "SWUP": 0x61
}
CAN_DEVICE_ID = CAN_DEVICES[8]  # CAN device ID(0x12) of the PCAN
CAN_DEVICE_SWUP_ID = CAN_DEVICES["SWUP"]
# Script behavior settings
NO_RESET                = False         # Disables initial IC resets when SWUP is already active (in order to maintain attachment to a debugger)
MODE_STEP_BY_STEP       = False         # Requests keyboard inputs between SWUP steps, if true
PRINT_FULL_SWUP_CONTENT = False         # Prints full SWUP package content, if true
SILENT_SWUP_STATE       = False         # Prints only the retrieved SWUP state, if true (and not the command, response and notification)

############################################################################
# INITIALIZE LOGGING
############################################################################
logger = console.create_logger(
    log_path="logs/",
    log_filename="logs/nxp_main_ncj29d6_aio_uwbmac_check_versions.log",
    backup_count=3,
    level_log=logging.DEBUG,
    level_console=logging.OK,
)

############################################################################

class EnumSwupState(IntEnum):
    """ SWUP state codes
        Defined by NCJ29D6 Foundation
    """
    SWUP_STATE_ACTIVE           = 0x06
    SWUP_STATE_TRANSFER         = 0x09
    SWUP_STATE_ERROR            = 0x0A

class EnumGid(IntEnum):
    """ Global identification codes
        Must be the same IDs that are used by SwupCanHostif (onic) and SwupCanActivator (onic)
    """
    GID_GENERIC                 = 0x00      # GID for generic activities
    GID_CUSTOM                  = 0x0E      # GID for application activities (to activate SWUP)
    GID_SWUPHIF                 = 0x0F      # GID for SWUP HIF activities

class EnumSwupHifVersionIds(IntEnum):
    """ SWUP HIF version IDs
        Must be the same IDs that are used by SwupCanHostif (onic) and by the SWUP descriptor file
    """
    SWUPHIF_VERSIONID_A         = 0xF00A
    SWUPHIF_VERSIONID_B         = 0xF00B
    SWUPHIF_VERSIONID_UNDEF     = 0xFFFF

class EnumSwupHifOid(IntEnum):
    """ SWUP HIF opcode IDs
        Must be the same IDs that are used by SwupCanHostif (onic)
    """
    SWUPHIF_OID_REBOOT_STATUS           = 0x01
    SWUPHIF_OID_GET_VERSION             = 0x02
    SWUPHIF_OID_TRANSER_MANIFEST        = 0x07
    SWUPHIF_OID_BUFFER_COMPONENT        = 0x08
    SWUPHIF_OID_START_UPDATE            = 0x0A
    SWUPHIF_OID_START_BUFFERED_UPDATE   = 0x0B
    SWUPHIF_OID_TRANSFER_COMPONENT      = 0x10
    SWUPHIF_OID_VERIFY_COMPONENT        = 0x11
    SWUPHIF_OID_VERIFY_ALL              = 0x12
    SWUPHIF_OID_FINISH_UPDATE           = 0x1A
    SWUPHIF_OID_DEACTIVATE              = 0x1B
    SWUPHIF_OID_SELECT_KEY_STORE        = 0x1C
    SWUPHIF_OID_GET_STATE               = 0x1D

class EnumSwupActivatorAppOid(IntEnum):
    """ SWUP Activator App opcode IDs
        Must be the same IDs that are used by SwupCanActivator (onic)
    """
    SWUPACTAPP_OID_ACTIVATE_SWUP        = 0x12

def print_pcan(pcan_status: EnumPcanStatus, silent: bool=False) -> str:
    if pcan_status == EnumPcanStatus.PCAN_STATUS_OK:
        pcan = f"\033[92mOK\033[0m"
    else:
        pcan = f"\033[91mNOT OK: {pcan_status.name}\033[0m"

    if not silent: print(f"PCAN: {pcan}")
    return pcan


def print_cmd_pcan(pcan_status: EnumPcanStatus, uci_fragments: list[list[int]], silent: bool=False) -> str:
    if len(uci_fragments) == 1:
        if not silent:  console.print_hex(uci_fragments[0])
    else:
        if not silent:  console.print(f"{console.as_hex(uci_fragments[0])} ... {console.as_hex(uci_fragments[-1])} ({len(uci_fragments)} fragments)")

    if pcan_status == EnumPcanStatus.PCAN_STATUS_OK:
        pcan = f"\033[92mOK\033[0m"
    else:
        pcan = f"\033[91mNOT OK: {pcan_status.name}\033[0m"

    if not silent: print(f"PCAN: {pcan}")
    return pcan


def print_cmd_pcan_api(pcan_status: EnumPcanStatus, uci_fragments: list[list[int]], silent: bool=False) -> str:
    if len(uci_fragments) == 1:
        if not silent:  console.print_hex(uci_fragments[0])
    else:
        if not silent:  console.print(f"{console.as_hex(uci_fragments[0])} ... {console.as_hex(uci_fragments[-1])} ({len(uci_fragments)} fragments)")

    if pcan_status == EnumPcanStatus.PCAN_STATUS_OK:
        pcan = f"\033[92mOK\033[0m"
    else:
        pcan = f"\033[91mNOT OK: {pcan_status.name}\033[0m"

    if uci.EnumUciStatus(uci_fragments[0][4]) == uci.EnumUciStatus.UCI_STATUS_OK:
        api = f"\033[92mOK\033[0m"
    else:
        api = f"\033[91mNOT OK: {uci.EnumUciStatus(uci_fragments[0][4]).name}\033[0m"

    if not silent: console.print(f"PCAN: {pcan}, API: {api}")
    return pcan, api


def swup_uci_get_swup_state(pcan_device: PcanDevice, silent: bool=True) -> EnumSwupState:
    CMD_SWUP_GET_STATE = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_GET_STATE.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    if not silent:  console.print("Transmitting command CMD_SWUP_GET_STATE:")
    pcan_status, cmd_get_swup_state, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_GET_STATE)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments, silent)

    if not silent:  console.print("Receiving response to command:")
    pcan_status, rsp_get_swup_state, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments, silent)

    if not silent:  console.print("Receiving notification to command:")
    pcan_status, ntf_get_swup_state, ntf_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, ntf_fragments, silent)

    swup_state_code = ntf_get_swup_state[4]
    a_dict          = {i.value: i.name for i in EnumSwupState}
    console.print(f"SWUP State: {a_dict[swup_state_code]}")

    return EnumSwupState(swup_state_code)


def swup_uci_get_swup_version(pcan_device: PcanDevice) -> None:
    CMD_SWUP_GET_VERSION = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_GET_VERSION.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_GET_VERSION:")
    pcan_status, cmd_get_swup_version, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_GET_VERSION)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_get_swup_version, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)

    console.print("Receiving notification to command:")
    pcan_status, ntf_get_swup_version, ntf_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, ntf_fragments)

    major   = sum([ntf_get_swup_version[4  + i] << (8 * i) for i in range(3)])
    minor   = sum([ntf_get_swup_version[8  + i] << (8 * i) for i in range(3)])
    patch   = sum([ntf_get_swup_version[12 + i] << (8 * i) for i in range(3)])
    ver_id  = sum([ntf_get_swup_version[16 + i] << (8 * i) for i in range(3)])
    console.print(f"SWUP Core Version: {major}.{minor}.{patch} (ID: {ver_id})")

    major   = sum([ntf_get_swup_version[20 + i] << (8 * i) for i in range(3)])
    minor   = sum([ntf_get_swup_version[24 + i] << (8 * i) for i in range(3)])
    patch   = sum([ntf_get_swup_version[28 + i] << (8 * i) for i in range(3)])
    ver_id  = sum([ntf_get_swup_version[32 + i] << (8 * i) for i in range(3)])
    console.print(f"SWUP Version:      {major}.{minor}.{patch} (ID: {ver_id})")


def swup_uci_select_keystore(pcan_device: PcanDevice, key_store_location: int) -> None:
    key_store_location_array = key_store_location.to_bytes(4,byteorder='little')
    key_store_location_array = list(key_store_location_array)

    CMD_SWUP_SELECT_KEY_STORE = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_SELECT_KEY_STORE.value,
        payload_length          = 4,
        payload                 = key_store_location_array
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_SELECT_KEY_STORE:")
    pcan_status, cmd_swup_select_key_store, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_SELECT_KEY_STORE)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_select_key_store, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)


def swup_uci_transfer_manifest(pcan_device: PcanDevice, swup_pkg_byte_list: list[int]) -> None:
    CMD_SWUP_TRANSFER_MANIFEST_LONG = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_TRANSER_MANIFEST.value,
        payload_length          = 4096,
        payload                 = swup_pkg_byte_list[:4096]
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_TRANSFER_MANIFEST_LONG:")
    pcan_status, cmd_swup_transfer_manifest, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_TRANSFER_MANIFEST_LONG)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_transfer_manifest, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)


def swup_uci_start_update(pcan_device: PcanDevice) -> None:
    CMD_SWUP_START_UPDATE = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_START_UPDATE.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_START_UPDATE:")
    pcan_status, cmd_swup_start_update, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_START_UPDATE)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_start_update, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)

    if uci.EnumUciStatus(rsp_fragments[0][4]) != uci.EnumUciStatus.UCI_STATUS_OK:
        console.print(f"\033[91mStarting the SWUP update has failed\033[0m")
        console.print("Exiting program...", console.StrColor.RED)
        exit()


def swup_uci_start_buffered_update(pcan_device: PcanDevice) -> None:
    CMD_SWUP_START_BUFFERED_UPDATE = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_START_BUFFERED_UPDATE.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_START_BUFFERED_UPDATE:")
    pcan_status, cmd_swup_start_buffered_update, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_START_BUFFERED_UPDATE)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_start_buffered_update, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)

    if uci.EnumUciStatus(rsp_fragments[0][4]) != uci.EnumUciStatus.UCI_STATUS_OK:
        console.print(f"\033[91mStarting the buffered SWUP update has failed\033[0m")
        console.print("Exiting program...", console.StrColor.RED)
        exit()


def swup_uci_verify_component(pcan_device: PcanDevice, swup_package: SwupPackage) -> list[bool]:

    num_components  = sum([comp.size > 0 for comp in swup_package.manifest.bundle.component_table])
    console.print(f"Found {num_components} SWUP components")

    verification_successfull = []

    for component_idx in range(0, num_components):
        CMD_SWUP_VERIFY_COMPONENT = uci.UciMessage(
            message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
            packet_boundary_flag    = 0,
            gid                     = EnumGid.GID_SWUPHIF.value,
            payload_extension       = 0,
            oid                     = EnumSwupHifOid.SWUPHIF_OID_VERIFY_COMPONENT.value,
            payload_length          = 1,
            payload                 = [component_idx]
        ).to_byte_stream()

        console.print(f"Transmitting command CMD_SWUP_VERIFY_COMPONENT for component {component_idx}:")
        pcan_status, cmd_swup_verify_component, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_VERIFY_COMPONENT)
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan(pcan_status, cmd_fragments)

        console.print("Receiving response to command:")
        pcan_status, rsp_swup_verify_component, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan_api(pcan_status, rsp_fragments)

        uci_response_code   = uci.EnumUciStatus(rsp_fragments[0][4])

        if uci_response_code == uci.EnumUciStatus.UCI_STATUS_OK:
            console.print(f"\033[92mVerification successfull\n\033[0m")
            verification_successfull.append(True)
        elif uci_response_code == uci.EnumUciStatus.UCI_STATUS_FAILED:
            console.print(f"\033[91mVerification failed\n\033[0m")
            verification_successfull.append(False)
        else:
            assert 0, f"Unexpected result of verification of component {component_idx}"

    console.print("Verification attampted for all components")
    return verification_successfull


def swup_uci_transfer_components(pcan_device: PcanDevice, swup_package: SwupPackage, verification_successfull: list[bool]) -> int:

    sizes = [comp.size for comp in swup_package.manifest.bundle.component_table]

    num_components  = sum([comp.size > 0 for comp in swup_package.manifest.bundle.component_table])
    num_segments    = sum([comp.size for comp in swup_package.manifest.bundle.component_table])
    console.print(f"Found {num_components} SWUP components with a total of {num_segments} segments")

    num_components_nv   = sum(not vs for vs in verification_successfull)
    num_segments_nv     = sum(sizes[i] for i in range(len(verification_successfull)) if not verification_successfull[i])
    console.print(f"Found {num_components_nv} SWUP components with a total of {num_segments_nv} segments that are not verified")

    console.print("  " + "Component".ljust(11) + "ID".ljust(8) + "Version".ljust(9) + "Segments".ljust(10) + "Status")
    for component_idx, component in enumerate(swup_package.manifest.bundle.component_table[0:num_components]):
        ver_s   = f"\033[92mVerified\033[0m" if verification_successfull[component_idx] else f"\033[91mNot verified\033[0m"
        console.print("  " + f"{component_idx}".ljust(11) + f"0x{component.version.id:04X}".ljust(8) + f"{component.version.major_version}.{component.version.minor_version}.{component.version.patch_version}".ljust(9) + f"{component.size}".ljust(10) + f"{ver_s}")

    taq = tqdm.tqdm(desc=f"Segment 1 of {num_segments_nv} (component 1 of {num_components_nv}) - PCAN: -, API: -", total=num_segments_nv)
    t   = 1

    for component_idx, component in enumerate(swup_package.manifest.bundle.component_table[0:num_components]):

        if verification_successfull[component_idx]:
            continue

        for segment_id in range(0, component.size):
            taq.update()

            segment_id_low      = (segment_id & 0x00FF) >> 0
            segment_id_high     = (segment_id & 0xFF00) >> 8
            byte_index_start    = segment_id * 4096

            segment_data        = component.data[byte_index_start : byte_index_start + 4096]

            CMD_SWUP_TRANSFER_COMPONENT_LONG = uci.UciMessage(
                message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
                packet_boundary_flag    = 0,
                gid                     = EnumGid.GID_SWUPHIF.value,
                payload_extension       = 1,
                oid                     = EnumSwupHifOid.SWUPHIF_OID_TRANSFER_COMPONENT.value,
                payload_length          = 1 + 2 + 4096,     # 1 byte for component_id, 2 bytes for segment_id, 4096 bytes for segment payload
                payload                 = [component_idx, segment_id_low, segment_id_high] + segment_data
            ).to_byte_stream()

            pcan_status, cmd_swup_transfer_component, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_TRANSFER_COMPONENT_LONG)
            pcan_str    = print_pcan(pcan_status, silent=True)

            if pcan_status != EnumPcanStatus.PCAN_STATUS_OK:
                console.print(f"PCAN: \033[91mNOT OK: {pcan_status.name}\033[0m")
                assert 0, "PCAN reported a problem"

            taq.desc = f"Segment {t} of {num_segments_nv} (in component {component_idx}) - Transmitting CMD_SWUP_TRANSFER_COMPONENT - PCAN: {pcan_str}, API: - "
            taq.refresh()

            pcan_status, rsp_swup_transfer_component, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
            assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
            pcan_str, api_str   = print_cmd_pcan_api(pcan_status, rsp_fragments, silent=True)

            if rsp_fragments[0][4] != uci.EnumUciStatus.UCI_STATUS_OK:
                taq.close()
                a_dict  = {i.value: i.name for i in uci.EnumUciStatus}
                console.print(f"API \033[91mNOT OK: {a_dict[rsp_fragments[0][4]]}\033[0m")
                assert 0, "API reported a problem"

            taq.desc = f"Segment {t} of {num_segments_nv} (in component {component_idx}) - Receiving response to command            - PCAN: {pcan_str}, API: {api_str}"
            taq.refresh()

            t = t + 1

    taq.close()
    console.print("SWUP package transferred")

    return num_segments_nv * 4096


def swup_uci_buffer_components(pcan_device: PcanDevice, swup_package: SwupPackage) -> int:

    sizes = [comp.size for comp in swup_package.manifest.bundle.component_table]

    num_components  = sum([comp.size > 0 for comp in swup_package.manifest.bundle.component_table])
    num_segments    = sum([comp.size for comp in swup_package.manifest.bundle.component_table])
    console.print(f"Found {num_components} SWUP components with a total of {num_segments} segments")

    console.print("  " + "Component".ljust(11) + "ID".ljust(8) + "Version".ljust(9) + "Segments".ljust(10))
    for component_idx, component in enumerate(swup_package.manifest.bundle.component_table[0:num_components]):
        console.print("  " + f"{component_idx}".ljust(11) + f"0x{component.version.id:04X}".ljust(8) + f"{component.version.major_version}.{component.version.minor_version}.{component.version.patch_version}".ljust(9) + f"{component.size}".ljust(10))

    taq = tqdm.tqdm(desc=f"Segment 1 of {num_segments} (component 1 of {num_components}) - PCAN: -, API: -", total=num_segments)
    t   = 1

    for component_idx, component in enumerate(swup_package.manifest.bundle.component_table[0:num_components]):

        for segment_id in range(0, component.size):
            taq.update()

            segment_id_low      = (segment_id & 0x00FF) >> 0
            segment_id_high     = (segment_id & 0xFF00) >> 8
            byte_index_start    = segment_id * 4096

            segment_data        = component.data[byte_index_start : byte_index_start + 4096]

            CMD_SWUP_BUFFER_COMPONENT_LONG = uci.UciMessage(
                message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
                packet_boundary_flag    = 0,
                gid                     = EnumGid.GID_SWUPHIF.value,
                payload_extension       = 1,
                oid                     = EnumSwupHifOid.SWUPHIF_OID_BUFFER_COMPONENT.value,
                payload_length          = 1 + 2 + 4096,     # 1 byte for component_id, 2 bytes for segment_id, 4096 bytes for segment payload
                payload                 = [component_idx, segment_id_low, segment_id_high] + segment_data
            ).to_byte_stream()

            pcan_status, cmd_swup_buffer_component, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_BUFFER_COMPONENT_LONG)
            pcan_str    = print_pcan(pcan_status, silent=True)

            if pcan_status != EnumPcanStatus.PCAN_STATUS_OK:
                console.print(f"PCAN: \033[91mNOT OK: {pcan_status.name}\033[0m")
                assert 0, "PCAN reported a problem"

            taq.desc = f"Segment {t} of {num_segments} (in component {component_idx}) - Transmitting CMD_SWUP_BUFFER_COMPONENT_LONG - PCAN: {pcan_str}, API: - "
            taq.refresh()

            pcan_status, rsp_swup_buffer_component, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
            assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
            pcan_str, api_str   = print_cmd_pcan_api(pcan_status, rsp_fragments, silent=True)

            if rsp_fragments[0][4] != uci.EnumUciStatus.UCI_STATUS_OK:
                taq.close()
                a_dict  = {i.value: i.name for i in uci.EnumUciStatus}
                console.print(f"API \033[91mNOT OK: {a_dict[rsp_fragments[0][4]]}\033[0m")
                assert 0, "API reported a problem"

            taq.desc = f"Segment {t} of {num_segments} (in component {component_idx}) - Receiving response to command            - PCAN: {pcan_str}, API: {api_str}"
            taq.refresh()

            t = t + 1

    taq.close()
    console.print("SWUP package buffered")

    return num_segments * 4096


def swup_uci_verify_all(pcan_device: PcanDevice) -> None:
    CMD_SWUP_VERIFY_ALL_COMPONENTS = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_VERIFY_ALL.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_VERIFY_ALL_COMPONENTS:")
    pcan_status, cmd_swup_verify_all_components, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_VERIFY_ALL_COMPONENTS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_verify_all_components, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)

    assert rsp_fragments[0][4] == uci.EnumUciStatus.UCI_STATUS_OK, f"Verification of components failed"

    console.print("All components verified")


def swup_uci_finish_update(pcan_device : PcanDevice) -> bool:
    CMD_SWUP_FINISH_UPDATE = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_FINISH_UPDATE.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_FINISH_UPDATE:")
    pcan_status, cmd_swup_finish_update, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_FINISH_UPDATE)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_finish_update, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan_api(pcan_status, rsp_fragments)

    console.print("SWUP update finished")


def swup_uci_deactivate(pcan_device: PcanDevice) -> None:
    CMD_SWUP_DEACTIVATE = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_SWUPHIF.value,
        payload_extension       = 0,
        oid                     = EnumSwupHifOid.SWUPHIF_OID_DEACTIVATE.value,
        payload_length          = 0,
        payload                 = []
    ).to_byte_stream()

    console.print("Transmitting command CMD_SWUP_DEACTIVATE:")
    pcan_status, cmd_swup_deactivate, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_SWUP_DEACTIVATE)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_deactivate, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=100)

    if pcan_status == EnumPcanStatus.PCAN_STATUS_ERR_TIMEOUT:
        console.print("No response from PCAN. Probably intended reset after successful update.")

    else:
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan_api(pcan_status, rsp_fragments)

    console.print("Deactivated SWUP and reset device")


def generic_uci_reset(pcan_device: PcanDevice) -> None:
    CMD_GENERIC_RESET = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_GENERIC.value,
        payload_extension       = 0,
        oid                     = 0x00,
        payload_length          = 1,
        payload                 = [00]
    ).to_byte_stream()

    console.print("Transmitting command CMD_GENERIC_RESET:")
    pcan_status, cmd_generic_reset, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_GENERIC_RESET)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_generic_reset, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=0)

    if pcan_status == EnumPcanStatus.PCAN_STATUS_ERR_TIMEOUT:
        console.print("No response from PCAN. Probably due to intended reset.")

    else:
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan_api(pcan_status, rsp_fragments)

    console.print("Device reset")
    pcan_status, rsp_generic_reset, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=0)

    if pcan_status == EnumPcanStatus.PCAN_STATUS_ERR_TIMEOUT:
        console.print("No response from PCAN. Probably due to intended reset.")

    else:
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan_api(pcan_status, rsp_fragments)
    pcan_status, rsp_generic_reset, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=0)

    if pcan_status == EnumPcanStatus.PCAN_STATUS_ERR_TIMEOUT:
        console.print("No response from PCAN. Probably due to intended reset.")

    else:
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan_api(pcan_status, rsp_fragments)

def generic_uci_receive_bootup_version_ntf(pcan_device: PcanDevice) -> int:
    console.print("Receiving Boot Up Notification:")
    pcan_status, ntf_boot_up, ntf_fragments, _ = pcan_device.receive_uci_message(timeout_ms=CAN_TIMEOUT_MS)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"

    print_cmd_pcan(pcan_status, ntf_fragments)

    major   = sum([ntf_boot_up[4  + i] << (8 * i) for i in range(3)])
    minor   = sum([ntf_boot_up[8  + i] << (8 * i) for i in range(3)])
    patch   = sum([ntf_boot_up[12 + i] << (8 * i) for i in range(3)])
    id      = sum([ntf_boot_up[16 + i] << (8 * i) for i in range(3)])

    return major, minor, patch, id


def app_uci_activate_swup(pcan_device: PcanDevice) -> None:
    CMD_APP_ACTIVATE_SWUP = uci.UciMessage(
        message_type            = uci.EnumUciMessageType.UCI_MT_COMMAND,
        packet_boundary_flag    = 0,
        gid                     = EnumGid.GID_CUSTOM.value,
        payload_extension       = 0,
        oid                     = EnumSwupActivatorAppOid.SWUPACTAPP_OID_ACTIVATE_SWUP.value,
        payload_length          = 1,
        payload                 = [00]
    ).to_byte_stream()

    console.print("Transmitting command CMD_APP_ACTIVATE_SWUP:")
    pcan_status, cmd_swup_deactivate, cmd_fragments, _ = pcan_device.transmit_uci_message(CMD_APP_ACTIVATE_SWUP)
    assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
    print_cmd_pcan(pcan_status, cmd_fragments)

    console.print("Receiving response to command:")
    pcan_status, rsp_swup_deactivate, rsp_fragments, _ = pcan_device.receive_uci_message(timeout_ms=0)
    if pcan_status == EnumPcanStatus.PCAN_STATUS_ERR_TIMEOUT:
        console.print("No response from PCAN. Probably intended reset after successful update.")
    else:
        assert pcan_status == EnumPcanStatus.PCAN_STATUS_OK, "Stopped due to PCAN error"
        print_cmd_pcan_api(pcan_status, rsp_fragments)

def wait_for_input() -> None:
    if MODE_STEP_BY_STEP is True:
        input("Press Enter to continue...")

############################################################################

def main():
    ###############################################################################
    # Set up
    ###############################################################################
    time_start_all      = time.time()
    current_swup_hif    = EnumSwupHifVersionIds.SWUPHIF_VERSIONID_UNDEF

    console.print(f"**************************************************************")
    console.print(f"Start of NCJ29D6 CAN UCI SWUP HOST demo app!")
    console.print(f"**************************************************************")
    console.print(f"")
    console.print(f"Configuration Parameters:")
    console.print(f"- SWUP_SELECTED_UPDATE      = {SWUP_SELECTED_UPDATE}")
    console.print(f"- SWUP_KEYSTORE_LOCATION    = {SWUP_KEYSTORE_LOCATION}")
    console.print(f"- CAN_TIMEOUT_MS            = {CAN_TIMEOUT_MS} ms")
    console.print(f"- CAN_IS_FD                 = {CAN_IS_FD}")
    console.print(f"- CAN_USE_EXTENDED_ID       = {CAN_USE_EXTENDED_ID}")
    console.print(f"- CAN_MAX_PAYLOAD           = {CAN_MAX_PAYLOAD} bytes")
    console.print(f"- CAN_DEVICE_ID             = 0x{CAN_DEVICE_ID:08X}")
    console.print(f"- CAN_DEVICE_SWUP_ID        = 0x{CAN_DEVICE_SWUP_ID:08X}")
    console.print(f"- NO_RESET                  = {NO_RESET}")
    console.print(f"- MODE_STEP_BY_STEP         = {MODE_STEP_BY_STEP}")
    console.print(f"- PRINT_FULL_SWUP_CONTENT   = {PRINT_FULL_SWUP_CONTENT}")
    console.print(f"- SILENT_SWUP_STATE         = {SILENT_SWUP_STATE}")
    console.print(f"")
    console.print(f"**************************************************************")

    ###############################################################################
    # Set up PCAN device
    ###############################################################################
    # Get list of locations for available PCAN devices
    pcan_device_locations = PcanDeviceManager.get_device_locations()

    # Abort if no devices found
    if len(pcan_device_locations) <= 0:
        sys.exit("No PCAN devices found. Aborting program...")

    # Print all devices 
    console.print("Detected " + str(len(pcan_device_locations)) + " PCAN device(s): " + str(pcan_device_locations))

    # Get the location of the first device
    device_location = pcan_device_locations[0]

    console.print("Proceeding with the first device in the list with location = " + str(device_location))
    
    # Open the first device based on its id
    pcan_device_0 = PcanDevice(
                device_id=CAN_DEVICE_ID,
                baudrate_bps=5e6,
                handle=device_location,
                max_can_payload_bytes=CAN_MAX_PAYLOAD,
                is_fd=CAN_IS_FD,
                use_extended_id=CAN_USE_EXTENDED_ID)
    pcan_device_0.open()

    pcan_device_swup = PcanDevice(
                device_id=CAN_DEVICE_SWUP_ID,
                baudrate_bps=5e6,
                handle=device_location,
                max_can_payload_bytes=CAN_MAX_PAYLOAD,
                is_fd=CAN_IS_FD,
                use_extended_id=CAN_USE_EXTENDED_ID)

    wait_for_input()

    ###############################################################################
    # Read SWUP .pkg file
    ###############################################################################
    for SWUP_PKG_FILENAME in SWUP_PKGS_DICT[SWUP_SELECTED_UPDATE]:
        console.print("\r\nReading SWUP package:", console.StrColor.BLUE, console.StrFormat.BOLD)
        with open(SWUP_PKG_FILENAME, "rb") as pkg_file:
            pkg_file_size = Path(SWUP_PKG_FILENAME).stat().st_size
            pkg_byte_list = list(pkg_file.read())

        swup_package                = SwupPackage.from_bytes(pkg_byte_list)
        swup_package_num_components = sum([comp.size > 0 for comp in swup_package.manifest.bundle.component_table])
        swup_package_num_segments   = sum([comp.size for comp in swup_package.manifest.bundle.component_table])

        console.print(f"- Filename          = {SWUP_PKG_FILENAME}", console.StrFormat.BOLD)

        if PRINT_FULL_SWUP_CONTENT == True:
            console.print(swup_package)
        else:
            console.print(f"- Size              = {pkg_file_size} bytes")
            console.print(f"- Origin ID         = 0x{swup_package.manifest.manifest_header.origin_id:08X}")
            console.print(f"- Manifest version  = {swup_package.manifest.manifest_header.manifest_version}")
            console.print(f"- Generator version = {swup_package.manifest.manifest_header.generator_version}")
            console.print(f"- opcode            = {swup_package.manifest.manifest_header.opcode.name} (0x{swup_package.manifest.manifest_header.opcode:X})")
            console.print(f"- Found {swup_package_num_components} SWUP components with a total of {swup_package_num_segments} segments")

        console.print("  " + "Component".ljust(11) + "ID".ljust(8) + "Version".ljust(9) + "Segments".ljust(10))
        for component_idx, component in enumerate(swup_package.manifest.bundle.component_table[0:swup_package_num_components]):
            console.print("  " + f"{component_idx}".ljust(11) + f"0x{component.version.id:04X}".ljust(8) + f"{component.version.major_version}.{component.version.minor_version}.{component.version.patch_version}".ljust(9) + f"{component.size}".ljust(10))

        ###############################################################################
        # Reset device and determine state.
        ###############################################################################
        if not NO_RESET:
            console.print("\r\nResetting device:", console.StrColor.BLUE, console.StrFormat.BOLD)
            generic_uci_reset(pcan_device_0)

            # major, minor, patch, ver_id = generic_uci_receive_bootup_version_ntf(pcan_device_0)

            # if ver_id in iter(EnumSwupHifVersionIds):
            #     current_swup_hif    = EnumSwupHifVersionIds(ver_id)
            #     in_swup             = True
            #     console.print(f"Retrieved SWUP CAN HIF Version: {major}.{minor}.{patch} (ID: 0x{current_swup_hif.value:04X}, Color: {current_swup_hif.name})")
            # else:
            #     console.print(f"Retrieved app version: {major}.{minor}.{patch} (ID: 0x{ver_id:04X})")
            #     in_swup             = False
            in_swup             = False

        ###############################################################################
        # Activating SWUP per UCI command, if SWUP not already active
        ###############################################################################
        if not NO_RESET:
            console.print("\r\nActivate SWUP from the application:", console.StrColor.BLUE, console.StrFormat.BOLD)
            if in_swup:
                console.print("Already activated")
            else:
                app_uci_activate_swup(pcan_device_0)
                # pcan_device_0.close()
                # pcan_device_swup.open()
                major, minor, patch, ver_id = generic_uci_receive_bootup_version_ntf(pcan_device_0)
                assert ver_id in iter(EnumSwupHifVersionIds), "Retrieved SWUP HIF version ID does not match any known SWUP HIF version ID"

                current_swup_hif    = EnumSwupHifVersionIds(ver_id)
                console.print(f"Retrieved SWUP CAN HIF Version: {major}.{minor}.{patch} (ID: 0x{current_swup_hif.value:04X}, Color: {current_swup_hif.name})")

            wait_for_input()

        ###############################################################################
        # Now we are in SWUP and the CAN/CAN-FD UCI interface is active
        ###############################################################################
        pcan_device_0.close()
        pcan_device_swup.open()
        # Get SWUP version
        console.print("\r\nGet SWUP version:", console.StrColor.BLUE, console.StrFormat.BOLD)
        swup_uci_get_swup_version(pcan_device_swup)
        swup_uci_get_swup_state(pcan_device_swup)
        wait_for_input()

        # Select key store
        console.print("\r\nSelect key-store:", console.StrColor.BLUE, console.StrFormat.BOLD)
        swup_uci_select_keystore(pcan_device_swup, SWUP_KEYSTORE_LOCATION)
        swup_uci_get_swup_state(pcan_device_swup, SILENT_SWUP_STATE)
        wait_for_input()

        # Transfer manifest
        time_start_transfer_manifest    = time.time()
        console.print("\r\nTransfer manifest:", console.StrColor.BLUE, console.StrFormat.BOLD)
        swup_uci_transfer_manifest(pcan_device_swup, pkg_byte_list)
        time_end_transfer_manifest      = time.time()
        swup_uci_get_swup_state(pcan_device_swup, SILENT_SWUP_STATE)
        wait_for_input()

        # NDP update
        if swup_package.manifest.manifest_header.origin_id == 0x4:

            # Buffer components
            console.print("\r\nBuffer components:", console.StrColor.BLUE, console.StrFormat.BOLD)
            time_start_transfer_components  = time.time()
            transfer_payload_size = swup_uci_buffer_components(pcan_device_swup, swup_package)
            time_end_transfer_components    = time.time()
            swup_uci_get_swup_state(pcan_device_swup, SILENT_SWUP_STATE)
            wait_for_input()

            # Start buffered update
            console.print("\r\nStart buffered update:", console.StrColor.BLUE, console.StrFormat.BOLD)
            swup_uci_start_buffered_update(pcan_device_swup)
            swup_uci_get_swup_state(pcan_device_swup, SILENT_SWUP_STATE)
            wait_for_input()

        # Non-NDP update
        else:
            console.print("\r\nNon-NDP update:", console.StrColor.GREEN, console.StrFormat.BOLD)
            # Start update
            console.print("\r\nStart update:", console.StrColor.BLUE, console.StrFormat.BOLD)
            swup_uci_start_update(pcan_device_swup)
            swup_uci_get_swup_state(pcan_device_swup, SILENT_SWUP_STATE)
            wait_for_input()

            # Verify components individually
            console.print("\r\nVerify components:", console.StrColor.BLUE, console.StrFormat.BOLD)
            verification_successfull = swup_uci_verify_component(pcan_device_swup, swup_package)
            swup_uci_get_swup_state(pcan_device_swup, SILENT_SWUP_STATE)
            wait_for_input()

            # Check HIF over-write protection
            console.print("\r\nCheck SWUP HIF over-write protection:", console.StrColor.BLUE, console.StrFormat.BOLD)
            console.print(f"Current SWUP CAN HIF ID: 0x{current_swup_hif.value:04X}")

            swup_package_component_ids  = [swup_package.manifest.bundle.component_table[i].version.id for i in range(0, swup_package_num_components)]
            new_swup_hif_ids            = [swup_package_component_ids[i] for i in range(0, swup_package_num_components) if swup_package_component_ids[i] in iter(EnumSwupHifVersionIds) and not verification_successfull[i]]

            s = [f"0x{EnumSwupHifVersionIds(new_swup_hif_id).value:04X}" for new_swup_hif_id in new_swup_hif_ids]
            console.print(f"New SWUP CAN HIF IDs:    {s}")

            if current_swup_hif in new_swup_hif_ids:
                console.print("Warning: Overwriting current SWUP HIF is invalid", console.StrColor.RED)
                console.print("Exiting program...", console.StrColor.RED)
                exit()

            if len(new_swup_hif_ids) == 0:
                console.print("No new (known) SWUP HIFs found to be updated")
            else:
                console.print("New SWUP HIFs to be updated are valid")

            wait_for_input()
############################################################################
if __name__ == "__main__":
    main()