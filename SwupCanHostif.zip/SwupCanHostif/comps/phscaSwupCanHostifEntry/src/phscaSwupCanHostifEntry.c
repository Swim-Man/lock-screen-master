/*
    Copyright 2023-2024 NXP

    NXP Confidential and Proprietary. This software is owned or controlled by NXP
    and may only be used strictly in accordance with the applicable license terms.
    By expressly accepting such terms or by downloading, installing, activating
    and/or otherwise using the software, you are agreeing that you have read, and
    that you agree to comply with and are bound by, such license terms. If you do
    not agree to be bound by the applicable license terms, then you may not
    retain, install, activate or otherwise use the software.
*/

/**
 * @file
 * @brief Normal secure APP definitions - representative normal secure HIF
 * @ingroup app
 */
#include <stdint.h>
#include <cmsis_armclang.h>
#include <phscaApi_Tag.h>
#include "phscaSwupCanHostifEntry.h"

#include "RTE_Components.h"
#include CMSIS_device_header

/** @brief The Major version data of SWUP hostif. */
#define PHSCA_SWUPCANHOSTIF_VERSION_MAJOR                     UINT32_C(1)

/** @brief The Minor version data of SWUP hostif. */
#define PHSCA_SWUPCANHOSTIF_VERSION_MINOR                     UINT32_C(0)

/** @brief The Patch version data of SWUP hostif. */
#define PHSCA_SWUPCANHOSTIF_VERSION_PATCH                     UINT32_C(0)

/** @brief The version ID of SWUP hostif */
#ifdef HIF_A
#define PHSCA_SWUPCANHOSTIF_VERSION_ID                        UINT32_C(0xF00A)
#endif

#ifdef HIF_B
#define PHSCA_SWUPCANHOSTIF_VERSION_ID                        UINT32_C(0xF00B)
#endif

/** @brief Marker tag for SWUP hostif */
#define PHSCA_SWUPCANHOSTIF_TAG                               PHSCAAPI_TAG_NS_HIF

/** @brief The flash page size */
#define PHSCA_SWUPCANHOSTIF_CONSTS_FLASH_PAGE_SIZE            UINT32_C(0x1000)

/** @brief The stack protector guard.
 *  @note The cost of adding this feature (requires ARM CLANG compile flag
 *   `-fstack-protector-strong` to make it operative) is in term of op-codes: +12 op-code THUMB words
 *  e.g. 24 bytes of code.
 *  Finally this goes into NS PACK and in addition the guard will be
 *        properly randomized at early run time.
 */
__WEAK void *__stack_chk_guard = (void*)(((uint32_t)'S') | (((uint32_t)'T') << 8) | (((uint32_t)'O') << 16) | (((uint32_t)'P') << 24));

__WEAK __NO_RETURN void __stack_chk_fail(void)
{
    /// Implement ns trap like secTrap
    for (;;)
    {
        if (0u == (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk))
        {
            __BKPT(0xDA);
        }
        __WFE();
    }
}
/**
 * @brief Padding sentinel value at the end of image
 */
extern uint32_t const gkphscaSwupCanHostif_EndOfImage;
__USED uint32_t const gkphscaSwupCanHostif_EndOfImage = UINT32_C(0xDEDEDEDE);

/**
 * @brief The secure HOSTIF header
 * This is not copied to RAM
 */
__USED phscaApi_ImageHeader_t const gkphscaSwupCanHostif_Info =
{
    .integrity =
    {
        .hash     = {0u},
        .reserved = {0u},
        .crc      = 0u,
        .size     = (5u*PHSCA_SWUPCANHOSTIF_CONSTS_FLASH_PAGE_SIZE - sizeof(phscaApi_ImageIntegrityInfo_t))
    },
    .specific =
    {
        .app =
        {
            .type         = (uint32_t)PHSCA_SWUPCANHOSTIF_TAG,
            .version      =
            {
                .major    = PHSCA_SWUPCANHOSTIF_VERSION_MAJOR,
                .minor    = PHSCA_SWUPCANHOSTIF_VERSION_MINOR,
                .patch    = PHSCA_SWUPCANHOSTIF_VERSION_PATCH,
                .id       = PHSCA_SWUPCANHOSTIF_VERSION_ID
            },
            .vtorPtr      = (uint32_t const* const)&__VECTOR_TABLE[0u],
            .mspStdLim    = (uint32_t)gkphscaSwupCanHostif_StdMspStart,
            .fastAppEntry = 0u,
            .mspFast      = 0u,
            .mspFastLim   = 0u,
            .reserved     = {0u}
        }
    }
};
