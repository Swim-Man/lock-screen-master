/*
    Copyright 2023-2024 NXP

    NXP Confidential and Proprietary. This software is owned or controlled by NXP
    and may only be used strictly in accordance with the applicable license terms.
    By expressly accepting such terms or by downloading, installing, activating
    and/or otherwise using the software, you are agreeing that you have read, and
    that you agree to comply with and are bound by, such license terms. If you do
    not agree to be bound by the applicable license terms, then you may not
    retain, install, activate or otherwise use the software.
*/

/**
 * @file
 * @brief Normal secure APP definitions - representative normal secure HOSTIF
 * Purpose: This include file stores defines, enums, etc known of this normal secure HOSTIF only.
 * @ingroup app
 */
#ifndef PHSCA_SWUPCANHOSTIF_CONSTS_H
#define PHSCA_SWUPCANHOSTIF_CONSTS_H

#include <phscaApi_Image.h>

/**
 * @brief Entry type in the vector table.
 */
typedef void (*Vector_Table_Entry_t)(void);

/** @brief the stack protectory guard pattern. */
__WEAK extern void *__stack_chk_guard;

/** @brief The ultimate terminator.
 *  @note The stack protector sub-system invokes it if stack is smashed.
 *  @return None
 */
__WEAK extern __NO_RETURN void __stack_chk_fail(void);

/**
 * @brief Various external objects used in 2 or more modules as well as the SCATTER file itself.
 * @note See for details on how to import parameters from SCATTER config inside of document
 * "Arm Compiler Version 6.14 User Guide"
 */
extern phscaApi_ImageHeader_t const gkphscaSwupCanHostif_Info;

/**
 * @brief SWUP hostif Load Region size
 * @return None
 */
extern uint8_t gkphscaSwupCanHostif_Size[]          __asm__ ("Load$$LR$$LR_HOSTIF$$Length");

/**
 * @brief In the SCATTER file the stack is defined as a byte range [Start...End)
 * # 'Start' belongs to the range.
 * # 'End' is already positioned right behind the addressable stack.
 * The stack base of the normal secure M33 MSP shall be set
 * to 'gkphscaSwupCanHostif_StdMspEnd' e.g. 'Image$$ARM_LIB_STACK$$ZI$$Limit'.
 * Reason: the stacks of the M33 grow from 'End' towards to 'Start' in
 * descending addresing/direction.
 * @return None
 */
extern uint8_t gkphscaSwupCanHostif_StdMspEnd[]     __asm__ ("Image$$ARM_LIB_STACK$$ZI$$Limit");

/**
 * @brief In the SCATTER file the stack is defined as a byte range [Start...End)
 * # 'Start' belongs to the range.
 * # 'End' is already positioned right behind the addressable stack.
 * The stack limiter 'MSPLIM' of the normal secure M33 MSP shall be set
 * to 'gkphscaSwupCanHostif_StdMspStart'e.g. 'Image$$ARM_LIB_STACK$$ZI$$Base'.
 * Reason: the stacks of the M33 grow from 'End' towards 'Start' in descending addresing/direction.
 * @return None
 */
extern uint8_t gkphscaSwupCanHostif_StdMspStart[]   __asm__ ("Image$$ARM_LIB_STACK$$ZI$$Base");

/**
 * @brief The base of the std MSP stack --- alias it's end because stack grows
 * downwards to start of MSP stack alias the MSP stack limiter --- is stored
 * inside of __VECTOR_TABLE[0] per calculating the value per CMSIS macro __INITIAL_SP
 */
extern const Vector_Table_Entry_t __VECTOR_TABLE[];

#endif /* PHSCA_SWUPCANHOSTIF_CONSTS_H */
