/*
 * Copyright 2024 NXP
 *
 * NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
 * used strictly in accordance with the applicable license terms. By expressly accepting such terms
 * or by downloading, installing, activating and/or otherwise using the software, you are agreeing
 * that you have read, and that you agree to comply with and are bound by, such license terms. If
 * you do not agree to be bound by the applicable license terms, then you may not retain, install,
 * activate or otherwise use the software.
 */

/**
 * @file
 * @brief SWUP related components for the SwupCanHostif example.
 * @details UCI commands are processed for SWUP activities.
 * @addtogroup PHSCA_SWUPUCI
 * @{
 */
 

/*************************************************************************/
/* Includes                                                              */
/*************************************************************************/

/* SDK */
#include <phscaApi_Status.h>
#include <phscaApi_Swup.h>
#include <phscaApi_Flash.h>
#include <phscaUci.h>

/* Custom */
#include <phscaCasHal.h>
#include <phscaCasTools.h>

/* Application */
#include <phscaSwupUci.h>
#include <phscaUciCanFd.h>


/*************************************************************************/
/* Preprocessor Definitions                                              */
/*************************************************************************/

/** @brief Start address of buffer region. */
#define PHSCA_SWUPUCI_BUFFER_START_ADDRESS                      ((uint32_t)0x00402000u)

/** @brief Size of buffer region in pages. */
#define PHSCA_SWUPUCI_BUFFER_SIZE_PAGES                         ((uint32_t)172u)

/** @brief Manifest offset in buffer in pages. */
#define PHSCA_SWUPUCI_BUFFER_MANIFEST_PAGEOFFSET                ((uint32_t)0u)

/** @brief Component offset in buffer in pages. */
#define PHSCA_SWUPUCI_BUFFER_COMPONENTS_PAGEOFFSET              ((uint32_t)1u)

/** @brief Size of one flash page in bytes (0x1000 = 4096 bytes). */
#define PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES                     ((uint32_t)4096u)

/** @brief Size of one flash page in words (0x1000 = 256 words). */
#define PHSCA_SWUPUCI_FLASH_PAGE_SIZE_WORDS                     ((uint32_t)256u)

/** @brief Size of flash that can be erased at once, in pages. */
#define PHSCA_SWUPUCI_ERASE_SIZE_PAGES                          ((uint32_t)16u)


/** @brief Payload length of CMD_SWUP_GET_VERSION*/
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_GET_VERSION            ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_TRANSFER_MANIFEST */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_TRANSFER_MANIFEST      ((uint32_t)4096u)

/** @brief Payload length of CMD_SWUP_START_UPDATE */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_START_UPDATE           ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_START_BUFFERED_UPDATE */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_START_BUFFERED_UPDATE  ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_TRANSFER_COMPONENT */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_TRANSFER_COMPONENT     ((uint32_t)4099u)

/** @brief Payload length of CMD_SWUP_BUFFER_COMPONENT */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_BUFFER_COMPONENT       ((uint32_t)4099u)

/** @brief Payload length of CMD_SWUP_VERIFY_COMPONENT */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_VERIFY_COMPONENT       ((uint32_t)1u)

/** @brief Payload length of CMD_SWUP_VERIFY_ALL*/
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_VERIFY_ALL             ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_FINISH_UPDATE */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_FINISH_UPDATE          ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_DEACTIVATE */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_DEACTIVATE             ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_GET_VERSION*/
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_GET_STATE              ((uint32_t)0u)

/** @brief Payload length of CMD_SWUP_SELECT_KEY_STORE */
#define PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_SELECT_KEY_STORE       ((uint32_t)4u)


/** @brief Component index max value */
#define PHSCA_SWUPUCI_COMPONENT_INDEX_MAX_VALUE                 ((uint8_t)0x7u)

/** @brief Component index position */
#define PHSCA_SWUPUCI_COMPONENT_INDEX_OFFSET                    ((uint32_t)0u)

/** @brief Segment ID position */
#define PHSCA_SWUPUCI_SEGMENT_ID_OFFSET                         ((uint32_t)1u)

/** @brief Component data position */
#define PHSCA_SWUPUCI_COMPONENT_DATA_OFFSET                     ((uint32_t)3u)


/*************************************************************************/
/* Private Type Definitions                                              */
/*************************************************************************/

/** @brief SWUP States. */
typedef enum __PACKED
{
    /** @brief SWUP state: Active. */
    PHSCA_SWUPUCI_STATE_ACTIVE      = (uint32_t)0x00000006u,
    
    /** @brief SWUP state: Transfer. */
    PHSCA_SWUPUCI_STATE_TRANSFER    = (uint32_t)0x00000009u,
    
    /** @brief SWUP state: Error. */
    PHSCA_SWUPUCI_STATE_ERROR       = (uint32_t)0x0000000Au,
    
} phscaSwupUci_SwupStates_t;


/** @brief Origin IDs. */
typedef enum __PACKED
{
    /** @brief Customer origin ID. */
    PHSCA_SWUPUCI_ORIGINID_CUSTOMER = (uint32_t)0x00000002u,
    
    /** @brief NXP origin ID. */
    PHSCA_SWUPUCI_ORIGINID_NXP      = (uint32_t)0x00000004u,
    
} phscaSwupUci_OriginID_t;



/*************************************************************************/
/* Private Function Prototypes                                           */
/*************************************************************************/


/*************************************************************************/
/* Private Variables                                                     */
/*************************************************************************/

/** @brief Indicates active operation mode. */
static phscaSwupUci_OperatingMode_t sphscaSwupUci_OperationMode = PHSCA_SWUPUCI_OPMODE_UNDEFINED;

/*************************************************************************/
/* Private Functions                                                     */
/*************************************************************************/

/** @brief Erases the buffer region. */
static phscaApi_Status_t phscaSwupUci_EraseBufferRegion(void)
{
    phscaApi_Status_t retVal = PHSCA_API_STATUS_INVALID;
    
    uint32_t currStartAddress;
    uint32_t currPageStart  = 0u;
    uint32_t currPageAmount = 0u;
    
    /* Safety check */
    if (PHSCA_SWUPUCI_OPMODE_BUFFERED != sphscaSwupUci_OperationMode)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }
    
    /* Erase buffer region */
    while (currPageStart < PHSCA_SWUPUCI_BUFFER_SIZE_PAGES)
    {
        if (currPageStart + PHSCA_SWUPUCI_ERASE_SIZE_PAGES > PHSCA_SWUPUCI_BUFFER_SIZE_PAGES)
        {
            currPageAmount = PHSCA_SWUPUCI_BUFFER_SIZE_PAGES - currPageStart;
        }
        else
        {
            currPageAmount = PHSCA_SWUPUCI_ERASE_SIZE_PAGES;
        }
        
        currStartAddress = PHSCA_SWUPUCI_BUFFER_START_ADDRESS + currPageStart * PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES;
        retVal = phscaApi_FlashErasePages(currStartAddress, currPageAmount);
        
        if (PHSCA_API_SUCCESS != retVal)
        {
            break;
        }
        
        currPageStart = currPageStart + PHSCA_SWUPUCI_ERASE_SIZE_PAGES;                    
    }
    
    /* Check if successfully erased */
    if (PHSCA_API_SUCCESS == retVal)
    {                    
        retVal = phscaApi_FlashBlankCheckWords(PHSCA_SWUPUCI_BUFFER_START_ADDRESS, PHSCA_SWUPUCI_FLASH_PAGE_SIZE_WORDS * PHSCA_SWUPUCI_BUFFER_SIZE_PAGES);
    }
    
    return retVal;
}


/** 
 * @brief Perform complete SWUP update from buffered SWUP package. 
 * During the update procedure, CAN-FD communication will be unavailable.
 */
static phscaApi_Status_t phscaSwupUci_StartBufferedUpdate(void)
{
    phscaApi_Status_t retVal = PHSCA_API_SUCCESS;
    uint32_t    pageAddress;
    uint8_t     pageFromFlash[PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES] PHSCA_CAS_TOOLS_FOUR_BYTE_BUFF_ALIGN = {0u};

    /* Deactivate clock and SBE */
    phscaUciCanFd_DeactivateCanHw();
    
    /* Transfer manifest (again) */
    if (PHSCA_API_SUCCESS == retVal)
    {
        pageAddress = PHSCA_SWUPUCI_BUFFER_START_ADDRESS + (PHSCA_SWUPUCI_BUFFER_MANIFEST_PAGEOFFSET) * PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES;
        (void)__builtin_memcpy(pageFromFlash, (void *)(pageAddress), PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES);
        
        phscaApi_InputData_t  manifestData =
        {
            .data = pageFromFlash,
            .size = PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES
        };
        
        retVal = phscaApi_Swup_TransferManifest(&manifestData);
    }

    /* Start update */
    if (PHSCA_API_SUCCESS == retVal)
    {
        retVal = phscaApi_Swup_StartUpdate();
    }
    
    /* Transfer components */
    if (PHSCA_API_SUCCESS == retVal)
    {   
        uint8_t     component_idx    = 0u;
        uint32_t    component_page_offset, component_size, pageOffset;
        
        /* Get manifest from flash */
        phscaApi_Swup_Manifest_t * manifest = NULL;
        manifest = (phscaApi_Swup_Manifest_t *)(PHSCA_SWUPUCI_BUFFER_START_ADDRESS + PHSCA_SWUPUCI_BUFFER_MANIFEST_PAGEOFFSET * PHSCA_SWUPUCI_BUFFER_SIZE_PAGES);
        
        /* Iterate over components */
        while (manifest->common_data.components.components[component_idx].size != 0)
        {
            component_page_offset   = manifest->common_data.components.components[component_idx].page_offset;
            component_size          = manifest->common_data.components.components[component_idx].size;
            
            /* Iterate over segments */
            for (uint32_t segment_id = 0; segment_id < component_size; segment_id++)
            {
                pageOffset  = component_page_offset + segment_id;
                pageAddress = PHSCA_SWUPUCI_BUFFER_START_ADDRESS + (PHSCA_SWUPUCI_BUFFER_COMPONENTS_PAGEOFFSET + pageOffset) * PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES;
                (void)__builtin_memcpy(pageFromFlash, (void *)(pageAddress), PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES);

                phscaApi_InputData_t    componentData = 
                {
                    .data = pageFromFlash,
                    .size = PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES
                };
                
                /* Transfer component */
                retVal = phscaApi_Swup_TransferComponent(component_idx, segment_id, &componentData);
                if (PHSCA_API_SUCCESS != retVal)
                {
                    break;
                }
                
            }
            
            if (PHSCA_API_SUCCESS != retVal)
            {
                break;
            }
            
            component_idx = component_idx + 1;
        }
    }
    
    /* Verify all components */
    if (PHSCA_API_SUCCESS == retVal)
    {   
        retVal = phscaApi_Swup_VerifyAll();
    }
    
    /* Finish Update */
    if (PHSCA_API_SUCCESS == retVal)
    {   
        retVal = phscaApi_Swup_FinishUpdate();
    }
    
    /* Re-activate SBE and clock */
    phscaUciCanFd_ActivateCanHw();
    
    /* Erase buffer region */
    if (PHSCA_API_SUCCESS == retVal)
    {   
        retVal = phscaSwupUci_EraseBufferRegion();
    }
    
    return retVal;
}



/*************************************************************************/
/* Public Type Definitions                                               */
/*************************************************************************/


/*************************************************************************/
/* Public Variables                                                      */
/*************************************************************************/


/*************************************************************************/
/* Public Functions                                                      */
/*************************************************************************/

/** @brief Processes UCI commands and triggers SWUP activities. */
phscaUci_Msg_Status_t phscaSwupUci_UciInputHandler(uint8_t const opCodeId, 
                                                   uint32_t const payloadLength, 
                                                   const uint8_t *const payloadData)
{
    phscaApi_Status_t       retVal      = PHSCA_API_STATUS_INVALID;
    phscaUci_Msg_Status_t   statusCode  = PHSCA_UCI_MSG_STATUS_UNKNOWN_OID;
    
    /* payloadData must be aligned to 4. Responsibility is on the caller. */
    /* Check if payloadData is indeed aligned */
    if(false == PHSCA_CAS_TOOLS_CHECK_ALIGNMENT(payloadData))
    {        
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1u);
    }

    /* Handle OID */
    switch ((phscaSwupUci_UciOid_t)opCodeId)
    {
        case (uint8_t)PHSCA_SWUPUCI_OID_GET_VERSION:
        {            
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_GET_VERSION != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else
            {
                phscaApi_Swup_Version_t swupVer = {0u};
                
                retVal = phscaApi_Swup_GetVersion(&swupVer);
                
                if (PHSCA_API_SUCCESS == retVal)
                {                   
                    (void)__builtin_memcpy(&gphscaUciCanFd_UciOpenNotificationBuffer[0], &swupVer, sizeof(phscaApi_Swup_Version_t));
                    gphscaUciCanFd_UciNotificationGid       = PHSCA_UCICANFD_GID_SWUP;
                    gphscaUciCanFd_UciNotificationOid       = opCodeId;
                    gphscaUciCanFd_UciNotificationLength    = (uint16_t)sizeof(phscaApi_Swup_Version_t);
                    gphscaUciCanFd_UciNewNotification       = true;
                }
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_TRANSFER_MANIFEST:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_TRANSFER_MANIFEST != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else
            {
                phscaApi_InputData_t  manifestData =
                {
                    .data = payloadData,
                    .size = PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_TRANSFER_MANIFEST
                };

                /* Determine operation mode from manifest origin ID. */
                phscaApi_Swup_Manifest_t const * const manifest = (phscaApi_Swup_Manifest_t const * const)((const void *)payloadData);
                
                if((uint32_t)PHSCA_SWUPUCI_ORIGINID_CUSTOMER == manifest->header.origin_ID)
                {
                    sphscaSwupUci_OperationMode = PHSCA_SWUPUCI_OPMODE_DIRECT;
                }
                else if((uint32_t)PHSCA_SWUPUCI_ORIGINID_NXP == manifest->header.origin_ID)
                {
                    sphscaSwupUci_OperationMode = PHSCA_SWUPUCI_OPMODE_BUFFERED;
                    
                    retVal = phscaSwupUci_EraseBufferRegion();
                    
                    if (PHSCA_API_SUCCESS == retVal)
                    {
                        uint32_t flashAddress = PHSCA_SWUPUCI_BUFFER_START_ADDRESS + PHSCA_SWUPUCI_BUFFER_MANIFEST_PAGEOFFSET * PHSCA_SWUPUCI_BUFFER_SIZE_PAGES;
                        retVal = phscaApi_FlashProgramWords(flashAddress, &manifestData);
                    }
                }
                else
                {
                    phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
                    while(1u);
                }
                
                retVal = phscaApi_Swup_TransferManifest(&manifestData);
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_START_UPDATE:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_START_UPDATE != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_DIRECT != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else   
            {   
                retVal = phscaApi_Swup_StartUpdate();
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_START_BUFFERED_UPDATE:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_START_BUFFERED_UPDATE != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_BUFFERED != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else   
            {   
                retVal = phscaSwupUci_StartBufferedUpdate();
                sphscaSwupUci_OperationMode = PHSCA_SWUPUCI_OPMODE_UNDEFINED;
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_TRANSFER_COMPONENT:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_TRANSFER_COMPONENT != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_DIRECT != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else
            {
                /* Get component data from input. */
                uint8_t                 component_idx = 0u;
                uint16_t                segment_id    = 0u;
                phscaApi_InputData_t    componentData = 
                {
                    .data = &payloadData[PHSCA_SWUPUCI_COMPONENT_DATA_OFFSET],
                    .size = PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_TRANSFER_COMPONENT - PHSCA_SWUPUCI_COMPONENT_DATA_OFFSET
                };
                
                (void)__builtin_memcpy(&component_idx, &payloadData[PHSCA_SWUPUCI_COMPONENT_INDEX_OFFSET], sizeof(component_idx));
                (void)__builtin_memcpy(&segment_id,    &payloadData[PHSCA_SWUPUCI_SEGMENT_ID_OFFSET], sizeof(segment_id));
                
                retVal = phscaApi_Swup_TransferComponent(component_idx, segment_id, &componentData);                
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_BUFFER_COMPONENT:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_BUFFER_COMPONENT != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_BUFFERED != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else
            {
                /* Get component data from input. */
                uint8_t                 component_idx = 0u;
                uint16_t                segment_id    = 0u;
                phscaApi_InputData_t    componentData = 
                {
                    .data = &payloadData[PHSCA_SWUPUCI_COMPONENT_DATA_OFFSET],
                    .size = PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_BUFFER_COMPONENT - PHSCA_SWUPUCI_COMPONENT_DATA_OFFSET
                };
                
                (void)__builtin_memcpy(&component_idx, &payloadData[PHSCA_SWUPUCI_COMPONENT_INDEX_OFFSET], sizeof(component_idx));
                (void)__builtin_memcpy(&segment_id,    &payloadData[PHSCA_SWUPUCI_SEGMENT_ID_OFFSET], sizeof(segment_id));
                
                
                /* Get page offset from component table and flash address. */
                phscaApi_Swup_Manifest_t * manifest = NULL;
                manifest = (phscaApi_Swup_Manifest_t *)(PHSCA_SWUPUCI_BUFFER_START_ADDRESS + PHSCA_SWUPUCI_BUFFER_MANIFEST_PAGEOFFSET * PHSCA_SWUPUCI_BUFFER_SIZE_PAGES);
                
                uint32_t pageOffset = manifest->common_data.components.components[component_idx].page_offset + segment_id;
                uint32_t flashAddress = PHSCA_SWUPUCI_BUFFER_START_ADDRESS + (PHSCA_SWUPUCI_BUFFER_COMPONENTS_PAGEOFFSET + pageOffset) * PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES; 
                
                /* Flash data. */
                retVal = phscaApi_FlashProgramWords(flashAddress, &componentData);
                
                /* Read back data to confirm correct flashing */
                if (PHSCA_API_SUCCESS == retVal)
                {
                    int compareResult = __builtin_memcmp((const void*) flashAddress, componentData.data, PHSCA_SWUPUCI_FLASH_PAGE_SIZE_BYTES);
                
                    if(compareResult != 0)
                    {
                        statusCode = PHSCA_UCI_MSG_STATUS_COMMAND_RETRY;
                    }
                }
            }
            break;
        }
                
        case (uint8_t)PHSCA_SWUPUCI_OID_VERIFY_COMPONENT:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_VERIFY_COMPONENT != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_DIRECT != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else
            {
                retVal = phscaApi_Swup_VerifyComponent(payloadData[PHSCA_SWUPUCI_COMPONENT_INDEX_OFFSET]);
            }
            break;
        }
                
        case (uint8_t)PHSCA_SWUPUCI_OID_VERIFY_ALL:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_VERIFY_ALL != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_DIRECT != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else
            {
                retVal = phscaApi_Swup_VerifyAll();
            }
            break;
        }
                
        case (uint8_t)PHSCA_SWUPUCI_OID_FINISH_UPDATE:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_FINISH_UPDATE != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else if (PHSCA_SWUPUCI_OPMODE_DIRECT != sphscaSwupUci_OperationMode)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            }
            else
            {
                retVal = phscaApi_Swup_FinishUpdate();
            }
            break;
        }
                
        case (uint8_t)PHSCA_SWUPUCI_OID_DEACTIVATE:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_DEACTIVATE != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else
            {
                retVal = phscaApi_Swup_Deactivate();
            }
            break;
        }
                
        case (uint8_t)PHSCA_SWUPUCI_OID_SELECT_KEY_STORE:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_SELECT_KEY_STORE != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else
            {
                uint32_t swupState = UINT32_MAX;
                
                retVal = phscaApi_Swup_GetState(&swupState);
                
                if (PHSCA_API_SUCCESS == retVal)
                {
                    if (PHSCA_SWUPUCI_STATE_ACTIVE != swupState)
                    {
                        statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
                    }
                    else
                    {
                        phscaApi_Swup_SealedKeyStore_t * keyStore = NULL;
                        (void)__builtin_memcpy(&keyStore, &payloadData[0u], sizeof(uint32_t));

                        retVal = phscaApi_Swup_SelectKeyStore((phscaApi_Swup_SealedKeyStore_t const* const)keyStore);
                    }
                }
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_GET_STATE:
        {
            if (PHSCA_SWUPUCI_CMD_PAYLOAD_LENGTH_GET_STATE != payloadLength)
            {
                statusCode = PHSCA_UCI_MSG_STATUS_INVALID_MESSAGE_SIZE;
            }
            else
            {
                uint32_t swupState   = UINT32_MAX;
                
                retVal = phscaApi_Swup_GetState(&swupState);

                if (PHSCA_API_SUCCESS == retVal)
                {
                    statusCode = PHSCA_UCI_MSG_STATUS_OK;
                    
                    (void)__builtin_memcpy(&gphscaUciCanFd_UciOpenNotificationBuffer[0], &swupState, sizeof(swupState));
                    gphscaUciCanFd_UciNotificationGid       = PHSCA_UCICANFD_GID_SWUP;
                    gphscaUciCanFd_UciNotificationOid       = opCodeId;
                    gphscaUciCanFd_UciNotificationLength    = (uint16_t)sizeof(swupState);
                    gphscaUciCanFd_UciNewNotification       = true;
                }
            }
            break;
        }
        
        case (uint8_t)PHSCA_SWUPUCI_OID_REBOOT_STATUS:
        {
            /* Should never be called from host side */
            statusCode = PHSCA_UCI_MSG_STATUS_REJECTED;
            break;
        }            
    }
    
    /* Interpret retVal */
    if (PHSCA_UCI_MSG_STATUS_UNKNOWN_OID == statusCode)
    {
        if (PHSCA_API_STATUS_INVALID == retVal)
        {
            statusCode = PHSCA_UCI_MSG_STATUS_UNKNOWN_OID;
        }
        else if (PHSCA_API_SUCCESS == retVal)
        {
            statusCode = PHSCA_UCI_MSG_STATUS_OK;
        }
        else if (PHSCA_API_ERR_PARAM == retVal)
        {
            statusCode = PHSCA_UCI_MSG_STATUS_INVALID_PARAM;
        }
        else
        {
            statusCode = PHSCA_UCI_MSG_STATUS_FAILED;
        }
    }
        
    return statusCode;
}

/**@}*/
