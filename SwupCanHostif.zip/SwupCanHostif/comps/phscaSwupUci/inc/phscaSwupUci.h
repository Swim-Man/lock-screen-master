/*
 * Copyright 2024 NXP
 *
 * NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
 * used strictly in accordance with the applicable license terms. By expressly accepting such terms
 * or by downloading, installing, activating and/or otherwise using the software, you are agreeing
 * that you have read, and that you agree to comply with and are bound by, such license terms. If
 * you do not agree to be bound by the applicable license terms, then you may not retain, install,
 * activate or otherwise use the software.
 */

/**
 * @file
 * @brief SWUP related components for the SwupCanHostif example.
 * @details UCI commands are processed for SWUP activities.
 * @addtogroup PHSCA_SWUPUCI
 * @{
 */
 

#ifndef PHSCASWUPUCI_H
#define PHSCASWUPUCI_H

/*************************************************************************/
/* Includes                                                              */
/*************************************************************************/

/* SDK */
#include <phscaApi_Status.h>
#include <phscaUci.h>

/* Custom */


/*************************************************************************/
/* Preprocessor Definitions                                              */
/*************************************************************************/



/*************************************************************************/
/* Private Type Definitions                                              */
/*************************************************************************/


/*************************************************************************/
/* Private Variables                                                     */
/*************************************************************************/

    
/*************************************************************************/
/* Private Functions                                                     */
/*************************************************************************/


/*************************************************************************/
/* Public Type Definitions                                               */
/*************************************************************************/

/** @brief Sends a boot notification. */
void phscaSwupUci_SendBootNotification(void);
    
/** @brief Command Opcode Identifiers (OIDs) for GID_SWUP. */
typedef enum __PACKED
{
    /** @brief SWUP boot up notification. */
    PHSCA_SWUPUCI_OID_REBOOT_STATUS         = (uint8_t)0x01,
    
    /** @brief Get SWUP version. */
    PHSCA_SWUPUCI_OID_GET_VERSION           = (uint8_t)0x02,
    
    /** @brief Transfer SWUP manifest. */
    PHSCA_SWUPUCI_OID_TRANSFER_MANIFEST     = (uint8_t)0x07,
    
    /** @brief Buffer a SWUP component. */
    PHSCA_SWUPUCI_OID_BUFFER_COMPONENT      = (uint8_t)0x08,
    
    /** @brief Start SWUP update. */
    PHSCA_SWUPUCI_OID_START_UPDATE          = (uint8_t)0x0A,
    
    /** @brief Start buffered SWUP update. */
    PHSCA_SWUPUCI_OID_START_BUFFERED_UPDATE = (uint8_t)0x0B,
       
    /** @brief Transfer a SWUP component. */
    PHSCA_SWUPUCI_OID_TRANSFER_COMPONENT    = (uint8_t)0x10,
    
    /** @brief Verify the last transferred SWUP component. */
    PHSCA_SWUPUCI_OID_VERIFY_COMPONENT      = (uint8_t)0x11,
    
    /** @brief Verify all transferred SWUP components. */
    PHSCA_SWUPUCI_OID_VERIFY_ALL            = (uint8_t)0x12,
    
    /** @brief Finish SWUP update. */
    PHSCA_SWUPUCI_OID_FINISH_UPDATE         = (uint8_t)0x1A,
    
    /** @brief Deactivates the SWUP. */
    PHSCA_SWUPUCI_OID_DEACTIVATE            = (uint8_t)0x1B,

    /** @brief Select a key store. */
    PHSCA_SWUPUCI_OID_SELECT_KEY_STORE      = (uint8_t)0x1C,
    
    /** @brief Get SWUP state. */
    PHSCA_SWUPUCI_OID_GET_STATE             = (uint8_t)0x1D,
    
} phscaSwupUci_UciOid_t;


/** @brief SWUP HIF operating mode (buffered for NDP, non-buffered for non-NDP. */
typedef enum __PACKED
{
    /** @brief Undefined operating mode for initial value. */
    PHSCA_SWUPUCI_OPMODE_UNDEFINED          = (uint8_t)0x00,
    
    /** @brief Buffered operating mode for NDP updates. */
    PHSCA_SWUPUCI_OPMODE_BUFFERED           = (uint8_t)0x01,
    
    /** @brief Direct transfer mode for non-NDP updates. */
    PHSCA_SWUPUCI_OPMODE_DIRECT             = (uint8_t)0x02,
        
} phscaSwupUci_OperatingMode_t;


/*************************************************************************/
/* Public Variables                                                      */
/*************************************************************************/


/*************************************************************************/
/* Public Functions                                                      */
/*************************************************************************/

/** 
 * @brief Processes UCI commands and triggers SWUP activities.
 * @param[in] opCodeId
 * @param[in] payloadLength
 * @param[in] payloadData Pointer to received payload buffer. This buffer must be aligned to 4 bytes.
 */
phscaUci_Msg_Status_t phscaSwupUci_UciInputHandler(uint8_t const opCodeId, 
                                                   uint32_t const payloadLength, 
                                                   const uint8_t *const payloadData);

/**@}*/
#endif /* PHSCASWUPUCI_H */
