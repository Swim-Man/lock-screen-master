/*
 * Copyright 2024 NXP
 *
 * NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
 * used strictly in accordance with the applicable license terms. By expressly accepting such terms
 * or by downloading, installing, activating and/or otherwise using the software, you are agreeing
 * that you have read, and that you agree to comply with and are bound by, such license terms. If
 * you do not agree to be bound by the applicable license terms, then you may not retain, install,
 * activate or otherwise use the software.
 */

/**
 * @file
 * @brief Main application entry
 */
/**
 * @addtogroup phscaMain
 * @{
 */


/*************************************************************************/
/* Includes                                                              */
/*************************************************************************/

/* Device */
#include <RTE_Components.h>
#include CMSIS_device_header

/* SDK */
#include <phscaApi_AppInfo.h>
#include <phscaApi_Clk.h>
#include <phscaApi_Image.h>
#include <phscaApi_Swup.h>

/* Driver */
#include <phscaGpTimers.h>
#include <phscaWatchdog.h>

/* Common components */
#include <phscaCasHal.h>

/* Application */
#include <phscaUciCanFd.h>


/*************************************************************************/
/* Preprocessor Definitions                                              */
/*************************************************************************/

/** @brief Enables a loop that waits for a debugger to attach. */
#define ENABLE_WAIT_FOR_DEBUGGER                (false)

/** @brief Blinking LED interval. */
#define LED_ON_OFF_TIME_MS                      (50u)

/** @brief Version ID of SwupCanHif A. */
#define SWUPCANHIF_A_ID                         ((uint32_t)0xF00A)

/** @brief Version ID of SwupCanHif B. */
#define SWUPCANHIF_B_ID                         ((uint32_t)0xF00B)

/** @brief Address of the app info header. */
#define PHSCAMAIN_FLASH_APPINFOPAGE_ADDRESS     ((uint32_t)0x00400000u)

/** @brief Address of the app image header. */
#ifdef HIF_A
#define PHSCAMAIN_FLASH_APPIMAGEHEADER_ADDRESS  ((uint32_t)0x004B0000u)
#endif

#ifdef HIF_B
#define PHSCAMAIN_FLASH_APPIMAGEHEADER_ADDRESS  ((uint32_t)0x004B8000u)
#endif


/*************************************************************************/
/* Private Function Prototypes                                           */
/*************************************************************************/


/*************************************************************************/
/* Private Type Definitions                                              */
/*************************************************************************/


/*************************************************************************/
/* Private Variables                                                     */
/*************************************************************************/

static uint32_t primary_hostif_boot_entry = 0u;


/*************************************************************************/
/* Private Functions                                                     */
/*************************************************************************/

static void phscaMain_ToggleLed_PrimaryHif(void)
{
    /* Yellow if primary HIF is HIF_A_Vx */
    if (primary_hostif_boot_entry == SWUPCANHIF_A_ID)
    {
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_0);
    }

    /* Red if primary HIF is HIF_B_Vx */
    else if (primary_hostif_boot_entry == SWUPCANHIF_B_ID)
    {
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_1);
    }
    
    /* Both if neither is true (indicates error) */
    else
    {
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_0);
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_1);
    }
}

#ifdef HIF_V1
static void phscaMain_ToggleLed_SecondaryHif(void)
{
    __NOP();
}
#else 
#ifdef HIF_V2
static void phscaMain_ToggleLed_SecondaryHif(void)
{
    /* Red if secondary HIF is HIF_B_Vx (primary HIF is HIF_A_Vx) */
    if (primary_hostif_boot_entry == SWUPCANHIF_A_ID)
    {
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_1);
    }

    /* Yellow if secondary HIF is HIF_A_Vx (primary HIF is HIF_B_Vx) */
    else if (primary_hostif_boot_entry == SWUPCANHIF_B_ID)
    {
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_0);
    }
    
    /* Both if neither is true (indicates error) */
    else
    {
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_0);
        phscaCasHal_LedToggle(PHSCA_CAS_HAL_LED_1);
    }
}
#else
#error HIF_V1 or HIF_V2 must be defined
#endif 
#endif

static void phscaMain_InitializeBlinkyLed(void)
{
    phscaApi_Status_t retVal = PHSCA_API_INVALID_STATE;
 
    /* Get primary hostif boot entry ID */
    phscaApi_AppInfo_t * appInfoPage = (phscaApi_AppInfo_t *)PHSCAMAIN_FLASH_APPINFOPAGE_ADDRESS;
    primary_hostif_boot_entry = appInfoPage->bundle.hostif_boot_entries.boot_entries[0];
    
    /* GPT (General Purpose Timers) initialization */
	phscaGpTimers_Init();
    
    
    /* Configure LED for primary HIF */
    retVal = phscaGpTimers_SetCb(PHSCAGPTIMERS_TIMER0, &phscaMain_ToggleLed_PrimaryHif);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }

    retVal = phscaGpTimers_SetMode(PHSCAGPTIMERS_TIMER0, PHSCAGPTIMERS_MODE_FREE_RUNNING);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }

    retVal = phscaGpTimers_IntEnable(PHSCAGPTIMERS_TIMER0);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }

    retVal = phscaGpTimers_Start(PHSCAGPTIMERS_TIMER0, LED_ON_OFF_TIME_MS, PHSCACASFLEXCAN_CLOCK_RATE_80MHZ);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }
    
    
    /* Configure LED for secondary HIF */
    retVal = phscaGpTimers_SetCb(PHSCAGPTIMERS_TIMER1, &phscaMain_ToggleLed_SecondaryHif);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }

    retVal = phscaGpTimers_SetMode(PHSCAGPTIMERS_TIMER1, PHSCAGPTIMERS_MODE_FREE_RUNNING);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }

    retVal = phscaGpTimers_IntEnable(PHSCAGPTIMERS_TIMER1);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }

    retVal = phscaGpTimers_Start(PHSCAGPTIMERS_TIMER1, LED_ON_OFF_TIME_MS * 4u, PHSCACASFLEXCAN_CLOCK_RATE_80MHZ);
    if(PHSCA_API_SUCCESS != retVal)
    {
        phscaCasHal_LedOn(PHSCA_CAS_HAL_LED_1);
        while(1);
    }
}

static void phscaMain_SendBootNotification(void)
{
    static phscaApi_ImageHeader_t * appImageHeader = NULL;
    appImageHeader = (phscaApi_ImageHeader_t *)PHSCAMAIN_FLASH_APPIMAGEHEADER_ADDRESS;
    
    phscaApi_Version_t appVersion;
    
    appVersion.major    = appImageHeader->specific.app.version.major;
    appVersion.minor    = appImageHeader->specific.app.version.minor;
    appVersion.patch    = appImageHeader->specific.app.version.patch;
    appVersion.id       = appImageHeader->specific.app.version.id;
    
    (void)__builtin_memcpy(&gphscaUciCanFd_UciOpenNotificationBuffer[0], &appVersion, sizeof(phscaApi_Version_t));
    gphscaUciCanFd_UciNotificationGid       = PHSCA_UCICANFD_GID_GENERIC;
    gphscaUciCanFd_UciNotificationOid       = PHSCA_UCICANFD_OID_GENERIC_BOOTUP;
    gphscaUciCanFd_UciNotificationLength    = (uint16_t)sizeof(phscaApi_Version_t);
    gphscaUciCanFd_UciNewNotification       = true;
}


/*************************************************************************/
/* Public Variables                                                      */
/*************************************************************************/


/*************************************************************************/
/* Public Functions                                                      */
/*************************************************************************/

/**
 * @brief The main entry point of SWUP CAN hostif
 * @return None
 */
__NO_RETURN int main(void)
{       
    /* Disable watchdog for easier debugging */
    phscaWatchdog_SetCounter(0u);

    /* Only proceed if the SW0 is not pressed */
    phscaCasHal_CheckSafetySwitch();
    
    /* Wait for debugger attachment */
    #if ENABLE_WAIT_FOR_DEBUGGER
    while (true)
    {
        if (0u != (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk))
        {
            __BKPT(0);
            break;
        }
        __NOP();
    }
    #endif

    /* Initialize hardware components */
    phscaCasHal_LedInit();
    phscaCasHal_SwitchInit();
        
    /* Activate CAN Clock */
    phscaUciCanFd_ActivateCanHw();
 
    /* Initialize blinky LED */
    phscaMain_InitializeBlinkyLed();
    
    /* Initialize UCI over CAN(-FD) */
    phscaUciCanFd_Init();
            
    /* Send boot notification with version */
    phscaMain_SendBootNotification();
    
    /* Main loop */
    while(1)
    {
        /* Handle UCI inputs over CAN-FD */
        phscaUciCanFd_Handler();
    }
}

/**@}*/
