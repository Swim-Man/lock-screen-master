#!/usr/bin/env python3
#
# Image signing tool for HIF image
#
# (c) NXP B.V. 2022-2023. All rights reserved.
#
# Disclaimer
# 1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
#     warranties of any kind. NXP makes no warranties to Licensee and shall not
#     indemnify Licensee or hold it harmless for any reason related to the NXP
#     Software/Source Code or otherwise be liable to the NXP customer. The NXP
#     customer acknowledges and agrees that the NXP Software/Source Code is
#     provided AS-IS and accepts all risks of utilizing the NXP Software under
#     the conditions set forth according to this disclaimer.
#
# 2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
#     BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
#     FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
#     RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
#     SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
#     INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
#     RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
#     CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
#     RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
#     THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
#     INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
#     (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
#     AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
#     SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
#     SUCH DAMAGES.
#
# 3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
#     time, also without informing customer.
#
# 4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
#     companies from and against any claims, suits, losses, damages,
#     liabilities, costs and expenses (including reasonable attorney's fees)
#     resulting from Licensee's and/or Licensee customer's/licensee's use of the
#     NXP Software/Source Code.

import argparse
import binascii
import crcmod
import textwrap
import logging
import intelhex as IHX
import struct


from Crypto.Hash import SHA256

logger = logging.getLogger("image-signer")

#----------------------------------------------------------------------------------------------------------------------
# CRC (and other checksum) calculation helpers
#

# CRC-32 (ROM parametrization)
romCrc32 = crcmod.mkCrcFun(poly=0x104C11DB7,initCrc=0xffffffff,rev=False,xorOut=False)

# CRC-16 (ROM parametrization)
romCrc16 = crcmod.mkCrcFun(poly=0x11021, initCrc=0xffff, rev=False, xorOut=False)

class ImageSigner:
	def __init__(self, input, fill_value = 0xDE, pad_to_word_size=0):
		"""
		Constructs an instance of image signing tool.
		"""

		# Setup the fill value
		fill_value = int(fill_value)
		if fill_value < 0 or fill_value > 255:
			raise ValueError("fill value must fit into a single (unsigned) byte (range 0..255)")

		# Load the source image
		self._input_image = IHX.IntelHex()
		self._input_image.padding = fill_value

		if not (':' in str(input)):
			raise ValueError("expecting an ihex: or bin: prefix for the input image specification")

		(fmt, file_name) = str(input).split(":", maxsplit=1)
		if fmt == "ihex":
			# We expect an Intel-Hex image
			logger.info("loading intel-hex image from '%s'", file_name)
			self._input_image.loadhex(file_name)

		elif fmt == "bin":
			# We expect a raw binary image
			(base_addr, file_name) = file_name.split(":", maxsplit=1)
			logger.info("loading raw binary image from '%s' with base address 0x%08X", file_name, base_addr)
			self._input_image.loadbin(file_name, int(base_addr, 0))

		else:
			# Unrecognized image format
			raise ValueError("Unrecognized image format prefix (recognized prefixes are 'ihex:' and 'bin:'")

		# Auto-pad the image (if needed)
		if pad_to_word_size > 1:
			# We perform automatic padding of the input image to flash word size
			logger.info("padding the input image to (flash) word size of %u bytes" % pad_to_word_size)

			# Determine the start addresses of words in the image
			word_start_addresses = set((addr // pad_to_word_size) * pad_to_word_size for addr in self._input_image.addresses())

			# Populate the full words
			for start in word_start_addresses:
				# Read/write the bytes in the word:
				# - the IntelHex package reads the provided fill value for any unoccupied ("hole") bytes
				# - writing the byte value back fills the holes (in each word)
				#
				for offset in range(0, pad_to_word_size):
					self._input_image[start + offset] = self._input_image[start + offset]

		else:
			logger.debug("automatic padding of input image to word-size is disabled")

		# Prepare the output image (as clone of the input)
		self._output_image = IHX.IntelHex(self._input_image)
		self._output_image.padding = fill_value

	def sign_image_at(self, image_addr = None, image_type = None):
		"""
		Processes the input image.
		"""

		# Extract the image header
		#
		# Expected header structure:
		#
		# +----------------------------------+
		# | uint8_t hash[32]                 |
		# +----------------------------------+
		# | uint8_t reserved[32]             |
		# +----------------------------------+
		# | uint32_t crc                     |
		# +----------------------------------+
		# | uint32_t size                    |
		# +----------------------------------+
		# | uint32_t type;                   |
		# | uint8_t payload[size - 4]        |
		# +----------------------------------+
		#

		# Determine the address of the source image
		image_addr = int(image_addr, 0) if not (image_addr is None) else self._input_image.minaddr()
		image_type = int(image_type, 0) if not (image_type is None) else None
		logger.info("processing image integrity header structure at 0x%08x", image_addr)

		# Read the input header
		input_header = self._input_image.gets(image_addr, 76)
		(hash, reserved, crc, payload_size, actual_type) = struct.unpack("<32s32sIII", input_header)

		# For debugging: Dump the incoming information
		logger.debug("input image: integrity.hash:         %s", binascii.hexlify(hash))
		logger.debug("input image: integrity.reserved:     %s", binascii.hexlify(reserved))
		logger.debug("input image: integrity.crc:          0x%08x", crc)
		logger.debug("input image: integrity.payload size: 0x%08x", payload_size)
		logger.debug("input image: specific.type:          0x%08x", actual_type)

		if not (image_type is None) and (image_type != actual_type):
			# Type check failed
			logger.error("mismatch between actual type of input image (0x%08x) and expected type (0x%08x)", actual_type, image_type)
			raise ValueError("unexpected type of input image")

		# Get the input payload byte array (including padding)
		payload_data = self._input_image.gets(image_addr + 72, payload_size)

		# Calculate the CRC-32 and SHA-256 hashes
		crc  = romCrc32(payload_data)
		hash = SHA256.new(data = payload_data).digest()

		logger.info(" updated sha256: %s", binascii.hexlify(hash))
		logger.info(" updated crc-32: 0x%08x", crc)

		# Update the output header
		output_header = struct.pack("<32s32sII", hash, reserved, crc, payload_size)
		self._output_image.puts(image_addr, output_header)

		# We explicitly instantiate the padded (sic!) payload data in the output image
		self._output_image.puts(image_addr + 72, payload_data)

	def write_ihex_output_to(self, output):
		"""
		Writes the Intel-Hex output image to the filesystem
		"""

		logger.info("writing intel-hex output to: '%s'", output)
		self._output_image.write_hex_file(f = output)

	@staticmethod
	def main():
		"""
		Command line frontend for the HIf image signer
		"""

		# Command line parsing
		parser = argparse.ArgumentParser(
		formatter_class = argparse.RawDescriptionHelpFormatter,
		description     = textwrap.dedent('''\
			NCJ29D6 B0 HIF - Image Signing Tool
			-------------------------------------------------------------------

			The image singing tool updates the image integrity check data (SHA2-256 hash and CRC)
			at the start of HIF component.
		'''))

		parser.add_argument("--verbose",    "-v", required=False, action="store_true", help="Enable verbose log output.")
		parser.add_argument("--input",      "-i", type=str, required=True, help="Input image file to be processed (prefix with 'ihex:' to load an Intel-Hex image or with 'bin:<addr>:' to load a raw binary")
		parser.add_argument("--output",     "-o", type=str, required=True, help="Output image file to written (can be the same as the input image)")
		parser.add_argument("--image-addr", "-a", type=str, required=False, default=None,   help="Address of the integrity header structure (default: lowest address in the input image)")
		parser.add_argument("--image-type", "-t", type=str, required=False, default=None,   help="Explicitly check for a particular image type (default: ignore the image type)")
		parser.add_argument("--fill-value", "-p", type=str, required=False, default="0xDE", help="Fill value for holes in the input image (default: 0xDE)")
		parser.add_argument("--pad-to-word-size", type=str, required=False, default="0x10", help="Pad input image to flash word size (default: pad to 16 byte word)")
		args = parser.parse_args()

		# Set log verbosity
		if args.verbose:
			logging.basicConfig(level=logging.DEBUG)
		else:
			logging.basicConfig(level=logging.INFO)

		try:
			# Now let the image signer do its job
			signer = ImageSigner(
				input             = args.input,
				fill_value        = int(args.fill_value, 0),
				pad_to_word_size  = int(args.pad_to_word_size, 0)
			)

			# Process the input image
			signer.sign_image_at(
				image_addr = args.image_addr,
				image_type = args.image_type
			)

			signer.write_ihex_output_to(
				output = args.output
			)

		except:
			# Log an error
			logger.error("image processing failed due to an unexpected error. see exception stack trace below for details:")

			# And let the exception propagate to the outside world
			raise
