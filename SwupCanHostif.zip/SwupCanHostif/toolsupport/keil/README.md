## Scope of this README.md
Please refer to the user guide of the SwupCanHostif example for more information.
In this README, only some brief information about the build mechanism is given.

## Script organization
Scripts are structured as follows:
- `postprocess.bat` updates the image integrity check data (SHA2-256 hash and CRC) at the start of HIF component.
- `gen_pkgs.bat` located in "...\onhost\src\apps\generic\swup_host_can_uci\swup_package_generator\" creates SWUP packages from SwupActivatorApp and SwupCanHostif hex files.

## Build machenism
After code complilation process, the output file is "./Build/Debug/SwupCanHostif_X_Vx.hex" (with X = {A, B}, x = {1, 2}, depending on the selected build target). 
The integrity information (SHA2-256 hash and CRC) of the output hex files is missing. To get the output hex files with the complete integrity information, `postprocess.bat` is executed for each SwupCanHostif hex file.
After all SwupCanHostif_X_Vx hex files have been generated and the integrity information is added, the `gen_pkgs.bat` script can be called to generate the SWUP packages.

In the "Options for Target 'Any Target'" > "User" > "After Build/Rebuild", the `postprocess.bat` script are set to be executed right after the code complilation process. 
The `gen_pkgs.bat` script needs to run only once after all hex files have been generated and signed.
- Run #1: "$Ppostprocess.bat" "$L@L"                                                                        Activate for all build targets
- Run #2: "$P..\..\..\..\onhost\src\apps\generic\swup_host_can_uci\swup_package_generator\gen_pkgs.bat"     Manually activate for selected build target (Recommendation: Only run once for last build target)

## Required python modules
- 'lxml'
- 'crcmod'
- 'intelhex'
- 'pycryptodome'
