# NCJ29D6 SwupCanHostif example
The SwupCanHostif is an onic SWUP host interface. Its main purpose is to perform SWUP updates using a CAN-FD interface.
Please refer to the user guide of the SwupCanHostif example for more information.