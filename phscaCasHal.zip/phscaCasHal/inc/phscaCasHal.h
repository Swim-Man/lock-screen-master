/*
   (c) NXP B.V. 2022-2023. All rights reserved.

   Disclaimer
   1. The NXP Software/Source Code is provided to Licensee "AS IS" without any
      warranties of any kind. NXP makes no warranties to Licensee and shall not
      indemnify Licensee or hold it harmless for any reason related to the NXP
      Software/Source Code or otherwise be liable to the NXP customer. The NXP
      customer acknowledges and agrees that the NXP Software/Source Code is
      provided AS-IS and accepts all risks of utilizing the NXP Software under
      the conditions set forth according to this disclaimer.

   2. NXP EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING,
      BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
      FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL PROPERTY
      RIGHTS. NXP SHALL HAVE NO LIABILITY TO THE NXP CUSTOMER, OR ITS
      SUBSIDIARIES, AFFILIATES, OR ANY OTHER THIRD PARTY FOR ANY DAMAGES,
      INCLUDING WITHOUT LIMITATION, DAMAGES RESULTING OR ALLEGED TO HAVE
      RESULTED FROM ANY DEFECT, ERROR OR OMISSION IN THE NXP SOFTWARE/SOURCE
      CODE, THIRD PARTY APPLICATION SOFTWARE AND/OR DOCUMENTATION, OR AS A
      RESULT OF ANY INFRINGEMENT OF ANY INTELLECTUAL PROPERTY RIGHT OF ANY
      THIRD PARTY. IN NO EVENT SHALL NXP BE LIABLE FOR ANY INCIDENTAL,
      INDIRECT, SPECIAL, EXEMPLARY, PUNITIVE, OR CONSEQUENTIAL DAMAGES
      (INCLUDING LOST PROFITS) SUFFERED BY NXP CUSTOMER OR ITS SUBSIDIARIES,
      AFFILIATES, OR ANY OTHER THIRD PARTY ARISING OUT OF OR RELATED TO THE NXP
      SOFTWARE/SOURCE CODE EVEN IF NXP HAS BEEN ADVISED OF THE POSSIBILITY OF
      SUCH DAMAGES.

   3. NXP reserves the right to make changes to the NXP Software/Sourcecode any
      time, also without informing customer.

   4. Licensee agrees to indemnify and hold harmless NXP and its affiliated
      companies from and against any claims, suits, losses, damages,
      liabilities, costs and expenses (including reasonable attorney's fees)
      resulting from Licensee's and/or Licensee customer's/licensee's use of the
      NXP Software/Source Code.
*/

/**
 * \file
 * \brief Functions to control the on board components of the CAS demo boards
 */

#ifndef PHSCA_CAS_HAL_H
#define PHSCA_CAS_HAL_H 1


/*--- Includes ---*/
/* Device includes */
#include <RTE_Components.h>
#include CMSIS_device_header
#include <stdbool.h>
#include <stdint.h>
#include <phscaApi_Status.h>


/*--- Type definitions ---*/
/**! @brief
 *  Select switch 0 or switch 1
 */
typedef enum {
    /** @brief Switch number 0 */
    PHSCA_CAS_HAL_SW_0  = 0,

    /** @brief Switch number 1 */
    PHSCA_CAS_HAL_SW_1  = 1
} phscaCasHal_Switches_t;

/**! @brief
 *  Select LED 0 or LED 1
 */
typedef enum {
    /** @brief LED number 0 */
    PHSCA_CAS_HAL_LED_0  = 0,

    /** @brief LED number 1 */
    PHSCA_CAS_HAL_LED_1  = 1
} phscaCasHal_Led_t;


/*--- Public functions ---*/
/*!
 * @brief Initializes the GPIOs to control the LEDs on the
 *        demo boards. The LEDs are turend OFF after initialization.
 */
void phscaCasHal_LedInit(void);

/*!
 * @brief Turns ON the specified LED
 * @param[in] led: Specifies which LED shall be controlled
 */
void phscaCasHal_LedOn(const phscaCasHal_Led_t led);

/*!
 * @brief Turns OFF the specified LED
 * @param[in] led: Specifies which LED shall be controlled
 */
void phscaCasHal_LedOff(const phscaCasHal_Led_t led);

/*!
 * @brief Toggles the specified LED
 * @param[in] led: Specifies which LED shall be controlled
 */
void phscaCasHal_LedToggle(const phscaCasHal_Led_t led);

/*!
 * @brief Configures the GPIOs to acept input signals from the
 *        switches mounted on the demo board (SW0 and SW1).
 */
void phscaCasHal_SwitchInit(void);

/*!
 * @brief Reads out the status of a switch
 * @param[in] Selects the switch which shall be read
 * @return If true, the switch is pressed, else the return
 *         value is false
 */
bool phscaCasHal_SwitchGet(const phscaCasHal_Switches_t sw);

/*!
 * @brief Configures SW0 as input and only proceeds if it is not pressed, otherwise the software is trapped into a while(1) loop.
 *        It recommended to call this function in beginning of main() as a mechanism to avoid reset loops caused by the application.
 *        This function disabled the internal watchdog timer.
 */
void phscaCasHal_CheckSafetySwitch(void);

/*!
 * @brief Initializes P11 as a trigger out and sets it to low
 */
void phscaCasHal_TriggerInit(void);

/*!
 * @brief Sets the trigger to high
 */
void phscaCasHal_TriggerHigh(void);

/*!
 * @brief Sets the trigger to low
 */
void phscaCasHal_TriggerLow(void);

/*!
 * @brief Toggles the trigger
 */
void phscaCasHal_TriggerToggle(void);

/*!
 * @brief Configures the P25 pin as a trigger out to SYNC devices
 * Attention: This will not workt together with phscaCasHal_SwitchInit()
 */
void phscaCasHal_SyncInit(void);

/*!
 * @brief Sets the SYNC pin to high
 */
void phscaCasHal_SyncHigh(void);

/*!
 * @brief Sets the SYNC pin to low
 */
void phscaCasHal_SyncLow(void);

/*!
 * @brief Performs a software reset through SCB->AIRCR ARM M33 register.
 */
__NO_RETURN void phscaCasHal_SwReset(void);

/*!
 * @brief Setup interrupt priorities
 */
void phscaCasHal_SetIntPrios(void);


#endif
