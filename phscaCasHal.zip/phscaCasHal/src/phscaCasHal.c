/*
 Copyright 2022-2024 NXP

 NXP Confidential and Proprietary.

 This software is owned or controlled by NXP and may only be used strictly in accordance
 with the applicable license terms. By expressly accepting such terms or by downloading,
 installing, activating and/or otherwise using the software, you are agreeing that you
 have read, and that you agree to comply with and are bound by, such license terms.
 If you do not agree to be bound by the applicable license terms, then you may not retain,
 install, activate or otherwise use the software.

 */

/**
 * \file
 * \brief Functions to control the on board components of the CAS demo boards
 */

/*--- Includes ---*/
/* Device includes */
#include <RTE_Components.h>
#include CMSIS_device_header

/* SDK includes */
#include <phscaApi_Clk.h>

/* Driver includes */
#include <phscaGpio.h>
#include <phscaWatchdog.h>

/* Common components */
#include <phscaCasHal.h>


/*--- Defines ---*/
// << [UCDXP29D6W-17] SWUPCANHostif support. start - Jeffrey Huang
#define GPIO_LED0       PHSCA_GPIO_PORT13
#define GPIO_LED1       PHSCA_GPIO_PORT13
// #define GPIO_SW0        PHSCA_GPIO_PORT12
// #define GPIO_SW1        PHSCA_GPIO_PORT25
// #define GPIO_TRIGGER    PHSCA_GPIO_PORT11
// #define GPIO_SYNC       PHSCA_GPIO_PORT25
// >> [UCDXP29D6W-17] SWUPCANHostif support. end

/*--- Functions ---*/
void phscaCasHal_LedInit(void)
{
    /* Set LED GPIOs as outputs */
    // phscaGpio_SetDirection(GPIO_LED0, PHSCA_GPIO_DIR_OUTPUT);
    phscaGpio_SetDirection(GPIO_LED1, PHSCA_GPIO_DIR_OUTPUT);

    /* Turn OFF LEDs */
    // phscaCasHal_LedOff(PHSCA_CAS_HAL_LED_0);
    phscaCasHal_LedOff(PHSCA_CAS_HAL_LED_1);
}

void phscaCasHal_LedOn(const phscaCasHal_Led_t led)
{
    phscaGpio_TypesPortIds_t    pin;

    switch(led)
    {
        case PHSCA_CAS_HAL_LED_0: pin =  GPIO_LED0;
            break;
        case PHSCA_CAS_HAL_LED_1: pin =  GPIO_LED1;
            break;
    }

    phscaGpio_SetPinStateLow(pin);
}

void phscaCasHal_LedOff(const phscaCasHal_Led_t led)
{
    phscaGpio_TypesPortIds_t pin;

    switch(led)
    {
        case PHSCA_CAS_HAL_LED_0:
            pin =  GPIO_LED0;
            break;
        case PHSCA_CAS_HAL_LED_1:
            pin =  GPIO_LED1;
            break;
    }

    phscaGpio_SetPinStateHigh(pin);
}

void phscaCasHal_LedToggle(const phscaCasHal_Led_t led)
{
    phscaGpio_TypesPortIds_t pin;

    switch(led)
    {
        case PHSCA_CAS_HAL_LED_0:
            pin = GPIO_LED0;
            break;
        case PHSCA_CAS_HAL_LED_1:
            pin = GPIO_LED1;
            break;
    }

    phscaGpio_TogglePin(pin);
}

void phscaCasHal_SwitchInit(void)
{
    // << [UCDXP29D6W-17] SWUPCANHostif support. start - Jeffrey Huang
    /* Set switch GPIOs as inputs */
    // phscaGpio_SetDirection(GPIO_SW0, PHSCA_GPIO_DIR_INPUT);
    // phscaGpio_SetDirection(GPIO_SW1, PHSCA_GPIO_DIR_INPUT);

    /* Activate pull up resistors */
    // phscaGpio_SetPullUpDown(GPIO_SW0, PHSCA_GPIO_PUD_PULL_UP);
    // phscaGpio_SetPullUpDown(GPIO_SW1, PHSCA_GPIO_PUD_PULL_UP);
    // >> [UCDXP29D6W-17] SWUPCANHostif support. end
}

bool phscaCasHal_SwitchGet(const phscaCasHal_Switches_t sw)
{
    // << [UCDXP29D6W-17] SWUPCANHostif support. start - Jeffrey Huang
    // phscaGpio_TypesPinStatus_t  state;
    // phscaGpio_TypesPortIds_t    pin;

    // switch(sw)
    // {
    //     case PHSCA_CAS_HAL_SW_0: pin =  GPIO_SW0;
    //         break;
    //     case PHSCA_CAS_HAL_SW_1: pin =  GPIO_SW1;
    //         break;
    // }

    // state = phscaGpio_GetPinState(pin);
    // return (PHSCA_GPIO_LOW == state)? true : false;
    return false;
    // >> [UCDXP29D6W-17] SWUPCANHostif support. end

}

void phscaCasHal_CheckSafetySwitch(void)
{
    // << [UCDXP29D6W-17] SWUPCANHostif support. start - Jeffrey Huang
    /* Set SW0 pin as GPIO */
    // phscaGpio_SetAltFunctionPin12(PHSCA_GPIO_ALTF1_P12_GPIO_SPI_INT0_N);

    // /* Set SW0 GPIO as input */
    // phscaGpio_SetDirection(GPIO_SW0, PHSCA_GPIO_DIR_INPUT);

    // /* Enable pull up resistor for SW0 */
    // phscaGpio_SetPullUpDown(GPIO_SW0, PHSCA_GPIO_PUD_PULL_UP);

    // /* Wait for SW0 to settle to high in case it is not pressed (the for loop and the 1x __NOP are equivalent to ~30 needed __NOP instructions) */
    // for(uint32_t volatile counter = 0u; counter < 20u; counter++)
    // {
    //     __NOP();
    // }

    // /* Get SW0 state */
    // bool state = phscaCasHal_SwitchGet(PHSCA_CAS_HAL_SW_0);

    // if(true == state)
    // {
    //    /*--- SW0 is pressed. Trap software here. ---*/

    //     /* Initialize the internal watchdog */
    //     phscaWatchdog_Init();
    //     /* Stop Watchdog timer. */
    //     phscaWatchdog_SetCounter(0u);
    //     /* Disable interrupts. */
    //     __disable_irq();
    //    /* Trap software and attach debugger. */
    //     while(1u);
    // }
    // >> [UCDXP29D6W-17] SWUPCANHostif support. end
}

void phscaCasHal_TriggerInit(void)
{
    // phscaGpio_SetDirection(GPIO_TRIGGER, PHSCA_GPIO_DIR_OUTPUT);
    // phscaCasHal_TriggerLow();
}

void phscaCasHal_TriggerHigh(void)
{
    // phscaGpio_SetPinStateHigh(GPIO_TRIGGER);
}

void phscaCasHal_TriggerLow(void)
{
    // phscaGpio_SetPinStateLow(GPIO_TRIGGER);
}

void phscaCasHal_TriggerToggle(void)
{
    // phscaGpio_TogglePin(GPIO_TRIGGER);
}

void phscaCasHal_SyncInit(void)
{
    /* Set GPIO as output */
    // phscaGpio_SetDirection(GPIO_SYNC, PHSCA_GPIO_DIR_OUTPUT);

    /* Set SYNC pin to low */
    // phscaCasHal_SyncLow();
}

void phscaCasHal_SyncHigh(void)
{
    // phscaGpio_SetPinStateHigh(GPIO_SYNC);
}

void phscaCasHal_SyncLow(void)
{
    // phscaGpio_SetPinStateLow(GPIO_SYNC);
}

__NO_RETURN void phscaCasHal_SwReset(void)
{
    /* Disable interrupts */
   //  __disable_irq();

   //  /* Perform system reset by writing VECTKEY cookie and setting SYSRESETREQ bit in SCB-AIRCR */
   //  SCB->AIRCR = (0x5FA << SCB_AIRCR_VECTKEY_Pos) |       // VECTKEY
   //               (SCB->AIRCR & SCB_AIRCR_PRIGROUP_Msk) |  // Preserve priority group bits
   //               SCB_AIRCR_SYSRESETREQ_Msk;               // Set SYSRESETREQ bit

   //  /* Ensure all outstanding memory accesses included buffered write are completed before reset */    
   //  __DSB();

   // /* Trap software and attach debugger. */
   //  while(1u);
}

void phscaCasHal_SetIntPrios(void)
{
    /* Configure priority grouping. */
    /* Sets 3 bits (Priority Grouping Number 0..7) of SCB->AIRCR.PRIGROUP.
    * NVIC->IPR register for each IRQ number is 8 bits wide.
    * x are preempt priority bits
    * y are subpriority bits
    * R5 implements __NVIC_PRIO_BITS of 4 bits (R5 specific), then we have total 16 prio levels. They can all be preempty prios, or all subprios, or a mix of both.
    * This depends on SCB->AIRCR.PRIGROUP using NVIC_SetPriorityGrouping function.
    * PRIGROUP: 0/1/2/3 -> xxxx.0000 (4 bits of __NVIC_PRIO_BITS are preempty prio, 0 bit of __NVIC_PRIO_BITS is subprio. This leads to 16 preempt pris 0..15, and no subprios)
    * PRIGROUP: 4 ->       xxx.y000  (3 bits of __NVIC_PRIO_BITS are preempty prio, 1 bit of __NVIC_PRIO_BITS is subprio. This leads to 8 preempt prios 0..7, and 2 subprios 0..1)
    * PRIGROUP: 5 ->       xx.yy000  (2 bits of __NVIC_PRIO_BITS are preempty prio, 2 bits of __NVIC_PRIO_BITS is subprio. This leads to 4 preempt prios 0..3, and 4 subprios 0..3)
    * PRIGROUP: 6 ->       x.yyy000  (1 bit of __NVIC_PRIO_BITS are preempty prio, 3 bits of __NVIC_PRIO_BITS is subprio. This leads to 2 preempt prios 0..1, and 8 subprios 0..7)
    * PRIGROUP: 7 ->       .yyyy000  (0 bit of __NVIC_PRIO_BITS are preempty prio, 4 bits of __NVIC_PRIO_BITS is subprio. This leads to no preempt prios, and 16 subprios 0..15)
    */
    /* Now we want to disable priority grouping, so we can choose either PRIGROUP 0/1/2/3 (they are identical in behaviour anyway). */
    NVIC_SetPriorityGrouping(0u);

    /* Confirm PRIGROUP value set above. */
    static uint32_t prioGrouping = 0u;
    prioGrouping = NVIC_GetPriorityGrouping();

    /* Now we configure NVIC->IPR for each IRQ number. */
    /* From now on we set preemptPrio to desired preempt Prio value. subPrio we leave at zero since it doesn't matter any since we disabled PRIGROUP above. */
    static uint32_t preemptPrio = 0u;
    static uint32_t subPrio = 0u;

    /* PLL IRQs (80, 81, 82). We want them to be the highest preempt prio (0) */
    preemptPrio = 0u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ80_GpPllLockRdy_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ81_RfPllOolockRdy_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ82_SysPllOolockRdy_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ80_GpPllLockRdy_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ81_RfPllOolockRdy_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ82_SysPllOolockRdy_IRQn);

    /* Reserved IRQs (64 and 77) */
    preemptPrio = 0u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ64_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ77_Reserved_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ64_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ77_Reserved_IRQn);

    /* BB IRQ (55). We want it to be second highest preempt prio (1). */
    preemptPrio = 1u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ55_Mailbox_IRQn, preemptPrio);
    /* Confirm BB IRQ prio (get its IPR register value). */
    preemptPrio = NVIC_GetPriority(IRQ55_Mailbox_IRQn);

    /* All other interrupts shall have a lower priority than BB IRQ. */

    /* Reserved IRQs (0 to 19) lowest priority */
    preemptPrio = 2u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ00_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ01_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ02_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ04_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ05_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ06_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ07_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ08_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ09_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ10_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ11_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ12_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ14_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ15_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ16_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ17_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ18_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ19_Reserved_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ00_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ01_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ02_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ04_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ05_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ06_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ07_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ08_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ09_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ10_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ11_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ12_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ14_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ15_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ16_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ17_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ18_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ19_Reserved_IRQn);

    /* Timers IRQs (20, 21, 22, 23) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ20_Timer0_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ21_Timer1_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ22_Timer2_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ23_Timer3_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ20_Timer0_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ21_Timer1_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ22_Timer2_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ23_Timer3_IRQn);

    /* SPI IRQ (24) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ24_LPSPI_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ24_LPSPI_IRQn);

    /* LinFlex IRQ (25) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ25_Linflex_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ25_Linflex_IRQn);

    /* I2C IRQs (26, 27) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ26_I2CMaster_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ27_I2CSlave_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ26_I2CMaster_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ27_I2CSlave_IRQn);

    /* GPIO IRQ (28) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ28_Port_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ28_Port_IRQn);

    /* CAN IRQs (29 -> 43) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ29_ErFdaInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ30_ErFwmInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ31_ErFovfInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ32_ErFufwInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ33_NceFaInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ34_NceHaInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ35_CeInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ36_Reserved_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ37_TxWrnInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ38_RxWrnInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ39_ErrFdInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ40_ErrInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ41_BusOffDoneInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ42_BusOffInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ43_MbOrInt_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ29_ErFdaInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ30_ErFwmInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ31_ErFovfInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ32_ErFufwInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ33_NceFaInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ34_NceHaInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ35_CeInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ36_Reserved_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ37_TxWrnInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ38_RxWrnInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ39_ErrFdInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ40_ErrInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ41_BusOffDoneInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ42_BusOffInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ43_MbOrInt_IRQn);

    /* DMA IRQs (44, 45, 46) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ44_DmacErr_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ45_DmacInt_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ46_DmacIntTc_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ44_DmacErr_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ45_DmacInt_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ46_DmacIntTc_IRQn);

    /* CTI IRQs (78 and 79) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ78_CTIIRQ_0_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ79_CTIIRQ_1_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ78_CTIIRQ_0_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ79_CTIIRQ_1_IRQn);

    /* GPADC IRQs (83, 84, 85, 86) */
    preemptPrio = 3u;
    preemptPrio = NVIC_EncodePriority(prioGrouping, preemptPrio, subPrio);
    NVIC_SetPriority(IRQ83_GpadcOvertemp_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ84_GpadcUndertemp_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ85_GpadcWarntemp_IRQn, preemptPrio);
    NVIC_SetPriority(IRQ86_GpadcOutValid_IRQn, preemptPrio);
    preemptPrio = NVIC_GetPriority(IRQ83_GpadcOvertemp_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ84_GpadcUndertemp_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ85_GpadcWarntemp_IRQn);
    preemptPrio = NVIC_GetPriority(IRQ86_GpadcOutValid_IRQn);
}
